# Overtone — NeoForge 1.21.1 port

Port of **Overtone 0.2.1** (by chifir4ik and PabJlo, MIT) from Minecraft 1.20.1 Forge to **1.21.1 NeoForge**.
Client-side music player: Yandex Music, SoundCloud, local files, karaoke lyrics, HUD.

The source was reconstructed by decompiling the official 1.20.1 Forge jar (no original source was available),
the Minecraft-facing layer (`dev.musicplayer.compat`, the entry point and the screens) was moved to the 1.21.1 API.

## What was changed for Android launchers (Zalith / Pojav / FCL)
* **Audio**: Java Sound has no output device on Android. If it fails, audio is now played through Minecraft's own
  OpenAL (`audio/OpenAlLine.java`). On desktop nothing changes: Java Sound is still tried first.
* **Cover art**: decoded with Minecraft's `NativeImage` (stb_image) instead of `ImageIO`/`Graphics2D`.
* **Links**: when no browser can be launched the link is copied to the clipboard and a toast is shown.
* The "system audio" visualizer source needs PulseAudio and is unavailable on Android (it falls back by itself).

## Building (GitHub Actions, no PC needed)
1. Create an empty repository on github.com and upload this folder. Add `build.yml` (delivered separately) at `.github/workflows/build.yml`.
2. Open the **Actions** tab, the `Build` workflow runs on every push (or press *Run workflow*).
3. When it is green, the jar is attached to the newest entry under **Releases** (`overtone-0.2.1-mc1.21.1-neoforge.jar`).
4. Put the jar into the `mods` folder of your NeoForge 1.21.1 instance in the launcher.

Local build: JDK 21 and Gradle 8.10+, then `gradle build -Pneo_version=21.1.x`.
