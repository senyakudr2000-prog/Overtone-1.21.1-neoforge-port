package dev.musicplayer.controller;

import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.audio.GameVolume;
import dev.musicplayer.config.PlayerConfig;
import dev.musicplayer.config.SessionState;
import dev.musicplayer.config.TokenStore;
import dev.musicplayer.local.LocalLibrary;
import dev.musicplayer.lyrics.LyricsService;
import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.MusicEntity;
import dev.musicplayer.model.Page;
import dev.musicplayer.model.Platform;
import dev.musicplayer.model.Track;
import dev.musicplayer.provider.LocalMusicProvider;
import dev.musicplayer.provider.MusicProvider;
import dev.musicplayer.provider.SoundCloudProvider;
import dev.musicplayer.provider.SpotifyProvider;
import dev.musicplayer.provider.YandexMusicProvider;
import dev.musicplayer.util.T;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutionException;

public final class PlayerController {
   public static final PlayerController I = new PlayerController();
   public final YandexMusicProvider yandex = new YandexMusicProvider();
   public final LocalMusicProvider local = new LocalMusicProvider();
   public final SoundCloudProvider soundcloud = new SoundCloudProvider();
   public final SpotifyProvider spotify = new SpotifyProvider();
   private final Map<Platform, MusicProvider> providers = new EnumMap<>(Platform.class);
   public volatile Platform platform;
   public volatile PlayerController.Tab tab = PlayerController.Tab.TRACKS;
   public volatile List<MusicEntity> artists = List.of();
   public volatile List<MusicEntity> albums = List.of();
   public volatile List<MusicEntity> playlists = List.of(MusicEntity.MINE);
   private final List<Page> trail = new CopyOnWriteArrayList<>();
   public volatile List<Track> results = List.of();
   public volatile int resultsVersion = 0;
   public volatile String status = "";
   public volatile Track current;
   public volatile List<LyricLine> lyrics = List.of();
   public volatile boolean lyricsLoading;
   public volatile float volume = 0.8F;
   public volatile boolean idle = true;
   public volatile PlayerController.Repeat repeat = PlayerController.Repeat.OFF;
   public volatile boolean shuffle;
   public volatile boolean waveActive;
   public volatile boolean waveLoading;
   public volatile boolean waveView;
   private volatile String waveSession;
   private volatile String waveBatch;
   private final List<Track> waveQueue = new CopyOnWriteArrayList<>();
   private final ArrayDeque<Track> waveHistory = new ArrayDeque<>();
   private volatile boolean waveFetching;
   private volatile boolean waveStalled;
   public volatile String waveSeed = "user:onyourwave";
   public volatile List<MusicEntity> stations = List.of();
   public volatile boolean stationsLoading;
   private final ArrayDeque<String> waveSeen = new ArrayDeque<>();
   private static final int WAVE_SEEN_MAX = 80;
   private volatile List<Track> queue = List.of();
   private volatile int index = -1;
   private final List<Track> userQueue = new CopyOnWriteArrayList<>();
   private final ArrayDeque<Integer> history = new ArrayDeque<>();
   private final Random rnd = new Random();
   private final ArrayDeque<Integer> shufflePlan = new ArrayDeque<>();
   private int prefetchTick;
   private volatile boolean showingLibrary;
   private int libraryVersion = -1;
   private float lastApplied = -1.0F;

   private PlayerController() {
      this.providers.put(Platform.YANDEX, this.yandex);
      this.providers.put(Platform.LOCAL, this.local);
      this.providers.put(Platform.SOUNDCLOUD, this.soundcloud);
      this.providers.put(Platform.SPOTIFY, this.spotify);

      for (MusicProvider p : this.providers.values()) {
         p.onFinished(() -> this.onTrackEnd(p));
         p.onAudioError(m -> {
            this.status = T.get("status.audio_error", m);
            this.idle = true;
         });
      }

      this.restoreSession();
      this.applyVolume(true);
      Runtime.getRuntime().addShutdownHook(new Thread(() -> {
         this.syncSession();
         SessionState.saveNow();
      }, "musicplayer-save"));
   }

   private static List<Track> known(List<Track> tracks) {
      return tracks.stream().filter(PlayerController::isKnown).toList();
   }

   private static boolean isKnown(Track t) {
      return t.provider() == null || Platform.byIdOrNull(t.provider()) != null;
   }

   private void restoreSession() {
      SessionState st = SessionState.get();
      this.volume = st.volume;
      this.shuffle = st.shuffle;
      Platform lastPlatform = Platform.byIdOrNull(st.platform);
      this.platform = lastPlatform != null && this.providers.containsKey(lastPlatform) ? lastPlatform : null;

      try {
         this.repeat = PlayerController.Repeat.valueOf(st.repeat);
      } catch (Exception var6) {
         this.repeat = PlayerController.Repeat.OFF;
      }

      this.userQueue.addAll(known(st.queueTracks()));
      List<Track> saved = known(st.resultTracks());
      Track last = st.currentTrack();
      if (last != null && !isKnown(last)) {
         last = null;
      }

      this.results = saved;
      if (last != null) {
         this.current = last;
         this.idle = true;
         int i = indexOf(saved, last.id());
         if (i >= 0) {
            this.queue = saved;
            this.index = i;
         } else {
            this.queue = List.of(last);
            this.index = 0;
         }
      }
   }

   private static int indexOf(List<Track> list, String id) {
      for (int i = 0; i < list.size(); i++) {
         if (list.get(i).id() != null && list.get(i).id().equals(id)) {
            return i;
         }
      }

      return -1;
   }

   private void syncSession() {
      SessionState st = SessionState.get();
      st.volume = this.volume;
      st.shuffle = this.shuffle;
      st.repeat = this.repeat.name();
      st.platform = this.platform == null ? null : this.platform.id;
      st.setTrack(this.current);
      st.setResults(this.results);
      st.setQueue(new ArrayList<>(this.userQueue));
   }

   private void persist() {
      this.syncSession();
      SessionState.markDirty();
   }

   public void tickPersist() {
      this.applyVolume(false);
      if (this.showingLibrary && this.platform == Platform.LOCAL && this.local.libraryVersion() != this.libraryVersion) {
         this.libraryVersion = this.local.libraryVersion();
         this.local.likedTracks().thenAccept(this::setResults);
      }

      SessionState.flushIfDirty(2000L);
      if (++this.prefetchTick >= 100) {
         this.prefetchTick = 0;
         this.refreshPrefetch();
      }
   }

   public boolean has(Platform p) {
      return this.providers.containsKey(p);
   }

   public MusicProvider provider(Platform p) {
      return this.providers.get(p);
   }

   public MusicProvider active() {
      return this.platform == null ? null : this.providers.get(this.platform);
   }

   public MusicProvider provider(Track t) {
      MusicProvider p = t == null ? null : this.providers.get(Platform.byId(t.provider()));
      return (MusicProvider)(p != null ? p : this.yandex);
   }

   public MusicProvider engine() {
      Track t = this.current;
      MusicProvider p = t != null ? this.provider(t) : this.active();
      return (MusicProvider)(p != null ? p : this.yandex);
   }

   public boolean ready() {
      MusicProvider p = this.active();
      return p != null && p.isLoggedIn();
   }

   public synchronized void selectPlatform(Platform p) {
      if (p != null && this.providers.containsKey(p)) {
         boolean changed = this.platform != p;
         this.platform = p;
         if (changed) {
            this.waveView = false;
            this.trail.clear();
            this.tab = PlayerController.Tab.TRACKS;
            this.results = List.of();
            this.resultsVersion++;
         }

         this.persist();
         if (p == Platform.LOCAL) {
            this.local.refresh();
            if (this.results.isEmpty()) {
               this.loadLiked();
            }
         }
      }
   }

   public void leavePlatform() {
      this.platform = null;
      this.persist();
   }

   public boolean addLocalPaths(List<Path> paths) {
      if (this.local.addPaths(paths) == 0) {
         this.status = T.get("status.no_audio_files");
         return false;
      } else {
         this.selectPlatform(Platform.LOCAL);
         this.loadLiked();
         return true;
      }
   }

   public void submitToken(String text) {
      this.status = T.get("status.checking_token");
      this.yandex.submitToken(text).whenComplete((v, e) -> this.status = e == null ? "" : T.get("status.login_failed", msg(e)));
   }

   public void linkSoundCloud(String text) {
      this.status = T.get("status.checking_token");
      this.soundcloud.link(text).whenComplete((v, e) -> this.status = e == null ? "" : T.get("status.login_failed", msg(e)));
   }

   public void loginSpotify(String clientId) {
      this.status = T.get("status.sp_browser");
      this.spotify.login(clientId).whenComplete((v, e) -> this.status = e == null ? "" : T.get("status.login_failed", msg(e)));
   }

   public void openLocalFolder() {
      if (!this.local.openFolder()) {
         this.status = T.get("status.folder_failed", LocalLibrary.defaultFolder().toAbsolutePath().normalize());
      }
   }

   public void loginSaved(TokenStore.Account a) {
      if (a != null) {
         this.status = T.get("status.logging_in", a.displayName());
         this.yandex.submitToken(a.token()).whenComplete((v, e) -> this.status = e == null ? "" : T.get("status.login_failed", msg(e)));
      }
   }

   public synchronized void logout() {
      MusicProvider p = this.active();
      if (p != null && p.platform().needsLogin) {
         boolean playingHere = this.current != null && this.provider(this.current) == p;
         p.logout();
         this.trail.clear();
         this.results = List.of();
         this.resultsVersion++;
         this.userQueue.removeIf(t -> this.provider(t) == p);
         if (playingHere) {
            this.current = null;
            this.lyrics = List.of();
            this.lyricsLoading = false;
            this.queue = List.of();
            this.index = -1;
            this.history.clear();
            this.idle = true;
         }

         if (p == this.yandex) {
            this.stopWave();
         }

         this.status = "";
         this.persist();
      }
   }

   public void search(String q) {
      if (q != null && !q.isBlank()) {
         this.waveView = false;
         MusicProvider p = this.active();
         if (p != null) {
            this.showingLibrary = false;
            this.status = T.get("status.searching");
            this.trail.clear();
            if (p == this.yandex) {
               this.yandex
                  .searchAll(q.trim())
                  .whenComplete(
                     (all, e) -> {
                        if (e != null) {
                           this.status = T.get("status.search_error", msg(e));
                        } else {
                           this.artists = all.artists();
                           this.albums = all.albums();
                           this.playlists = all.playlists();
                           this.setResults(all.tracks());
                           this.tab = !all.tracks().isEmpty()
                              ? PlayerController.Tab.TRACKS
                              : (
                                 !all.artists().isEmpty()
                                    ? PlayerController.Tab.ARTISTS
                                    : (!all.albums().isEmpty() ? PlayerController.Tab.ALBUMS : PlayerController.Tab.TRACKS)
                              );
                           this.status = all.tracks().isEmpty() && all.artists().isEmpty() && all.albums().isEmpty() ? T.get("status.nothing_found") : "";
                        }
                     }
                  );
            } else if (p == this.spotify) {
               this.spotify.searchAll(q.trim()).whenComplete((all, e) -> {
                  if (e != null) {
                     this.status = T.get("status.search_error", msg(e));
                  } else {
                     this.artists = List.of();
                     this.albums = List.of();
                     List<MusicEntity> pls = new ArrayList<>();
                     pls.add(MusicEntity.MINE);
                     pls.addAll(all.playlists());
                     this.playlists = pls;
                     this.setResults(all.tracks());
                     this.tab = all.tracks().isEmpty() && !all.playlists().isEmpty() ? PlayerController.Tab.PLAYLISTS : PlayerController.Tab.TRACKS;
                     this.status = all.tracks().isEmpty() && all.playlists().isEmpty() ? T.get("status.nothing_found") : "";
                  }
               });
            } else {
               p.search(q.trim()).whenComplete((r, e) -> {
                  if (e != null) {
                     this.status = T.get("status.search_error", msg(e));
                  } else {
                     this.setResults((List<Track>)r);
                     this.status = r.isEmpty() ? T.get("status.nothing_found") : "";
                  }
               });
            }
         }
      }
   }

   public void loadLiked() {
      this.waveView = false;
      this.trail.clear();
      this.tab = PlayerController.Tab.TRACKS;
      MusicProvider p = this.active();
      if (p != null) {
         this.showingLibrary = p == this.local;
         this.libraryVersion = this.local.libraryVersion();
         this.status = T.get("status.loading");
         p.likedTracks().whenComplete((r, e) -> {
            if (e != null) {
               this.status = T.get("status.error", msg(e));
            } else {
               this.setResults((List<Track>)r);
               this.status = r.isEmpty() ? T.get("status.empty_list", p.likedLabel()) : "";
            }
         });
      }
   }

   public Page page() {
      return this.trail.isEmpty() ? null : this.trail.get(this.trail.size() - 1);
   }

   public void open(MusicEntity e) {
      if (e != null) {
         this.status = T.get("status.opening");
         (this.platform == Platform.SPOTIFY ? this.spotify.open(e) : this.yandex.open(e)).whenComplete((pg, ex) -> {
            if (ex != null) {
               this.status = T.get("status.error", msg(ex));
            } else {
               this.waveView = false;
               this.trail.add(pg);
               this.tab = PlayerController.Tab.TRACKS;
               this.status = pg.tracks().isEmpty() && pg.entities().isEmpty() ? T.get("status.nothing_found") : "";
            }
         });
      }
   }

   public void back() {
      if (!this.trail.isEmpty()) {
         this.trail.remove(this.trail.size() - 1);
      }

      this.tab = PlayerController.Tab.TRACKS;
   }

   public void playAll(Page pg) {
      if (pg != null && !pg.tracks().isEmpty()) {
         this.playFrom(pg.tracks(), 0);
      }
   }

   public void openArtistOf(Track t) {
      if (t != null && t.artist() != null && !t.artist().isBlank() && isYandex(t)) {
         String name = t.artist().split(",")[0].trim();
         this.status = T.get("status.opening");
         this.yandex
            .searchAll(name)
            .whenComplete(
               (all, ex) -> {
                  if (ex != null) {
                     this.status = T.get("status.error", msg(ex));
                  } else {
                     MusicEntity best = all.artists()
                        .stream()
                        .filter(a -> a.title().equalsIgnoreCase(name))
                        .findFirst()
                        .orElse(all.artists().isEmpty() ? null : all.artists().get(0));
                     if (best == null) {
                        this.status = T.get("status.nothing_found");
                     } else {
                        this.open(best);
                     }
                  }
               }
            );
      }
   }

   public void openAlbumOf(Track t) {
      if (t != null && t.album() != null && !t.album().isBlank() && isYandex(t)) {
         String album = t.album();
         this.status = T.get("status.opening");
         this.yandex
            .searchAll(t.artist().split(",")[0].trim() + " " + album)
            .whenComplete(
               (all, ex) -> {
                  if (ex != null) {
                     this.status = T.get("status.error", msg(ex));
                  } else {
                     MusicEntity best = all.albums()
                        .stream()
                        .filter(a -> a.title().equalsIgnoreCase(album))
                        .findFirst()
                        .orElse(all.albums().isEmpty() ? null : all.albums().get(0));
                     if (best == null) {
                        this.status = T.get("status.nothing_found");
                     } else {
                        this.open(best);
                     }
                  }
               }
            );
      }
   }

   private static boolean isYandex(Track t) {
      return t.provider() == null || "yandex".equals(t.provider());
   }

   private void setResults(List<Track> r) {
      this.results = r;
      this.resultsVersion++;
      this.persist();
   }

   public synchronized void playFrom(List<Track> list, int i) {
      if (i >= 0 && i < list.size()) {
         this.stopWave();
         this.queue = list;
         this.index = i;
         this.history.clear();
         this.shufflePlan.clear();
         this.playTrack(list.get(i));
      }
   }

   private void playTrack(Track t) {
      this.current = t;
      this.idle = false;
      this.persist();
      this.lyrics = List.of();
      this.lyricsLoading = true;
      this.status = T.get("status.loading_track");
      MusicProvider p = this.provider(t);

      for (MusicProvider other : this.providers.values()) {
         if (other != p) {
            other.stop();
         }
      }

      p.play(t).whenComplete((v, e) -> {
         if (this.current == t) {
            this.status = e == null ? "" : T.get("status.play_failed", msg(e));
         }
      });
      this.refreshPrefetch();
      LyricsService.fetch(t, p).whenComplete((l, e) -> {
         if (this.current == t) {
            this.lyrics = (List<LyricLine>)(e == null && l != null ? l : List.of());
            this.lyricsLoading = false;
         }
      });
   }

   private void onTrackEnd(MusicProvider source) {
      if (source == this.engine()) {
         Track t = this.current;
         if (this.repeat == PlayerController.Repeat.ONE && t != null) {
            this.playTrack(t);
         } else {
            this.advance(false);
         }
      }
   }

   public void next() {
      this.advance(true);
   }

   private synchronized void advance(boolean manual) {
      if (!this.userQueue.isEmpty()) {
         Track t = this.userQueue.remove(0);
         this.playTrack(t);
      } else if (this.waveActive) {
         this.waveAdvance(manual);
      } else {
         List<Track> q = this.queue;
         int n = q.size();
         if (n != 0) {
            int ni;
            if (this.shuffle && n > 1) {
               this.history.push(this.index);

               while (this.history.size() > 50) {
                  this.history.removeLast();
               }

               this.fillShufflePlan(n);
               ni = this.shufflePlan.pollFirst();
            } else {
               ni = this.index + 1;
               if (ni >= n) {
                  if (this.repeat != PlayerController.Repeat.ALL && !manual) {
                     this.idle = true;
                     this.status = "";
                     return;
                  }

                  ni = 0;
               }
            }

            this.index = ni;
            this.playTrack(q.get(ni));
         }
      }
   }

   public synchronized void prev() {
      List<Track> q = this.queue;
      if (!q.isEmpty()) {
         if (!this.idle && this.engine().positionMs() > 3000L) {
            this.engine().seek(0L);
         } else if (this.waveActive) {
            this.wavePrev();
         } else {
            this.shufflePlan.clear();
            if (this.shuffle && !this.history.isEmpty()) {
               this.index = this.history.pop();
            } else {
               this.index = (this.index - 1 + q.size()) % q.size();
            }

            this.playTrack(q.get(this.index));
         }
      }
   }

   public void togglePause() {
      if (this.current != null) {
         if (this.idle) {
            this.playTrack(this.current);
         } else {
            MusicProvider p = this.engine();
            if (p.isPlaying()) {
               p.pause();
            } else {
               p.resume();
            }
         }
      }
   }

   public void seekBy(long deltaMs) {
      if (this.current != null && !this.idle) {
         this.seekTo(this.engine().positionMs() + deltaMs);
      }
   }

   public void seekTo(long ms) {
      Track t = this.current;
      if (t != null && !this.idle) {
         long dur = t.durationMs() > 0L ? t.durationMs() : Long.MAX_VALUE;
         this.engine().seek(Math.max(0L, Math.min(dur - 500L, ms)));
      }
   }

   public synchronized void toggleShuffle() {
      this.shuffle = !this.shuffle;
      this.history.clear();
      this.shufflePlan.clear();
      this.persist();
      this.refreshPrefetch();
   }

   public void cycleRepeat() {
      this.repeat = PlayerController.Repeat.values()[(this.repeat.ordinal() + 1) % PlayerController.Repeat.values().length];
      this.persist();
      this.refreshPrefetch();
   }

   public List<Track> queueSnapshot() {
      return new ArrayList<>(this.userQueue);
   }

   public void addToQueue(Track t) {
      if (t != null) {
         this.userQueue.add(t);
         this.persist();
         this.refreshPrefetch();
      }
   }

   public void playNext(Track t) {
      if (t != null) {
         this.userQueue.add(0, t);
         this.persist();
         this.refreshPrefetch();
      }
   }

   public void queueRemove(int i) {
      if (i >= 0 && i < this.userQueue.size()) {
         this.userQueue.remove(i);
         this.persist();
         this.refreshPrefetch();
      }
   }

   public synchronized void queueMoveUp(int i) {
      if (i > 0 && i < this.userQueue.size()) {
         Track t = this.userQueue.remove(i);
         this.userQueue.add(i - 1, t);
         this.persist();
         this.refreshPrefetch();
      }
   }

   public void playQueued(int i) {
      if (i >= 0 && i < this.userQueue.size()) {
         Track t = this.userQueue.remove(i);
         this.playTrack(t);
      }
   }

   public void removeLocal(Track t) {
      if (this.local.remove(t.id())) {
         this.status = T.get("status.local_removed", t.title());
      }
   }

   public void clearQueue() {
      this.userQueue.clear();
      this.persist();
      this.refreshPrefetch();
   }

   public synchronized void startWave() {
      this.startWave("user:onyourwave");
   }

   public synchronized void startStation(MusicEntity station) {
      if (!station.id().equals(this.waveSeed) || !this.waveActive && !this.waveLoading) {
         this.stopWave();
         this.startWave(station.id());
      } else {
         this.waveView = true;
      }
   }

   private synchronized void startWave(String seed) {
      this.waveView = true;
      if (!this.waveActive && !this.waveLoading) {
         this.waveLoading = true;
         this.waveSeed = seed;
         this.status = T.get("status.wave_starting");
         this.yandex.waveStart(seed).whenComplete((b, e) -> {
            this.waveLoading = false;
            if (seed.equals(this.waveSeed)) {
               if (e != null) {
                  this.status = T.get("status.wave_failed", msg(e));
                  this.waveView = false;
               } else if (b.tracks().isEmpty()) {
                  this.status = T.get("status.wave_empty");
                  this.waveView = false;
               } else {
                  synchronized (this) {
                     this.userQueue.clear();
                     this.waveSession = b.sessionId();
                     this.waveBatch = b.batchId();
                     this.waveQueue.clear();
                     this.waveHistory.clear();
                     this.waveSeen.clear();
                     this.waveQueue.addAll(b.tracks());
                     this.waveActive = true;
                     this.status = "";
                     this.yandex.waveFeedback(this.waveSession, this.waveBatch, "radioStarted", null, 0.0);
                     this.playWaveTrack(this.waveQueue.remove(0));
                  }
               }
            }
         });
      }
   }

   public synchronized void stopWave() {
      this.waveActive = false;
      this.waveLoading = false;
      this.waveView = false;
      this.waveSession = null;
      this.waveBatch = null;
      this.waveQueue.clear();
      this.waveHistory.clear();
      this.waveSeen.clear();
   }

   public void toggleWave() {
      if (this.waveActive && this.waveView) {
         this.stopWave();
      } else {
         this.startWave();
      }
   }

   public List<Track> waveSnapshot() {
      List<Track> out = new ArrayList<>();
      Track c = this.current;
      if (c != null) {
         out.add(c);
      }

      out.addAll(this.waveQueue);
      return out;
   }

   public void loadStations() {
      if (!this.stationsLoading && this.stations.isEmpty()) {
         this.stationsLoading = true;
         this.yandex.waveStations().whenComplete((list, e) -> {
            this.stationsLoading = false;
            if (e != null) {
               this.status = T.get("status.error", msg(e));
            } else {
               this.stations = (List<MusicEntity>)list;
            }
         });
      }
   }

   private List<Track> fresh(List<Track> in) {
      List<Track> out = new ArrayList<>();

      for (Track t : in) {
         if (t.id() != null && !this.waveSeen.contains(t.id()) && !this.waveQueue.stream().anyMatch(q -> t.id().equals(q.id()))) {
            out.add(t);
         }
      }

      return out.isEmpty() ? in : out;
   }

   private void playWaveTrack(Track t) {
      if (t.id() != null) {
         this.waveSeen.add(t.id());

         while (this.waveSeen.size() > 80) {
            this.waveSeen.removeFirst();
         }
      }

      this.playTrack(t);
      this.yandex.waveFeedback(this.waveSession, this.waveBatch, "trackStarted", t.id(), 0.0);
      this.topUpWave(t);
   }

   private void topUpWave(Track justStarted) {
      if (this.waveActive && !this.waveFetching && this.waveQueue.size() < 4) {
         this.waveFetching = true;
         String sid = this.waveSession;
         Track last = this.waveQueue.isEmpty() ? justStarted : this.waveQueue.get(this.waveQueue.size() - 1);
         this.yandex.waveMore(sid, this.waveSeed, last.id()).whenComplete((b, e) -> {
            this.waveFetching = false;
            if (e != null) {
               this.status = T.get("status.wave_no_answer", msg(e));
               this.waveStalled = false;
               this.idle = true;
            } else if (this.waveActive && sid.equals(this.waveSession)) {
               this.waveSession = b.sessionId();
               this.waveBatch = b.batchId();

               for (Track t : this.fresh(b.tracks())) {
                  if (t.id() != null && !t.id().equals(last.id())) {
                     this.waveQueue.add(t);
                  }
               }

               this.refreshPrefetch();
               if (this.waveStalled && !this.waveQueue.isEmpty()) {
                  this.waveStalled = false;
                  synchronized (this) {
                     this.status = "";
                     this.playWaveTrack(this.waveQueue.remove(0));
                  }
               }
            }
         });
      }
   }

   private synchronized void waveAdvance(boolean skipped) {
      Track prev = this.current;
      if (prev != null) {
         this.yandex.waveFeedback(this.waveSession, this.waveBatch, skipped ? "skip" : "trackFinished", prev.id(), this.yandex.positionMs() / 1000.0);
         this.waveHistory.push(prev);

         while (this.waveHistory.size() > 20) {
            this.waveHistory.removeLast();
         }
      }

      if (!this.waveQueue.isEmpty()) {
         this.playWaveTrack(this.waveQueue.remove(0));
      } else if (this.waveFetching) {
         this.waveStalled = true;
         this.status = T.get("status.wave_next");
      } else {
         this.waveFetching = true;
         this.waveLoading = true;
         String sid = this.waveSession;
         this.yandex.waveMore(sid, this.waveSeed, prev == null ? "" : prev.id()).whenComplete((b, e) -> {
            this.waveFetching = false;
            this.waveLoading = false;
            if (e != null) {
               this.status = T.get("status.wave_no_answer", msg(e));
               this.idle = true;
            } else {
               synchronized (this) {
                  if (this.waveActive && sid.equals(this.waveSession) && !b.tracks().isEmpty()) {
                     this.waveSession = b.sessionId();
                     this.waveBatch = b.batchId();
                     this.waveQueue.addAll(this.fresh(b.tracks()));
                     this.status = "";
                     this.playWaveTrack(this.waveQueue.remove(0));
                  }
               }
            }
         });
      }
   }

   private void wavePrev() {
      Track back = this.waveHistory.poll();
      if (back == null) {
         this.yandex.seek(0L);
      } else {
         Track cur = this.current;
         if (cur != null) {
            this.waveQueue.add(0, cur);
         }

         this.playTrack(back);
      }
   }

   public synchronized void playWaveIndex(int i) {
      if (this.waveActive && i > 0 && i <= this.waveQueue.size()) {
         Track cur = this.current;
         if (cur != null) {
            this.yandex.waveFeedback(this.waveSession, this.waveBatch, "skip", cur.id(), this.yandex.positionMs() / 1000.0);
         }

         for (int k = 0; k < i - 1; k++) {
            this.waveQueue.remove(0);
         }

         this.playWaveTrack(this.waveQueue.remove(0));
      }
   }

   public void waveDislike() {
      Track t = this.current;
      if (t != null && this.waveActive) {
         this.yandex.dislike(t).whenComplete((v, e) -> {
            if (e != null) {
               this.status = T.get("status.dislike_failed", msg(e));
            }
         });
         this.next();
      }
   }

   private void fillShufflePlan(int n) {
      int last = this.shufflePlan.isEmpty() ? this.index : this.shufflePlan.peekLast();

      while (this.shufflePlan.size() < 3) {
         int c = this.rnd.nextInt(n);
         if (c != last || n <= 1) {
            this.shufflePlan.addLast(c);
            last = c;
         }
      }
   }

   public int loadingPercent() {
      Track t = this.current;
      return t == null ? -1 : this.provider(t).loadPercent(t.id());
   }

   public synchronized void refreshPrefetch() {
      Track cur = this.current;
      if (cur != null && !this.idle) {
         int count = PlayerConfig.get().prefetchCount;
         List<Track> ahead = new ArrayList<>();
         Set<String> keep = new HashSet<>();
         keep.add(cur.id());

         for (Track t : this.userQueue) {
            if (ahead.size() >= count) {
               break;
            }

            ahead.add(t);
         }

         if (this.waveActive) {
            for (Track t : this.waveQueue) {
               if (ahead.size() >= count) {
                  break;
               }

               ahead.add(t);
            }
         } else if (this.repeat != PlayerController.Repeat.ONE) {
            List<Track> q = this.queue;
            int n = q.size();
            if (n > 0) {
               if (this.shuffle && n > 1) {
                  this.fillShufflePlan(n);

                  for (int idx : this.shufflePlan) {
                     if (ahead.size() >= count) {
                        break;
                     }

                     if (idx < n) {
                        ahead.add(q.get(idx));
                     }
                  }
               } else {
                  for (int k = 1; k < n && ahead.size() < count; k++) {
                     int ni = this.index + k;
                     if (ni >= n) {
                        if (this.repeat != PlayerController.Repeat.ALL) {
                           break;
                        }

                        ni %= n;
                     }

                     ahead.add(q.get(ni));
                  }
               }

               if (this.repeat == PlayerController.Repeat.ALL) {
                  for (int k = 0; k < Math.min(n, 40); k++) {
                     keep.add(q.get(k).id());
                  }
               }
            }
         }

         MusicProvider owner = this.provider(cur);
         ahead.removeIf(t -> this.provider(t) != owner);
         owner.setPrefetch(cur.id(), ahead, keep);
      } else {
         for (MusicProvider p : this.providers.values()) {
            p.setPrefetch(null, List.of(), Set.of());
         }
      }
   }

   public boolean canLike(Track t) {
      return t != null && this.provider(t).supportsLikes();
   }

   public boolean isLiked(Track t) {
      return this.canLike(t) && this.provider(t).isLiked(t.id());
   }

   public void toggleLike() {
      Track t = this.current;
      if (this.canLike(t)) {
         MusicProvider p = this.provider(t);
         boolean like = !p.isLiked(t.id());
         p.setLiked(t, like).whenComplete((v, e) -> {
            if (e != null) {
               this.status = T.get("status.like_failed", msg(e));
            }
         });
      }
   }

   public void changeVolume(float delta) {
      this.setVolume(this.volume + delta);
   }

   public void setVolume(float v) {
      this.volume = Math.max(0.0F, Math.min(1.0F, v));
      SessionState.get().volume = this.volume;
      SessionState.markDirty();
      this.applyVolume(true);
   }

   public void toggleMute() {
      SessionState st = SessionState.get();
      if (this.volume > 0.0F) {
         st.preMuteVolume = this.volume;
         this.setVolume(0.0F);
      } else {
         this.setVolume(st.preMuteVolume);
      }
   }

   private void applyVolume(boolean force) {
      float eff = this.volume * GameVolume.factor();
      if (force || !(Math.abs(eff - this.lastApplied) < 0.002F)) {
         this.lastApplied = eff;

         for (MusicProvider p : this.providers.values()) {
            p.setVolume(p == this.spotify ? this.volume : eff);
         }
      }
   }

   private static String msg(Throwable e) {
      MusicPlayerMod.LOGGER.warn("Overtone error", e);
      Throwable c = e;

      while (c.getCause() != null && (c instanceof CompletionException || c instanceof ExecutionException)) {
         c = c.getCause();
      }

      return c.getMessage() != null ? c.getMessage() : c.getClass().getSimpleName();
   }

   public static enum Repeat {
      OFF,
      ALL,
      ONE;

      private Repeat() {
      }
   }

   public static enum Tab {
      TRACKS,
      ARTISTS,
      ALBUMS,
      PLAYLISTS,
      STATIONS;

      private Tab() {
      }
   }
}
