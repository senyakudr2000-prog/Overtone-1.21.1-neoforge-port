package dev.musicplayer.jlayer;

import java.io.InputStream;

public interface JavaLayerHook {
   InputStream getResourceAsStream(String var1);
}
