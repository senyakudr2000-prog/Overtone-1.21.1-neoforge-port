package dev.musicplayer.jlayer;

public abstract class OBuffer {
   public static final int O_BUFFER_SIZE = 2304;
   public static final int MAX_CHANNELS = 2;

   public OBuffer() {
   }

   public abstract void append(int var1, short var2);

   public void appendSamples(int channel, float[] f) {
      int i = 0;

      while (i < 32) {
         short s = clip(f[i++]);
         this.append(channel, s);
      }
   }

   private static short clip(float sample) {
      return sample > 32767.0F ? 32767 : (sample < -32768.0F ? -32768 : (short)sample);
   }

   public abstract void writeBuffer(int var1);

   public abstract void close();

   public abstract void clearBuffer();

   public abstract void setStopFlag();
}
