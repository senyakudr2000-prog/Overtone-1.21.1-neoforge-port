package dev.musicplayer.jlayer;

public class DecoderException extends JavaLayerException implements DecoderErrors {
   private int errorCode = 512;

   public DecoderException(String msg, Throwable t) {
      super(msg, t);
   }

   public DecoderException(int errorCode, Throwable t) {
      this(getErrorString(errorCode), t);
      this.errorCode = errorCode;
   }

   public int getErrorCode() {
      return this.errorCode;
   }

   public static String getErrorString(int errorcode) {
      return "Decoder errorCode " + Integer.toHexString(errorcode);
   }
}
