package dev.musicplayer.jlayer;

final class BitReserve {
   private static final int BUFSIZE = 32768;
   private static final int BUFSIZE_MASK = 32767;
   private int offset;
   private int totbit;
   private int bufByteIdx;
   private final int[] buf = new int[32768];
   private int buf_bit_idx;

   BitReserve() {
      this.offset = 0;
      this.totbit = 0;
      this.bufByteIdx = 0;
   }

   public int hsstell() {
      return this.totbit;
   }

   public int hgetbits(int N) {
      this.totbit += N;
      int val = 0;
      int pos = this.bufByteIdx;
      if (pos + N < 32768) {
         while (N-- > 0) {
            val <<= 1;
            val |= this.buf[pos++] != 0 ? 1 : 0;
         }
      } else {
         while (N-- > 0) {
            val <<= 1;
            val |= this.buf[pos] != 0 ? 1 : 0;
            pos = pos + 1 & 32767;
         }
      }

      this.bufByteIdx = pos;
      return val;
   }

   public int hget1bit() {
      this.totbit++;
      int val = this.buf[this.bufByteIdx];
      this.bufByteIdx = this.bufByteIdx + 1 & 32767;
      return val;
   }

   public void hputbuf(int val) {
      int ofs = this.offset;
      this.buf[ofs++] = val & 128;
      this.buf[ofs++] = val & 64;
      this.buf[ofs++] = val & 32;
      this.buf[ofs++] = val & 16;
      this.buf[ofs++] = val & 8;
      this.buf[ofs++] = val & 4;
      this.buf[ofs++] = val & 2;
      this.buf[ofs++] = val & 1;
      if (ofs == 32768) {
         this.offset = 0;
      } else {
         this.offset = ofs;
      }
   }

   public void rewindNBits(int n) {
      this.totbit -= n;
      this.bufByteIdx -= n;
      if (this.bufByteIdx < 0) {
         this.bufByteIdx += 32768;
      }
   }

   public void rewindNBytes(int n) {
      int bits = n << 3;
      this.totbit -= bits;
      this.bufByteIdx -= bits;
      if (this.bufByteIdx < 0) {
         this.bufByteIdx += 32768;
      }
   }
}
