package dev.musicplayer.jlayer;

public class SampleBuffer extends OBuffer {
   private final short[] buffer = new short[2304];
   private final int[] bufferP = new int[2];
   private final int channels;
   private final int frequency;

   public SampleBuffer(int sample_frequency, int number_of_channels) {
      this.channels = number_of_channels;
      this.frequency = sample_frequency;

      for (int i = 0; i < number_of_channels; i++) {
         this.bufferP[i] = (short)i;
      }
   }

   public int getChannelCount() {
      return this.channels;
   }

   public int getSampleFrequency() {
      return this.frequency;
   }

   public short[] getBuffer() {
      return this.buffer;
   }

   public int getBufferLength() {
      return this.bufferP[0];
   }

   @Override
   public void append(int channel, short value) {
      this.buffer[this.bufferP[channel]] = value;
      this.bufferP[channel] = this.bufferP[channel] + this.channels;
   }

   @Override
   public void appendSamples(int channel, float[] f) {
      int pos = this.bufferP[channel];

      for (int i = 0; i < 32; pos += this.channels) {
         float fs = f[i++];
         fs = fs > 32767.0F ? 32767.0F : Math.max(fs, -32767.0F);
         short s = (short)fs;
         this.buffer[pos] = s;
      }

      this.bufferP[channel] = pos;
   }

   @Override
   public void writeBuffer(int val) {
   }

   @Override
   public void close() {
   }

   @Override
   public void clearBuffer() {
      for (int i = 0; i < this.channels; i++) {
         this.bufferP[i] = (short)i;
      }
   }

   @Override
   public void setStopFlag() {
   }
}
