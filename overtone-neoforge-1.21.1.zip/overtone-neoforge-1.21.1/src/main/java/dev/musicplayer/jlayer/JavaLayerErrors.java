package dev.musicplayer.jlayer;

public interface JavaLayerErrors {
   int BITSTREAM_ERROR = 256;
   int DECODER_ERROR = 512;
}
