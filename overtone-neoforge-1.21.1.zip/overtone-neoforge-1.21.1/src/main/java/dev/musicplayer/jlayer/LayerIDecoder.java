package dev.musicplayer.jlayer;

class LayerIDecoder implements FrameDecoder {
   protected Bitstream stream;
   protected Header header;
   protected SynthesisFilter filter1;
   protected SynthesisFilter filter2;
   protected OBuffer buffer;
   protected int whichChannels;
   protected int mode;
   protected int num_subbands;
   protected LayerIDecoder.Subband[] subbands;
   protected final Crc16 crc = new Crc16();

   public LayerIDecoder() {
   }

   public void create(Bitstream stream, Header header, SynthesisFilter filterA, SynthesisFilter filterB, OBuffer buffer, int whichCh) {
      this.stream = stream;
      this.header = header;
      this.filter1 = filterA;
      this.filter2 = filterB;
      this.buffer = buffer;
      this.whichChannels = whichCh;
   }

   @Override
   public void decodeFrame() throws DecoderException {
      this.num_subbands = this.header.numberOfSubbands();
      this.subbands = new LayerIDecoder.Subband[32];
      this.mode = this.header.mode();
      this.createSubbands();
      this.readAllocation();
      this.readScaleFactorSelection();
      if (this.crc != null || this.header.checksumOk()) {
         this.readScaleFactors();
         this.readSampleData();
      }
   }

   protected void createSubbands() {
      if (this.mode == 3) {
         for (int i = 0; i < this.num_subbands; i++) {
            this.subbands[i] = new LayerIDecoder.SubbandLayer1(i);
         }
      } else if (this.mode == 1) {
         int i;
         for (i = 0; i < this.header.intensityStereoBound(); i++) {
            this.subbands[i] = new LayerIDecoder.SubbandLayer1Stereo(i);
         }

         while (i < this.num_subbands) {
            this.subbands[i] = new LayerIDecoder.SubbandLayer1IntensityStereo(i);
            i++;
         }
      } else {
         for (int i = 0; i < this.num_subbands; i++) {
            this.subbands[i] = new LayerIDecoder.SubbandLayer1Stereo(i);
         }
      }
   }

   protected void readAllocation() throws DecoderException {
      for (int i = 0; i < this.num_subbands; i++) {
         this.subbands[i].readAllocation(this.stream, this.header, this.crc);
      }
   }

   protected void readScaleFactorSelection() {
   }

   protected void readScaleFactors() {
      for (int i = 0; i < this.num_subbands; i++) {
         this.subbands[i].readScaleFactor(this.stream, this.header);
      }
   }

   protected void readSampleData() {
      boolean readReady = false;
      boolean writeReady = false;
      int mode = this.header.mode();

      do {
         for (int i = 0; i < this.num_subbands; i++) {
            readReady = this.subbands[i].readSampleData(this.stream);
         }

         do {
            for (int var5 = 0; var5 < this.num_subbands; var5++) {
               writeReady = this.subbands[var5].put_next_sample(this.whichChannels, this.filter1, this.filter2);
            }

            this.filter1.calculate_pcm_samples(this.buffer);
            if (this.whichChannels == 0 && mode != 3) {
               this.filter2.calculate_pcm_samples(this.buffer);
            }
         } while (!writeReady);
      } while (!readReady);
   }

   abstract static class Subband {
      public static final float[] scaleFactors = new float[]{
         2.0F,
         1.587401F,
         1.2599211F,
         1.0F,
         0.7937005F,
         0.62996054F,
         0.5F,
         0.39685026F,
         0.31498027F,
         0.25F,
         0.19842513F,
         0.15749013F,
         0.125F,
         0.099212565F,
         0.07874507F,
         0.0625F,
         0.049606282F,
         0.039372534F,
         0.03125F,
         0.024803141F,
         0.019686267F,
         0.015625F,
         0.012401571F,
         0.009843133F,
         0.0078125F,
         0.0062007853F,
         0.0049215667F,
         0.00390625F,
         0.0031003926F,
         0.0024607833F,
         0.001953125F,
         0.0015501963F,
         0.0012303917F,
         9.765625E-4F,
         7.7509816E-4F,
         6.1519584E-4F,
         4.8828125E-4F,
         3.8754908E-4F,
         3.0759792E-4F,
         2.4414062E-4F,
         1.9377454E-4F,
         1.5379896E-4F,
         1.2207031E-4F,
         9.688727E-5F,
         7.689948E-5F,
         6.1035156E-5F,
         4.8443635E-5F,
         3.844974E-5F,
         3.0517578E-5F,
         2.4221818E-5F,
         1.922487E-5F,
         1.5258789E-5F,
         1.2110909E-5F,
         9.612435E-6F,
         7.6293945E-6F,
         6.0554544E-6F,
         4.8062175E-6F,
         3.8146973E-6F,
         3.0277272E-6F,
         2.4031087E-6F,
         1.9073486E-6F,
         1.5138636E-6F,
         1.2015544E-6F,
         0.0F
      };

      Subband() {
      }

      public abstract void readAllocation(Bitstream var1, Header var2, Crc16 var3) throws DecoderException;

      public abstract void readScaleFactor(Bitstream var1, Header var2);

      public abstract boolean readSampleData(Bitstream var1);

      public abstract boolean put_next_sample(int var1, SynthesisFilter var2, SynthesisFilter var3);
   }

   static class SubbandLayer1 extends LayerIDecoder.Subband {
      public static final float[] tableFactor = new float[]{
         0.0F,
         0.6666667F,
         0.2857143F,
         0.13333334F,
         0.06451613F,
         0.031746034F,
         0.015748031F,
         0.007843138F,
         0.0039138943F,
         0.0019550342F,
         9.770396E-4F,
         4.884005E-4F,
         2.4417043E-4F,
         1.2207776E-4F,
         6.103702E-5F
      };
      public static final float[] tableOffset = new float[]{
         0.0F,
         -0.6666667F,
         -0.8571429F,
         -0.9333334F,
         -0.9677419F,
         -0.98412704F,
         -0.992126F,
         -0.9960785F,
         -0.99804306F,
         -0.9990225F,
         -0.9995115F,
         -0.99975586F,
         -0.9998779F,
         -0.99993896F,
         -0.9999695F
      };
      protected final int subbandNumber;
      protected int sampleNumber;
      protected int allocation;
      protected float scaleFactor;
      protected int sampleLength;
      protected float sample;
      protected float factor;
      protected float offset;

      public SubbandLayer1(int subbandNumber) {
         this.subbandNumber = subbandNumber;
         this.sampleNumber = 0;
      }

      @Override
      public void readAllocation(Bitstream stream, Header header, Crc16 crc) throws DecoderException {
         if ((this.allocation = stream.getBits(4)) == 15) {
            throw new DecoderException(514, null);
         } else {
            if (crc != null) {
               crc.addBits(this.allocation, 4);
            }

            if (this.allocation != 0) {
               this.sampleLength = this.allocation + 1;
               this.factor = tableFactor[this.allocation];
               this.offset = tableOffset[this.allocation];
            }
         }
      }

      @Override
      public void readScaleFactor(Bitstream stream, Header header) {
         if (this.allocation != 0) {
            this.scaleFactor = scaleFactors[stream.getBits(6)];
         }
      }

      @Override
      public boolean readSampleData(Bitstream stream) {
         if (this.allocation != 0) {
            this.sample = stream.getBits(this.sampleLength);
         }

         if (++this.sampleNumber == 12) {
            this.sampleNumber = 0;
            return true;
         } else {
            return false;
         }
      }

      @Override
      public boolean put_next_sample(int channels, SynthesisFilter filter1, SynthesisFilter filter2) {
         if (this.allocation != 0 && channels != 2) {
            float scaled_sample = (this.sample * this.factor + this.offset) * this.scaleFactor;
            filter1.inputSample(scaled_sample, this.subbandNumber);
         }

         return true;
      }
   }

   static class SubbandLayer1IntensityStereo extends LayerIDecoder.SubbandLayer1 {
      protected float channel2ScaleFactor;

      public SubbandLayer1IntensityStereo(int subbandNumber) {
         super(subbandNumber);
      }

      @Override
      public void readAllocation(Bitstream stream, Header header, Crc16 crc) throws DecoderException {
         super.readAllocation(stream, header, crc);
      }

      @Override
      public void readScaleFactor(Bitstream stream, Header header) {
         if (this.allocation != 0) {
            this.scaleFactor = scaleFactors[stream.getBits(6)];
            this.channel2ScaleFactor = scaleFactors[stream.getBits(6)];
         }
      }

      @Override
      public boolean readSampleData(Bitstream stream) {
         return super.readSampleData(stream);
      }

      @Override
      public boolean put_next_sample(int channels, SynthesisFilter filter1, SynthesisFilter filter2) {
         if (this.allocation != 0) {
            this.sample = this.sample * this.factor + this.offset;
            if (channels == 0) {
               float sample1 = this.sample * this.scaleFactor;
               float sample2 = this.sample * this.channel2ScaleFactor;
               filter1.inputSample(sample1, this.subbandNumber);
               filter2.inputSample(sample2, this.subbandNumber);
            } else if (channels == 1) {
               float sample1 = this.sample * this.scaleFactor;
               filter1.inputSample(sample1, this.subbandNumber);
            } else {
               float sample2 = this.sample * this.channel2ScaleFactor;
               filter1.inputSample(sample2, this.subbandNumber);
            }
         }

         return true;
      }
   }

   static class SubbandLayer1Stereo extends LayerIDecoder.SubbandLayer1 {
      protected int channel2Allocation;
      protected float channel2ScaleFactor;
      protected int channel2SampleLength;
      protected float channel2Sample;
      protected float channel2Factor;
      protected float channel2Offset;

      public SubbandLayer1Stereo(int subbandNumber) {
         super(subbandNumber);
      }

      @Override
      public void readAllocation(Bitstream stream, Header header, Crc16 crc) throws DecoderException {
         this.allocation = stream.getBits(4);
         this.channel2Allocation = stream.getBits(4);
         if (crc != null) {
            crc.addBits(this.allocation, 4);
            crc.addBits(this.channel2Allocation, 4);
         }

         if (this.allocation != 0) {
            this.sampleLength = this.allocation + 1;
            this.factor = tableFactor[this.allocation];
            this.offset = tableOffset[this.allocation];
         }

         if (this.channel2Allocation != 0) {
            this.channel2SampleLength = this.channel2Allocation + 1;
            this.channel2Factor = tableFactor[this.channel2Allocation];
            this.channel2Offset = tableOffset[this.channel2Allocation];
         }
      }

      @Override
      public void readScaleFactor(Bitstream stream, Header header) {
         if (this.allocation != 0) {
            this.scaleFactor = scaleFactors[stream.getBits(6)];
         }

         if (this.channel2Allocation != 0) {
            this.channel2ScaleFactor = scaleFactors[stream.getBits(6)];
         }
      }

      @Override
      public boolean readSampleData(Bitstream stream) {
         boolean returnValue = super.readSampleData(stream);
         if (this.channel2Allocation != 0) {
            this.channel2Sample = stream.getBits(this.channel2SampleLength);
         }

         return returnValue;
      }

      @Override
      public boolean put_next_sample(int channels, SynthesisFilter filter1, SynthesisFilter filter2) {
         super.put_next_sample(channels, filter1, filter2);
         if (this.channel2Allocation != 0 && channels != 1) {
            float sample2 = (this.channel2Sample * this.channel2Factor + this.channel2Offset) * this.channel2ScaleFactor;
            if (channels == 0) {
               filter2.inputSample(sample2, this.subbandNumber);
            } else {
               filter1.inputSample(sample2, this.subbandNumber);
            }
         }

         return true;
      }
   }
}
