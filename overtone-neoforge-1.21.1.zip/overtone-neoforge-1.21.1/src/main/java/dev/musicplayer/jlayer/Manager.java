package dev.musicplayer.jlayer;

public class Manager {
   public Manager() {
   }

   public void addControl(Control c) {
   }

   public void removeControl(Control c) {
   }

   public void removeAll() {
   }
}
