package dev.musicplayer.jlayer;

public final class GaplessTrim {
   private static final int SAMPLES_PER_FRAME = 1152;
   private final long first;
   private final long last;
   private long position;
   private int offset;

   private GaplessTrim(long first, long last) {
      this.first = first;
      this.last = last;
   }

   public static GaplessTrim of(Header header, int channels) {
      if (header != null && channels >= 1) {
         long first = (long)header.samplesToSkipAtStart() * channels;
         int frames = header.vbrFrames();
         if (frames <= 0) {
            return new GaplessTrim(first, -1L);
         } else {
            long total = frames * 1152L * channels;
            long last = total - (long)header.samplesToSkipAtEnd() * channels;
            return new GaplessTrim(first, Math.max(first, last));
         }
      } else {
         return new GaplessTrim(0L, -1L);
      }
   }

   public int accept(int bufferLength) {
      long start = Math.max(this.position, this.first);
      long end = this.position + bufferLength;
      if (this.last >= 0L) {
         end = Math.min(end, this.last);
      }

      this.position += bufferLength;
      if (end <= start) {
         this.offset = 0;
         return 0;
      } else {
         this.offset = (int)(start - (this.position - bufferLength));
         return (int)(end - start);
      }
   }

   public int offset() {
      return this.offset;
   }

   public boolean isTrimming() {
      return this.first > 0L || this.last >= 0L;
   }
}
