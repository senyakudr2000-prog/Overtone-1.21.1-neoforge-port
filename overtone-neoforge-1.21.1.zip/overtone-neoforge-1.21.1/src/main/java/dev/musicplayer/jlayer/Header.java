package dev.musicplayer.jlayer;

public final class Header {
   public static final int MPEG2_LSF = 0;
   public static final int MPEG1 = 1;
   public static final int MPEG25_LSF = 2;
   public static final int STEREO = 0;
   public static final int JOINT_STEREO = 1;
   public static final int DUAL_CHANNEL = 2;
   public static final int SINGLE_CHANNEL = 3;
   public static final int FOURTYFOUR_POINT_ONE = 0;
   public static final int FOURTYEIGHT = 1;
   public static final int THIRTYTWO = 2;
   public static final int DECODER_DELAY = 529;
   public static final int[][] frequencies = new int[][]{{22050, 24000, 16000, 1}, {44100, 48000, 32000, 1}, {11025, 12000, 8000, 1}};
   public static final int[][][] bitrates = new int[][][]{
      {
            {0, 32000, 48000, 56000, 64000, 80000, 96000, 112000, 128000, 144000, 160000, 176000, 192000, 224000, 256000, 0},
            {0, 8000, 16000, 24000, 32000, 40000, 48000, 56000, 64000, 80000, 96000, 112000, 128000, 144000, 160000, 0},
            {0, 8000, 16000, 24000, 32000, 40000, 48000, 56000, 64000, 80000, 96000, 112000, 128000, 144000, 160000, 0}
      },
      {
            {0, 32000, 64000, 96000, 128000, 160000, 192000, 224000, 256000, 288000, 320000, 352000, 384000, 416000, 448000, 0},
            {0, 32000, 48000, 56000, 64000, 80000, 96000, 112000, 128000, 160000, 192000, 224000, 256000, 320000, 384000, 0},
            {0, 32000, 40000, 48000, 56000, 64000, 80000, 96000, 112000, 128000, 160000, 192000, 224000, 256000, 320000, 0}
      },
      {
            {0, 32000, 48000, 56000, 64000, 80000, 96000, 112000, 128000, 144000, 160000, 176000, 192000, 224000, 256000, 0},
            {0, 8000, 16000, 24000, 32000, 40000, 48000, 56000, 64000, 80000, 96000, 112000, 128000, 144000, 160000, 0},
            {0, 8000, 16000, 24000, 32000, 40000, 48000, 56000, 64000, 80000, 96000, 112000, 128000, 144000, 160000, 0}
      }
   };
   private static final double[] h_vbr_time_per_frame = new double[]{-1.0, 384.0, 1152.0, 1152.0};
   private static final float[][] msPerFrames = new float[][]{{8.707483F, 8.0F, 12.0F}, {26.12245F, 24.0F, 36.0F}, {26.12245F, 24.0F, 36.0F}};
   private int hLayer;
   private int hVersion;
   private int hBitrateIndex;
   private int h_protection_bit;
   private int h_sample_frequency;
   private int h_mode;
   private int h_mode_extension;
   private int h_padding_bit;
   private int hNumberOfSubbands;
   private int hIntensityStereoBound;
   private boolean h_copyright;
   private boolean h_original;
   private boolean h_vbr;
   private int h_vbr_frames;
   private int h_vbr_scale = -1;
   private int h_vbr_bytes;
   private byte[] h_vbr_toc;
   private int h_enc_delay = -1;
   private int h_enc_padding = -1;
   public short checksum;
   public int framesize;
   public int nSlots;
   private byte syncmode = 0;
   private Crc16 crc;
   private int _headerstring = -1;

   Header() {
   }

   void read_header(Bitstream stream, Crc16[] crcp) throws BitstreamException {
      boolean sync = false;

      int headerString;
      do {
         headerString = stream.syncHeader(this.syncmode);
         this._headerstring = headerString;
         if (this.syncmode == 0) {
            this.hVersion = headerString >>> 19 & 1;
            if ((headerString >>> 20 & 1) == 0) {
               if (this.hVersion != 0) {
                  throw stream.newBitstreamException(256);
               }

               this.hVersion = 2;
            }

            this.h_sample_frequency = headerString >>> 10 & 3;
            if (this.h_sample_frequency == 3) {
               throw stream.newBitstreamException(256);
            }
         }

         this.hLayer = 4 - (headerString >>> 17) & 3;
         this.h_protection_bit = headerString >>> 16 & 1;
         this.hBitrateIndex = headerString >>> 12 & 15;
         this.h_padding_bit = headerString >>> 9 & 1;
         this.h_mode = headerString >>> 6 & 3;
         this.h_mode_extension = headerString >>> 4 & 3;
         if (this.h_mode == 1) {
            this.hIntensityStereoBound = (this.h_mode_extension << 2) + 4;
         } else {
            this.hIntensityStereoBound = 0;
         }

         this.h_copyright = (headerString >>> 3 & 1) == 1;
         this.h_original = (headerString >>> 2 & 1) == 1;
         this.calculateNumberOfSubbands(this.calculateChannelBitrate());
         if (this.hIntensityStereoBound > this.hNumberOfSubbands) {
            this.hIntensityStereoBound = this.hNumberOfSubbands;
         }

         this.calculateFrameSize();
         int framesizeloaded = stream.readFrameData(this.framesize);
         if (this.framesize >= 0 && framesizeloaded != this.framesize) {
            throw stream.newBitstreamException(261);
         }

         if (stream.isSyncCurrentPosition(this.syncmode)) {
            if (this.syncmode == 0) {
               this.syncmode = 1;
               stream.setSyncWord(headerString & -521024);
            }

            sync = true;
         } else {
            stream.unreadFrame();
         }
      } while (!sync);

      stream.parseFrame();
      if (this.h_protection_bit == 0) {
         this.checksum = (short)stream.getBits(16);
         if (this.crc == null) {
            this.crc = new Crc16();
         }

         this.crc.addBits(headerString, 16);
         crcp[0] = this.crc;
      } else {
         crcp[0] = null;
      }
   }

   private int calculateChannelBitrate() {
      int channelBitrate = this.hBitrateIndex;
      if (this.h_mode != 3) {
         if (channelBitrate == 4) {
            channelBitrate = 1;
         } else {
            channelBitrate -= 4;
         }
      }

      return channelBitrate;
   }

   private void calculateNumberOfSubbands(int channelBitrate) {
      if (this.hLayer == 1) {
         this.hNumberOfSubbands = 32;
      } else if (channelBitrate != 1 && channelBitrate != 2) {
         if (this.h_sample_frequency != 1 && (channelBitrate < 3 || channelBitrate > 5)) {
            this.hNumberOfSubbands = 30;
         } else {
            this.hNumberOfSubbands = 27;
         }
      } else {
         this.hNumberOfSubbands = this.h_sample_frequency == 2 ? 12 : 8;
      }
   }

   void parseVBR(byte[] firstFrame) throws BitstreamException {
      if (!this.parseXingVBR(firstFrame)) {
         this.parseVBRIHeader(firstFrame);
      }
   }

   private boolean parseXingVBR(byte[] firstFrame) {
      byte[] tmp = new byte[4];
      int offset;
      if (this.hVersion == 1) {
         offset = this.h_mode == 3 ? 17 : 32;
      } else {
         offset = this.h_mode == 3 ? 9 : 17;
      }

      try {
         System.arraycopy(firstFrame, offset, tmp, 0, 4);
         if ("Xing".equals(new String(tmp)) || "Info".equals(new String(tmp))) {
            this.h_vbr = true;
            this.h_vbr_frames = -1;
            this.h_vbr_bytes = -1;
            this.h_vbr_scale = -1;
            this.h_vbr_toc = new byte[100];
            int flags = 0;

            for (int i = 0; i < 4; i++) {
               flags <<= 8;
               flags += firstFrame[offset + 4 + i] & 255;
            }

            offset += 8;
            if ((flags & 1) != 0) {
               for (int i = 0; i < 4; i++) {
                  this.h_vbr_frames <<= 8;
                  this.h_vbr_frames = this.h_vbr_frames + (firstFrame[offset + i] & 255);
               }

               offset += 4;
            }

            if ((flags & 2) != 0) {
               for (int i = 0; i < 4; i++) {
                  this.h_vbr_bytes <<= 8;
                  this.h_vbr_bytes = this.h_vbr_bytes + (firstFrame[offset + i] & 255);
               }

               offset += 4;
            }

            if ((flags & 4) != 0) {
               System.arraycopy(firstFrame, offset, this.h_vbr_toc, 0, 100);
               offset += 100;
            }

            if ((flags & 8) != 0) {
               for (int i = 0; i < 4; i++) {
                  this.h_vbr_scale <<= 8;
                  this.h_vbr_scale = this.h_vbr_scale + (firstFrame[offset + i] & 255);
               }

               offset += 4;
            }

            this.parseLameTag(firstFrame, offset);
            return true;
         }
      } catch (ArrayIndexOutOfBoundsException var6) {
      }

      return false;
   }

   private void parseLameTag(byte[] firstFrame, int offset) {
      try {
         if (!startsWith(firstFrame, offset, "LAME") && !startsWith(firstFrame, offset, "Lavc") && !startsWith(firstFrame, offset, "Lavf")) {
            return;
         }

         int at = offset + 21;
         this.h_enc_delay = (firstFrame[at] & 255) << 4 | (firstFrame[at + 1] & 255) >> 4;
         this.h_enc_padding = (firstFrame[at + 1] & 15) << 8 | firstFrame[at + 2] & 255;
      } catch (ArrayIndexOutOfBoundsException var4) {
         this.h_enc_delay = -1;
         this.h_enc_padding = -1;
      }
   }

   void copyVbrFrom(Header headerFrame) {
      this.h_vbr = headerFrame.h_vbr;
      this.h_vbr_frames = headerFrame.h_vbr_frames;
      this.h_vbr_bytes = headerFrame.h_vbr_bytes;
      this.h_vbr_scale = headerFrame.h_vbr_scale;
      this.h_vbr_toc = headerFrame.h_vbr_toc;
      this.h_enc_delay = headerFrame.h_enc_delay;
      this.h_enc_padding = headerFrame.h_enc_padding;
   }

   private static boolean startsWith(byte[] data, int offset, String marker) {
      if (offset >= 0 && offset + marker.length() <= data.length) {
         for (int i = 0; i < marker.length(); i++) {
            if (data[offset + i] != (byte)marker.charAt(i)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private void parseVBRIHeader(byte[] firstFrame) {
      byte[] tmp = new byte[4];
      int offset = 36;

      try {
         System.arraycopy(firstFrame, offset, tmp, 0, 4);
         if ("VBRI".equals(new String(tmp))) {
            this.h_vbr = true;
            this.h_vbr_frames = -1;
            this.h_vbr_bytes = -1;
            this.h_vbr_scale = -1;
            offset += 6;
            offset += 2;
            offset += 2;

            for (int i = 0; i < 4; i++) {
               this.h_vbr_bytes <<= 8;
               this.h_vbr_bytes = this.h_vbr_bytes + (firstFrame[offset + i] & 255);
            }

            offset += 4;

            for (int i = 0; i < 4; i++) {
               this.h_vbr_frames <<= 8;
               this.h_vbr_frames = this.h_vbr_frames + (firstFrame[offset + i] & 255);
            }
         }
      } catch (ArrayIndexOutOfBoundsException var5) {
      }
   }

   public int calculateFrameSize() {
      if (this.hLayer == 1) {
         this.framesize = 12 * bitrates[this.hVersion][0][this.hBitrateIndex] / frequencies[this.hVersion][this.h_sample_frequency];
         if (this.h_padding_bit != 0) {
            this.framesize++;
         }

         this.framesize <<= 2;
         this.nSlots = 0;
      } else {
         this.framesize = 144 * bitrates[this.hVersion][this.hLayer - 1][this.hBitrateIndex] / frequencies[this.hVersion][this.h_sample_frequency];
         if (this.hVersion == 0 || this.hVersion == 2) {
            this.framesize >>= 1;
         }

         if (this.h_padding_bit != 0) {
            this.framesize++;
         }

         if (this.hLayer == 3) {
            if (this.hVersion == 1) {
               this.nSlots = this.framesize - (this.h_mode == 3 ? 17 : 32) - (this.h_protection_bit != 0 ? 0 : 2) - 4;
            } else {
               this.nSlots = this.framesize - (this.h_mode == 3 ? 9 : 17) - (this.h_protection_bit != 0 ? 0 : 2) - 4;
            }
         } else {
            this.nSlots = 0;
         }
      }

      this.framesize -= 4;
      return this.framesize;
   }

   public int version() {
      return this.hVersion;
   }

   public int layer() {
      return this.hLayer;
   }

   public int bitrateIndex() {
      return this.hBitrateIndex;
   }

   public int sampleFrequency() {
      return this.h_sample_frequency;
   }

   public int frequency() {
      return frequencies[this.hVersion][this.h_sample_frequency];
   }

   public int mode() {
      return this.h_mode;
   }

   public boolean checksums() {
      return this.h_protection_bit == 0;
   }

   public boolean copyright() {
      return this.h_copyright;
   }

   public boolean original() {
      return this.h_original;
   }

   public boolean vbr() {
      return this.h_vbr;
   }

   public int vbrScale() {
      return this.h_vbr_scale;
   }

   public byte[] vbrToc() {
      return this.h_vbr_toc;
   }

   public int vbrFrames() {
      return this.h_vbr_frames;
   }

   public int encoderDelay() {
      return this.h_enc_delay;
   }

   public int encoderPadding() {
      return this.h_enc_padding;
   }

   public int samplesToSkipAtStart() {
      return this.h_enc_delay < 0 ? 0 : this.h_enc_delay + 529;
   }

   public int samplesToSkipAtEnd() {
      return this.h_enc_padding < 0 ? 0 : Math.max(0, this.h_enc_padding - 529);
   }

   public boolean checksumOk() {
      return this.checksum == this.crc.checksum();
   }

   public boolean padding() {
      return this.h_padding_bit != 0;
   }

   public int slots() {
      return this.nSlots;
   }

   public int modeExtension() {
      return this.h_mode_extension;
   }

   public int numberOfSubbands() {
      return this.hNumberOfSubbands;
   }

   public int intensityStereoBound() {
      return this.hIntensityStereoBound;
   }

   public int getSyncHeader() {
      return this._headerstring;
   }

   public int bitrate() {
      return this.h_vbr && this.h_vbr_frames > 0
         ? (int)(this.h_vbr_bytes * 8 / (this.msPerFrame() * this.h_vbr_frames)) * 1000
         : bitrates[this.hVersion][this.hLayer - 1][this.hBitrateIndex];
   }

   public int bitrateInstant() {
      return bitrates[this.hVersion][this.hLayer - 1][this.hBitrateIndex];
   }

   public float msPerFrame() {
      if (!this.h_vbr) {
         return msPerFrames[this.hLayer - 1][this.h_sample_frequency];
      } else {
         double tpf = h_vbr_time_per_frame[this.hLayer] / this.frequency();
         if (this.hVersion == 0 || this.hVersion == 2) {
            tpf /= 2.0;
         }

         return (float)(tpf * 1000.0);
      }
   }

   public int maxNumberOfFrames(int streamSize) {
      if (this.h_vbr) {
         return this.h_vbr_frames;
      } else {
         int frameSizeWithHeader = this.framesize + 4 - this.h_padding_bit;
         return frameSizeWithHeader == 0 ? 0 : streamSize / frameSizeWithHeader;
      }
   }

   public int minNumberOfFrames(int streamSize) {
      if (this.h_vbr) {
         return this.h_vbr_frames;
      } else {
         int frameSizeWithPadding = this.framesize + 5 - this.h_padding_bit;
         return frameSizeWithPadding == 0 ? 0 : streamSize / frameSizeWithPadding;
      }
   }

   public float totalMs(int streamSize) {
      return this.maxNumberOfFrames(streamSize) * this.msPerFrame();
   }

   public String layerString() {
      return switch (this.hLayer) {
         case 1 -> "I";
         case 2 -> "II";
         case 3 -> "III";
         default -> "Unknown";
      };
   }

   public String bitrateString() {
      if (this.h_vbr) {
         return this.bitrate() / 1000 + " kbit/s";
      } else {
         int br = this.bitrateInstant();
         return br == 0 ? "free format" : br / 1000 + " kbit/s";
      }
   }

   public String sampleFrequencyString() {
      int freq = this.frequency();
      if (freq >= 1000) {
         return "%.1f".formatted(freq / 1000.0F) + " kHz";
      } else {
         return freq > 0 ? freq + " Hz" : "Unknown";
      }
   }

   public String modeString() {
      return switch (this.h_mode) {
         case 0 -> "Stereo";
         case 1 -> "Joint stereo";
         case 2 -> "Dual channel";
         case 3 -> "Single channel";
         default -> null;
      };
   }

   public String versionString() {
      return switch (this.hVersion) {
         case 0 -> "MPEG-2 LSF";
         case 1 -> "MPEG-1";
         case 2 -> "MPEG-2.5 LSF";
         default -> "Unknown";
      };
   }

   @Override
   public String toString() {
      return String.format(
         "Layer %s frame %s %s%s checksums %s, %s",
         this.layerString(),
         this.modeString(),
         this.versionString(),
         this.checksums() ? "" : " no",
         this.sampleFrequencyString(),
         this.bitrateString()
      );
   }
}
