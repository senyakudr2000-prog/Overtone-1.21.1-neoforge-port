package dev.musicplayer.jlayer;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Path;

public class FileSource implements Source, AutoCloseable {
   private final RandomAccessFile file;
   private final long length;

   public FileSource(File file) throws IOException {
      this.file = new RandomAccessFile(file, "r");
      this.length = this.file.length();
   }

   public FileSource(Path path) throws IOException {
      this(path.toFile());
   }

   @Override
   public int read(byte[] b, int offs, int len) throws IOException {
      return this.file.read(b, offs, len);
   }

   @Override
   public boolean willReadBlock() {
      return false;
   }

   @Override
   public boolean isSeekable() {
      return true;
   }

   @Override
   public long length() {
      return this.length;
   }

   @Override
   public long tell() {
      try {
         return this.file.getFilePointer();
      } catch (IOException var2) {
         return -1L;
      }
   }

   @Override
   public long seek(long pos) {
      try {
         long wanted = Math.max(0L, Math.min(pos, this.length));
         this.file.seek(wanted);
         return wanted;
      } catch (IOException var5) {
         return -1L;
      }
   }

   @Override
   public void close() throws IOException {
      this.file.close();
   }
}
