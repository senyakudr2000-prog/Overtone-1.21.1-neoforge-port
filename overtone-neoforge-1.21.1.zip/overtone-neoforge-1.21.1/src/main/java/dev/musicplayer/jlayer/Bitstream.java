package dev.musicplayer.jlayer;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.util.Objects;

public final class Bitstream implements BitstreamErrors, AutoCloseable {
   static final byte INITIAL_SYNC = 0;
   static final byte STRICT_SYNC = 1;
   private static final int BUFFER_INT_SIZE = 433;
   private static final int[] bitmask = new int[]{0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535, 131071};
   private final int[] frameBuffer = new int[433];
   private final byte[] frameBytes = new byte[1732];
   private final byte[] syncBuf = new byte[4];
   private PushbackInputStream source;
   private final Source origin;
   private long position;
   private final Header header = new Header();
   private Crc16[] crc = new Crc16[1];
   private byte[] rawId3v2 = null;
   private int frameSize;
   private int wordPointer;
   private int bitIndex;
   private int syncWord;
   private int headerPos = 0;
   private boolean singleChMode;
   private boolean firstFrame = true;
   private boolean eof = false;
   private boolean closed = false;
   private long totalFramesRead = 0L;
   private long totalBytesRead = 0L;

   public Bitstream(InputStream in) {
      this(in, null);
   }

   public Bitstream(Source source) {
      this(asStream(Objects.requireNonNull(source, "Source cannot be null")), source);
   }

   private Bitstream(InputStream in, Source origin) {
      Objects.requireNonNull(in, "InputStream cannot be null");
      this.origin = origin;
      InputStream var3 = new BufferedInputStream(in);
      this.loadID3v2(var3);
      this.firstFrame = true;
      this.position = this.headerPos;
      this.source = new PushbackInputStream(var3, 1732);
      this.closeFrame();
   }

   private static InputStream asStream(final Source source) {
      return new InputStream() {
         @Override
         public int read() throws IOException {
            byte[] one = new byte[1];
            int read = source.read(one, 0, 1);
            return read <= 0 ? -1 : one[0] & 0xFF;
         }

         @Override
         public int read(byte[] b, int offs, int len) throws IOException {
            return source.read(b, offs, len);
         }

         @Override
         public void close() throws IOException {
            if (source instanceof AutoCloseable closeable) {
               try {
                  closeable.close();
               } catch (IOException var3) {
                  throw var3;
               } catch (Exception var4) {
                  throw new IOException(var4);
               }
            }
         }
      };
   }

   public int getHeaderPosition() {
      return this.headerPos;
   }

   @Deprecated
   public int header_pos() {
      return this.headerPos;
   }

   private void loadID3v2(InputStream in) {
      int size = -1;

      try {
         in.mark(10);
         size = readID3v2Header(in);
         this.headerPos = size;
      } catch (IOException var14) {
      } finally {
         try {
            in.reset();
         } catch (IOException var12) {
         }
      }

      if (size > 0) {
         try {
            this.rawId3v2 = new byte[size];
            in.readNBytes(this.rawId3v2, 0, this.rawId3v2.length);
         } catch (IOException var13) {
            this.rawId3v2 = null;
         }
      }
   }

   private static int readID3v2Header(InputStream in) throws IOException {
      byte[] id3header = new byte[4];
      int size = -10;
      in.readNBytes(id3header, 0, 3);
      if (id3header[0] == 73 && id3header[1] == 68 && id3header[2] == 51) {
         in.readNBytes(id3header, 0, 3);
         in.readNBytes(id3header, 0, 4);
         size = (id3header[0] << 21) + (id3header[1] << 14) + (id3header[2] << 7) + id3header[3];
      }

      return size + 10;
   }

   public InputStream getRawID3v2() {
      return this.rawId3v2 == null ? null : new ByteArrayInputStream(this.rawId3v2);
   }

   public boolean hasID3v2Tag() {
      return this.rawId3v2 != null && this.rawId3v2.length > 0;
   }

   public int getID3v2TagSize() {
      return this.rawId3v2 == null ? 0 : this.rawId3v2.length;
   }

   public Header readFrame() throws BitstreamException {
      Header result = null;

      try {
         result = this.readNextFrame();
         if (this.firstFrame && result != null) {
            result.parseVBR(this.frameBytes);
            this.firstFrame = false;
            if (result.vbr()) {
               this.closeFrame();
               Header audio = this.readNextFrame();
               if (audio != null) {
                  audio.copyVbrFrom(result);
               }

               result = audio;
            }
         }
      } catch (BitstreamException var5) {
         if (var5.getErrorCode() == 261) {
            try {
               this.closeFrame();
               result = this.readNextFrame();
            } catch (BitstreamException var4) {
               if (var4.getErrorCode() != 260) {
                  throw this.newBitstreamException(var4.getErrorCode(), var4);
               }
            }
         } else if (var5.getErrorCode() != 260) {
            throw var5;
         }
      }

      if (result != null) {
         this.totalFramesRead++;
      }

      return result;
   }

   private Header readNextFrame() throws BitstreamException {
      if (this.eof) {
         return null;
      } else if (this.closed) {
         throw this.newBitstreamException(258, new IllegalStateException("Bitstream is closed"));
      } else {
         if (this.frameSize == -1) {
            this.nextFrame();
         }

         return this.header;
      }
   }

   private void nextFrame() throws BitstreamException {
      this.header.read_header(this, this.crc);
      if (this.frameSize > 0) {
         this.totalBytesRead = this.totalBytesRead + this.frameSize;
      }
   }

   public boolean isSeekable() {
      return this.origin != null && this.origin.isSeekable();
   }

   public long position() {
      return this.position;
   }

   public long length() {
      return this.origin == null ? -1L : this.origin.length();
   }

   public long seek(long position) throws BitstreamException {
      if (this.closed) {
         throw this.newBitstreamException(258, new IllegalStateException("Bitstream is closed"));
      } else if (!this.isSeekable()) {
         return -1L;
      } else {
         long landed = this.origin.seek(Math.max(0L, position));
         if (landed == -1L) {
            throw this.newBitstreamException(258, new IOException("the source refused to seek to " + position));
         } else {
            this.source = new PushbackInputStream(new BufferedInputStream(asStream(this.origin)), 1732);
            this.position = landed;
            this.eof = false;
            this.firstFrame = false;
            this.closeFrame();
            return landed;
         }
      }
   }

   public void closeFrame() {
      this.frameSize = -1;
      this.wordPointer = -1;
      this.bitIndex = -1;
   }

   BitstreamException newBitstreamException(int errorCode) {
      return new BitstreamException(errorCode, null);
   }

   BitstreamException newBitstreamException(int errorCode, Throwable cause) {
      return new BitstreamException(errorCode, cause);
   }

   public int readBits(int n) {
      return this.getBits(n);
   }

   public int readCheckedBits(int n) {
      return this.getBits(n);
   }

   int syncHeader(byte syncMode) throws BitstreamException {
      int bytesRead = this.readBytes(this.syncBuf, 0, 3);
      if (bytesRead != 3) {
         throw this.newBitstreamException(260, null);
      } else {
         int headerString = this.syncBuf[0] << 16 & 0xFF0000 | this.syncBuf[1] << 8 & 0xFF00 | this.syncBuf[2] << 0 & 0xFF;

         boolean sync;
         do {
            headerString <<= 8;
            if (this.readBytes(this.syncBuf, 3, 1) != 1) {
               throw this.newBitstreamException(260, null);
            }

            headerString |= this.syncBuf[3] & 255;
            sync = this.isSyncMark(headerString, syncMode, this.syncWord);
         } while (!sync);

         return headerString;
      }
   }

   public boolean isSyncMark(int headerString, int syncMode, int word) {
      boolean sync;
      if (syncMode == 0) {
         sync = (headerString & -2097152) == -2097152;
      } else {
         sync = (headerString & -521216) == word && (headerString & 192) == 192 == this.singleChMode;
      }

      if (sync) {
         sync = (headerString >>> 10 & 3) != 3;
      }

      if (sync) {
         sync = (headerString >>> 17 & 3) != 0;
      }

      if (sync) {
         sync = (headerString >>> 19 & 3) != 1;
      }

      return sync;
   }

   int readFrameData(int byteSize) throws BitstreamException {
      int numread = this.readFully(this.frameBytes, 0, byteSize);
      this.frameSize = byteSize;
      this.wordPointer = -1;
      this.bitIndex = -1;
      return numread;
   }

   void parseFrame() {
      int b = 0;
      int byteSize = this.frameSize;

      for (int k = 0; k < byteSize; k += 4) {
         byte b0 = this.frameBytes[k];
         byte b1 = k + 1 < byteSize ? this.frameBytes[k + 1] : 0;
         byte b2 = k + 2 < byteSize ? this.frameBytes[k + 2] : 0;
         byte b3 = k + 3 < byteSize ? this.frameBytes[k + 3] : 0;
         this.frameBuffer[b++] = b0 << 24 & 0xFF000000 | b1 << 16 & 0xFF0000 | b2 << 8 & 0xFF00 | b3 & 255;
      }

      this.wordPointer = 0;
      this.bitIndex = 0;
   }

   public int getBits(int numberOfBits) {
      if (numberOfBits <= 0) {
         return 0;
      } else if (numberOfBits > 32) {
         throw new IllegalArgumentException("Cannot read more than 32 bits at once: " + numberOfBits);
      } else {
         int sum = this.bitIndex + numberOfBits;
         if (this.wordPointer < 0) {
            this.wordPointer = 0;
         }

         int maxWords = (this.frameSize + 3) / 4;
         if (maxWords <= 0) {
            return 0;
         } else if (sum <= 32) {
            if (this.wordPointer >= maxWords) {
               return 0;
            } else {
               int w = this.frameBuffer[this.wordPointer];
               int returnValue = w >>> 32 - sum & bitmask[numberOfBits];
               this.bitIndex += numberOfBits;
               if (this.bitIndex == 32) {
                  this.bitIndex = 0;
                  this.wordPointer++;
                  if (this.wordPointer >= maxWords) {
                     this.wordPointer = maxWords - 1;
                     this.bitIndex = 0;
                  }
               }

               return returnValue;
            }
         } else if (this.wordPointer >= maxWords) {
            return 0;
         } else {
            int right = this.frameBuffer[this.wordPointer] & 65535;
            this.wordPointer++;
            int left = 0;
            if (this.wordPointer < maxWords) {
               left = this.frameBuffer[this.wordPointer] & -65536;
            }

            int returnValue = right << 16 & -65536 | left >>> 16 & 65535;
            returnValue >>>= 48 - sum;
            returnValue &= bitmask[numberOfBits];
            this.bitIndex = sum - 32;
            return returnValue;
         }
      }
   }

   public boolean isSyncCurrentPosition(int syncmode) throws BitstreamException {
      int read = this.readBytes(this.syncBuf, 0, 4);
      int headerString = this.syncBuf[0] << 24 & 0xFF000000 | this.syncBuf[1] << 16 & 0xFF0000 | this.syncBuf[2] << 8 & 0xFF00 | this.syncBuf[3] & 255;

      try {
         this.source.unread(this.syncBuf, 0, read);
         this.position -= read;
      } catch (IOException var5) {
      }
      return switch (read) {
         case 0 -> true;
         case 4 -> this.isSyncMark(headerString, syncmode, this.syncWord);
         default -> false;
      };
   }

   public void unreadFrame() throws BitstreamException {
      if (this.wordPointer == -1 && this.bitIndex == -1 && this.frameSize > 0) {
         try {
            this.source.unread(this.frameBytes, 0, this.frameSize);
            this.position = this.position - this.frameSize;
         } catch (IOException var2) {
            throw this.newBitstreamException(258, var2);
         }
      }
   }

   public int getBit() {
      return this.getBits(1);
   }

   public void skipBits(int numberOfBits) {
      this.getBits(numberOfBits);
   }

   public int getBitPosition() {
      return this.wordPointer * 32 + this.bitIndex;
   }

   void setSyncWord(int syncWord) {
      this.syncWord = syncWord & -193;
      this.singleChMode = (syncWord & 192) == 192;
   }

   private int readFully(byte[] b, int offs, int len) throws BitstreamException {
      int nRead = 0;

      try {
         while (len > 0) {
            int bytesRead = this.source.read(b, offs, len);
            if (bytesRead == -1) {
               this.eof = true;

               while (len-- > 0) {
                  b[offs++] = 0;
               }
               break;
            }

            nRead += bytesRead;
            this.position += bytesRead;
            offs += bytesRead;
            len -= bytesRead;
         }

         return nRead;
      } catch (IOException var6) {
         throw this.newBitstreamException(258, var6);
      }
   }

   private int readBytes(byte[] b, int offs, int len) throws BitstreamException {
      int totalBytesRead = 0;

      try {
         while (len > 0) {
            int bytesread = this.source.read(b, offs, len);
            if (bytesread == -1) {
               this.eof = true;
               break;
            }

            totalBytesRead += bytesread;
            this.position += bytesread;
            offs += bytesread;
            len -= bytesread;
         }

         return totalBytesRead;
      } catch (IOException var6) {
         throw this.newBitstreamException(258, var6);
      }
   }

   public byte[] getFrameBytes() {
      if (this.frameSize <= 0) {
         return null;
      } else {
         byte[] out = new byte[this.frameSize];
         System.arraycopy(this.frameBytes, 0, out, 0, this.frameSize);
         return out;
      }
   }

   public int getFrameSize() {
      return this.frameSize;
   }

   public boolean isEOF() {
      return this.eof;
   }

   public boolean isClosed() {
      return this.closed;
   }

   public long getTotalFramesRead() {
      return this.totalFramesRead;
   }

   public long getTotalBytesRead() {
      return this.totalBytesRead;
   }

   public String getStatistics() {
      return "Bitstream Statistics: frames=%d, bytes=%d, ID3v2=%d bytes".formatted(this.totalFramesRead, this.totalBytesRead, this.getID3v2TagSize());
   }

   public void resetStatistics() {
      this.totalFramesRead = 0L;
      this.totalBytesRead = 0L;
   }

   @Override
   public void close() throws BitstreamException {
      if (!this.closed) {
         try {
            this.source.close();
         } catch (IOException var5) {
            throw new BitstreamException(var5);
         } finally {
            this.closed = true;
         }
      }
   }

   @Override
   public String toString() {
      return "Bitstream[closed=%b, eof=%b, frames=%d, position=%d bits]".formatted(this.closed, this.eof, this.totalFramesRead, this.getBitPosition());
   }
}
