package dev.musicplayer.jlayer;

public class JavaLayerError extends Error {
   public JavaLayerError() {
   }
}
