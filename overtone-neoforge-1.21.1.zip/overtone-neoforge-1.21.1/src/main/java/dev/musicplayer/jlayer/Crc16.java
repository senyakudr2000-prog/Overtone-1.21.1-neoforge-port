package dev.musicplayer.jlayer;

public final class Crc16 {
   private static final short polynomial = -32763;
   private short crc = -1;

   public Crc16() {
   }

   public void addBits(int bitString, int length) {
      int bitmask = 1 << length - 1;

      do {
         if ((this.crc & '\u8000') == 0 ^ (bitString & bitmask) == 0) {
            this.crc = (short)(this.crc << 1);
            this.crc ^= -32763;
         } else {
            this.crc = (short)(this.crc << 1);
         }
      } while ((bitmask >>>= 1) != 0);
   }

   public short checksum() {
      short sum = this.crc;
      this.crc = -1;
      return sum;
   }
}
