package dev.musicplayer.jlayer;

public class BitstreamException extends JavaLayerException implements BitstreamErrors {
   private int errorCode = 256;

   public BitstreamException(String msg, Throwable t) {
      super(msg, t);
   }

   public BitstreamException(int errorCode, Throwable t) {
      this(getErrorString(errorCode), t);
      this.errorCode = errorCode;
   }

   public BitstreamException(Throwable t) {
      this(258, t);
   }

   public int getErrorCode() {
      return this.errorCode;
   }

   public static String getErrorString(int errorcode) {
      return "Bitstream errorCode " + Integer.toHexString(errorcode);
   }
}
