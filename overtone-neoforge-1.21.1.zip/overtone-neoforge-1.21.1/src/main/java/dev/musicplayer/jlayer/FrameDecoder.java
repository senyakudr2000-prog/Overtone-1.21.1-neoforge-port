package dev.musicplayer.jlayer;

public interface FrameDecoder {
   void decodeFrame() throws DecoderException;
}
