package dev.musicplayer.jlayer;

final class LayerIIIDecoder implements FrameDecoder {
   static final double d43 = 1.3333333333333333;
   public final int[] scaleFacBuffer;
   private int checkSumHuff = 0;
   private final int[] is1d;
   private final float[][][] ro;
   private final float[][][] lr;
   private final float[] out1d;
   private final float[][] prevBlock;
   private final float[][] k;
   private final int[] nonzero;
   private final Bitstream stream;
   private final Header header;
   private final SynthesisFilter filter1;
   private final SynthesisFilter filter2;
   private final OBuffer buffer;
   private final int whichChannels;
   private BitReserve br;
   private final LayerIIIDecoder.III_SideInfo si;
   private final LayerIIIDecoder.Temporaire2[] III_scalefac_t;
   private final LayerIIIDecoder.Temporaire2[] scalefac;
   private final int maxGr;
   private int frameStart;
   private int part2Start;
   private final int channels;
   private final int firstChannel;
   private final int lastChannel;
   private final int sfreq;
   private final float[] samples1 = new float[32];
   private final float[] samples2 = new float[32];
   private final int[] newSlen = new int[4];
   final int[] x = new int[]{0};
   final int[] y = new int[]{0};
   final int[] v = new int[]{0};
   final int[] w = new int[]{0};
   final int[] is_pos = new int[576];
   final float[] is_ratio = new float[576];
   final float[] tsOutCopy = new float[18];
   final float[] rawout = new float[36];
   private int counter = 0;
   private static final int SSLIMIT = 18;
   private static final int SBLIMIT = 32;
   private static final int[][] sLen;
   public static final int[] preTab;
   private final LayerIIIDecoder.SBI[] sfBandIndex;
   public static final float[] two_to_negative_half_pow;
   public static final float[] t_43;
   public static final float[][] io;
   public static final float[] TAN12;
   private static int[][] reorderTable;
   private static final float[] cs;
   private static final float[] ca;
   public static final float[][] win;
   public final LayerIIIDecoder.SfTable sfTable;
   public static final int[][][] nr_of_sfb_block;

   public LayerIIIDecoder(Bitstream stream, Header header, SynthesisFilter filterA, SynthesisFilter filterB, OBuffer buffer, int whichCh) {
      HuffCodeTab.initHuff();
      this.is1d = new int[580];
      this.ro = new float[2][32][18];
      this.lr = new float[2][32][18];
      this.out1d = new float[576];
      this.prevBlock = new float[2][576];
      this.k = new float[2][576];
      this.nonzero = new int[2];
      this.III_scalefac_t = new LayerIIIDecoder.Temporaire2[2];
      this.III_scalefac_t[0] = new LayerIIIDecoder.Temporaire2();
      this.III_scalefac_t[1] = new LayerIIIDecoder.Temporaire2();
      this.scalefac = this.III_scalefac_t;
      this.sfBandIndex = new LayerIIIDecoder.SBI[9];
      int[] l0 = new int[]{0, 6, 12, 18, 24, 30, 36, 44, 54, 66, 80, 96, 116, 140, 168, 200, 238, 284, 336, 396, 464, 522, 576};
      int[] s0 = new int[]{0, 4, 8, 12, 18, 24, 32, 42, 56, 74, 100, 132, 174, 192};
      int[] l1 = new int[]{0, 6, 12, 18, 24, 30, 36, 44, 54, 66, 80, 96, 114, 136, 162, 194, 232, 278, 330, 394, 464, 540, 576};
      int[] s1 = new int[]{0, 4, 8, 12, 18, 26, 36, 48, 62, 80, 104, 136, 180, 192};
      int[] l2 = new int[]{0, 6, 12, 18, 24, 30, 36, 44, 54, 66, 80, 96, 116, 140, 168, 200, 238, 284, 336, 396, 464, 522, 576};
      int[] s2 = new int[]{0, 4, 8, 12, 18, 26, 36, 48, 62, 80, 104, 134, 174, 192};
      int[] l3 = new int[]{0, 4, 8, 12, 16, 20, 24, 30, 36, 44, 52, 62, 74, 90, 110, 134, 162, 196, 238, 288, 342, 418, 576};
      int[] s3 = new int[]{0, 4, 8, 12, 16, 22, 30, 40, 52, 66, 84, 106, 136, 192};
      int[] l4 = new int[]{0, 4, 8, 12, 16, 20, 24, 30, 36, 42, 50, 60, 72, 88, 106, 128, 156, 190, 230, 276, 330, 384, 576};
      int[] s4 = new int[]{0, 4, 8, 12, 16, 22, 28, 38, 50, 64, 80, 100, 126, 192};
      int[] l5 = new int[]{0, 4, 8, 12, 16, 20, 24, 30, 36, 44, 54, 66, 82, 102, 126, 156, 194, 240, 296, 364, 448, 550, 576};
      int[] s5 = new int[]{0, 4, 8, 12, 16, 22, 30, 42, 58, 78, 104, 138, 180, 192};
      int[] l6 = new int[]{0, 6, 12, 18, 24, 30, 36, 44, 54, 66, 80, 96, 116, 140, 168, 200, 238, 284, 336, 396, 464, 522, 576};
      int[] s6 = new int[]{0, 4, 8, 12, 18, 26, 36, 48, 62, 80, 104, 134, 174, 192};
      int[] l7 = new int[]{0, 6, 12, 18, 24, 30, 36, 44, 54, 66, 80, 96, 116, 140, 168, 200, 238, 284, 336, 396, 464, 522, 576};
      int[] s7 = new int[]{0, 4, 8, 12, 18, 26, 36, 48, 62, 80, 104, 134, 174, 192};
      int[] l8 = new int[]{0, 12, 24, 36, 48, 60, 72, 88, 108, 132, 160, 192, 232, 280, 336, 400, 476, 566, 568, 570, 572, 574, 576};
      int[] s8 = new int[]{0, 8, 16, 24, 36, 52, 72, 96, 124, 160, 162, 164, 166, 192};
      this.sfBandIndex[0] = new LayerIIIDecoder.SBI(l0, s0);
      this.sfBandIndex[1] = new LayerIIIDecoder.SBI(l1, s1);
      this.sfBandIndex[2] = new LayerIIIDecoder.SBI(l2, s2);
      this.sfBandIndex[3] = new LayerIIIDecoder.SBI(l3, s3);
      this.sfBandIndex[4] = new LayerIIIDecoder.SBI(l4, s4);
      this.sfBandIndex[5] = new LayerIIIDecoder.SBI(l5, s5);
      this.sfBandIndex[6] = new LayerIIIDecoder.SBI(l6, s6);
      this.sfBandIndex[7] = new LayerIIIDecoder.SBI(l7, s7);
      this.sfBandIndex[8] = new LayerIIIDecoder.SBI(l8, s8);
      if (reorderTable == null) {
         reorderTable = new int[9][];

         for (int i = 0; i < 9; i++) {
            reorderTable[i] = reorder(this.sfBandIndex[i].s);
         }
      }

      int[] ll0 = new int[]{0, 6, 11, 16, 21};
      int[] ss0 = new int[]{0, 6, 12};
      this.sfTable = new LayerIIIDecoder.SfTable(ll0, ss0);
      this.scaleFacBuffer = new int[54];
      this.stream = stream;
      this.header = header;
      this.filter1 = filterA;
      this.filter2 = filterB;
      this.buffer = buffer;
      this.whichChannels = whichCh;
      this.frameStart = 0;
      this.channels = this.header.mode() == 3 ? 1 : 2;
      this.maxGr = this.header.version() == 1 ? 2 : 1;
      this.sfreq = this.header.sampleFrequency() + (this.header.version() == 1 ? 3 : (this.header.version() == 2 ? 6 : 0));
      if (this.channels == 2) {
         switch (this.whichChannels) {
            case 0:
            default:
               this.firstChannel = 0;
               this.lastChannel = 1;
               break;
            case 1:
            case 3:
               this.firstChannel = this.lastChannel = 0;
               break;
            case 2:
               this.firstChannel = this.lastChannel = 1;
         }
      } else {
         this.firstChannel = this.lastChannel = 0;
      }

      for (int ch = 0; ch < 2; ch++) {
         for (int j = 0; j < 576; j++) {
            this.prevBlock[ch][j] = 0.0F;
         }
      }

      this.nonzero[0] = this.nonzero[1] = 576;
      this.br = new BitReserve();
      this.si = new LayerIIIDecoder.III_SideInfo();
   }

   public void seek_notify() {
      this.frameStart = 0;

      for (int ch = 0; ch < 2; ch++) {
         for (int j = 0; j < 576; j++) {
            this.prevBlock[ch][j] = 0.0F;
         }
      }

      this.br = new BitReserve();
   }

   @Override
   public void decodeFrame() {
      this.decode();
   }

   public void decode() {
      int nSlots = this.header.slots();
      this.getSideInfo();

      for (int i = 0; i < nSlots; i++) {
         this.br.hputbuf(this.stream.getBits(8));
      }

      int mainDataEnd = this.br.hsstell() >>> 3;
      int flushMain;
      if ((flushMain = this.br.hsstell() & 7) != 0) {
         this.br.hgetbits(8 - flushMain);
         mainDataEnd++;
      }

      int bytesToDiscard = this.frameStart - mainDataEnd - this.si.mainDataBegin;
      this.frameStart += nSlots;
      if (bytesToDiscard >= 0) {
         if (mainDataEnd > 4096) {
            this.frameStart -= 4096;
            this.br.rewindNBytes(4096);
         }

         while (bytesToDiscard > 0) {
            this.br.hgetbits(8);
            bytesToDiscard--;
         }

         for (int gr = 0; gr < this.maxGr; gr++) {
            for (int ch = 0; ch < this.channels; ch++) {
               this.part2Start = this.br.hsstell();
               if (this.header.version() == 1) {
                  this.get_scale_factors(ch, gr);
               } else {
                  this.getLSFScaleFactors(ch, gr);
               }

               this.huffman_decode(ch, gr);
               this.dequantize_sample(this.ro[ch], ch, gr);
            }

            this.stereo(gr);
            if (this.whichChannels == 3 && this.channels > 1) {
               this.do_downmix();
            }

            for (int var11 = this.firstChannel; var11 <= this.lastChannel; var11++) {
               this.reorder(this.lr[var11], var11, gr);
               this.antialias(var11, gr);
               this.hybrid(var11, gr);

               for (int sb18 = 18; sb18 < 576; sb18 += 36) {
                  for (int ss = 1; ss < 18; ss += 2) {
                     this.out1d[sb18 + ss] = -this.out1d[sb18 + ss];
                  }
               }

               if (var11 != 0 && this.whichChannels != 2) {
                  for (int ss = 0; ss < 18; ss++) {
                     int sb = 0;

                     for (int var16 = 0; var16 < 576; var16 += 18) {
                        this.samples2[sb] = this.out1d[var16 + ss];
                        sb++;
                     }

                     this.filter2.inputSamples(this.samples2);
                     this.filter2.calculate_pcm_samples(this.buffer);
                  }
               } else {
                  for (int ss = 0; ss < 18; ss++) {
                     int sb = 0;

                     for (int var15 = 0; var15 < 576; var15 += 18) {
                        this.samples1[sb] = this.out1d[var15 + ss];
                        sb++;
                     }

                     this.filter1.inputSamples(this.samples1);
                     this.filter1.calculate_pcm_samples(this.buffer);
                  }
               }
            }
         }

         this.counter++;
         this.buffer.writeBuffer(1);
      }
   }

   private boolean getSideInfo() {
      if (this.header.version() == 1) {
         this.si.mainDataBegin = this.stream.getBits(9);
         if (this.channels == 1) {
            this.si.privateBits = this.stream.getBits(5);
         } else {
            this.si.privateBits = this.stream.getBits(3);
         }

         for (int ch = 0; ch < this.channels; ch++) {
            this.si.ch[ch].scfsi[0] = this.stream.getBits(1);
            this.si.ch[ch].scfsi[1] = this.stream.getBits(1);
            this.si.ch[ch].scfsi[2] = this.stream.getBits(1);
            this.si.ch[ch].scfsi[3] = this.stream.getBits(1);
         }

         for (int gr = 0; gr < 2; gr++) {
            for (int var3 = 0; var3 < this.channels; var3++) {
               this.si.ch[var3].gr[gr].part2_3_length = this.stream.getBits(12);
               this.si.ch[var3].gr[gr].bigValues = this.stream.getBits(9);
               this.si.ch[var3].gr[gr].globalGain = this.stream.getBits(8);
               this.si.ch[var3].gr[gr].scalefacCompress = this.stream.getBits(4);
               this.si.ch[var3].gr[gr].windowSwitchingFlag = this.stream.getBits(1);
               if (this.si.ch[var3].gr[gr].windowSwitchingFlag != 0) {
                  this.si.ch[var3].gr[gr].blockType = this.stream.getBits(2);
                  this.si.ch[var3].gr[gr].mixedBlockFlag = this.stream.getBits(1);
                  this.si.ch[var3].gr[gr].tableSelect[0] = this.stream.getBits(5);
                  this.si.ch[var3].gr[gr].tableSelect[1] = this.stream.getBits(5);
                  this.si.ch[var3].gr[gr].subblockGain[0] = this.stream.getBits(3);
                  this.si.ch[var3].gr[gr].subblockGain[1] = this.stream.getBits(3);
                  this.si.ch[var3].gr[gr].subblockGain[2] = this.stream.getBits(3);
                  if (this.si.ch[var3].gr[gr].blockType == 0) {
                     return false;
                  }

                  if (this.si.ch[var3].gr[gr].blockType == 2 && this.si.ch[var3].gr[gr].mixedBlockFlag == 0) {
                     this.si.ch[var3].gr[gr].region0Count = 8;
                  } else {
                     this.si.ch[var3].gr[gr].region0Count = 7;
                  }

                  this.si.ch[var3].gr[gr].region1Count = 20 - this.si.ch[var3].gr[gr].region0Count;
               } else {
                  this.si.ch[var3].gr[gr].tableSelect[0] = this.stream.getBits(5);
                  this.si.ch[var3].gr[gr].tableSelect[1] = this.stream.getBits(5);
                  this.si.ch[var3].gr[gr].tableSelect[2] = this.stream.getBits(5);
                  this.si.ch[var3].gr[gr].region0Count = this.stream.getBits(4);
                  this.si.ch[var3].gr[gr].region1Count = this.stream.getBits(3);
                  this.si.ch[var3].gr[gr].blockType = 0;
               }

               this.si.ch[var3].gr[gr].preflag = this.stream.getBits(1);
               this.si.ch[var3].gr[gr].scalefacScale = this.stream.getBits(1);
               this.si.ch[var3].gr[gr].count1TableSelect = this.stream.getBits(1);
            }
         }
      } else {
         this.si.mainDataBegin = this.stream.getBits(8);
         if (this.channels == 1) {
            this.si.privateBits = this.stream.getBits(1);
         } else {
            this.si.privateBits = this.stream.getBits(2);
         }

         for (int ch = 0; ch < this.channels; ch++) {
            this.si.ch[ch].gr[0].part2_3_length = this.stream.getBits(12);
            this.si.ch[ch].gr[0].bigValues = this.stream.getBits(9);
            this.si.ch[ch].gr[0].globalGain = this.stream.getBits(8);
            this.si.ch[ch].gr[0].scalefacCompress = this.stream.getBits(9);
            this.si.ch[ch].gr[0].windowSwitchingFlag = this.stream.getBits(1);
            if (this.si.ch[ch].gr[0].windowSwitchingFlag != 0) {
               this.si.ch[ch].gr[0].blockType = this.stream.getBits(2);
               this.si.ch[ch].gr[0].mixedBlockFlag = this.stream.getBits(1);
               this.si.ch[ch].gr[0].tableSelect[0] = this.stream.getBits(5);
               this.si.ch[ch].gr[0].tableSelect[1] = this.stream.getBits(5);
               this.si.ch[ch].gr[0].subblockGain[0] = this.stream.getBits(3);
               this.si.ch[ch].gr[0].subblockGain[1] = this.stream.getBits(3);
               this.si.ch[ch].gr[0].subblockGain[2] = this.stream.getBits(3);
               if (this.si.ch[ch].gr[0].blockType == 0) {
                  return false;
               }

               if (this.si.ch[ch].gr[0].blockType == 2 && this.si.ch[ch].gr[0].mixedBlockFlag == 0) {
                  this.si.ch[ch].gr[0].region0Count = 8;
               } else {
                  this.si.ch[ch].gr[0].region0Count = 7;
                  this.si.ch[ch].gr[0].region1Count = 20 - this.si.ch[ch].gr[0].region0Count;
               }
            } else {
               this.si.ch[ch].gr[0].tableSelect[0] = this.stream.getBits(5);
               this.si.ch[ch].gr[0].tableSelect[1] = this.stream.getBits(5);
               this.si.ch[ch].gr[0].tableSelect[2] = this.stream.getBits(5);
               this.si.ch[ch].gr[0].region0Count = this.stream.getBits(4);
               this.si.ch[ch].gr[0].region1Count = this.stream.getBits(3);
               this.si.ch[ch].gr[0].blockType = 0;
            }

            this.si.ch[ch].gr[0].scalefacScale = this.stream.getBits(1);
            this.si.ch[ch].gr[0].count1TableSelect = this.stream.getBits(1);
         }
      }

      return true;
   }

   private void get_scale_factors(int ch, int gr) {
      LayerIIIDecoder.GrInfoS grInfo = this.si.ch[ch].gr[gr];
      int scaleComp = grInfo.scalefacCompress;
      int length0 = sLen[0][scaleComp];
      int length1 = sLen[1][scaleComp];
      if (grInfo.windowSwitchingFlag != 0 && grInfo.blockType == 2) {
         if (grInfo.mixedBlockFlag != 0) {
            for (int sfb = 0; sfb < 8; sfb++) {
               this.scalefac[ch].l[sfb] = this.br.hgetbits(sLen[0][grInfo.scalefacCompress]);
            }

            for (int var9 = 3; var9 < 6; var9++) {
               for (int window = 0; window < 3; window++) {
                  this.scalefac[ch].s[window][var9] = this.br.hgetbits(sLen[0][grInfo.scalefacCompress]);
               }
            }

            for (int var10 = 6; var10 < 12; var10++) {
               for (int window = 0; window < 3; window++) {
                  this.scalefac[ch].s[window][var10] = this.br.hgetbits(sLen[1][grInfo.scalefacCompress]);
               }
            }

            int var11 = 12;

            for (int window = 0; window < 3; window++) {
               this.scalefac[ch].s[window][var11] = 0;
            }
         } else {
            this.scalefac[ch].s[0][0] = this.br.hgetbits(length0);
            this.scalefac[ch].s[1][0] = this.br.hgetbits(length0);
            this.scalefac[ch].s[2][0] = this.br.hgetbits(length0);
            this.scalefac[ch].s[0][1] = this.br.hgetbits(length0);
            this.scalefac[ch].s[1][1] = this.br.hgetbits(length0);
            this.scalefac[ch].s[2][1] = this.br.hgetbits(length0);
            this.scalefac[ch].s[0][2] = this.br.hgetbits(length0);
            this.scalefac[ch].s[1][2] = this.br.hgetbits(length0);
            this.scalefac[ch].s[2][2] = this.br.hgetbits(length0);
            this.scalefac[ch].s[0][3] = this.br.hgetbits(length0);
            this.scalefac[ch].s[1][3] = this.br.hgetbits(length0);
            this.scalefac[ch].s[2][3] = this.br.hgetbits(length0);
            this.scalefac[ch].s[0][4] = this.br.hgetbits(length0);
            this.scalefac[ch].s[1][4] = this.br.hgetbits(length0);
            this.scalefac[ch].s[2][4] = this.br.hgetbits(length0);
            this.scalefac[ch].s[0][5] = this.br.hgetbits(length0);
            this.scalefac[ch].s[1][5] = this.br.hgetbits(length0);
            this.scalefac[ch].s[2][5] = this.br.hgetbits(length0);
            this.scalefac[ch].s[0][6] = this.br.hgetbits(length1);
            this.scalefac[ch].s[1][6] = this.br.hgetbits(length1);
            this.scalefac[ch].s[2][6] = this.br.hgetbits(length1);
            this.scalefac[ch].s[0][7] = this.br.hgetbits(length1);
            this.scalefac[ch].s[1][7] = this.br.hgetbits(length1);
            this.scalefac[ch].s[2][7] = this.br.hgetbits(length1);
            this.scalefac[ch].s[0][8] = this.br.hgetbits(length1);
            this.scalefac[ch].s[1][8] = this.br.hgetbits(length1);
            this.scalefac[ch].s[2][8] = this.br.hgetbits(length1);
            this.scalefac[ch].s[0][9] = this.br.hgetbits(length1);
            this.scalefac[ch].s[1][9] = this.br.hgetbits(length1);
            this.scalefac[ch].s[2][9] = this.br.hgetbits(length1);
            this.scalefac[ch].s[0][10] = this.br.hgetbits(length1);
            this.scalefac[ch].s[1][10] = this.br.hgetbits(length1);
            this.scalefac[ch].s[2][10] = this.br.hgetbits(length1);
            this.scalefac[ch].s[0][11] = this.br.hgetbits(length1);
            this.scalefac[ch].s[1][11] = this.br.hgetbits(length1);
            this.scalefac[ch].s[2][11] = this.br.hgetbits(length1);
            this.scalefac[ch].s[0][12] = 0;
            this.scalefac[ch].s[1][12] = 0;
            this.scalefac[ch].s[2][12] = 0;
         }
      } else {
         if (this.si.ch[ch].scfsi[0] == 0 || gr == 0) {
            this.scalefac[ch].l[0] = this.br.hgetbits(length0);
            this.scalefac[ch].l[1] = this.br.hgetbits(length0);
            this.scalefac[ch].l[2] = this.br.hgetbits(length0);
            this.scalefac[ch].l[3] = this.br.hgetbits(length0);
            this.scalefac[ch].l[4] = this.br.hgetbits(length0);
            this.scalefac[ch].l[5] = this.br.hgetbits(length0);
         }

         if (this.si.ch[ch].scfsi[1] == 0 || gr == 0) {
            this.scalefac[ch].l[6] = this.br.hgetbits(length0);
            this.scalefac[ch].l[7] = this.br.hgetbits(length0);
            this.scalefac[ch].l[8] = this.br.hgetbits(length0);
            this.scalefac[ch].l[9] = this.br.hgetbits(length0);
            this.scalefac[ch].l[10] = this.br.hgetbits(length0);
         }

         if (this.si.ch[ch].scfsi[2] == 0 || gr == 0) {
            this.scalefac[ch].l[11] = this.br.hgetbits(length1);
            this.scalefac[ch].l[12] = this.br.hgetbits(length1);
            this.scalefac[ch].l[13] = this.br.hgetbits(length1);
            this.scalefac[ch].l[14] = this.br.hgetbits(length1);
            this.scalefac[ch].l[15] = this.br.hgetbits(length1);
         }

         if (this.si.ch[ch].scfsi[3] == 0 || gr == 0) {
            this.scalefac[ch].l[16] = this.br.hgetbits(length1);
            this.scalefac[ch].l[17] = this.br.hgetbits(length1);
            this.scalefac[ch].l[18] = this.br.hgetbits(length1);
            this.scalefac[ch].l[19] = this.br.hgetbits(length1);
            this.scalefac[ch].l[20] = this.br.hgetbits(length1);
         }

         this.scalefac[ch].l[21] = 0;
         this.scalefac[ch].l[22] = 0;
      }
   }

   private void getLSFScaleData(int ch, int gr) {
      int mode_ext = this.header.modeExtension();
      int blockNumber = 0;
      LayerIIIDecoder.GrInfoS grInfo = this.si.ch[ch].gr[gr];
      int scalefacComp = grInfo.scalefacCompress;
      int blockTypeNumber;
      if (grInfo.blockType == 2) {
         if (grInfo.mixedBlockFlag == 0) {
            blockTypeNumber = 1;
         } else if (grInfo.mixedBlockFlag == 1) {
            blockTypeNumber = 2;
         } else {
            blockTypeNumber = 0;
         }
      } else {
         blockTypeNumber = 0;
      }

      if (mode_ext != 1 && mode_ext != 3 || ch != 1) {
         if (scalefacComp < 400) {
            this.newSlen[0] = (scalefacComp >>> 4) / 5;
            this.newSlen[1] = (scalefacComp >>> 4) % 5;
            this.newSlen[2] = (scalefacComp & 15) >>> 2;
            this.newSlen[3] = scalefacComp & 3;
            this.si.ch[ch].gr[gr].preflag = 0;
            blockNumber = 0;
         } else if (scalefacComp < 500) {
            this.newSlen[0] = (scalefacComp - 400 >>> 2) / 5;
            this.newSlen[1] = (scalefacComp - 400 >>> 2) % 5;
            this.newSlen[2] = scalefacComp - 400 & 3;
            this.newSlen[3] = 0;
            this.si.ch[ch].gr[gr].preflag = 0;
            blockNumber = 1;
         } else if (scalefacComp < 512) {
            this.newSlen[0] = (scalefacComp - 500) / 3;
            this.newSlen[1] = (scalefacComp - 500) % 3;
            this.newSlen[2] = 0;
            this.newSlen[3] = 0;
            this.si.ch[ch].gr[gr].preflag = 1;
            blockNumber = 2;
         }
      }

      if ((mode_ext == 1 || mode_ext == 3) && ch == 1) {
         int intScalefacComp = scalefacComp >>> 1;
         if (intScalefacComp < 180) {
            this.newSlen[0] = intScalefacComp / 36;
            this.newSlen[1] = intScalefacComp % 36 / 6;
            this.newSlen[2] = intScalefacComp % 36 % 6;
            this.newSlen[3] = 0;
            this.si.ch[ch].gr[gr].preflag = 0;
            blockNumber = 3;
         } else if (intScalefacComp < 244) {
            this.newSlen[0] = (intScalefacComp - 180 & 63) >>> 4;
            this.newSlen[1] = (intScalefacComp - 180 & 15) >>> 2;
            this.newSlen[2] = intScalefacComp - 180 & 3;
            this.newSlen[3] = 0;
            this.si.ch[ch].gr[gr].preflag = 0;
            blockNumber = 4;
         } else if (intScalefacComp < 255) {
            this.newSlen[0] = (intScalefacComp - 244) / 3;
            this.newSlen[1] = (intScalefacComp - 244) % 3;
            this.newSlen[2] = 0;
            this.newSlen[3] = 0;
            this.si.ch[ch].gr[gr].preflag = 0;
            blockNumber = 5;
         }
      }

      for (int x = 0; x < 45; x++) {
         this.scaleFacBuffer[x] = 0;
      }

      int m = 0;

      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < nr_of_sfb_block[blockNumber][blockTypeNumber][i]; j++) {
            this.scaleFacBuffer[m] = this.newSlen[i] == 0 ? 0 : this.br.hgetbits(this.newSlen[i]);
            m++;
         }
      }
   }

   private void getLSFScaleFactors(int ch, int gr) {
      int m = 0;
      LayerIIIDecoder.GrInfoS grInfo = this.si.ch[ch].gr[gr];
      this.getLSFScaleData(ch, gr);
      if (grInfo.windowSwitchingFlag == 0 || grInfo.blockType != 2) {
         for (int sfb = 0; sfb < 21; sfb++) {
            this.scalefac[ch].l[sfb] = this.scaleFacBuffer[m];
            m++;
         }

         this.scalefac[ch].l[21] = 0;
         this.scalefac[ch].l[22] = 0;
      } else if (grInfo.mixedBlockFlag != 0) {
         for (int sfb = 0; sfb < 8; sfb++) {
            this.scalefac[ch].l[sfb] = this.scaleFacBuffer[m];
            m++;
         }

         for (int var7 = 3; var7 < 12; var7++) {
            for (int window = 0; window < 3; window++) {
               this.scalefac[ch].s[window][var7] = this.scaleFacBuffer[m];
               m++;
            }
         }

         for (int window = 0; window < 3; window++) {
            this.scalefac[ch].s[window][12] = 0;
         }
      } else {
         for (int sfb = 0; sfb < 12; sfb++) {
            for (int window = 0; window < 3; window++) {
               this.scalefac[ch].s[window][sfb] = this.scaleFacBuffer[m];
               m++;
            }
         }

         for (int window = 0; window < 3; window++) {
            this.scalefac[ch].s[window][12] = 0;
         }
      }
   }

   private void huffman_decode(int ch, int gr) {
      this.x[0] = 0;
      this.y[0] = 0;
      this.v[0] = 0;
      this.w[0] = 0;
      int part2_3_end = this.part2Start + this.si.ch[ch].gr[gr].part2_3_length;
      int region1Start;
      int region2Start;
      if (this.si.ch[ch].gr[gr].windowSwitchingFlag != 0 && this.si.ch[ch].gr[gr].blockType == 2) {
         region1Start = this.sfreq == 8 ? 72 : 36;
         region2Start = 576;
      } else {
         int buf = this.si.ch[ch].gr[gr].region0Count + 1;
         int buf1 = buf + this.si.ch[ch].gr[gr].region1Count + 1;
         if (buf1 > this.sfBandIndex[this.sfreq].l.length - 1) {
            buf1 = this.sfBandIndex[this.sfreq].l.length - 1;
         }

         region1Start = this.sfBandIndex[this.sfreq].l[buf];
         region2Start = this.sfBandIndex[this.sfreq].l[buf1];
      }

      int index = 0;

      for (int i = 0; i < this.si.ch[ch].gr[gr].bigValues << 1; i += 2) {
         HuffCodeTab h;
         if (i < region1Start) {
            h = HuffCodeTab.ht[this.si.ch[ch].gr[gr].tableSelect[0]];
         } else if (i < region2Start) {
            h = HuffCodeTab.ht[this.si.ch[ch].gr[gr].tableSelect[1]];
         } else {
            h = HuffCodeTab.ht[this.si.ch[ch].gr[gr].tableSelect[2]];
         }

         HuffCodeTab.huffman_decoder(h, this.x, this.y, this.v, this.w, this.br);
         this.is1d[index++] = this.x[0];
         this.is1d[index++] = this.y[0];
         this.checkSumHuff = this.checkSumHuff + this.x[0] + this.y[0];
      }

      HuffCodeTab h = HuffCodeTab.ht[this.si.ch[ch].gr[gr].count1TableSelect + 32];

      int num_bits;
      for (num_bits = this.br.hsstell(); num_bits < part2_3_end && index < 576; num_bits = this.br.hsstell()) {
         HuffCodeTab.huffman_decoder(h, this.x, this.y, this.v, this.w, this.br);
         this.is1d[index++] = this.v[0];
         this.is1d[index++] = this.w[0];
         this.is1d[index++] = this.x[0];
         this.is1d[index++] = this.y[0];
         this.checkSumHuff = this.checkSumHuff + this.v[0] + this.w[0] + this.x[0] + this.y[0];
      }

      if (num_bits > part2_3_end) {
         this.br.rewindNBits(num_bits - part2_3_end);
         index -= 4;
      }

      num_bits = this.br.hsstell();
      if (num_bits < part2_3_end) {
         this.br.hgetbits(part2_3_end - num_bits);
      }

      this.nonzero[ch] = Math.min(index, 576);
      if (index < 0) {
         index = 0;
      }

      while (index < 576) {
         this.is1d[index] = 0;
         index++;
      }
   }

   private void i_stereo_k_values(int is_pos, int io_type, int i) {
      if (is_pos == 0) {
         this.k[0][i] = 1.0F;
         this.k[1][i] = 1.0F;
      } else if ((is_pos & 1) != 0) {
         this.k[0][i] = io[io_type][is_pos + 1 >>> 1];
         this.k[1][i] = 1.0F;
      } else {
         this.k[0][i] = 1.0F;
         this.k[1][i] = io[io_type][is_pos >>> 1];
      }
   }

   private void dequantize_sample(float[][] xr, int ch, int gr) {
      LayerIIIDecoder.GrInfoS gr_info = this.si.ch[ch].gr[gr];
      int cb = 0;
      int cb_begin = 0;
      int cb_width = 0;
      int index = 0;
      float[][] xr_1d = xr;
      int next_cb_boundary;
      if (gr_info.windowSwitchingFlag == 0 || gr_info.blockType != 2) {
         next_cb_boundary = this.sfBandIndex[this.sfreq].l[1];
      } else if (gr_info.mixedBlockFlag != 0) {
         next_cb_boundary = this.sfBandIndex[this.sfreq].l[1];
      } else {
         cb_width = this.sfBandIndex[this.sfreq].s[1];
         next_cb_boundary = (cb_width << 2) - cb_width;
         cb_begin = 0;
      }

      float g_gain = (float)Math.pow(2.0, 0.25 * (gr_info.globalGain - 210.0));

      for (int j = 0; j < this.nonzero[ch]; j++) {
         int reste = j % 18;
         int quotien = (j - reste) / 18;
         if (this.is1d[j] == 0) {
            xr_1d[quotien][reste] = 0.0F;
         } else {
            int abv = this.is1d[j];
            if (abv < t_43.length) {
               if (this.is1d[j] > 0) {
                  xr_1d[quotien][reste] = g_gain * t_43[abv];
               } else if (-abv < t_43.length) {
                  xr_1d[quotien][reste] = -g_gain * t_43[-abv];
               } else {
                  xr_1d[quotien][reste] = -g_gain * (float)Math.pow(-abv, 1.3333333333333333);
               }
            } else if (this.is1d[j] > 0) {
               xr_1d[quotien][reste] = g_gain * (float)Math.pow(abv, 1.3333333333333333);
            } else {
               xr_1d[quotien][reste] = -g_gain * (float)Math.pow(-abv, 1.3333333333333333);
            }
         }
      }

      for (int var23 = 0; var23 < this.nonzero[ch]; var23++) {
         int reste = var23 % 18;
         int quotien = (var23 - reste) / 18;
         if (index == next_cb_boundary) {
            if (gr_info.windowSwitchingFlag == 0 || gr_info.blockType != 2) {
               next_cb_boundary = this.sfBandIndex[this.sfreq].l[++cb + 1];
            } else if (gr_info.mixedBlockFlag != 0) {
               if (index == this.sfBandIndex[this.sfreq].l[8]) {
                  next_cb_boundary = this.sfBandIndex[this.sfreq].s[4];
                  next_cb_boundary = (next_cb_boundary << 2) - next_cb_boundary;
                  cb = 3;
                  cb_width = this.sfBandIndex[this.sfreq].s[4] - this.sfBandIndex[this.sfreq].s[3];
                  cb_begin = this.sfBandIndex[this.sfreq].s[3];
                  cb_begin = (cb_begin << 2) - cb_begin;
               } else if (index < this.sfBandIndex[this.sfreq].l[8]) {
                  next_cb_boundary = this.sfBandIndex[this.sfreq].l[++cb + 1];
               } else {
                  next_cb_boundary = this.sfBandIndex[this.sfreq].s[++cb + 1];
                  next_cb_boundary = (next_cb_boundary << 2) - next_cb_boundary;
                  cb_begin = this.sfBandIndex[this.sfreq].s[cb];
                  cb_width = this.sfBandIndex[this.sfreq].s[cb + 1] - cb_begin;
                  cb_begin = (cb_begin << 2) - cb_begin;
               }
            } else {
               next_cb_boundary = this.sfBandIndex[this.sfreq].s[++cb + 1];
               next_cb_boundary = (next_cb_boundary << 2) - next_cb_boundary;
               cb_begin = this.sfBandIndex[this.sfreq].s[cb];
               cb_width = this.sfBandIndex[this.sfreq].s[cb + 1] - cb_begin;
               cb_begin = (cb_begin << 2) - cb_begin;
            }
         }

         if (gr_info.windowSwitchingFlag == 0
            || (gr_info.blockType != 2 || gr_info.mixedBlockFlag != 0) && (gr_info.blockType != 2 || gr_info.mixedBlockFlag == 0 || var23 < 36)) {
            int idx = this.scalefac[ch].l[cb];
            if (gr_info.preflag != 0) {
               idx += preTab[cb];
            }

            idx <<= gr_info.scalefacScale;
            xr_1d[quotien][reste] = xr_1d[quotien][reste] * two_to_negative_half_pow[idx];
         } else {
            int t_index = (index - cb_begin) / cb_width;
            int idx = this.scalefac[ch].s[t_index][cb] << gr_info.scalefacScale;
            idx += gr_info.subblockGain[t_index] << 2;
            xr_1d[quotien][reste] = xr_1d[quotien][reste] * two_to_negative_half_pow[idx];
         }

         index++;
      }

      for (int var24 = this.nonzero[ch]; var24 < 576; var24++) {
         int restex = var24 % 18;
         int quotienx = (var24 - restex) / 18;
         if (restex < 0) {
            restex = 0;
         }

         if (quotienx < 0) {
            quotienx = 0;
         }

         xr_1d[quotienx][restex] = 0.0F;
      }
   }

   private void reorder(float[][] xr, int ch, int gr) {
      LayerIIIDecoder.GrInfoS gr_info = this.si.ch[ch].gr[gr];
      float[][] xr_1d = xr;
      if (gr_info.windowSwitchingFlag != 0 && gr_info.blockType == 2) {
         for (int index = 0; index < 576; index++) {
            this.out1d[index] = 0.0F;
         }

         if (gr_info.mixedBlockFlag != 0) {
            for (int var18 = 0; var18 < 36; var18++) {
               int reste = var18 % 18;
               int quotien = (var18 - reste) / 18;
               this.out1d[var18] = xr_1d[quotien][reste];
            }

            for (int sfb = 3; sfb < 13; sfb++) {
               int sfb_start = this.sfBandIndex[this.sfreq].s[sfb];
               int sfb_lines = this.sfBandIndex[this.sfreq].s[sfb + 1] - sfb_start;
               int sfb_start3 = (sfb_start << 2) - sfb_start;
               int freq = 0;

               for (int freq3 = 0; freq < sfb_lines; freq3 += 3) {
                  int src_line = sfb_start3 + freq;
                  int des_line = sfb_start3 + freq3;
                  int reste = src_line % 18;
                  int quotien = (src_line - reste) / 18;
                  this.out1d[des_line] = xr_1d[quotien][reste];
                  src_line += sfb_lines;
                  des_line++;
                  reste = src_line % 18;
                  quotien = (src_line - reste) / 18;
                  this.out1d[des_line] = xr_1d[quotien][reste];
                  src_line += sfb_lines;
                  des_line++;
                  reste = src_line % 18;
                  quotien = (src_line - reste) / 18;
                  this.out1d[des_line] = xr_1d[quotien][reste];
                  freq++;
               }
            }
         } else {
            for (int var19 = 0; var19 < 576; var19++) {
               int j = reorderTable[this.sfreq][var19];
               int reste = j % 18;
               int quotien = (j - reste) / 18;
               this.out1d[var19] = xr_1d[quotien][reste];
            }
         }
      } else {
         for (int index = 0; index < 576; index++) {
            int reste = index % 18;
            int quotien = (index - reste) / 18;
            this.out1d[index] = xr_1d[quotien][reste];
         }
      }
   }

   private void stereo(int gr) {
      if (this.channels == 1) {
         for (int sb = 0; sb < 32; sb++) {
            for (int ss = 0; ss < 18; ss += 3) {
               this.lr[0][sb][ss] = this.ro[0][sb][ss];
               this.lr[0][sb][ss + 1] = this.ro[0][sb][ss + 1];
               this.lr[0][sb][ss + 2] = this.ro[0][sb][ss + 2];
            }
         }
      } else {
         LayerIIIDecoder.GrInfoS gr_info = this.si.ch[0].gr[gr];
         int mode_ext = this.header.modeExtension();
         boolean ms_stereo = this.header.mode() == 1 && (mode_ext & 2) != 0;
         boolean i_stereo = this.header.mode() == 1 && (mode_ext & 1) != 0;
         boolean lsf = this.header.version() == 0 || this.header.version() == 2;
         int io_type = gr_info.scalefacCompress & 1;

         for (int i = 0; i < 576; i++) {
            this.is_pos[i] = 7;
            this.is_ratio[i] = 0.0F;
         }

         if (i_stereo) {
            if (gr_info.windowSwitchingFlag != 0 && gr_info.blockType == 2) {
               if (gr_info.mixedBlockFlag != 0) {
                  int max_sfb = 0;

                  for (int j = 0; j < 3; j++) {
                     int sfbcnt = 2;

                     for (int sfb = 12; sfb >= 3; sfb--) {
                        int var48 = this.sfBandIndex[this.sfreq].s[sfb];
                        int lines = this.sfBandIndex[this.sfreq].s[sfb + 1] - var48;

                        for (int var49 = (var48 << 2) - var48 + (j + 1) * lines - 1; lines > 0; var49--) {
                           if (this.ro[1][var49 / 18][var49 % 18] != 0.0F) {
                              sfbcnt = sfb;
                              sfb = -10;
                              lines = -10;
                           }

                           lines--;
                        }
                     }

                     int var38 = sfbcnt + 1;
                     if (var38 > max_sfb) {
                        max_sfb = var38;
                     }

                     while (var38 < 12) {
                        int temp = this.sfBandIndex[this.sfreq].s[var38];
                        int sb = this.sfBandIndex[this.sfreq].s[var38 + 1] - temp;

                        for (int var50 = (temp << 2) - temp + j * sb; sb > 0; sb--) {
                           this.is_pos[var50] = this.scalefac[1].s[j][var38];
                           if (this.is_pos[var50] != 7) {
                              if (lsf) {
                                 this.i_stereo_k_values(this.is_pos[var50], io_type, var50);
                              } else {
                                 this.is_ratio[var50] = TAN12[this.is_pos[var50]];
                              }
                           }

                           var50++;
                        }

                        var38++;
                     }

                     var38 = this.sfBandIndex[this.sfreq].s[10];
                     int sb = this.sfBandIndex[this.sfreq].s[11] - var38;
                     var38 = (var38 << 2) - var38 + j * sb;
                     int temp = this.sfBandIndex[this.sfreq].s[11];
                     sb = this.sfBandIndex[this.sfreq].s[12] - temp;

                     for (int var51 = (temp << 2) - temp + j * sb; sb > 0; sb--) {
                        this.is_pos[var51] = this.is_pos[var38];
                        if (lsf) {
                           this.k[0][var51] = this.k[0][var38];
                           this.k[1][var51] = this.k[1][var38];
                        } else {
                           this.is_ratio[var51] = this.is_ratio[var38];
                        }

                        var51++;
                     }
                  }

                  if (max_sfb <= 3) {
                     int var52 = 2;
                     int ss = 17;
                     int sb = -1;

                     while (var52 >= 0) {
                        if (this.ro[1][var52][ss] != 0.0F) {
                           sb = (var52 << 4) + (var52 << 1) + ss;
                           var52 = -1;
                        } else if (--ss < 0) {
                           var52--;
                           ss = 17;
                        }
                     }

                     var52 = 0;

                     while (this.sfBandIndex[this.sfreq].l[var52] <= sb) {
                        var52++;
                     }

                     int sfb = var52;

                     for (int var54 = this.sfBandIndex[this.sfreq].l[var52]; sfb < 8; sfb++) {
                        for (int var28 = this.sfBandIndex[this.sfreq].l[sfb + 1] - this.sfBandIndex[this.sfreq].l[sfb]; var28 > 0; var28--) {
                           this.is_pos[var54] = this.scalefac[1].l[sfb];
                           if (this.is_pos[var54] != 7) {
                              if (lsf) {
                                 this.i_stereo_k_values(this.is_pos[var54], io_type, var54);
                              } else {
                                 this.is_ratio[var54] = TAN12[this.is_pos[var54]];
                              }
                           }

                           var54++;
                        }
                     }
                  }
               } else {
                  for (int j = 0; j < 3; j++) {
                     int sfbcnt = -1;

                     for (int sfb = 12; sfb >= 0; sfb--) {
                        int temp = this.sfBandIndex[this.sfreq].s[sfb];
                        int lines = this.sfBandIndex[this.sfreq].s[sfb + 1] - temp;

                        for (int var45 = (temp << 2) - temp + (j + 1) * lines - 1; lines > 0; var45--) {
                           if (this.ro[1][var45 / 18][var45 % 18] != 0.0F) {
                              sfbcnt = sfb;
                              sfb = -10;
                              lines = -10;
                           }

                           lines--;
                        }
                     }

                     for (int var35 = sfbcnt + 1; var35 < 12; var35++) {
                        int temp = this.sfBandIndex[this.sfreq].s[var35];
                        int sb = this.sfBandIndex[this.sfreq].s[var35 + 1] - temp;

                        for (int var46 = (temp << 2) - temp + j * sb; sb > 0; sb--) {
                           this.is_pos[var46] = this.scalefac[1].s[j][var35];
                           if (this.is_pos[var46] != 7) {
                              if (lsf) {
                                 this.i_stereo_k_values(this.is_pos[var46], io_type, var46);
                              } else {
                                 this.is_ratio[var46] = TAN12[this.is_pos[var46]];
                              }
                           }

                           var46++;
                        }
                     }

                     int temp = this.sfBandIndex[this.sfreq].s[10];
                     int temp2 = this.sfBandIndex[this.sfreq].s[11];
                     int sb = temp2 - temp;
                     int var36 = (temp << 2) - temp + j * sb;
                     sb = this.sfBandIndex[this.sfreq].s[12] - temp2;

                     for (int var47 = (temp2 << 2) - temp2 + j * sb; sb > 0; sb--) {
                        this.is_pos[var47] = this.is_pos[var36];
                        if (lsf) {
                           this.k[0][var47] = this.k[0][var36];
                           this.k[1][var47] = this.k[1][var36];
                        } else {
                           this.is_ratio[var47] = this.is_ratio[var36];
                        }

                        var47++;
                     }
                  }
               }
            } else {
               int var42 = 31;
               int ss = 17;
               int sb = 0;

               while (var42 >= 0) {
                  if (this.ro[1][var42][ss] != 0.0F) {
                     sb = (var42 << 4) + (var42 << 1) + ss;
                     var42 = -1;
                  } else if (--ss < 0) {
                     var42--;
                     ss = 17;
                  }
               }

               var42 = 0;

               while (this.sfBandIndex[this.sfreq].l[var42] <= sb) {
                  var42++;
               }

               int sfb = var42;

               for (var42 = this.sfBandIndex[this.sfreq].l[var42]; sfb < 21; sfb++) {
                  for (int var19 = this.sfBandIndex[this.sfreq].l[sfb + 1] - this.sfBandIndex[this.sfreq].l[sfb]; var19 > 0; var19--) {
                     this.is_pos[var42] = this.scalefac[1].l[sfb];
                     if (this.is_pos[var42] != 7) {
                        if (lsf) {
                           this.i_stereo_k_values(this.is_pos[var42], io_type, var42);
                        } else {
                           this.is_ratio[var42] = TAN12[this.is_pos[var42]];
                        }
                     }

                     var42++;
                  }
               }

               sfb = this.sfBandIndex[this.sfreq].l[20];

               for (int var20 = 576 - this.sfBandIndex[this.sfreq].l[21]; var20 > 0 && var42 < 576; var20--) {
                  this.is_pos[var42] = this.is_pos[sfb];
                  if (lsf) {
                     this.k[0][var42] = this.k[0][sfb];
                     this.k[1][var42] = this.k[1][sfb];
                  } else {
                     this.is_ratio[var42] = this.is_ratio[sfb];
                  }

                  var42++;
               }
            }
         }

         int var55 = 0;

         for (int sb = 0; sb < 32; sb++) {
            for (int ss = 0; ss < 18; ss++) {
               if (this.is_pos[var55] == 7) {
                  if (ms_stereo) {
                     this.lr[0][sb][ss] = (this.ro[0][sb][ss] + this.ro[1][sb][ss]) * 0.70710677F;
                     this.lr[1][sb][ss] = (this.ro[0][sb][ss] - this.ro[1][sb][ss]) * 0.70710677F;
                  } else {
                     this.lr[0][sb][ss] = this.ro[0][sb][ss];
                     this.lr[1][sb][ss] = this.ro[1][sb][ss];
                  }
               } else if (i_stereo) {
                  if (lsf) {
                     this.lr[0][sb][ss] = this.ro[0][sb][ss] * this.k[0][var55];
                     this.lr[1][sb][ss] = this.ro[0][sb][ss] * this.k[1][var55];
                  } else {
                     this.lr[1][sb][ss] = this.ro[0][sb][ss] / (1.0F + this.is_ratio[var55]);
                     this.lr[0][sb][ss] = this.lr[1][sb][ss] * this.is_ratio[var55];
                  }
               }

               var55++;
            }
         }
      }
   }

   private void antialias(int ch, int gr) {
      LayerIIIDecoder.GrInfoS gr_info = this.si.ch[ch].gr[gr];
      if (gr_info.windowSwitchingFlag == 0 || gr_info.blockType != 2 || gr_info.mixedBlockFlag != 0) {
         int sb18lim;
         if (gr_info.windowSwitchingFlag != 0 && gr_info.mixedBlockFlag != 0 && gr_info.blockType == 2) {
            sb18lim = 18;
         } else {
            sb18lim = 558;
         }

         for (int sb18 = 0; sb18 < sb18lim; sb18 += 18) {
            for (int ss = 0; ss < 8; ss++) {
               int src_idx1 = sb18 + 17 - ss;
               int src_idx2 = sb18 + 18 + ss;
               float bu = this.out1d[src_idx1];
               float bd = this.out1d[src_idx2];
               this.out1d[src_idx1] = bu * cs[ss] - bd * ca[ss];
               this.out1d[src_idx2] = bd * cs[ss] + bu * ca[ss];
            }
         }
      }
   }

   private void hybrid(int ch, int gr) {
      LayerIIIDecoder.GrInfoS gr_info = this.si.ch[ch].gr[gr];

      for (int sb18 = 0; sb18 < 576; sb18 += 18) {
         int bt = gr_info.windowSwitchingFlag != 0 && gr_info.mixedBlockFlag != 0 && sb18 < 36 ? 0 : gr_info.blockType;
         float[] tsOut = this.out1d;
         System.arraycopy(tsOut, 0 + sb18, this.tsOutCopy, 0, 18);
         this.inv_mdct(this.tsOutCopy, this.rawout, bt);
         System.arraycopy(this.tsOutCopy, 0, tsOut, 0 + sb18, 18);
         float[][] prvblk = this.prevBlock;
         tsOut[0 + sb18] = this.rawout[0] + prvblk[ch][sb18 + 0];
         prvblk[ch][sb18 + 0] = this.rawout[18];
         tsOut[1 + sb18] = this.rawout[1] + prvblk[ch][sb18 + 1];
         prvblk[ch][sb18 + 1] = this.rawout[19];
         tsOut[2 + sb18] = this.rawout[2] + prvblk[ch][sb18 + 2];
         prvblk[ch][sb18 + 2] = this.rawout[20];
         tsOut[3 + sb18] = this.rawout[3] + prvblk[ch][sb18 + 3];
         prvblk[ch][sb18 + 3] = this.rawout[21];
         tsOut[4 + sb18] = this.rawout[4] + prvblk[ch][sb18 + 4];
         prvblk[ch][sb18 + 4] = this.rawout[22];
         tsOut[5 + sb18] = this.rawout[5] + prvblk[ch][sb18 + 5];
         prvblk[ch][sb18 + 5] = this.rawout[23];
         tsOut[6 + sb18] = this.rawout[6] + prvblk[ch][sb18 + 6];
         prvblk[ch][sb18 + 6] = this.rawout[24];
         tsOut[7 + sb18] = this.rawout[7] + prvblk[ch][sb18 + 7];
         prvblk[ch][sb18 + 7] = this.rawout[25];
         tsOut[8 + sb18] = this.rawout[8] + prvblk[ch][sb18 + 8];
         prvblk[ch][sb18 + 8] = this.rawout[26];
         tsOut[9 + sb18] = this.rawout[9] + prvblk[ch][sb18 + 9];
         prvblk[ch][sb18 + 9] = this.rawout[27];
         tsOut[10 + sb18] = this.rawout[10] + prvblk[ch][sb18 + 10];
         prvblk[ch][sb18 + 10] = this.rawout[28];
         tsOut[11 + sb18] = this.rawout[11] + prvblk[ch][sb18 + 11];
         prvblk[ch][sb18 + 11] = this.rawout[29];
         tsOut[12 + sb18] = this.rawout[12] + prvblk[ch][sb18 + 12];
         prvblk[ch][sb18 + 12] = this.rawout[30];
         tsOut[13 + sb18] = this.rawout[13] + prvblk[ch][sb18 + 13];
         prvblk[ch][sb18 + 13] = this.rawout[31];
         tsOut[14 + sb18] = this.rawout[14] + prvblk[ch][sb18 + 14];
         prvblk[ch][sb18 + 14] = this.rawout[32];
         tsOut[15 + sb18] = this.rawout[15] + prvblk[ch][sb18 + 15];
         prvblk[ch][sb18 + 15] = this.rawout[33];
         tsOut[16 + sb18] = this.rawout[16] + prvblk[ch][sb18 + 16];
         prvblk[ch][sb18 + 16] = this.rawout[34];
         tsOut[17 + sb18] = this.rawout[17] + prvblk[ch][sb18 + 17];
         prvblk[ch][sb18 + 17] = this.rawout[35];
      }
   }

   private void do_downmix() {
      for (int sb = 0; sb < 18; sb++) {
         for (int ss = 0; ss < 18; ss += 3) {
            this.lr[0][sb][ss] = (this.lr[0][sb][ss] + this.lr[1][sb][ss]) * 0.5F;
            this.lr[0][sb][ss + 1] = (this.lr[0][sb][ss + 1] + this.lr[1][sb][ss + 1]) * 0.5F;
            this.lr[0][sb][ss + 2] = (this.lr[0][sb][ss + 2] + this.lr[1][sb][ss + 2]) * 0.5F;
         }
      }
   }

   public void inv_mdct(float[] in, float[] out, int block_type) {
      if (block_type == 2) {
         out[0] = 0.0F;
         out[1] = 0.0F;
         out[2] = 0.0F;
         out[3] = 0.0F;
         out[4] = 0.0F;
         out[5] = 0.0F;
         out[6] = 0.0F;
         out[7] = 0.0F;
         out[8] = 0.0F;
         out[9] = 0.0F;
         out[10] = 0.0F;
         out[11] = 0.0F;
         out[12] = 0.0F;
         out[13] = 0.0F;
         out[14] = 0.0F;
         out[15] = 0.0F;
         out[16] = 0.0F;
         out[17] = 0.0F;
         out[18] = 0.0F;
         out[19] = 0.0F;
         out[20] = 0.0F;
         out[21] = 0.0F;
         out[22] = 0.0F;
         out[23] = 0.0F;
         out[24] = 0.0F;
         out[25] = 0.0F;
         out[26] = 0.0F;
         out[27] = 0.0F;
         out[28] = 0.0F;
         out[29] = 0.0F;
         out[30] = 0.0F;
         out[31] = 0.0F;
         out[32] = 0.0F;
         out[33] = 0.0F;
         out[34] = 0.0F;
         out[35] = 0.0F;
         int six_i = 0;

         for (int i = 0; i < 3; i++) {
            in[15 + i] = in[15 + i] + in[12 + i];
            in[12 + i] = in[12 + i] + in[9 + i];
            in[9 + i] = in[9 + i] + in[6 + i];
            in[6 + i] = in[6 + i] + in[3 + i];
            in[3 + i] = in[3 + i] + in[0 + i];
            in[15 + i] = in[15 + i] + in[9 + i];
            in[9 + i] = in[9 + i] + in[3 + i];
            float pp2 = in[12 + i] * 0.5F;
            float pp1 = in[6 + i] * 0.8660254F;
            float sum = in[0 + i] + pp2;
            float tmpf_1 = in[0 + i] - in[12 + i];
            float tmpf_0 = sum + pp1;
            float tmpf_2 = sum - pp1;
            pp2 = in[15 + i] * 0.5F;
            pp1 = in[9 + i] * 0.8660254F;
            sum = in[3 + i] + pp2;
            float tmpf_4 = in[3 + i] - in[15 + i];
            float tmpf_5 = sum + pp1;
            float tmpf_3 = sum - pp1;
            tmpf_3 *= 1.9318516F;
            tmpf_4 *= 0.70710677F;
            tmpf_5 *= 0.5176381F;
            float var50 = tmpf_0 + tmpf_5;
            tmpf_5 = tmpf_0 - tmpf_5;
            float var55 = tmpf_1 + tmpf_4;
            tmpf_4 = tmpf_1 - tmpf_4;
            float var59 = tmpf_2 + tmpf_3;
            tmpf_3 = tmpf_2 - tmpf_3;
            tmpf_0 = var50 * 0.5043145F;
            tmpf_1 = var55 * 0.5411961F;
            tmpf_2 = var59 * 0.6302362F;
            tmpf_3 *= 0.8213398F;
            tmpf_4 *= 1.306563F;
            tmpf_5 *= 3.830649F;
            float tmpf_8 = -tmpf_0 * 0.7933533F;
            float tmpf_9 = -tmpf_0 * 0.6087614F;
            float tmpf_7 = -tmpf_1 * 0.9238795F;
            float tmpf_10 = -tmpf_1 * 0.38268343F;
            float tmpf_6 = -tmpf_2 * 0.9914449F;
            float tmpf_11 = -tmpf_2 * 0.13052619F;
            tmpf_1 = tmpf_4 * 0.38268343F;
            tmpf_2 = tmpf_5 * 0.6087614F;
            float var66 = -tmpf_5 * 0.7933533F;
            tmpf_4 = -tmpf_4 * 0.9238795F;
            tmpf_5 = -tmpf_3 * 0.9914449F;
            tmpf_0 = tmpf_3 * 0.13052619F;
            out[six_i + 6] = out[six_i + 6] + tmpf_0;
            out[six_i + 7] = out[six_i + 7] + tmpf_1;
            out[six_i + 8] = out[six_i + 8] + tmpf_2;
            out[six_i + 9] = out[six_i + 9] + var66;
            out[six_i + 10] = out[six_i + 10] + tmpf_4;
            out[six_i + 11] = out[six_i + 11] + tmpf_5;
            out[six_i + 12] = out[six_i + 12] + tmpf_6;
            out[six_i + 13] = out[six_i + 13] + tmpf_7;
            out[six_i + 14] = out[six_i + 14] + tmpf_8;
            out[six_i + 15] = out[six_i + 15] + tmpf_9;
            out[six_i + 16] = out[six_i + 16] + tmpf_10;
            out[six_i + 17] = out[six_i + 17] + tmpf_11;
            six_i += 6;
         }
      } else {
         in[17] += in[16];
         in[16] += in[15];
         in[15] += in[14];
         in[14] += in[13];
         in[13] += in[12];
         in[12] += in[11];
         in[11] += in[10];
         in[10] += in[9];
         in[9] += in[8];
         in[8] += in[7];
         in[7] += in[6];
         in[6] += in[5];
         in[5] += in[4];
         in[4] += in[3];
         in[3] += in[2];
         in[2] += in[1];
         in[1] += in[0];
         in[17] += in[15];
         in[15] += in[13];
         in[13] += in[11];
         in[11] += in[9];
         in[9] += in[7];
         in[7] += in[5];
         in[5] += in[3];
         in[3] += in[1];
         float i00 = in[0] + in[0];
         float iip12 = i00 + in[12];
         float tmp0 = iip12 + in[4] * 1.8793852F + in[8] * 1.5320889F + in[16] * 0.34729636F;
         float tmp1 = i00 + in[4] - in[8] - in[12] - in[12] - in[16];
         float tmp2 = iip12 - in[4] * 0.34729636F - in[8] * 1.8793852F + in[16] * 1.5320889F;
         float tmp3 = iip12 - in[4] * 1.5320889F + in[8] * 0.34729636F - in[16] * 1.8793852F;
         float tmp4 = in[0] - in[4] + in[8] - in[12] + in[16];
         float i66_ = in[6] * 1.7320508F;
         float tmp0_ = in[2] * 1.9696155F + i66_ + in[10] * 1.2855753F + in[14] * 0.6840403F;
         float tmp1_ = (in[2] - in[10] - in[14]) * 1.7320508F;
         float tmp2_ = in[2] * 1.2855753F - i66_ - in[10] * 0.6840403F + in[14] * 1.9696155F;
         float tmp3_ = in[2] * 0.6840403F - i66_ + in[10] * 1.9696155F - in[14] * 1.2855753F;
         float i0 = in[1] + in[1];
         float i0p12 = i0 + in[13];
         float tmp0o = i0p12 + in[5] * 1.8793852F + in[9] * 1.5320889F + in[17] * 0.34729636F;
         float tmp1o = i0 + in[5] - in[9] - in[13] - in[13] - in[17];
         float tmp2o = i0p12 - in[5] * 0.34729636F - in[9] * 1.8793852F + in[17] * 1.5320889F;
         float tmp3o = i0p12 - in[5] * 1.5320889F + in[9] * 0.34729636F - in[17] * 1.8793852F;
         float tmp4o = (in[1] - in[5] + in[9] - in[13] + in[17]) * 0.70710677F;
         float i6_ = in[7] * 1.7320508F;
         float tmp0_o = in[3] * 1.9696155F + i6_ + in[11] * 1.2855753F + in[15] * 0.6840403F;
         float tmp1_o = (in[3] - in[11] - in[15]) * 1.7320508F;
         float tmp2_o = in[3] * 1.2855753F - i6_ - in[11] * 0.6840403F + in[15] * 1.9696155F;
         float tmp3_o = in[3] * 0.6840403F - i6_ + in[11] * 1.9696155F - in[15] * 1.2855753F;
         float e = tmp0 + tmp0_;
         float o = (tmp0o + tmp0_o) * 0.5019099F;
         float tmpf_0 = e + o;
         float tmpf_17 = e - o;
         e = tmp1 + tmp1_;
         o = (tmp1o + tmp1_o) * 0.5176381F;
         float tmpf_1 = e + o;
         float tmpf_16 = e - o;
         e = tmp2 + tmp2_;
         o = (tmp2o + tmp2_o) * 0.55168897F;
         float tmpf_2 = e + o;
         float tmpf_15 = e - o;
         e = tmp3 + tmp3_;
         o = (tmp3o + tmp3_o) * 0.61038727F;
         float tmpf_3 = e + o;
         float tmpf_14 = e - o;
         float tmpf_4 = tmp4 + tmp4o;
         float tmpf_13 = tmp4 - tmp4o;
         e = tmp3 - tmp3_;
         o = (tmp3o - tmp3_o) * 0.8717234F;
         float tmpf_5 = e + o;
         float tmpf_12 = e - o;
         e = tmp2 - tmp2_;
         o = (tmp2o - tmp2_o) * 1.1831008F;
         float tmpf_6 = e + o;
         float tmpf_11 = e - o;
         e = tmp1 - tmp1_;
         o = (tmp1o - tmp1_o) * 1.9318516F;
         float tmpf_7 = e + o;
         float tmpf_10 = e - o;
         e = tmp0 - tmp0_;
         o = (tmp0o - tmp0_o) * 5.7368565F;
         float tmpf_8 = e + o;
         float tmpf_9 = e - o;
         float[] win_bt = win[block_type];
         out[0] = -tmpf_9 * win_bt[0];
         out[1] = -tmpf_10 * win_bt[1];
         out[2] = -tmpf_11 * win_bt[2];
         out[3] = -tmpf_12 * win_bt[3];
         out[4] = -tmpf_13 * win_bt[4];
         out[5] = -tmpf_14 * win_bt[5];
         out[6] = -tmpf_15 * win_bt[6];
         out[7] = -tmpf_16 * win_bt[7];
         out[8] = -tmpf_17 * win_bt[8];
         out[9] = tmpf_17 * win_bt[9];
         out[10] = tmpf_16 * win_bt[10];
         out[11] = tmpf_15 * win_bt[11];
         out[12] = tmpf_14 * win_bt[12];
         out[13] = tmpf_13 * win_bt[13];
         out[14] = tmpf_12 * win_bt[14];
         out[15] = tmpf_11 * win_bt[15];
         out[16] = tmpf_10 * win_bt[16];
         out[17] = tmpf_9 * win_bt[17];
         out[18] = tmpf_8 * win_bt[18];
         out[19] = tmpf_7 * win_bt[19];
         out[20] = tmpf_6 * win_bt[20];
         out[21] = tmpf_5 * win_bt[21];
         out[22] = tmpf_4 * win_bt[22];
         out[23] = tmpf_3 * win_bt[23];
         out[24] = tmpf_2 * win_bt[24];
         out[25] = tmpf_1 * win_bt[25];
         out[26] = tmpf_0 * win_bt[26];
         out[27] = tmpf_0 * win_bt[27];
         out[28] = tmpf_1 * win_bt[28];
         out[29] = tmpf_2 * win_bt[29];
         out[30] = tmpf_3 * win_bt[30];
         out[31] = tmpf_4 * win_bt[31];
         out[32] = tmpf_5 * win_bt[32];
         out[33] = tmpf_6 * win_bt[33];
         out[34] = tmpf_7 * win_bt[34];
         out[35] = tmpf_8 * win_bt[35];
      }
   }

   private static float[] createT43() {
      float[] t43 = new float[8192];
      double d43 = 1.3333333333333333;

      for (int i = 0; i < 8192; i++) {
         t43[i] = (float)Math.pow(i, 1.3333333333333333);
      }

      return t43;
   }

   static int[] reorder(int[] scalefacBand) {
      int j = 0;
      int[] ix = new int[576];

      for (int sfb = 0; sfb < 13; sfb++) {
         int start = scalefacBand[sfb];
         int end = scalefacBand[sfb + 1];

         for (int window = 0; window < 3; window++) {
            for (int i = start; i < end; i++) {
               ix[3 * i + window] = j++;
            }
         }
      }

      return ix;
   }

   static {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.OutOfMemoryError: Java heap space
      //   at org.jetbrains.java.decompiler.util.collections.FastSparseSetFactory$FastSparseSet.getCopy(FastSparseSetFactory.java:95)
      //   at org.jetbrains.java.decompiler.util.collections.SFormsFastMapDirect.getCopy(SFormsFastMapDirect.java:67)
      //   at org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAUConstructorSparseEx.updateLiveMap(SSAUConstructorSparseEx.java:269)
      //   at org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAUConstructorSparseEx.onAssignment(SSAUConstructorSparseEx.java:262)
      //   at org.jetbrains.java.decompiler.modules.decompiler.sforms.SFormsConstructor.updateVarExprent(SFormsConstructor.java:214)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent.processSforms(AssignmentExprent.java:306)
      //   at org.jetbrains.java.decompiler.modules.decompiler.sforms.SFormsConstructor.ssaStatements(SFormsConstructor.java:126)
      //   at org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAUConstructorSparseEx.splitVariables(SSAUConstructorSparseEx.java:45)
      //   at org.jetbrains.java.decompiler.modules.decompiler.StackVarsProcessor.simplifyStackVars(StackVarsProcessor.java:65)
      //   at org.jetbrains.java.decompiler.modules.decompiler.StackVarsProcessor.simplifyStackVars(StackVarsProcessor.java:40)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:231)
      //
      // Bytecode:
      // 000: bipush 2
      // 001: anewarray 165
      // 004: dup
      // 005: bipush 0
      // 006: bipush 16
      // 008: newarray 10
      // 00a: dup
      // 00b: bipush 0
      // 00c: bipush 0
      // 00d: iastore
      // 00e: dup
      // 00f: bipush 1
      // 010: bipush 0
      // 011: iastore
      // 012: dup
      // 013: bipush 2
      // 014: bipush 0
      // 015: iastore
      // 016: dup
      // 017: bipush 3
      // 018: bipush 0
      // 019: iastore
      // 01a: dup
      // 01b: bipush 4
      // 01c: bipush 3
      // 01d: iastore
      // 01e: dup
      // 01f: bipush 5
      // 020: bipush 1
      // 021: iastore
      // 022: dup
      // 023: bipush 6
      // 025: bipush 1
      // 026: iastore
      // 027: dup
      // 028: bipush 7
      // 02a: bipush 1
      // 02b: iastore
      // 02c: dup
      // 02d: bipush 8
      // 02f: bipush 2
      // 030: iastore
      // 031: dup
      // 032: bipush 9
      // 034: bipush 2
      // 035: iastore
      // 036: dup
      // 037: bipush 10
      // 039: bipush 2
      // 03a: iastore
      // 03b: dup
      // 03c: bipush 11
      // 03e: bipush 3
      // 03f: iastore
      // 040: dup
      // 041: bipush 12
      // 043: bipush 3
      // 044: iastore
      // 045: dup
      // 046: bipush 13
      // 048: bipush 3
      // 049: iastore
      // 04a: dup
      // 04b: bipush 14
      // 04d: bipush 4
      // 04e: iastore
      // 04f: dup
      // 050: bipush 15
      // 052: bipush 4
      // 053: iastore
      // 054: aastore
      // 055: dup
      // 056: bipush 1
      // 057: bipush 16
      // 059: newarray 10
      // 05b: dup
      // 05c: bipush 0
      // 05d: bipush 0
      // 05e: iastore
      // 05f: dup
      // 060: bipush 1
      // 061: bipush 1
      // 062: iastore
      // 063: dup
      // 064: bipush 2
      // 065: bipush 2
      // 066: iastore
      // 067: dup
      // 068: bipush 3
      // 069: bipush 3
      // 06a: iastore
      // 06b: dup
      // 06c: bipush 4
      // 06d: bipush 0
      // 06e: iastore
      // 06f: dup
      // 070: bipush 5
      // 071: bipush 1
      // 072: iastore
      // 073: dup
      // 074: bipush 6
      // 076: bipush 2
      // 077: iastore
      // 078: dup
      // 079: bipush 7
      // 07b: bipush 3
      // 07c: iastore
      // 07d: dup
      // 07e: bipush 8
      // 080: bipush 1
      // 081: iastore
      // 082: dup
      // 083: bipush 9
      // 085: bipush 2
      // 086: iastore
      // 087: dup
      // 088: bipush 10
      // 08a: bipush 3
      // 08b: iastore
      // 08c: dup
      // 08d: bipush 11
      // 08f: bipush 1
      // 090: iastore
      // 091: dup
      // 092: bipush 12
      // 094: bipush 2
      // 095: iastore
      // 096: dup
      // 097: bipush 13
      // 099: bipush 3
      // 09a: iastore
      // 09b: dup
      // 09c: bipush 14
      // 09e: bipush 2
      // 09f: iastore
      // 0a0: dup
      // 0a1: bipush 15
      // 0a3: bipush 3
      // 0a4: iastore
      // 0a5: aastore
      // 0a6: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.sLen [[I
      // 0a9: bipush 22
      // 0ab: newarray 10
      // 0ad: dup
      // 0ae: bipush 0
      // 0af: bipush 0
      // 0b0: iastore
      // 0b1: dup
      // 0b2: bipush 1
      // 0b3: bipush 0
      // 0b4: iastore
      // 0b5: dup
      // 0b6: bipush 2
      // 0b7: bipush 0
      // 0b8: iastore
      // 0b9: dup
      // 0ba: bipush 3
      // 0bb: bipush 0
      // 0bc: iastore
      // 0bd: dup
      // 0be: bipush 4
      // 0bf: bipush 0
      // 0c0: iastore
      // 0c1: dup
      // 0c2: bipush 5
      // 0c3: bipush 0
      // 0c4: iastore
      // 0c5: dup
      // 0c6: bipush 6
      // 0c8: bipush 0
      // 0c9: iastore
      // 0ca: dup
      // 0cb: bipush 7
      // 0cd: bipush 0
      // 0ce: iastore
      // 0cf: dup
      // 0d0: bipush 8
      // 0d2: bipush 0
      // 0d3: iastore
      // 0d4: dup
      // 0d5: bipush 9
      // 0d7: bipush 0
      // 0d8: iastore
      // 0d9: dup
      // 0da: bipush 10
      // 0dc: bipush 0
      // 0dd: iastore
      // 0de: dup
      // 0df: bipush 11
      // 0e1: bipush 1
      // 0e2: iastore
      // 0e3: dup
      // 0e4: bipush 12
      // 0e6: bipush 1
      // 0e7: iastore
      // 0e8: dup
      // 0e9: bipush 13
      // 0eb: bipush 1
      // 0ec: iastore
      // 0ed: dup
      // 0ee: bipush 14
      // 0f0: bipush 1
      // 0f1: iastore
      // 0f2: dup
      // 0f3: bipush 15
      // 0f5: bipush 2
      // 0f6: iastore
      // 0f7: dup
      // 0f8: bipush 16
      // 0fa: bipush 2
      // 0fb: iastore
      // 0fc: dup
      // 0fd: bipush 17
      // 0ff: bipush 3
      // 100: iastore
      // 101: dup
      // 102: bipush 18
      // 104: bipush 3
      // 105: iastore
      // 106: dup
      // 107: bipush 19
      // 109: bipush 3
      // 10a: iastore
      // 10b: dup
      // 10c: bipush 20
      // 10e: bipush 2
      // 10f: iastore
      // 110: dup
      // 111: bipush 21
      // 113: bipush 0
      // 114: iastore
      // 115: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.preTab [I
      // 118: bipush 64
      // 11a: newarray 6
      // 11c: dup
      // 11d: bipush 0
      // 11e: fconst_1
      // 11f: fastore
      // 120: dup
      // 121: bipush 1
      // 122: ldc_w 0.70710677
      // 125: fastore
      // 126: dup
      // 127: bipush 2
      // 128: ldc_w 0.5
      // 12b: fastore
      // 12c: dup
      // 12d: bipush 3
      // 12e: ldc_w 0.35355338
      // 131: fastore
      // 132: dup
      // 133: bipush 4
      // 134: ldc_w 0.25
      // 137: fastore
      // 138: dup
      // 139: bipush 5
      // 13a: ldc_w 0.17677669
      // 13d: fastore
      // 13e: dup
      // 13f: bipush 6
      // 141: ldc_w 0.125
      // 144: fastore
      // 145: dup
      // 146: bipush 7
      // 148: ldc_w 0.088388346
      // 14b: fastore
      // 14c: dup
      // 14d: bipush 8
      // 14f: ldc_w 0.0625
      // 152: fastore
      // 153: dup
      // 154: bipush 9
      // 156: ldc_w 0.044194173
      // 159: fastore
      // 15a: dup
      // 15b: bipush 10
      // 15d: ldc_w 0.03125
      // 160: fastore
      // 161: dup
      // 162: bipush 11
      // 164: ldc_w 0.022097087
      // 167: fastore
      // 168: dup
      // 169: bipush 12
      // 16b: ldc_w 0.015625
      // 16e: fastore
      // 16f: dup
      // 170: bipush 13
      // 172: ldc_w 0.011048543
      // 175: fastore
      // 176: dup
      // 177: bipush 14
      // 179: ldc_w 0.0078125
      // 17c: fastore
      // 17d: dup
      // 17e: bipush 15
      // 180: ldc_w 0.0055242716
      // 183: fastore
      // 184: dup
      // 185: bipush 16
      // 187: ldc_w 0.00390625
      // 18a: fastore
      // 18b: dup
      // 18c: bipush 17
      // 18e: ldc_w 0.0027621358
      // 191: fastore
      // 192: dup
      // 193: bipush 18
      // 195: ldc_w 0.001953125
      // 198: fastore
      // 199: dup
      // 19a: bipush 19
      // 19c: ldc_w 0.0013810679
      // 19f: fastore
      // 1a0: dup
      // 1a1: bipush 20
      // 1a3: ldc_w 9.765625E-4
      // 1a6: fastore
      // 1a7: dup
      // 1a8: bipush 21
      // 1aa: ldc_w 6.9053395E-4
      // 1ad: fastore
      // 1ae: dup
      // 1af: bipush 22
      // 1b1: ldc_w 4.8828125E-4
      // 1b4: fastore
      // 1b5: dup
      // 1b6: bipush 23
      // 1b8: ldc_w 3.4526698E-4
      // 1bb: fastore
      // 1bc: dup
      // 1bd: bipush 24
      // 1bf: ldc_w 2.4414062E-4
      // 1c2: fastore
      // 1c3: dup
      // 1c4: bipush 25
      // 1c6: ldc_w 1.7263349E-4
      // 1c9: fastore
      // 1ca: dup
      // 1cb: bipush 26
      // 1cd: ldc_w 1.2207031E-4
      // 1d0: fastore
      // 1d1: dup
      // 1d2: bipush 27
      // 1d4: ldc_w 8.6316744E-5
      // 1d7: fastore
      // 1d8: dup
      // 1d9: bipush 28
      // 1db: ldc_w 6.1035156E-5
      // 1de: fastore
      // 1df: dup
      // 1e0: bipush 29
      // 1e2: ldc_w 4.3158372E-5
      // 1e5: fastore
      // 1e6: dup
      // 1e7: bipush 30
      // 1e9: ldc_w 3.0517578E-5
      // 1ec: fastore
      // 1ed: dup
      // 1ee: bipush 31
      // 1f0: ldc_w 2.1579186E-5
      // 1f3: fastore
      // 1f4: dup
      // 1f5: bipush 32
      // 1f7: ldc_w 1.5258789E-5
      // 1fa: fastore
      // 1fb: dup
      // 1fc: bipush 33
      // 1fe: ldc_w 1.0789593E-5
      // 201: fastore
      // 202: dup
      // 203: bipush 34
      // 205: ldc_w 7.6293945E-6
      // 208: fastore
      // 209: dup
      // 20a: bipush 35
      // 20c: ldc_w 5.3947965E-6
      // 20f: fastore
      // 210: dup
      // 211: bipush 36
      // 213: ldc_w 3.8146973E-6
      // 216: fastore
      // 217: dup
      // 218: bipush 37
      // 21a: ldc_w 2.6973983E-6
      // 21d: fastore
      // 21e: dup
      // 21f: bipush 38
      // 221: ldc_w 1.9073486E-6
      // 224: fastore
      // 225: dup
      // 226: bipush 39
      // 228: ldc_w 1.3486991E-6
      // 22b: fastore
      // 22c: dup
      // 22d: bipush 40
      // 22f: ldc_w 9.536743E-7
      // 232: fastore
      // 233: dup
      // 234: bipush 41
      // 236: ldc_w 6.7434956E-7
      // 239: fastore
      // 23a: dup
      // 23b: bipush 42
      // 23d: ldc_w 4.7683716E-7
      // 240: fastore
      // 241: dup
      // 242: bipush 43
      // 244: ldc_w 3.3717478E-7
      // 247: fastore
      // 248: dup
      // 249: bipush 44
      // 24b: ldc_w 2.3841858E-7
      // 24e: fastore
      // 24f: dup
      // 250: bipush 45
      // 252: ldc_w 1.6858739E-7
      // 255: fastore
      // 256: dup
      // 257: bipush 46
      // 259: ldc_w 1.1920929E-7
      // 25c: fastore
      // 25d: dup
      // 25e: bipush 47
      // 260: ldc_w 8.4293696E-8
      // 263: fastore
      // 264: dup
      // 265: bipush 48
      // 267: ldc_w 5.9604645E-8
      // 26a: fastore
      // 26b: dup
      // 26c: bipush 49
      // 26e: ldc_w 4.2146848E-8
      // 271: fastore
      // 272: dup
      // 273: bipush 50
      // 275: ldc_w 2.9802322E-8
      // 278: fastore
      // 279: dup
      // 27a: bipush 51
      // 27c: ldc_w 2.1073424E-8
      // 27f: fastore
      // 280: dup
      // 281: bipush 52
      // 283: ldc_w 1.4901161E-8
      // 286: fastore
      // 287: dup
      // 288: bipush 53
      // 28a: ldc_w 1.0536712E-8
      // 28d: fastore
      // 28e: dup
      // 28f: bipush 54
      // 291: ldc_w 7.450581E-9
      // 294: fastore
      // 295: dup
      // 296: bipush 55
      // 298: ldc_w 5.268356E-9
      // 29b: fastore
      // 29c: dup
      // 29d: bipush 56
      // 29f: ldc_w 3.7252903E-9
      // 2a2: fastore
      // 2a3: dup
      // 2a4: bipush 57
      // 2a6: ldc_w 2.634178E-9
      // 2a9: fastore
      // 2aa: dup
      // 2ab: bipush 58
      // 2ad: ldc_w 1.8626451E-9
      // 2b0: fastore
      // 2b1: dup
      // 2b2: bipush 59
      // 2b4: ldc_w 1.317089E-9
      // 2b7: fastore
      // 2b8: dup
      // 2b9: bipush 60
      // 2bb: ldc_w 9.313226E-10
      // 2be: fastore
      // 2bf: dup
      // 2c0: bipush 61
      // 2c2: ldc_w 6.585445E-10
      // 2c5: fastore
      // 2c6: dup
      // 2c7: bipush 62
      // 2c9: ldc_w 4.656613E-10
      // 2cc: fastore
      // 2cd: dup
      // 2ce: bipush 63
      // 2d0: ldc_w 3.2927225E-10
      // 2d3: fastore
      // 2d4: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.two_to_negative_half_pow [F
      // 2d7: invokestatic dev/musicplayer/jlayer/LayerIIIDecoder.createT43 ()[F
      // 2da: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.t_43 [F
      // 2dd: bipush 2
      // 2de: anewarray 525
      // 2e1: dup
      // 2e2: bipush 0
      // 2e3: bipush 32
      // 2e5: newarray 6
      // 2e7: dup
      // 2e8: bipush 0
      // 2e9: fconst_1
      // 2ea: fastore
      // 2eb: dup
      // 2ec: bipush 1
      // 2ed: ldc_w 0.8408964
      // 2f0: fastore
      // 2f1: dup
      // 2f2: bipush 2
      // 2f3: ldc_w 0.70710677
      // 2f6: fastore
      // 2f7: dup
      // 2f8: bipush 3
      // 2f9: ldc_w 0.59460354
      // 2fc: fastore
      // 2fd: dup
      // 2fe: bipush 4
      // 2ff: ldc_w 0.5
      // 302: fastore
      // 303: dup
      // 304: bipush 5
      // 305: ldc_w 0.4204482
      // 308: fastore
      // 309: dup
      // 30a: bipush 6
      // 30c: ldc_w 0.35355338
      // 30f: fastore
      // 310: dup
      // 311: bipush 7
      // 313: ldc_w 0.29730177
      // 316: fastore
      // 317: dup
      // 318: bipush 8
      // 31a: ldc_w 0.25
      // 31d: fastore
      // 31e: dup
      // 31f: bipush 9
      // 321: ldc_w 0.2102241
      // 324: fastore
      // 325: dup
      // 326: bipush 10
      // 328: ldc_w 0.17677669
      // 32b: fastore
      // 32c: dup
      // 32d: bipush 11
      // 32f: ldc_w 0.14865088
      // 332: fastore
      // 333: dup
      // 334: bipush 12
      // 336: ldc_w 0.125
      // 339: fastore
      // 33a: dup
      // 33b: bipush 13
      // 33d: ldc_w 0.10511205
      // 340: fastore
      // 341: dup
      // 342: bipush 14
      // 344: ldc_w 0.088388346
      // 347: fastore
      // 348: dup
      // 349: bipush 15
      // 34b: ldc_w 0.07432544
      // 34e: fastore
      // 34f: dup
      // 350: bipush 16
      // 352: ldc_w 0.0625
      // 355: fastore
      // 356: dup
      // 357: bipush 17
      // 359: ldc_w 0.052556027
      // 35c: fastore
      // 35d: dup
      // 35e: bipush 18
      // 360: ldc_w 0.044194173
      // 363: fastore
      // 364: dup
      // 365: bipush 19
      // 367: ldc_w 0.03716272
      // 36a: fastore
      // 36b: dup
      // 36c: bipush 20
      // 36e: ldc_w 0.03125
      // 371: fastore
      // 372: dup
      // 373: bipush 21
      // 375: ldc_w 0.026278013
      // 378: fastore
      // 379: dup
      // 37a: bipush 22
      // 37c: ldc_w 0.022097087
      // 37f: fastore
      // 380: dup
      // 381: bipush 23
      // 383: ldc_w 0.01858136
      // 386: fastore
      // 387: dup
      // 388: bipush 24
      // 38a: ldc_w 0.015625
      // 38d: fastore
      // 38e: dup
      // 38f: bipush 25
      // 391: ldc_w 0.013139007
      // 394: fastore
      // 395: dup
      // 396: bipush 26
      // 398: ldc_w 0.011048543
      // 39b: fastore
      // 39c: dup
      // 39d: bipush 27
      // 39f: ldc_w 0.00929068
      // 3a2: fastore
      // 3a3: dup
      // 3a4: bipush 28
      // 3a6: ldc_w 0.0078125
      // 3a9: fastore
      // 3aa: dup
      // 3ab: bipush 29
      // 3ad: ldc_w 0.0065695033
      // 3b0: fastore
      // 3b1: dup
      // 3b2: bipush 30
      // 3b4: ldc_w 0.0055242716
      // 3b7: fastore
      // 3b8: dup
      // 3b9: bipush 31
      // 3bb: ldc_w 0.00464534
      // 3be: fastore
      // 3bf: aastore
      // 3c0: dup
      // 3c1: bipush 1
      // 3c2: bipush 32
      // 3c4: newarray 6
      // 3c6: dup
      // 3c7: bipush 0
      // 3c8: fconst_1
      // 3c9: fastore
      // 3ca: dup
      // 3cb: bipush 1
      // 3cc: ldc_w 0.70710677
      // 3cf: fastore
      // 3d0: dup
      // 3d1: bipush 2
      // 3d2: ldc_w 0.5
      // 3d5: fastore
      // 3d6: dup
      // 3d7: bipush 3
      // 3d8: ldc_w 0.35355338
      // 3db: fastore
      // 3dc: dup
      // 3dd: bipush 4
      // 3de: ldc_w 0.25
      // 3e1: fastore
      // 3e2: dup
      // 3e3: bipush 5
      // 3e4: ldc_w 0.17677669
      // 3e7: fastore
      // 3e8: dup
      // 3e9: bipush 6
      // 3eb: ldc_w 0.125
      // 3ee: fastore
      // 3ef: dup
      // 3f0: bipush 7
      // 3f2: ldc_w 0.088388346
      // 3f5: fastore
      // 3f6: dup
      // 3f7: bipush 8
      // 3f9: ldc_w 0.0625
      // 3fc: fastore
      // 3fd: dup
      // 3fe: bipush 9
      // 400: ldc_w 0.044194173
      // 403: fastore
      // 404: dup
      // 405: bipush 10
      // 407: ldc_w 0.03125
      // 40a: fastore
      // 40b: dup
      // 40c: bipush 11
      // 40e: ldc_w 0.022097087
      // 411: fastore
      // 412: dup
      // 413: bipush 12
      // 415: ldc_w 0.015625
      // 418: fastore
      // 419: dup
      // 41a: bipush 13
      // 41c: ldc_w 0.011048543
      // 41f: fastore
      // 420: dup
      // 421: bipush 14
      // 423: ldc_w 0.0078125
      // 426: fastore
      // 427: dup
      // 428: bipush 15
      // 42a: ldc_w 0.0055242716
      // 42d: fastore
      // 42e: dup
      // 42f: bipush 16
      // 431: ldc_w 0.00390625
      // 434: fastore
      // 435: dup
      // 436: bipush 17
      // 438: ldc_w 0.0027621358
      // 43b: fastore
      // 43c: dup
      // 43d: bipush 18
      // 43f: ldc_w 0.001953125
      // 442: fastore
      // 443: dup
      // 444: bipush 19
      // 446: ldc_w 0.0013810679
      // 449: fastore
      // 44a: dup
      // 44b: bipush 20
      // 44d: ldc_w 9.765625E-4
      // 450: fastore
      // 451: dup
      // 452: bipush 21
      // 454: ldc_w 6.9053395E-4
      // 457: fastore
      // 458: dup
      // 459: bipush 22
      // 45b: ldc_w 4.8828125E-4
      // 45e: fastore
      // 45f: dup
      // 460: bipush 23
      // 462: ldc_w 3.4526698E-4
      // 465: fastore
      // 466: dup
      // 467: bipush 24
      // 469: ldc_w 2.4414062E-4
      // 46c: fastore
      // 46d: dup
      // 46e: bipush 25
      // 470: ldc_w 1.7263349E-4
      // 473: fastore
      // 474: dup
      // 475: bipush 26
      // 477: ldc_w 1.2207031E-4
      // 47a: fastore
      // 47b: dup
      // 47c: bipush 27
      // 47e: ldc_w 8.6316744E-5
      // 481: fastore
      // 482: dup
      // 483: bipush 28
      // 485: ldc_w 6.1035156E-5
      // 488: fastore
      // 489: dup
      // 48a: bipush 29
      // 48c: ldc_w 4.3158372E-5
      // 48f: fastore
      // 490: dup
      // 491: bipush 30
      // 493: ldc_w 3.0517578E-5
      // 496: fastore
      // 497: dup
      // 498: bipush 31
      // 49a: ldc_w 2.1579186E-5
      // 49d: fastore
      // 49e: aastore
      // 49f: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.io [[F
      // 4a2: bipush 16
      // 4a4: newarray 6
      // 4a6: dup
      // 4a7: bipush 0
      // 4a8: fconst_0
      // 4a9: fastore
      // 4aa: dup
      // 4ab: bipush 1
      // 4ac: ldc_w 0.2679492
      // 4af: fastore
      // 4b0: dup
      // 4b1: bipush 2
      // 4b2: ldc_w 0.57735026
      // 4b5: fastore
      // 4b6: dup
      // 4b7: bipush 3
      // 4b8: fconst_1
      // 4b9: fastore
      // 4ba: dup
      // 4bb: bipush 4
      // 4bc: ldc_w 1.7320508
      // 4bf: fastore
      // 4c0: dup
      // 4c1: bipush 5
      // 4c2: ldc_w 3.732051
      // 4c5: fastore
      // 4c6: dup
      // 4c7: bipush 6
      // 4c9: ldc_w 1.0E11
      // 4cc: fastore
      // 4cd: dup
      // 4ce: bipush 7
      // 4d0: ldc_w -3.732051
      // 4d3: fastore
      // 4d4: dup
      // 4d5: bipush 8
      // 4d7: ldc_w -1.7320508
      // 4da: fastore
      // 4db: dup
      // 4dc: bipush 9
      // 4de: ldc_w -1.0
      // 4e1: fastore
      // 4e2: dup
      // 4e3: bipush 10
      // 4e5: ldc_w -0.57735026
      // 4e8: fastore
      // 4e9: dup
      // 4ea: bipush 11
      // 4ec: ldc_w -0.2679492
      // 4ef: fastore
      // 4f0: dup
      // 4f1: bipush 12
      // 4f3: fconst_0
      // 4f4: fastore
      // 4f5: dup
      // 4f6: bipush 13
      // 4f8: ldc_w 0.2679492
      // 4fb: fastore
      // 4fc: dup
      // 4fd: bipush 14
      // 4ff: ldc_w 0.57735026
      // 502: fastore
      // 503: dup
      // 504: bipush 15
      // 506: fconst_1
      // 507: fastore
      // 508: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.TAN12 [F
      // 50b: bipush 8
      // 50d: newarray 6
      // 50f: dup
      // 510: bipush 0
      // 511: ldc_w 0.8574929
      // 514: fastore
      // 515: dup
      // 516: bipush 1
      // 517: ldc_w 0.881742
      // 51a: fastore
      // 51b: dup
      // 51c: bipush 2
      // 51d: ldc_w 0.94962865
      // 520: fastore
      // 521: dup
      // 522: bipush 3
      // 523: ldc_w 0.9833146
      // 526: fastore
      // 527: dup
      // 528: bipush 4
      // 529: ldc_w 0.9955178
      // 52c: fastore
      // 52d: dup
      // 52e: bipush 5
      // 52f: ldc_w 0.9991606
      // 532: fastore
      // 533: dup
      // 534: bipush 6
      // 536: ldc_w 0.9998992
      // 539: fastore
      // 53a: dup
      // 53b: bipush 7
      // 53d: ldc_w 0.99999315
      // 540: fastore
      // 541: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.cs [F
      // 544: bipush 8
      // 546: newarray 6
      // 548: dup
      // 549: bipush 0
      // 54a: ldc_w -0.51449573
      // 54d: fastore
      // 54e: dup
      // 54f: bipush 1
      // 550: ldc_w -0.47173196
      // 553: fastore
      // 554: dup
      // 555: bipush 2
      // 556: ldc_w -0.31337744
      // 559: fastore
      // 55a: dup
      // 55b: bipush 3
      // 55c: ldc_w -0.1819132
      // 55f: fastore
      // 560: dup
      // 561: bipush 4
      // 562: ldc_w -0.09457419
      // 565: fastore
      // 566: dup
      // 567: bipush 5
      // 568: ldc_w -0.040965583
      // 56b: fastore
      // 56c: dup
      // 56d: bipush 6
      // 56f: ldc_w -0.014198569
      // 572: fastore
      // 573: dup
      // 574: bipush 7
      // 576: ldc_w -0.0036999746
      // 579: fastore
      // 57a: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.ca [F
      // 57d: bipush 4
      // 57e: anewarray 525
      // 581: dup
      // 582: bipush 0
      // 583: bipush 36
      // 585: newarray 6
      // 587: dup
      // 588: bipush 0
      // 589: ldc_w -0.016141215
      // 58c: fastore
      // 58d: dup
      // 58e: bipush 1
      // 58f: ldc_w -0.05360318
      // 592: fastore
      // 593: dup
      // 594: bipush 2
      // 595: ldc_w -0.100707136
      // 598: fastore
      // 599: dup
      // 59a: bipush 3
      // 59b: ldc_w -0.16280818
      // 59e: fastore
      // 59f: dup
      // 5a0: bipush 4
      // 5a1: ldc_w -0.5
      // 5a4: fastore
      // 5a5: dup
      // 5a6: bipush 5
      // 5a7: ldc_w -0.38388735
      // 5aa: fastore
      // 5ab: dup
      // 5ac: bipush 6
      // 5ae: ldc_w -0.6206114
      // 5b1: fastore
      // 5b2: dup
      // 5b3: bipush 7
      // 5b5: ldc_w -1.1659756
      // 5b8: fastore
      // 5b9: dup
      // 5ba: bipush 8
      // 5bc: ldc_w -3.8720753
      // 5bf: fastore
      // 5c0: dup
      // 5c1: bipush 9
      // 5c3: ldc_w -4.225629
      // 5c6: fastore
      // 5c7: dup
      // 5c8: bipush 10
      // 5ca: ldc_w -1.519529
      // 5cd: fastore
      // 5ce: dup
      // 5cf: bipush 11
      // 5d1: ldc_w -0.97416484
      // 5d4: fastore
      // 5d5: dup
      // 5d6: bipush 12
      // 5d8: ldc_w -0.73744076
      // 5db: fastore
      // 5dc: dup
      // 5dd: bipush 13
      // 5df: ldc_w -1.2071068
      // 5e2: fastore
      // 5e3: dup
      // 5e4: bipush 14
      // 5e6: ldc_w -0.5163616
      // 5e9: fastore
      // 5ea: dup
      // 5eb: bipush 15
      // 5ed: ldc_w -0.45426053
      // 5f0: fastore
      // 5f1: dup
      // 5f2: bipush 16
      // 5f4: ldc_w -0.40715656
      // 5f7: fastore
      // 5f8: dup
      // 5f9: bipush 17
      // 5fb: ldc_w -0.3696946
      // 5fe: fastore
      // 5ff: dup
      // 600: bipush 18
      // 602: ldc_w -0.3387627
      // 605: fastore
      // 606: dup
      // 607: bipush 19
      // 609: ldc_w -0.31242222
      // 60c: fastore
      // 60d: dup
      // 60e: bipush 20
      // 610: ldc_w -0.28939587
      // 613: fastore
      // 614: dup
      // 615: bipush 21
      // 617: ldc_w -0.26880082
      // 61a: fastore
      // 61b: dup
      // 61c: bipush 22
      // 61e: ldc_w -0.5
      // 621: fastore
      // 622: dup
      // 623: bipush 23
      // 625: ldc_w -0.23251417
      // 628: fastore
      // 629: dup
      // 62a: bipush 24
      // 62c: ldc_w -0.21596715
      // 62f: fastore
      // 630: dup
      // 631: bipush 25
      // 633: ldc_w -0.20004979
      // 636: fastore
      // 637: dup
      // 638: bipush 26
      // 63a: ldc_w -0.18449493
      // 63d: fastore
      // 63e: dup
      // 63f: bipush 27
      // 641: ldc_w -0.16905846
      // 644: fastore
      // 645: dup
      // 646: bipush 28
      // 648: ldc_w -0.15350361
      // 64b: fastore
      // 64c: dup
      // 64d: bipush 29
      // 64f: ldc_w -0.13758625
      // 652: fastore
      // 653: dup
      // 654: bipush 30
      // 656: ldc_w -0.12103922
      // 659: fastore
      // 65a: dup
      // 65b: bipush 31
      // 65d: ldc_w -0.20710678
      // 660: fastore
      // 661: dup
      // 662: bipush 32
      // 664: ldc_w -0.084752575
      // 667: fastore
      // 668: dup
      // 669: bipush 33
      // 66b: ldc_w -0.06415752
      // 66e: fastore
      // 66f: dup
      // 670: bipush 34
      // 672: ldc_w -0.041131172
      // 675: fastore
      // 676: dup
      // 677: bipush 35
      // 679: ldc_w -0.014790705
      // 67c: fastore
      // 67d: aastore
      // 67e: dup
      // 67f: bipush 1
      // 680: bipush 36
      // 682: newarray 6
      // 684: dup
      // 685: bipush 0
      // 686: ldc_w -0.016141215
      // 689: fastore
      // 68a: dup
      // 68b: bipush 1
      // 68c: ldc_w -0.05360318
      // 68f: fastore
      // 690: dup
      // 691: bipush 2
      // 692: ldc_w -0.100707136
      // 695: fastore
      // 696: dup
      // 697: bipush 3
      // 698: ldc_w -0.16280818
      // 69b: fastore
      // 69c: dup
      // 69d: bipush 4
      // 69e: ldc_w -0.5
      // 6a1: fastore
      // 6a2: dup
      // 6a3: bipush 5
      // 6a4: ldc_w -0.38388735
      // 6a7: fastore
      // 6a8: dup
      // 6a9: bipush 6
      // 6ab: ldc_w -0.6206114
      // 6ae: fastore
      // 6af: dup
      // 6b0: bipush 7
      // 6b2: ldc_w -1.1659756
      // 6b5: fastore
      // 6b6: dup
      // 6b7: bipush 8
      // 6b9: ldc_w -3.8720753
      // 6bc: fastore
      // 6bd: dup
      // 6be: bipush 9
      // 6c0: ldc_w -4.225629
      // 6c3: fastore
      // 6c4: dup
      // 6c5: bipush 10
      // 6c7: ldc_w -1.519529
      // 6ca: fastore
      // 6cb: dup
      // 6cc: bipush 11
      // 6ce: ldc_w -0.97416484
      // 6d1: fastore
      // 6d2: dup
      // 6d3: bipush 12
      // 6d5: ldc_w -0.73744076
      // 6d8: fastore
      // 6d9: dup
      // 6da: bipush 13
      // 6dc: ldc_w -1.2071068
      // 6df: fastore
      // 6e0: dup
      // 6e1: bipush 14
      // 6e3: ldc_w -0.5163616
      // 6e6: fastore
      // 6e7: dup
      // 6e8: bipush 15
      // 6ea: ldc_w -0.45426053
      // 6ed: fastore
      // 6ee: dup
      // 6ef: bipush 16
      // 6f1: ldc_w -0.40715656
      // 6f4: fastore
      // 6f5: dup
      // 6f6: bipush 17
      // 6f8: ldc_w -0.3696946
      // 6fb: fastore
      // 6fc: dup
      // 6fd: bipush 18
      // 6ff: ldc_w -0.33908543
      // 702: fastore
      // 703: dup
      // 704: bipush 19
      // 706: ldc_w -0.3151181
      // 709: fastore
      // 70a: dup
      // 70b: bipush 20
      // 70d: ldc_w -0.29642227
      // 710: fastore
      // 711: dup
      // 712: bipush 21
      // 714: ldc_w -0.28184548
      // 717: fastore
      // 718: dup
      // 719: bipush 22
      // 71b: ldc_w -0.5411961
      // 71e: fastore
      // 71f: dup
      // 720: bipush 23
      // 722: ldc_w -0.2621323
      // 725: fastore
      // 726: dup
      // 727: bipush 24
      // 729: ldc_w -0.25387916
      // 72c: fastore
      // 72d: dup
      // 72e: bipush 25
      // 730: ldc_w -0.2329629
      // 733: fastore
      // 734: dup
      // 735: bipush 26
      // 737: ldc_w -0.19852729
      // 73a: fastore
      // 73b: dup
      // 73c: bipush 27
      // 73e: ldc_w -0.15233535
      // 741: fastore
      // 742: dup
      // 743: bipush 28
      // 745: ldc_w -0.0964964
      // 748: fastore
      // 749: dup
      // 74a: bipush 29
      // 74c: ldc_w -0.03342383
      // 74f: fastore
      // 750: dup
      // 751: bipush 30
      // 753: fconst_0
      // 754: fastore
      // 755: dup
      // 756: bipush 31
      // 758: fconst_0
      // 759: fastore
      // 75a: dup
      // 75b: bipush 32
      // 75d: fconst_0
      // 75e: fastore
      // 75f: dup
      // 760: bipush 33
      // 762: fconst_0
      // 763: fastore
      // 764: dup
      // 765: bipush 34
      // 767: fconst_0
      // 768: fastore
      // 769: dup
      // 76a: bipush 35
      // 76c: fconst_0
      // 76d: fastore
      // 76e: aastore
      // 76f: dup
      // 770: bipush 2
      // 771: bipush 36
      // 773: newarray 6
      // 775: dup
      // 776: bipush 0
      // 777: ldc_w -0.0483008
      // 77a: fastore
      // 77b: dup
      // 77c: bipush 1
      // 77d: ldc_w -0.15715657
      // 780: fastore
      // 781: dup
      // 782: bipush 2
      // 783: ldc_w -0.28325045
      // 786: fastore
      // 787: dup
      // 788: bipush 3
      // 789: ldc_w -0.42953748
      // 78c: fastore
      // 78d: dup
      // 78e: bipush 4
      // 78f: ldc_w -1.2071068
      // 792: fastore
      // 793: dup
      // 794: bipush 5
      // 795: ldc_w -0.8242648
      // 798: fastore
      // 799: dup
      // 79a: bipush 6
      // 79c: ldc_w -1.1451749
      // 79f: fastore
      // 7a0: dup
      // 7a1: bipush 7
      // 7a3: ldc_w -1.769529
      // 7a6: fastore
      // 7a7: dup
      // 7a8: bipush 8
      // 7aa: ldc_w -4.5470223
      // 7ad: fastore
      // 7ae: dup
      // 7af: bipush 9
      // 7b1: ldc_w -3.489053
      // 7b4: fastore
      // 7b5: dup
      // 7b6: bipush 10
      // 7b8: ldc_w -0.7329629
      // 7bb: fastore
      // 7bc: dup
      // 7bd: bipush 11
      // 7bf: ldc_w -0.15076515
      // 7c2: fastore
      // 7c3: dup
      // 7c4: bipush 12
      // 7c6: fconst_0
      // 7c7: fastore
      // 7c8: dup
      // 7c9: bipush 13
      // 7cb: fconst_0
      // 7cc: fastore
      // 7cd: dup
      // 7ce: bipush 14
      // 7d0: fconst_0
      // 7d1: fastore
      // 7d2: dup
      // 7d3: bipush 15
      // 7d5: fconst_0
      // 7d6: fastore
      // 7d7: dup
      // 7d8: bipush 16
      // 7da: fconst_0
      // 7db: fastore
      // 7dc: dup
      // 7dd: bipush 17
      // 7df: fconst_0
      // 7e0: fastore
      // 7e1: dup
      // 7e2: bipush 18
      // 7e4: fconst_0
      // 7e5: fastore
      // 7e6: dup
      // 7e7: bipush 19
      // 7e9: fconst_0
      // 7ea: fastore
      // 7eb: dup
      // 7ec: bipush 20
      // 7ee: fconst_0
      // 7ef: fastore
      // 7f0: dup
      // 7f1: bipush 21
      // 7f3: fconst_0
      // 7f4: fastore
      // 7f5: dup
      // 7f6: bipush 22
      // 7f8: fconst_0
      // 7f9: fastore
      // 7fa: dup
      // 7fb: bipush 23
      // 7fd: fconst_0
      // 7fe: fastore
      // 7ff: dup
      // 800: bipush 24
      // 802: fconst_0
      // 803: fastore
      // 804: dup
      // 805: bipush 25
      // 807: fconst_0
      // 808: fastore
      // 809: dup
      // 80a: bipush 26
      // 80c: fconst_0
      // 80d: fastore
      // 80e: dup
      // 80f: bipush 27
      // 811: fconst_0
      // 812: fastore
      // 813: dup
      // 814: bipush 28
      // 816: fconst_0
      // 817: fastore
      // 818: dup
      // 819: bipush 29
      // 81b: fconst_0
      // 81c: fastore
      // 81d: dup
      // 81e: bipush 30
      // 820: fconst_0
      // 821: fastore
      // 822: dup
      // 823: bipush 31
      // 825: fconst_0
      // 826: fastore
      // 827: dup
      // 828: bipush 32
      // 82a: fconst_0
      // 82b: fastore
      // 82c: dup
      // 82d: bipush 33
      // 82f: fconst_0
      // 830: fastore
      // 831: dup
      // 832: bipush 34
      // 834: fconst_0
      // 835: fastore
      // 836: dup
      // 837: bipush 35
      // 839: fconst_0
      // 83a: fastore
      // 83b: aastore
      // 83c: dup
      // 83d: bipush 3
      // 83e: bipush 36
      // 840: newarray 6
      // 842: dup
      // 843: bipush 0
      // 844: fconst_0
      // 845: fastore
      // 846: dup
      // 847: bipush 1
      // 848: fconst_0
      // 849: fastore
      // 84a: dup
      // 84b: bipush 2
      // 84c: fconst_0
      // 84d: fastore
      // 84e: dup
      // 84f: bipush 3
      // 850: fconst_0
      // 851: fastore
      // 852: dup
      // 853: bipush 4
      // 854: fconst_0
      // 855: fastore
      // 856: dup
      // 857: bipush 5
      // 858: fconst_0
      // 859: fastore
      // 85a: dup
      // 85b: bipush 6
      // 85d: ldc_w -0.15076514
      // 860: fastore
      // 861: dup
      // 862: bipush 7
      // 864: ldc_w -0.7329629
      // 867: fastore
      // 868: dup
      // 869: bipush 8
      // 86b: ldc_w -3.489053
      // 86e: fastore
      // 86f: dup
      // 870: bipush 9
      // 872: ldc_w -4.5470223
      // 875: fastore
      // 876: dup
      // 877: bipush 10
      // 879: ldc_w -1.769529
      // 87c: fastore
      // 87d: dup
      // 87e: bipush 11
      // 880: ldc_w -1.1451749
      // 883: fastore
      // 884: dup
      // 885: bipush 12
      // 887: ldc_w -0.8313774
      // 88a: fastore
      // 88b: dup
      // 88c: bipush 13
      // 88e: ldc_w -1.306563
      // 891: fastore
      // 892: dup
      // 893: bipush 14
      // 895: ldc_w -0.54142016
      // 898: fastore
      // 899: dup
      // 89a: bipush 15
      // 89c: ldc_w -0.46528974
      // 89f: fastore
      // 8a0: dup
      // 8a1: bipush 16
      // 8a3: ldc_w -0.4106699
      // 8a6: fastore
      // 8a7: dup
      // 8a8: bipush 17
      // 8aa: ldc_w -0.3700468
      // 8ad: fastore
      // 8ae: dup
      // 8af: bipush 18
      // 8b1: ldc_w -0.3387627
      // 8b4: fastore
      // 8b5: dup
      // 8b6: bipush 19
      // 8b8: ldc_w -0.31242222
      // 8bb: fastore
      // 8bc: dup
      // 8bd: bipush 20
      // 8bf: ldc_w -0.28939587
      // 8c2: fastore
      // 8c3: dup
      // 8c4: bipush 21
      // 8c6: ldc_w -0.26880082
      // 8c9: fastore
      // 8ca: dup
      // 8cb: bipush 22
      // 8cd: ldc_w -0.5
      // 8d0: fastore
      // 8d1: dup
      // 8d2: bipush 23
      // 8d4: ldc_w -0.23251417
      // 8d7: fastore
      // 8d8: dup
      // 8d9: bipush 24
      // 8db: ldc_w -0.21596715
      // 8de: fastore
      // 8df: dup
      // 8e0: bipush 25
      // 8e2: ldc_w -0.20004979
      // 8e5: fastore
      // 8e6: dup
      // 8e7: bipush 26
      // 8e9: ldc_w -0.18449493
      // 8ec: fastore
      // 8ed: dup
      // 8ee: bipush 27
      // 8f0: ldc_w -0.16905846
      // 8f3: fastore
      // 8f4: dup
      // 8f5: bipush 28
      // 8f7: ldc_w -0.15350361
      // 8fa: fastore
      // 8fb: dup
      // 8fc: bipush 29
      // 8fe: ldc_w -0.13758625
      // 901: fastore
      // 902: dup
      // 903: bipush 30
      // 905: ldc_w -0.12103922
      // 908: fastore
      // 909: dup
      // 90a: bipush 31
      // 90c: ldc_w -0.20710678
      // 90f: fastore
      // 910: dup
      // 911: bipush 32
      // 913: ldc_w -0.084752575
      // 916: fastore
      // 917: dup
      // 918: bipush 33
      // 91a: ldc_w -0.06415752
      // 91d: fastore
      // 91e: dup
      // 91f: bipush 34
      // 921: ldc_w -0.041131172
      // 924: fastore
      // 925: dup
      // 926: bipush 35
      // 928: ldc_w -0.014790705
      // 92b: fastore
      // 92c: aastore
      // 92d: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.win [[F
      // 930: bipush 6
      // 932: anewarray 786
      // 935: dup
      // 936: bipush 0
      // 937: bipush 3
      // 938: anewarray 165
      // 93b: dup
      // 93c: bipush 0
      // 93d: bipush 4
      // 93e: newarray 10
      // 940: dup
      // 941: bipush 0
      // 942: bipush 6
      // 944: iastore
      // 945: dup
      // 946: bipush 1
      // 947: bipush 5
      // 948: iastore
      // 949: dup
      // 94a: bipush 2
      // 94b: bipush 5
      // 94c: iastore
      // 94d: dup
      // 94e: bipush 3
      // 94f: bipush 5
      // 950: iastore
      // 951: aastore
      // 952: dup
      // 953: bipush 1
      // 954: bipush 4
      // 955: newarray 10
      // 957: dup
      // 958: bipush 0
      // 959: bipush 9
      // 95b: iastore
      // 95c: dup
      // 95d: bipush 1
      // 95e: bipush 9
      // 960: iastore
      // 961: dup
      // 962: bipush 2
      // 963: bipush 9
      // 965: iastore
      // 966: dup
      // 967: bipush 3
      // 968: bipush 9
      // 96a: iastore
      // 96b: aastore
      // 96c: dup
      // 96d: bipush 2
      // 96e: bipush 4
      // 96f: newarray 10
      // 971: dup
      // 972: bipush 0
      // 973: bipush 6
      // 975: iastore
      // 976: dup
      // 977: bipush 1
      // 978: bipush 9
      // 97a: iastore
      // 97b: dup
      // 97c: bipush 2
      // 97d: bipush 9
      // 97f: iastore
      // 980: dup
      // 981: bipush 3
      // 982: bipush 9
      // 984: iastore
      // 985: aastore
      // 986: aastore
      // 987: dup
      // 988: bipush 1
      // 989: bipush 3
      // 98a: anewarray 165
      // 98d: dup
      // 98e: bipush 0
      // 98f: bipush 4
      // 990: newarray 10
      // 992: dup
      // 993: bipush 0
      // 994: bipush 6
      // 996: iastore
      // 997: dup
      // 998: bipush 1
      // 999: bipush 5
      // 99a: iastore
      // 99b: dup
      // 99c: bipush 2
      // 99d: bipush 7
      // 99f: iastore
      // 9a0: dup
      // 9a1: bipush 3
      // 9a2: bipush 3
      // 9a3: iastore
      // 9a4: aastore
      // 9a5: dup
      // 9a6: bipush 1
      // 9a7: bipush 4
      // 9a8: newarray 10
      // 9aa: dup
      // 9ab: bipush 0
      // 9ac: bipush 9
      // 9ae: iastore
      // 9af: dup
      // 9b0: bipush 1
      // 9b1: bipush 9
      // 9b3: iastore
      // 9b4: dup
      // 9b5: bipush 2
      // 9b6: bipush 12
      // 9b8: iastore
      // 9b9: dup
      // 9ba: bipush 3
      // 9bb: bipush 6
      // 9bd: iastore
      // 9be: aastore
      // 9bf: dup
      // 9c0: bipush 2
      // 9c1: bipush 4
      // 9c2: newarray 10
      // 9c4: dup
      // 9c5: bipush 0
      // 9c6: bipush 6
      // 9c8: iastore
      // 9c9: dup
      // 9ca: bipush 1
      // 9cb: bipush 9
      // 9cd: iastore
      // 9ce: dup
      // 9cf: bipush 2
      // 9d0: bipush 12
      // 9d2: iastore
      // 9d3: dup
      // 9d4: bipush 3
      // 9d5: bipush 6
      // 9d7: iastore
      // 9d8: aastore
      // 9d9: aastore
      // 9da: dup
      // 9db: bipush 2
      // 9dc: bipush 3
      // 9dd: anewarray 165
      // 9e0: dup
      // 9e1: bipush 0
      // 9e2: bipush 4
      // 9e3: newarray 10
      // 9e5: dup
      // 9e6: bipush 0
      // 9e7: bipush 11
      // 9e9: iastore
      // 9ea: dup
      // 9eb: bipush 1
      // 9ec: bipush 10
      // 9ee: iastore
      // 9ef: dup
      // 9f0: bipush 2
      // 9f1: bipush 0
      // 9f2: iastore
      // 9f3: dup
      // 9f4: bipush 3
      // 9f5: bipush 0
      // 9f6: iastore
      // 9f7: aastore
      // 9f8: dup
      // 9f9: bipush 1
      // 9fa: bipush 4
      // 9fb: newarray 10
      // 9fd: dup
      // 9fe: bipush 0
      // 9ff: bipush 18
      // a01: iastore
      // a02: dup
      // a03: bipush 1
      // a04: bipush 18
      // a06: iastore
      // a07: dup
      // a08: bipush 2
      // a09: bipush 0
      // a0a: iastore
      // a0b: dup
      // a0c: bipush 3
      // a0d: bipush 0
      // a0e: iastore
      // a0f: aastore
      // a10: dup
      // a11: bipush 2
      // a12: bipush 4
      // a13: newarray 10
      // a15: dup
      // a16: bipush 0
      // a17: bipush 15
      // a19: iastore
      // a1a: dup
      // a1b: bipush 1
      // a1c: bipush 18
      // a1e: iastore
      // a1f: dup
      // a20: bipush 2
      // a21: bipush 0
      // a22: iastore
      // a23: dup
      // a24: bipush 3
      // a25: bipush 0
      // a26: iastore
      // a27: aastore
      // a28: aastore
      // a29: dup
      // a2a: bipush 3
      // a2b: bipush 3
      // a2c: anewarray 165
      // a2f: dup
      // a30: bipush 0
      // a31: bipush 4
      // a32: newarray 10
      // a34: dup
      // a35: bipush 0
      // a36: bipush 7
      // a38: iastore
      // a39: dup
      // a3a: bipush 1
      // a3b: bipush 7
      // a3d: iastore
      // a3e: dup
      // a3f: bipush 2
      // a40: bipush 7
      // a42: iastore
      // a43: dup
      // a44: bipush 3
      // a45: bipush 0
      // a46: iastore
      // a47: aastore
      // a48: dup
      // a49: bipush 1
      // a4a: bipush 4
      // a4b: newarray 10
      // a4d: dup
      // a4e: bipush 0
      // a4f: bipush 12
      // a51: iastore
      // a52: dup
      // a53: bipush 1
      // a54: bipush 12
      // a56: iastore
      // a57: dup
      // a58: bipush 2
      // a59: bipush 12
      // a5b: iastore
      // a5c: dup
      // a5d: bipush 3
      // a5e: bipush 0
      // a5f: iastore
      // a60: aastore
      // a61: dup
      // a62: bipush 2
      // a63: bipush 4
      // a64: newarray 10
      // a66: dup
      // a67: bipush 0
      // a68: bipush 6
      // a6a: iastore
      // a6b: dup
      // a6c: bipush 1
      // a6d: bipush 15
      // a6f: iastore
      // a70: dup
      // a71: bipush 2
      // a72: bipush 12
      // a74: iastore
      // a75: dup
      // a76: bipush 3
      // a77: bipush 0
      // a78: iastore
      // a79: aastore
      // a7a: aastore
      // a7b: dup
      // a7c: bipush 4
      // a7d: bipush 3
      // a7e: anewarray 165
      // a81: dup
      // a82: bipush 0
      // a83: bipush 4
      // a84: newarray 10
      // a86: dup
      // a87: bipush 0
      // a88: bipush 6
      // a8a: iastore
      // a8b: dup
      // a8c: bipush 1
      // a8d: bipush 6
      // a8f: iastore
      // a90: dup
      // a91: bipush 2
      // a92: bipush 6
      // a94: iastore
      // a95: dup
      // a96: bipush 3
      // a97: bipush 3
      // a98: iastore
      // a99: aastore
      // a9a: dup
      // a9b: bipush 1
      // a9c: bipush 4
      // a9d: newarray 10
      // a9f: dup
      // aa0: bipush 0
      // aa1: bipush 12
      // aa3: iastore
      // aa4: dup
      // aa5: bipush 1
      // aa6: bipush 9
      // aa8: iastore
      // aa9: dup
      // aaa: bipush 2
      // aab: bipush 9
      // aad: iastore
      // aae: dup
      // aaf: bipush 3
      // ab0: bipush 6
      // ab2: iastore
      // ab3: aastore
      // ab4: dup
      // ab5: bipush 2
      // ab6: bipush 4
      // ab7: newarray 10
      // ab9: dup
      // aba: bipush 0
      // abb: bipush 6
      // abd: iastore
      // abe: dup
      // abf: bipush 1
      // ac0: bipush 12
      // ac2: iastore
      // ac3: dup
      // ac4: bipush 2
      // ac5: bipush 9
      // ac7: iastore
      // ac8: dup
      // ac9: bipush 3
      // aca: bipush 6
      // acc: iastore
      // acd: aastore
      // ace: aastore
      // acf: dup
      // ad0: bipush 5
      // ad1: bipush 3
      // ad2: anewarray 165
      // ad5: dup
      // ad6: bipush 0
      // ad7: bipush 4
      // ad8: newarray 10
      // ada: dup
      // adb: bipush 0
      // adc: bipush 8
      // ade: iastore
      // adf: dup
      // ae0: bipush 1
      // ae1: bipush 8
      // ae3: iastore
      // ae4: dup
      // ae5: bipush 2
      // ae6: bipush 5
      // ae7: iastore
      // ae8: dup
      // ae9: bipush 3
      // aea: bipush 0
      // aeb: iastore
      // aec: aastore
      // aed: dup
      // aee: bipush 1
      // aef: bipush 4
      // af0: newarray 10
      // af2: dup
      // af3: bipush 0
      // af4: bipush 15
      // af6: iastore
      // af7: dup
      // af8: bipush 1
      // af9: bipush 12
      // afb: iastore
      // afc: dup
      // afd: bipush 2
      // afe: bipush 9
      // b00: iastore
      // b01: dup
      // b02: bipush 3
      // b03: bipush 0
      // b04: iastore
      // b05: aastore
      // b06: dup
      // b07: bipush 2
      // b08: bipush 4
      // b09: newarray 10
      // b0b: dup
      // b0c: bipush 0
      // b0d: bipush 6
      // b0f: iastore
      // b10: dup
      // b11: bipush 1
      // b12: bipush 18
      // b14: iastore
      // b15: dup
      // b16: bipush 2
      // b17: bipush 9
      // b19: iastore
      // b1a: dup
      // b1b: bipush 3
      // b1c: bipush 0
      // b1d: iastore
      // b1e: aastore
      // b1f: aastore
      // b20: putstatic dev/musicplayer/jlayer/LayerIIIDecoder.nr_of_sfb_block [[[I
      // b23: return
   }

   static class GrInfoS {
      public int part2_3_length = 0;
      public int bigValues = 0;
      public int globalGain = 0;
      public int scalefacCompress = 0;
      public int windowSwitchingFlag = 0;
      public int blockType = 0;
      public int mixedBlockFlag = 0;
      public final int[] tableSelect;
      public final int[] subblockGain;
      public int region0Count = 0;
      public int region1Count = 0;
      public int preflag = 0;
      public int scalefacScale = 0;
      public int count1TableSelect = 0;

      public GrInfoS() {
         this.tableSelect = new int[3];
         this.subblockGain = new int[3];
      }
   }

   static class III_SideInfo {
      public int mainDataBegin = 0;
      public int privateBits = 0;
      public final LayerIIIDecoder.Temporaire[] ch = new LayerIIIDecoder.Temporaire[2];

      public III_SideInfo() {
         this.ch[0] = new LayerIIIDecoder.Temporaire();
         this.ch[1] = new LayerIIIDecoder.Temporaire();
      }
   }

   static class SBI {
      public final int[] l;
      public final int[] s;

      public SBI() {
         this.l = new int[23];
         this.s = new int[14];
      }

      public SBI(int[] thel, int[] thes) {
         this.l = thel;
         this.s = thes;
      }
   }

   static class SfTable {
      public final int[] l;
      public final int[] s;

      public SfTable() {
         this.l = new int[5];
         this.s = new int[3];
      }

      public SfTable(int[] thel, int[] thes) {
         this.l = thel;
         this.s = thes;
      }
   }

   static class Temporaire {
      public final int[] scfsi = new int[4];
      public final LayerIIIDecoder.GrInfoS[] gr = new LayerIIIDecoder.GrInfoS[2];

      public Temporaire() {
         this.gr[0] = new LayerIIIDecoder.GrInfoS();
         this.gr[1] = new LayerIIIDecoder.GrInfoS();
      }
   }

   static class Temporaire2 {
      public final int[] l = new int[23];
      public final int[][] s = new int[3][13];

      public Temporaire2() {
      }
   }
}
