package dev.musicplayer.jlayer;

import java.io.IOException;
import java.io.InputStream;

public class InputStreamSource implements Source {
   private final InputStream in;
   private long position;

   public InputStreamSource(InputStream in) {
      if (in == null) {
         throw new NullPointerException("in");
      } else {
         this.in = in;
      }
   }

   @Override
   public int read(byte[] b, int offs, int len) throws IOException {
      int read = this.in.read(b, offs, len);
      if (read > 0) {
         this.position += read;
      }

      return read;
   }

   @Override
   public boolean willReadBlock() {
      return true;
   }

   @Override
   public boolean isSeekable() {
      return false;
   }

   @Override
   public long tell() {
      return this.position;
   }

   @Override
   public long seek(long to) {
      return -1L;
   }

   @Override
   public long length() {
      return -1L;
   }
}
