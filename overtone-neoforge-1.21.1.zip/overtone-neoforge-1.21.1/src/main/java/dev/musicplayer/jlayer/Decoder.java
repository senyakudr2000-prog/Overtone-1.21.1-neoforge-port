package dev.musicplayer.jlayer;

public class Decoder implements DecoderErrors {
   private static final Decoder.Params DEFAULT_PARAMS = new Decoder.Params();
   private OBuffer output;
   private SynthesisFilter filter1;
   private SynthesisFilter filter2;
   private LayerIIIDecoder l3decoder;
   private LayerIIDecoder l2decoder;
   private LayerIDecoder l1decoder;
   private int outputFrequency;
   private int outputChannels;
   private final Equalizer equalizer = new Equalizer();
   private final Decoder.Params params;
   private boolean initialized;

   public Decoder() {
      this(null);
   }

   public Decoder(Decoder.Params params) {
      if (params == null) {
         params = DEFAULT_PARAMS;
      }

      this.params = params;
      Equalizer eq = this.params.getInitialEqualizerSettings();
      if (eq != null) {
         this.equalizer.setFrom(eq);
      }
   }

   public static Decoder.Params getDefaultParams() {
      return (Decoder.Params)DEFAULT_PARAMS.clone();
   }

   public void setEqualizer(Equalizer eq) {
      if (eq == null) {
         eq = Equalizer.PASS_THRU_EQ;
      }

      this.equalizer.setFrom(eq);
      float[] factors = this.equalizer.getBandFactors();
      if (this.filter1 != null) {
         this.filter1.setEQ(factors);
      }

      if (this.filter2 != null) {
         this.filter2.setEQ(factors);
      }
   }

   public OBuffer decodeFrame(Header header, Bitstream stream) throws DecoderException {
      if (!this.initialized) {
         this.initialize(header);
      }

      int layer = header.layer();
      this.output.clearBuffer();
      FrameDecoder decoder = this.retrieveDecoder(header, stream, layer);
      decoder.decodeFrame();
      this.output.writeBuffer(1);
      return this.output;
   }

   public void seekNotify() {
      if (this.l3decoder != null) {
         this.l3decoder.seek_notify();
      }

      if (this.filter1 != null) {
         this.filter1.reset();
      }

      if (this.filter2 != null) {
         this.filter2.reset();
      }

      if (this.output != null) {
         this.output.clearBuffer();
      }
   }

   public void setOutputBuffer(OBuffer out) {
      this.output = out;
   }

   public int getOutputFrequency() {
      return this.outputFrequency;
   }

   public int getOutputChannels() {
      return this.outputChannels;
   }

   public int getOutputBlockSize() {
      return 2304;
   }

   public SampleBuffer decodeNextFrame(Bitstream stream) throws BitstreamException, DecoderException {
      Header h = stream.readFrame();
      if (h == null) {
         return null;
      } else {
         int channels = h.mode() == 3 ? 1 : 2;
         SampleBuffer sb = new SampleBuffer(h.frequency(), channels);
         this.setOutputBuffer(sb);
         this.decodeFrame(h, stream);
         stream.closeFrame();
         return sb;
      }
   }

   public byte[] decodeNextFrameToPCM(Bitstream stream) throws BitstreamException, DecoderException {
      SampleBuffer sb = this.decodeNextFrame(stream);
      if (sb == null) {
         return null;
      } else {
         short[] buf = sb.getBuffer();
         int len = sb.getBufferLength();
         byte[] out = new byte[len * 2];

         for (int i = 0; i < len; i++) {
            short s = buf[i];
            out[i * 2] = (byte)(s & 255);
            out[i * 2 + 1] = (byte)(s >>> 8 & 0xFF);
         }

         return out;
      }
   }

   protected DecoderException newDecoderException(int errorCode) {
      return new DecoderException(errorCode, null);
   }

   protected DecoderException newDecoderException(int errorCode, Throwable throwable) {
      return new DecoderException(errorCode, throwable);
   }

   protected FrameDecoder retrieveDecoder(Header header, Bitstream stream, int layer) throws DecoderException {
      FrameDecoder decoder = (FrameDecoder)(switch (layer) {
         case 1 -> {
            if (this.l1decoder == null) {
               this.l1decoder = new LayerIDecoder();
               this.l1decoder.create(stream, header, this.filter1, this.filter2, this.output, 0);
            }

            yield this.l1decoder;
         }
         case 2 -> {
            if (this.l2decoder == null) {
               this.l2decoder = new LayerIIDecoder();
               this.l2decoder.create(stream, header, this.filter1, this.filter2, this.output, 0);
            }

            yield this.l2decoder;
         }
         case 3 -> {
            if (this.l3decoder == null) {
               this.l3decoder = new LayerIIIDecoder(stream, header, this.filter1, this.filter2, this.output, 0);
            }

            yield this.l3decoder;
         }
         default -> null;
      });
      if (decoder == null) {
         throw this.newDecoderException(513, null);
      } else {
         return decoder;
      }
   }

   private void initialize(Header header) throws DecoderException {
      float scalefactor = 32700.0F;
      int mode = header.mode();
      int layer = header.layer();
      int channels = mode == 3 ? 1 : 2;
      if (this.output == null) {
         this.output = new SampleBuffer(header.frequency(), channels);
      }

      float[] factors = this.equalizer.getBandFactors();
      this.filter1 = new SynthesisFilter(0, scalefactor, factors);
      if (channels == 2) {
         this.filter2 = new SynthesisFilter(1, scalefactor, factors);
      }

      this.outputChannels = channels;
      this.outputFrequency = header.frequency();
      this.initialized = true;
   }

   public static class Params implements Cloneable {
      private OutputChannels outputChannels = OutputChannels.BOTH;
      private final Equalizer equalizer = new Equalizer();

      public Params() {
      }

      @Override
      public Object clone() {
         try {
            return super.clone();
         } catch (CloneNotSupportedException var2) {
            throw new InternalError(this + ": " + var2);
         }
      }

      public void setOutputChannels(OutputChannels out) {
         if (out == null) {
            throw new NullPointerException("out");
         } else {
            this.outputChannels = out;
         }
      }

      public OutputChannels getOutputChannels() {
         return this.outputChannels;
      }

      public Equalizer getInitialEqualizerSettings() {
         return this.equalizer;
      }
   }
}
