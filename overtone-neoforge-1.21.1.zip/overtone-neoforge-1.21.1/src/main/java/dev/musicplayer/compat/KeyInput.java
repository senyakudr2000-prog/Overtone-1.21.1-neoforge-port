package dev.musicplayer.compat;

import net.minecraft.client.KeyMapping;

public final class KeyInput {
   private final int key;
   private final int scan;
   private final int mods;

   public KeyInput(int key, int scan, int mods) {
      this.key = key;
      this.scan = scan;
      this.mods = mods;
   }

   public int key() {
      return this.key;
   }

   public int scan() {
      return this.scan;
   }

   public int mods() {
      return this.mods;
   }

   public boolean matches(KeyMapping km) {
      return km.matches(this.key, this.scan);
   }
}
