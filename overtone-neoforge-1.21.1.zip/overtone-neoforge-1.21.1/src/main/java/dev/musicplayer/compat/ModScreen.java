package dev.musicplayer.compat;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Base class for the mod's screens. NeoForge 1.21.1 port: Screen.render() itself draws the
 * background (blur / dim), so renderBackground() is guarded to run at most once per frame.
 */
public abstract class ModScreen extends Screen {
   private boolean backgroundDone;
   private long lastClick;

   protected ModScreen(Component title) {
      super(title);
   }

   protected abstract void draw(Canvas var1, int var2, int var3, float var4);

   protected final void drawWidgets(Canvas g, int mx, int my, float delta) {
      super.render(((CanvasImpl)g).ctx, mx, my, delta);
   }

   @Override
   public final void render(GuiGraphics g, int mx, int my, float delta) {
      this.renderBackground(g, mx, my, delta);
      this.draw(new CanvasImpl(g), mx, my, delta);
      this.backgroundDone = false;
   }

   @Override
   public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
      if (!this.backgroundDone) {
         this.backgroundDone = true;
         super.renderBackground(g, mx, my, delta);
      }
   }

   protected boolean onClick(double x, double y, int button, boolean doubleClick) {
      return super.mouseClicked(x, y, button);
   }

   protected boolean onDrag(double x, double y, int button, double dx, double dy) {
      return super.mouseDragged(x, y, button, dx, dy);
   }

   protected boolean onRelease(double x, double y, int button) {
      return super.mouseReleased(x, y, button);
   }

   protected boolean onKey(KeyInput in) {
      return super.keyPressed(in.key(), in.scan(), in.mods());
   }

   @Override
   public final boolean mouseClicked(double x, double y, int button) {
      long now = System.currentTimeMillis();
      boolean doubleClick = now - this.lastClick < 250L;
      this.lastClick = now;
      return this.onClick(x, y, button, doubleClick);
   }

   @Override
   public final boolean mouseDragged(double x, double y, int button, double dx, double dy) {
      return this.onDrag(x, y, button, dx, dy);
   }

   @Override
   public final boolean mouseReleased(double x, double y, int button) {
      return this.onRelease(x, y, button);
   }

   @Override
   public final boolean keyPressed(int key, int scan, int mods) {
      return this.onKey(new KeyInput(key, scan, mods));
   }

   @Override
   public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
      return super.mouseScrolled(x, y, horizontal, vertical);
   }
}
