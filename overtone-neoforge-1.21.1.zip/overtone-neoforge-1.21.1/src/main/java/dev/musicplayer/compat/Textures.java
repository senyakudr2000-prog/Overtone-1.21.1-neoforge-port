package dev.musicplayer.compat;

import com.mojang.blaze3d.platform.NativeImage;
import dev.musicplayer.MusicPlayerMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

public final class Textures {
   private Textures() {
   }

   public static Tex upload(String name, int[] argb, int size) {
      Minecraft mc = Minecraft.getInstance();
      if (mc == null) {
         return null;
      } else {
         try {
            NativeImage image = new NativeImage(size, size, false);

            for (int y = 0; y < size; y++) {
               for (int x = 0; x < size; x++) {
                  image.setPixelRGBA(x, y, toAbgr(argb[y * size + x]));
               }
            }

            DynamicTexture texture = new DynamicTexture(image);
            ResourceLocation id = ResourceLocation.fromNamespaceAndPath("musicplayer", name);
            mc.getTextureManager().register(id, texture);
            return new Tex(id);
         } catch (Exception var7) {
            MusicPlayerMod.LOGGER.warn("Failed to upload cover art as a texture", var7);
            return null;
         }
      }
   }

   public static void release(Tex tex) {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && tex != null) {
         mc.getTextureManager().release(tex.id);
      }
   }

   private static int toAbgr(int argb) {
      return argb & -16711936 | (argb & 0xFF) << 16 | argb >> 16 & 0xFF;
   }
}
