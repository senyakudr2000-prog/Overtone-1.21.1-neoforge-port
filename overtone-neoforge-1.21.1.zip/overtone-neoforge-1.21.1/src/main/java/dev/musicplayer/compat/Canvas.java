package dev.musicplayer.compat;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.util.FormattedCharSequence;

public abstract class Canvas {
   public Canvas() {
   }

   public abstract int screenWidth();

   public abstract int screenHeight();

   public abstract void fill(int var1, int var2, int var3, int var4, int var5);

   public abstract void text(Font var1, String var2, int var3, int var4, int var5, boolean var6);

   public abstract void text(Font var1, FormattedCharSequence var2, int var3, int var4, int var5);

   public abstract void texture(Tex var1, int var2, int var3, int var4, int var5, int var6, float var7);

   public abstract void pushMatrix();

   public abstract void translate(float var1, float var2);

   public abstract void scale(float var1, float var2);

   public abstract void popMatrix();

   private static Font font() {
      return Minecraft.getInstance().font;
   }

   public void rect(int x, int y, int width, int height, int argb) {
      if (width > 0 && height > 0) {
         this.fill(x, y, x + width, y + height, argb);
      }
   }

   public void text(String value, int x, int y, int argb, boolean shadow) {
      this.text(font(), value, x, y, argb, shadow);
   }

   public void text(Font font, String value, int x, int y, int argb) {
      this.text(font, value, x, y, argb, true);
   }

   public void push(float scale) {
      this.pushMatrix();
      if (scale != 1.0F) {
         this.scale(scale, scale);
      }
   }

   public void pop() {
      this.popMatrix();
   }

   public int textWidth(String value) {
      return font().width(value);
   }

   public int lineHeight() {
      return 9;
   }

   public String trim(String value, int maxWidth) {
      if (value == null) {
         return "";
      } else {
         Font font = font();
         if (font.width(value) <= maxWidth) {
            return value;
         } else {
            int ellipsis = font.width("...");
            StringBuilder sb = new StringBuilder();
            int w = 0;

            for (int i = 0; i < value.length(); i++) {
               int cw = font.width(String.valueOf(value.charAt(i)));
               if (w + cw + ellipsis > maxWidth) {
                  break;
               }

               w += cw;
               sb.append(value.charAt(i));
            }

            return sb.append("...").toString();
         }
      }
   }

   public List<String> wrap(String text, int maxWidth, int maxLines) {
      List<String> out = new ArrayList<>();
      if (text != null && !text.isBlank()) {
         StringBuilder cur = new StringBuilder();
         String[] words = text.trim().split("\\s+");

         int i;
         for (i = 0; i < words.length; i++) {
            String test = cur.length() == 0 ? words[i] : cur + " " + words[i];
            if (font().width(test) <= maxWidth) {
               cur.setLength(0);
               cur.append(test);
            } else {
               if (cur.length() > 0) {
                  out.add(cur.toString());
                  cur.setLength(0);
                  if (out.size() >= maxLines) {
                     break;
                  }
               }

               cur.append(words[i]);
            }
         }

         boolean truncated = i < words.length;
         if (!truncated && cur.length() > 0 && out.size() < maxLines) {
            out.add(cur.toString());
         }

         for (int k = 0; k < out.size(); k++) {
            String line = out.get(k);
            if (truncated && k == out.size() - 1) {
               line = line + "...";
            }

            out.set(k, this.trim(line, maxWidth));
         }

         return out;
      } else {
         return out;
      }
   }

   public static boolean statusBarsVisible() {
      Minecraft mc = Minecraft.getInstance();
      return mc.gameMode != null && mc.gameMode.canHurtPlayer();
   }
}
