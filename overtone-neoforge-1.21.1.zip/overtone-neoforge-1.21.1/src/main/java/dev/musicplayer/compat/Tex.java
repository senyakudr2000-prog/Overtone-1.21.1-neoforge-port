package dev.musicplayer.compat;

import net.minecraft.resources.ResourceLocation;

public final class Tex {
   public final ResourceLocation id;

   public Tex(ResourceLocation id) {
      this.id = id;
   }
}
