package dev.musicplayer.compat;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.FormattedCharSequence;

public final class CanvasImpl extends Canvas {
   final GuiGraphics ctx;

   public CanvasImpl(GuiGraphics ctx) {
      this.ctx = ctx;
   }

   @Override
   public int screenWidth() {
      return this.ctx.guiWidth();
   }

   @Override
   public int screenHeight() {
      return this.ctx.guiHeight();
   }

   @Override
   public void fill(int x1, int y1, int x2, int y2, int argb) {
      this.ctx.fill(x1, y1, x2, y2, argb);
   }

   @Override
   public void text(Font font, String value, int x, int y, int argb, boolean shadow) {
      this.ctx.drawString(font, value, x, y, argb, shadow);
   }

   @Override
   public void text(Font font, FormattedCharSequence value, int x, int y, int argb) {
      this.ctx.drawString(font, value, x, y, argb, true);
   }

   @Override
   public void texture(Tex texture, int x, int y, int width, int height, int textureSize, float alpha) {
      RenderSystem.enableBlend();
      this.ctx.setColor(1.0F, 1.0F, 1.0F, Math.max(0.0F, Math.min(1.0F, alpha)));
      this.ctx.blit(texture.id, x, y, width, height, 0.0F, 0.0F, textureSize, textureSize, textureSize, textureSize);
      this.ctx.setColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   @Override
   public void pushMatrix() {
      this.ctx.pose().pushPose();
   }

   @Override
   public void translate(float x, float y) {
      this.ctx.pose().translate(x, y, 0.0F);
   }

   @Override
   public void scale(float x, float y) {
      this.ctx.pose().scale(x, y, 1.0F);
   }

   @Override
   public void popMatrix() {
      this.ctx.pose().popPose();
   }
}
