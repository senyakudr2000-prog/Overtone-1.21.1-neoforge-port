package dev.musicplayer.compat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

public final class Game {
   private Game() {
   }

   public static Screen screen() {
      Minecraft mc = Minecraft.getInstance();
      return mc.screen;
   }

   public static boolean guiOpen() {
      return screen() != null;
   }

   public static boolean playerListHeld() {
      return Minecraft.getInstance().options.keyPlayerList.isDown();
   }

   public static void open(Screen screen) {
      Minecraft mc = Minecraft.getInstance();
      mc.setScreen(screen);
   }
}
