package dev.musicplayer.compat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.phys.Vec3;

public final class CameraPos {
   private CameraPos() {
   }

   public static Vec3 get() {
      GameRenderer renderer = Minecraft.getInstance().gameRenderer;
      return renderer == null ? null : renderer.getMainCamera().getPosition();
   }
}
