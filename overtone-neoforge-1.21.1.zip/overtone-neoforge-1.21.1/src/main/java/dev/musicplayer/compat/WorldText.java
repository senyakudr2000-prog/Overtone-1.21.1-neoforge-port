package dev.musicplayer.compat;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.util.FormattedCharSequence;

public abstract class WorldText {
   public WorldText() {
   }

   public abstract void text(PoseStack var1, float var2, float var3, FormattedCharSequence var4, boolean var5, boolean var6, int var7);

   public abstract void rotateY(PoseStack var1, float var2);

   public abstract void rotateZ(PoseStack var1, float var2);

   public void rotateX(PoseStack pose, float rad) {
   }

   public void flush() {
   }
}
