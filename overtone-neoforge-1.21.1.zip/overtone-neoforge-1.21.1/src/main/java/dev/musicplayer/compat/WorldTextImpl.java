package dev.musicplayer.compat;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Font.DisplayMode;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.util.FormattedCharSequence;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class WorldTextImpl extends WorldText {
   private static final int LIGHT = 15728880;
   private static final float SHADOW_BACK = 0.5F;
   private final BufferSource buffers = Minecraft.getInstance().renderBuffers().bufferSource();
   private final List<WorldTextImpl.Front> fronts = new ArrayList<>();

   public WorldTextImpl() {
   }

   @Override
   public void text(PoseStack pose, float x, float y, FormattedCharSequence seq, boolean shadow, boolean seeThrough, int argb) {
      Font font = Minecraft.getInstance().font;
      DisplayMode mode = seeThrough ? DisplayMode.SEE_THROUGH : DisplayMode.NORMAL;
      if (!shadow) {
         font.drawInBatch(seq, x, y, argb, false, pose.last().pose(), this.buffers, mode, 0, 15728880);
      } else {
         int dark = argb & 0xFF000000 | (argb & 16579836) >> 2;
         pose.pushPose();
         pose.translate(0.0F, 0.0F, -towardViewer(pose.last().pose()) * 0.5F);
         font.drawInBatch(seq, x + 1.0F, y + 1.0F, dark, false, pose.last().pose(), this.buffers, mode, 0, 15728880);
         pose.popPose();
         this.fronts.add(new WorldTextImpl.Front(seq, x, y, argb, mode, new Matrix4f(pose.last().pose())));
      }
   }

   private static float towardViewer(Matrix4f m) {
      Vector3f origin = m.transformPosition(0.0F, 0.0F, 0.0F, new Vector3f());
      Vector3f ahead = m.transformPosition(0.0F, 0.0F, 1.0F, new Vector3f());
      return ahead.length() < origin.length() ? 1.0F : -1.0F;
   }

   @Override
   public void rotateY(PoseStack pose, float rad) {
      pose.mulPose(new Quaternionf().rotationY(rad));
   }

   @Override
   public void rotateX(PoseStack pose, float rad) {
      pose.mulPose(new Quaternionf().rotationX(rad));
   }

   @Override
   public void rotateZ(PoseStack pose, float rad) {
      pose.mulPose(new Quaternionf().rotationZ(rad));
   }

   @Override
   public void flush() {
      this.buffers.endBatch();
      if (!this.fronts.isEmpty()) {
         Font font = Minecraft.getInstance().font;

         for (WorldTextImpl.Front f : this.fronts) {
            font.drawInBatch(f.seq, f.x, f.y, f.argb, false, f.pose, this.buffers, f.mode, 0, 15728880);
         }

         this.fronts.clear();
         this.buffers.endBatch();
      }
   }

   private record Front(FormattedCharSequence seq, float x, float y, int argb, DisplayMode mode, Matrix4f pose) {
   }
}
