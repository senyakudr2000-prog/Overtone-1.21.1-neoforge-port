package dev.musicplayer.compat;

import com.mojang.blaze3d.platform.InputConstants.Key;
import com.mojang.blaze3d.platform.InputConstants.Type;
import net.minecraft.client.KeyMapping;

public final class Keys {
   public static final int ENTER = 257;
   public static final int KP_ENTER = 335;
   public static final int ESCAPE = 256;
   public static final int DELETE = 261;
   public static final int BACKSPACE = 259;
   public static final int SPACE = 32;
   public static final int LEFT = 263;
   public static final int RIGHT = 262;
   public static final int UP = 265;
   public static final int DOWN = 264;
   private static final String CATEGORY = "key.category.musicplayer.main";

   private Keys() {
   }

   public static Key key(int code) {
      return Type.KEYSYM.getOrCreate(code);
   }

   public static KeyMapping create(String translationKey, int defaultKey) {
      return new KeyMapping(translationKey, Type.KEYSYM, defaultKey, "key.category.musicplayer.main");
   }
}
