package dev.musicplayer;

import dev.musicplayer.config.HudConfig;
import dev.musicplayer.controller.PlayerController;
import dev.musicplayer.hud.CoverArt;
import dev.musicplayer.input.Hotkeys;
import dev.musicplayer.viz.Visualizer;
import java.nio.file.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class MusicPlayerMod {
   public static final String MOD_ID = "musicplayer";
   public static final String NAME = "Overtone";
   public static final String AUTHORS = "chifir4ik, PabJlo";
   public static final Logger LOGGER = LoggerFactory.getLogger("Overtone");

   private MusicPlayerMod() {
   }

   public static void init(Path configDir, Path gameDir) {
      Env.init(configDir, gameDir);
      LOGGER.info("{} by {}", "Overtone", "chifir4ik, PabJlo");
      HudConfig.get();
      Hotkeys.create();
   }

   public static void onClientStarted() {
      Hotkeys.onClientStarted();
   }

   public static void onClientTick() {
      CoverArt.tick();
      Hotkeys.tick();
      PlayerController.I.tickPersist();
      Visualizer.tick();
   }
}
