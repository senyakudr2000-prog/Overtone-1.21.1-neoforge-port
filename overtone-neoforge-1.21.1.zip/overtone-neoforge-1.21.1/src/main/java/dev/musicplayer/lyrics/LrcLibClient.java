package dev.musicplayer.lyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.Track;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.function.Supplier;

public final class LrcLibClient {
   private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).build();
   private static final double MAX_DIFF_SYNCED = 5.0;
   private static final double MAX_DIFF_PLAIN = 15.0;
   private static final long PAUSE_MS = 300000L;
   private static volatile long pausedUntil;

   private LrcLibClient() {
   }

   private static boolean paused() {
      return System.currentTimeMillis() < pausedUntil;
   }

   private static List<LyricLine> failed(Throwable e) {
      Throwable cause = e;

      while (cause.getCause() != null) {
         cause = cause.getCause();
      }

      boolean outage = cause instanceof IOException || cause instanceof JsonParseException || cause instanceof IllegalStateException;
      if (outage) {
         if (!paused()) {
            MusicPlayerMod.LOGGER.warn("LRCLIB unavailable ({}), lookups paused for 5 minutes", cause.toString());
         }

         pausedUntil = System.currentTimeMillis() + 300000L;
      }

      return List.of();
   }

   private static void checkStatus(HttpResponse<?> r) {
      int sc = r.statusCode();
      if (sc == 429 || sc >= 500) {
         throw new CompletionException(new IOException("HTTP " + sc));
      }
   }

   public static CompletableFuture<List<LyricLine>> fetch(Track t) {
      List<TrackMatch.Query> queries = TrackMatch.queries(t);
      TrackMatch.Query main = queries.get(0);
      String clean = TrackMatch.cleanTitle(main.title());
      String artist = TrackMatch.firstArtist(main.artist());
      CompletableFuture<List<LyricLine>> f = exact(t, main.title(), main.artist(), t.album());
      f = then(f, () -> exact(t, clean, artist, null));

      for (TrackMatch.Query q : queries) {
         String title = TrackMatch.cleanTitle(q.title());
         String by = TrackMatch.firstArtist(q.artist());
         f = then(f, () -> search(t, "track_name=" + enc(q.title()) + "&artist_name=" + enc(q.artist())));
         f = then(f, () -> search(t, "track_name=" + enc(title) + "&artist_name=" + enc(by)));
         f = then(f, () -> search(t, "q=" + enc(title + " " + by)));
      }

      f = then(f, () -> search(t, "track_name=" + enc(clean)));
      return f.exceptionally(e -> List.of());
   }

   private static CompletableFuture<List<LyricLine>> then(CompletableFuture<List<LyricLine>> prev, Supplier<CompletableFuture<List<LyricLine>>> next) {
      return prev.thenCompose(l -> l.isEmpty() ? next.get() : CompletableFuture.completedFuture((List<LyricLine>)l));
   }

   private static CompletableFuture<List<LyricLine>> exact(Track t, String title, String artist, String album) {
      if (paused()) {
         return CompletableFuture.completedFuture(List.of());
      } else {
         String url = "https://lrclib.net/api/get?track_name="
            + enc(title)
            + "&artist_name="
            + enc(artist)
            + (album != null ? "&album_name=" + enc(album) : "")
            + (t.durationMs() > 0L ? "&duration=" + Math.round(t.durationMs() / 1000.0) : "");
         return HTTP.sendAsync(req(url), BodyHandlers.ofString(StandardCharsets.UTF_8)).<List<LyricLine>>thenApply(r -> {
            checkStatus((HttpResponse<?>)r);
            if (r.statusCode() != 200) {
               return List.of();
            } else {
               LrcLibClient.Candidate c = candidate(JsonParser.parseString(r.body()).getAsJsonObject(), t);
               return c == null ? List.of() : c.lines;
            }
         }).exceptionally(LrcLibClient::failed);
      }
   }

   private static CompletableFuture<List<LyricLine>> search(Track t, String query) {
      return paused()
         ? CompletableFuture.completedFuture(List.of())
         : HTTP.sendAsync(req("https://lrclib.net/api/search?" + query), BodyHandlers.ofString(StandardCharsets.UTF_8)).<List<LyricLine>>thenApply(r -> {
            checkStatus((HttpResponse<?>)r);
            if (r.statusCode() != 200) {
               return List.of();
            } else {
               JsonArray arr = JsonParser.parseString(r.body()).getAsJsonArray();
               LrcLibClient.Candidate best = null;

               for (JsonElement e : arr) {
                  LrcLibClient.Candidate c = candidate(e.getAsJsonObject(), t);
                  if (c != null && (best == null || c.betterThan(best))) {
                     best = c;
                  }
               }

               return best == null ? List.of() : best.lines;
            }
         }).exceptionally(LrcLibClient::failed);
   }

   private static LrcLibClient.Candidate candidate(JsonObject o, Track t) {
      TrackMatch.Level level = TrackMatch.level(str(o, "trackName"), str(o, "artistName"), t);
      if (level == TrackMatch.Level.NONE) {
         return null;
      } else {
         double diff = TrackMatch.durationDiff(o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsDouble() : 0.0, t);
         List<LyricLine> synced = hasText(o, "syncedLyrics") ? LrcParser.parse(o.get("syncedLyrics").getAsString()) : List.of();
         if (!synced.isEmpty() && TrackMatch.durationFits(diff, 5.0, level) && TrackMatch.scriptOk(t.title(), synced)) {
            return new LrcLibClient.Candidate(synced, true, diff);
         } else {
            List<LyricLine> plain = hasText(o, "plainLyrics") ? LrcParser.plain(o.get("plainLyrics").getAsString()) : List.of();
            return !plain.isEmpty() && TrackMatch.durationFits(diff, 15.0, level) && TrackMatch.scriptOk(t.title(), plain)
               ? new LrcLibClient.Candidate(plain, false, diff)
               : null;
         }
      }
   }

   private static String str(JsonObject o, String k) {
      return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
   }

   private static boolean hasText(JsonObject o, String k) {
      return !str(o, k).isBlank();
   }

   private static HttpRequest req(String url) {
      return HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "Overtone (Minecraft mod)").timeout(Duration.ofSeconds(7L)).GET().build();
   }

   private static String enc(String s) {
      return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8);
   }

   private record Candidate(List<LyricLine> lines, boolean synced, double diff) {
      boolean betterThan(LrcLibClient.Candidate o) {
         return this.synced != o.synced ? this.synced : Double.compare(Double.isNaN(this.diff) ? 0.0 : this.diff, Double.isNaN(o.diff) ? 0.0 : o.diff) < 0;
      }
   }
}
