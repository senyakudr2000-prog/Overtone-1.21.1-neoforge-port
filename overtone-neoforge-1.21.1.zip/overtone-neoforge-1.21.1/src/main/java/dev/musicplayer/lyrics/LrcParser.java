package dev.musicplayer.lyrics;

import dev.musicplayer.config.HudConfig;
import dev.musicplayer.model.LyricLine;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LrcParser {
   private static final Pattern TAG = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]");
   private static final Pattern WORD_TAG = Pattern.compile("<(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?>");
   private static final Pattern OFFSET = Pattern.compile("^\\s*\\[offset:\\s*([+-]?\\d{1,6})\\s*]", 10);

   private LrcParser() {
   }

   public static List<LyricLine> plain(String text) {
      List<LyricLine> out = new ArrayList<>();
      if (text != null && !text.isBlank()) {
         for (String line : text.split("\\R")) {
            out.add(new LyricLine(Long.MAX_VALUE, line));
         }

         return out;
      } else {
         return out;
      }
   }

   public static List<LyricLine> parse(String lrc) {
      List<LyricLine> out = new ArrayList<>();
      if (lrc == null) {
         return out;
      } else {
         long offset = 0L;
         Matcher om = OFFSET.matcher(lrc);
         if (om.find()) {
            offset = Long.parseLong(om.group(1));
         }

         for (String raw : lrc.split("\\R")) {
            Matcher m = TAG.matcher(raw);
            List<Long> times = new ArrayList<>();

            int end;
            for (end = 0; m.find() && m.start() == end; end = m.end()) {
               long min = Long.parseLong(m.group(1));
               long sec = Long.parseLong(m.group(2));
               String frac = m.group(3);
               long ms = 0L;
               if (frac != null) {
                  ms = Long.parseLong(frac);
                  if (frac.length() == 1) {
                     ms *= 100L;
                  } else if (frac.length() == 2) {
                     ms *= 10L;
                  }
               }

               times.add(min * 60000L + sec * 1000L + ms);
            }

            if (!times.isEmpty()) {
               String body = raw.substring(end);
               if (WORD_TAG.matcher(body).find()) {
                  for (long t : times) {
                     out.add(parseWords(Math.max(0L, t - offset), body, offset));
                  }
               } else {
                  String text = body.trim();

                  for (long t : times) {
                     out.add(new LyricLine(Math.max(0L, t - offset), text));
                  }
               }
            }
         }

         out.sort(Comparator.comparingLong(LyricLine::timeMs));
         return out;
      }
   }

   private static long tagMs(Matcher m) {
      long ms = 0L;
      String frac = m.group(3);
      if (frac != null) {
         ms = Long.parseLong(frac);
         if (frac.length() == 1) {
            ms *= 100L;
         } else if (frac.length() == 2) {
            ms *= 10L;
         }
      }

      return Long.parseLong(m.group(1)) * 60000L + Long.parseLong(m.group(2)) * 1000L + ms;
   }

   private static LyricLine parseWords(long lineMs, String body, long offset) {
      StringBuilder plain = new StringBuilder();
      List<long[]> marks = new ArrayList<>();
      Matcher m = WORD_TAG.matcher(body);

      int last;
      for (last = 0; m.find(); last = m.end()) {
         plain.append(body, last, m.start());
         marks.add(new long[]{plain.length(), Math.max(0L, tagMs(m) - offset)});
      }

      plain.append(body.substring(last));
      String text = plain.toString();
      List<LyricLine.Word> words = new ArrayList<>();
      int i = 0;
      int n = text.length();

      while (i < n) {
         while (i < n && Character.isWhitespace(text.charAt(i))) {
            i++;
         }

         int start = i;

         while (i < n && !Character.isWhitespace(text.charAt(i))) {
            i++;
         }

         if (i > start) {
            long t = lineMs;

            for (long[] mk : marks) {
               if (mk[0] > start) {
                  break;
               }

               t = mk[1];
            }

            words.add(new LyricLine.Word(Math.max(lineMs, t), text.substring(start, i)));
         }
      }

      return new LyricLine(lineMs, text.trim(), words.isEmpty() ? null : words);
   }

   public static int currentIndex(List<LyricLine> lines, long positionMs) {
      positionMs -= HudConfig.get().lyricsShiftMs;
      int lo = 0;
      int hi = lines.size() - 1;
      int ans = -1;

      while (lo <= hi) {
         int mid = lo + hi >>> 1;
         if (lines.get(mid).timeMs() <= positionMs) {
            ans = mid;
            lo = mid + 1;
         } else {
            hi = mid - 1;
         }
      }

      return ans;
   }
}
