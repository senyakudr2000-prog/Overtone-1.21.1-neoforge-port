package dev.musicplayer.lyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.musicplayer.Env;
import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.Track;
import dev.musicplayer.net.SafeHttp;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.regex.Pattern;

public final class AmllClient {
   private static final String BASE = "https://raw.githubusercontent.com/amll-dev/amll-ttml-db/refs/heads/main/";
   private static final SafeHttp HTTP = new SafeHttp(Set.of("raw.githubusercontent.com"));
   private static final Map<String, String> HEADERS = Map.of("User-Agent", "Overtone (Minecraft mod)");
   private static final Pattern FILE = Pattern.compile("[\\w.-]+\\.ttml");
   private static final long INDEX_TTL_MS = Duration.ofDays(3L).toMillis();
   private static final long RETRY_AFTER_FAIL_MS = Duration.ofMinutes(10L).toMillis();
   private static final int MAX_VERSIONS = 3;
   private static final int WAIT_SECONDS = 4;
   private static final ExecutorService LOADER = Executors.newSingleThreadExecutor(r -> {
      Thread t = new Thread(r, "musicplayer-amll-index");
      t.setDaemon(true);
      return t;
   });
   private static volatile List<AmllClient.Entry> index;
   private static volatile long indexedAt;
   private static volatile long failedAt;
   private static CompletableFuture<List<AmllClient.Entry>> loading;

   private AmllClient() {
   }

   public static CompletableFuture<List<LyricLine>> fetch(Track t) {
      return LyricsIo.run(() -> lookup(t));
   }

   private static List<LyricLine> lookup(Track t) throws Exception {
      List<AmllClient.Entry> all;
      try {
         all = indexNow().get(4L, TimeUnit.SECONDS);
      } catch (TimeoutException var9) {
         return List.of();
      }

      List<String> wanted = new ArrayList<>();

      for (TrackMatch.Query q : TrackMatch.queries(t)) {
         wanted.add(TrackMatch.norm(TrackMatch.cleanTitle(q.title())));
      }

      List<AmllClient.Entry> hits = new ArrayList<>();

      for (AmllClient.Entry e : all) {
         if (matches(e, t, wanted)) {
            hits.add(e);
         }
      }

      int i = hits.size() - 1;

      for (int tried = 0; i >= 0 && tried < 3; tried++) {
         String file = hits.get(i).file();
         if (FILE.matcher(file).matches()) {
            try {
               List<LyricLine> lines = TtmlParser.parse(
                  HTTP.get("https://raw.githubusercontent.com/amll-dev/amll-ttml-db/refs/heads/main/raw-lyrics/" + file, HEADERS)
               );
               if (!lines.isEmpty() && fitsTrack(lines, t)) {
                  return lines;
               }
            } catch (IOException var8) {
            }
         }

         i--;
      }

      return List.of();
   }

   private static boolean fitsTrack(List<LyricLine> lines, Track t) {
      if (t.durationMs() <= 0L) {
         return true;
      } else {
         long last = lines.get(lines.size() - 1).timeMs();
         return last <= t.durationMs() + 3000L && last >= t.durationMs() / 2L;
      }
   }

   private static boolean matches(AmllClient.Entry e, Track t, List<String> wanted) {
      for (String title : e.titles()) {
         String have = TrackMatch.norm(TrackMatch.cleanTitle(title));
         if (!have.isEmpty() && !wanted.stream().noneMatch(w -> !w.isEmpty() && (have.contains(w) || w.contains(have)))) {
            for (String artist : e.artists()) {
               if (TrackMatch.level(title, artist, t) == TrackMatch.Level.FULL) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private static synchronized CompletableFuture<List<AmllClient.Entry>> indexNow() {
      List<AmllClient.Entry> current = index;
      boolean stale = current == null || System.currentTimeMillis() - indexedAt > INDEX_TTL_MS;
      if (stale && loading == null) {
         CompletableFuture<List<AmllClient.Entry>> f = CompletableFuture.supplyAsync(() -> {
            try {
               return loadIndex();
            } catch (IOException var1x) {
               throw new CompletionException(var1x);
            }
         }, LOADER);
         loading = f;
         f.whenComplete((r, e) -> {
            synchronized (AmllClient.class) {
               loading = null;
            }
         });
      }

      return current != null ? CompletableFuture.completedFuture(current) : loading;
   }

   private static List<AmllClient.Entry> loadIndex() throws IOException {
      Path cache = Env.configDir().resolve("musicplayer-cache").resolve("amll-index.jsonl");
      boolean fresh = Files.exists(cache) && System.currentTimeMillis() - Files.getLastModifiedTime(cache).toMillis() < INDEX_TTL_MS;
      if (fresh) {
         return publish(Files.readString(cache, StandardCharsets.UTF_8), false);
      } else if (System.currentTimeMillis() - failedAt < RETRY_AFTER_FAIL_MS) {
         if (index != null) {
            return index;
         } else {
            throw new IOException("AMLL index is unavailable");
         }
      } else {
         try {
            String raw = HTTP.get("https://raw.githubusercontent.com/amll-dev/amll-ttml-db/refs/heads/main/metadata/raw-lyrics-index.jsonl", HEADERS);
            Files.createDirectories(cache.getParent());
            Path tmp = cache.resolveSibling(cache.getFileName() + ".tmp");
            Files.writeString(tmp, raw, StandardCharsets.UTF_8);
            Files.move(tmp, cache, StandardCopyOption.REPLACE_EXISTING);
            return publish(raw, false);
         } catch (InterruptedException | IOException var4) {
            if (var4 instanceof InterruptedException) {
               Thread.currentThread().interrupt();
            }

            failedAt = System.currentTimeMillis();
            MusicPlayerMod.LOGGER.warn("AMLL TTML DB index is unavailable: {}", var4.getMessage());
            if (index != null) {
               return index;
            } else if (!Files.exists(cache)) {
               throw new IOException("AMLL index is unavailable", var4);
            } else {
               return publish(Files.readString(cache, StandardCharsets.UTF_8), true);
            }
         }
      }
   }

   private static List<AmllClient.Entry> publish(String raw, boolean outdated) {
      List<AmllClient.Entry> parsed = parseIndex(raw);
      index = parsed;
      indexedAt = outdated ? System.currentTimeMillis() - INDEX_TTL_MS + RETRY_AFTER_FAIL_MS : System.currentTimeMillis();
      return parsed;
   }

   private static List<AmllClient.Entry> parseIndex(String raw) {
      List<AmllClient.Entry> out = new ArrayList<>();

      for (String line : raw.split("\\R")) {
         if (!line.isBlank()) {
            try {
               JsonObject o = JsonParser.parseString(line).getAsJsonObject();
               List<String> titles = new ArrayList<>();
               List<String> artists = new ArrayList<>();

               for (JsonElement m : o.getAsJsonArray("metadata")) {
                  JsonArray pair = m.getAsJsonArray();
                  String key = pair.get(0).getAsString();
                  List<String> target = key.equals("musicName") ? titles : (key.equals("artists") ? artists : null);
                  if (target != null) {
                     for (JsonElement v : pair.get(1).getAsJsonArray()) {
                        target.add(v.getAsString());
                     }
                  }
               }

               if (!titles.isEmpty() && !artists.isEmpty()) {
                  out.add(new AmllClient.Entry(titles, artists, o.get("rawLyricFile").getAsString()));
               }
            } catch (RuntimeException var16) {
            }
         }
      }

      return out;
   }

   private record Entry(List<String> titles, List<String> artists, String file) {
   }
}
