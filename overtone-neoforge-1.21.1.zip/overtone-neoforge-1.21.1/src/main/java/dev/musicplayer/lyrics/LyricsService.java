package dev.musicplayer.lyrics;

import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.config.PlayerConfig;
import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.Track;
import dev.musicplayer.provider.MusicProvider;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public final class LyricsService {
   private static final long ONLINE_TIMEOUT_SECONDS = 12L;
   private static final long TOTAL_TIMEOUT_SECONDS = 30L;

   private LyricsService() {
   }

   public static CompletableFuture<List<LyricLine>> fetch(Track t, MusicProvider source) {
      return source.lyrics(t, true)
         .exceptionally(e -> List.of())
         .thenCompose(l -> !l.isEmpty() ? done((List<LyricLine>)l) : online(t))
         .thenCompose(
            l -> !l.isEmpty() && !isPlain((List<LyricLine>)l)
               ? done((List<LyricLine>)l)
               : source.lyrics(t, false).exceptionally(e -> List.of()).thenApply(y -> y.isEmpty() ? l : y)
         )
         .exceptionally(e -> List.of())
         .completeOnTimeout(List.of(), 30L, TimeUnit.SECONDS)
         .thenApply(l -> {
            if (l.isEmpty()) {
               MusicPlayerMod.LOGGER.info("No lyrics found: \"{}\" by {}", t.title(), t.artist());
            }

            return l;
         });
   }

   private static CompletableFuture<List<LyricLine>> online(Track t) {
      PlayerConfig c = PlayerConfig.get();
      if (!c.onlineLyrics) {
         return done(List.of());
      } else {
         CompletableFuture<List<LyricLine>> f = c.amllLyrics ? AmllClient.fetch(t) : done(List.of());
         f = f.thenCompose(l -> l.isEmpty() ? LrcLibClient.fetch(t) : done((List<LyricLine>)l));
         if (c.kugouLyrics) {
            f = f.thenCompose(
               l -> !l.isEmpty() && !isPlain((List<LyricLine>)l) ? done((List<LyricLine>)l) : KuGouClient.fetch(t).thenApply(k -> k.isEmpty() ? l : k)
            );
         }

         return f.completeOnTimeout(List.of(), 12L, TimeUnit.SECONDS);
      }
   }

   private static boolean isPlain(List<LyricLine> l) {
      return l.get(0).timeMs() == Long.MAX_VALUE;
   }

   private static CompletableFuture<List<LyricLine>> done(List<LyricLine> l) {
      return CompletableFuture.completedFuture(l);
   }
}
