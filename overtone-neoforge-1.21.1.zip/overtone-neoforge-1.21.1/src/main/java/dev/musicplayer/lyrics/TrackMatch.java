package dev.musicplayer.lyrics;

import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.Track;
import java.lang.Character.UnicodeScript;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class TrackMatch {
   private static final Pattern ARTIST_DASH_TITLE = Pattern.compile("^(.+?)\\s+[-\u2013\u2014]\\s+(.+)$");
   private static final String SPLIT = ",|&| feat\\.| ft\\.| x ";

   private TrackMatch() {
   }

   static List<TrackMatch.Query> queries(Track t) {
      List<TrackMatch.Query> out = new ArrayList<>();
      out.add(new TrackMatch.Query(t.title(), t.artist()));
      Matcher m = ARTIST_DASH_TITLE.matcher(t.title() == null ? "" : t.title());
      if (m.matches()) {
         out.add(new TrackMatch.Query(m.group(2).trim(), m.group(1).trim()));
      }

      return out;
   }

   static TrackMatch.Level level(String foundTitle, String foundArtist, Track t) {
      TrackMatch.Level best = TrackMatch.Level.NONE;

      for (TrackMatch.Query q : queries(t)) {
         if (titleOk(foundTitle, q.title())) {
            if (artistOk(foundArtist, q.artist())) {
               return TrackMatch.Level.FULL;
            }

            if (norm(cleanTitle(foundTitle)).equals(norm(cleanTitle(q.title())))) {
               best = TrackMatch.Level.LOOSE;
            }
         }
      }

      return best;
   }

   static boolean durationFits(double diff, double max, TrackMatch.Level level) {
      return level == TrackMatch.Level.LOOSE ? !Double.isNaN(diff) && diff <= Math.min(max, 3.0) : Double.isNaN(diff) || diff <= max;
   }

   static double durationDiff(double foundSeconds, Track t) {
      return t.durationMs() > 0L && !(foundSeconds <= 0.0) ? Math.abs(foundSeconds - t.durationMs() / 1000.0) : Double.NaN;
   }

   static boolean scriptOk(String title, List<LyricLine> lines) {
      if (!hasCyrillic(title)) {
         return true;
      } else {
         int cyr = 0;
         int letters = 0;

         for (LyricLine l : lines) {
            for (char c : l.text().toCharArray()) {
               if (UnicodeScript.of(c) == UnicodeScript.CYRILLIC) {
                  cyr++;
                  letters++;
               } else if (Character.isLetter(c)) {
                  letters++;
               }
            }
         }

         return letters == 0 || cyr >= letters * 0.2;
      }
   }

   static boolean titleOk(String found, String wanted) {
      return similar(norm(cleanTitle(found)), norm(cleanTitle(wanted))) || similar(norm(found), norm(wanted));
   }

   static boolean artistOk(String found, String wanted) {
      String f = norm(found);
      if (f.isEmpty()) {
         return false;
      } else {
         for (String name : (wanted == null ? "" : wanted).split(",|&| feat\\.| ft\\.| x ")) {
            String n = norm(name);
            if (!n.isEmpty() && similar(f, n)) {
               return true;
            }
         }

         return similar(f, norm(wanted));
      }
   }

   private static boolean similar(String a, String b) {
      if (a.isEmpty() || b.isEmpty()) {
         return false;
      } else if (a.equals(b)) {
         return true;
      } else {
         String shorter = a.length() <= b.length() ? a : b;
         String longer = shorter == a ? b : a;
         return longer.contains(shorter) && shorter.length() * 2 >= longer.length();
      }
   }

   private static boolean hasCyrillic(String s) {
      if (s == null) {
         return false;
      } else {
         for (char c : s.toCharArray()) {
            if (UnicodeScript.of(c) == UnicodeScript.CYRILLIC) {
               return true;
            }
         }

         return false;
      }
   }

   static String norm(String s) {
      return s == null ? "" : s.toLowerCase(Locale.ROOT).replace('\u0451', '\u0435').replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
   }

   static String firstArtist(String artist) {
      if (artist == null) {
         return "";
      } else {
         String a = artist.split(",|&| feat\\.| ft\\.| x ")[0].trim();
         return a.isEmpty() ? artist : a;
      }
   }

   static String cleanTitle(String title) {
      if (title == null) {
         return "";
      } else {
         String c = title.replaceAll("\\s*[\\(\\[].*?[\\)\\]]", "")
            .replaceAll("(?i)\\s+(feat\\.|ft\\.|featuring)\\s.*$", "")
            .replaceAll("\\s+-\\s+.*$", "")
            .trim();
         return c.isEmpty() ? title : c;
      }
   }

   static enum Level {
      NONE,
      LOOSE,
      FULL;

      private Level() {
      }
   }

   record Query(String title, String artist) {
   }
}
