package dev.musicplayer.lyrics;

import dev.musicplayer.model.LyricLine;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class LyricsIo {
   private static final ExecutorService POOL = Executors.newFixedThreadPool(2, r -> {
      Thread t = new Thread(r, "musicplayer-lyrics");
      t.setDaemon(true);
      return t;
   });

   private LyricsIo() {
   }

   static CompletableFuture<List<LyricLine>> run(Callable<List<LyricLine>> task) {
      return CompletableFuture.supplyAsync(() -> {
         try {
            return task.call();
         } catch (Exception var2) {
            return List.of();
         }
      }, POOL);
   }
}
