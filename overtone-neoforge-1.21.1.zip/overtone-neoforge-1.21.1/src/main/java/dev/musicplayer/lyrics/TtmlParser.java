package dev.musicplayer.lyrics;

import dev.musicplayer.model.LyricLine;
import java.io.StringReader;
import java.lang.Character.UnicodeScript;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

final class TtmlParser {
   private static final String TTM = "http://www.w3.org/ns/ttml#metadata";
   private static final int CJK_GROUP = 4;
   private static final Pattern SPACING = Pattern.compile("</span>\\s+<span|<span[^>]*>\\s|\\s</span>");

   private TtmlParser() {
   }

   static List<LyricLine> parse(String xml) {
      List<LyricLine> out = new ArrayList<>();
      boolean legacy = !SPACING.matcher(xml).find();

      try {
         DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
         f.setNamespaceAware(true);

         try {
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
         } catch (ParserConfigurationException var8) {
            f.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
         }

         Document doc = f.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
         NodeList ps = doc.getElementsByTagNameNS("*", "p");

         for (int i = 0; i < ps.getLength(); i++) {
            LyricLine l = line((Element)ps.item(i), legacy);
            if (l != null) {
               out.add(l);
            }
         }
      } catch (Exception var9) {
         return List.of();
      }

      out.sort(Comparator.comparingLong(LyricLine::timeMs));
      return out;
   }

   private static LyricLine line(Element p, boolean legacy) {
      long begin = time(p.getAttribute("begin"));
      List<TtmlParser.Piece> pieces = new ArrayList<>();
      walk(p, pieces, new boolean[1], begin);
      if (pieces.isEmpty()) {
         String text = ownText(p);
         return begin >= 0L && !text.isEmpty() ? new LyricLine(begin, text) : null;
      } else {
         pieces.sort(Comparator.comparingLong(TtmlParser.Piece::ms));
         if (begin < 0L) {
            begin = pieces.get(0).ms();
         }

         if (legacy) {
            pieces = spaced(pieces);
         }

         List<LyricLine.Word> words = new ArrayList<>();
         StringBuilder text = new StringBuilder();
         StringBuilder word = null;
         long wordMs = 0L;
         int len = 0;

         for (TtmlParser.Piece pc : pieces) {
            if (pc.spaceBefore() && text.length() > 0) {
               text.append(' ');
            }

            text.append(pc.text());
            int n = pc.text().codePointCount(0, pc.text().length());
            boolean glue = word != null && !pc.spaceBefore() && (len < 4 || !cjk(word.codePointBefore(word.length())) || !cjk(pc.text().codePointAt(0)));
            if (glue) {
               word.append(pc.text());
               len += n;
            } else {
               if (word != null) {
                  words.add(new LyricLine.Word(Math.max(begin, wordMs), word.toString()));
               }

               word = new StringBuilder(pc.text());
               wordMs = pc.ms();
               len = n;
            }
         }

         words.add(new LyricLine.Word(Math.max(begin, wordMs), word.toString()));
         return new LyricLine(begin, text.toString(), words);
      }
   }

   private static void walk(Node parent, List<TtmlParser.Piece> out, boolean[] gap, long fallback) {
      for (Node c = parent.getFirstChild(); c != null; c = c.getNextSibling()) {
         if (c.getNodeType() == 3) {
            if (c.getTextContent().isBlank()) {
               gap[0] = true;
            }
         } else if (c instanceof Element e) {
            String role = e.getAttributeNS("http://www.w3.org/ns/ttml#metadata", "role");
            if (!role.equals("x-translation") && !role.equals("x-roman")) {
               if (hasChildElements(e)) {
                  gap[0] = true;
                  walk(e, out, gap, fallback);
                  gap[0] = true;
               } else {
                  String s = e.getTextContent();
                  if (s.isBlank()) {
                     gap[0] = true;
                  } else {
                     long t = time(e.getAttribute("begin"));
                     if (t < 0L) {
                        t = fallback;
                     }

                     boolean space = gap[0] || Character.isWhitespace(s.charAt(0));

                     for (String part : s.strip().split("\\s+")) {
                        out.add(new TtmlParser.Piece(t, part, space));
                        space = true;
                     }

                     gap[0] = Character.isWhitespace(s.charAt(s.length() - 1));
                  }
               }
            }
         }
      }
   }

   private static List<TtmlParser.Piece> spaced(List<TtmlParser.Piece> in) {
      if (in.size() >= 2 && !cjk(in.get(0).text().codePointAt(0))) {
         List<TtmlParser.Piece> out = new ArrayList<>(in.size());
         out.add(in.get(0));

         for (int i = 1; i < in.size(); i++) {
            TtmlParser.Piece p = in.get(i);
            String prev = in.get(i - 1).text();
            boolean attach = ",.!?;:)'\u2019".indexOf(p.text().charAt(0)) >= 0 || "'\u2019(".indexOf(prev.charAt(prev.length() - 1)) >= 0;
            out.add(new TtmlParser.Piece(p.ms(), p.text(), !attach));
         }

         return out;
      } else {
         return in;
      }
   }

   private static boolean hasChildElements(Element e) {
      for (Node c = e.getFirstChild(); c != null; c = c.getNextSibling()) {
         if (c instanceof Element) {
            return true;
         }
      }

      return false;
   }

   private static String ownText(Element p) {
      StringBuilder sb = new StringBuilder();

      for (Node c = p.getFirstChild(); c != null; c = c.getNextSibling()) {
         if (c.getNodeType() == 3) {
            sb.append(c.getTextContent());
         }
      }

      return sb.toString().strip();
   }

   private static boolean cjk(int cp) {
      UnicodeScript s = UnicodeScript.of(cp);
      return s == UnicodeScript.HAN || s == UnicodeScript.HIRAGANA || s == UnicodeScript.KATAKANA || s == UnicodeScript.HANGUL;
   }

   static long time(String s) {
      if (s == null) {
         return -1L;
      } else {
         s = s.strip();

         try {
            if (s.endsWith("ms")) {
               return Math.round(Double.parseDouble(s.substring(0, s.length() - 2)));
            } else if (s.endsWith("s")) {
               return Math.round(Double.parseDouble(s.substring(0, s.length() - 1)) * 1000.0);
            } else {
               String[] parts = s.split(":");
               double sec = 0.0;

               for (String part : parts) {
                  sec = sec * 60.0 + Double.parseDouble(part);
               }

               return Math.round(sec * 1000.0);
            }
         } catch (NumberFormatException var8) {
            return -1L;
         }
      }
   }

   private record Piece(long ms, String text, boolean spaceBefore) {
   }
}
