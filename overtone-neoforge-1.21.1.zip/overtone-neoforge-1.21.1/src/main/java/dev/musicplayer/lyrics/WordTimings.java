package dev.musicplayer.lyrics;

import dev.musicplayer.model.LyricLine;
import java.util.List;

public final class WordTimings {
   public final String[] words;
   public final long[] start;
   public final long[] end;
   public final boolean real;

   private WordTimings(String[] words, long[] start, long[] end, boolean real) {
      this.words = words;
      this.start = start;
      this.end = end;
      this.real = real;
   }

   public static WordTimings of(LyricLine line, LyricLine next) {
      if (line != null && line.text() != null && line.timeMs() != Long.MAX_VALUE) {
         long nextGap = next != null && next.timeMs() != Long.MAX_VALUE ? Math.max(1L, next.timeMs() - line.timeMs()) : 5000L;
         if (line.hasWordTimings()) {
            List<LyricLine.Word> src = line.words();
            int n = src.size();
            String[] w = new String[n];
            long[] s = new long[n];
            long[] e = new long[n];

            for (int i = 0; i < n; i++) {
               w[i] = src.get(i).text();
               s[i] = src.get(i).timeMs();
               long end = i + 1 < n ? src.get(i + 1).timeMs() : Math.min(line.timeMs() + nextGap - 100L, s[i] + 1500L);
               e[i] = Math.max(s[i] + 140L, end);
            }

            return new WordTimings(w, s, e, true);
         } else {
            String t = line.text().trim();
            if (t.isEmpty()) {
               return null;
            } else {
               String[] parts = t.split("\\s+");
               int chars = 0;

               for (String p : parts) {
                  chars += Math.max(1, p.length());
               }

               long usable = Math.max(400L, Math.min(nextGap - 120L, Math.max(1400L, chars * 80L)));
               long[] s = new long[parts.length];
               long[] e = new long[parts.length];
               int before = 0;

               for (int i = 0; i < parts.length; i++) {
                  int len = Math.max(1, parts[i].length());
                  s[i] = line.timeMs() + usable * before / chars;
                  e[i] = s[i] + Math.max(140L, usable * len / chars);
                  before += len;
               }

               return new WordTimings(parts, s, e, false);
            }
         }
      } else {
         return null;
      }
   }
}
