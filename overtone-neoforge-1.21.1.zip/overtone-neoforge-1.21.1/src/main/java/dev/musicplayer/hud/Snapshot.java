package dev.musicplayer.hud;

import dev.musicplayer.controller.PlayerController;
import dev.musicplayer.lyrics.LrcParser;
import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.Track;
import dev.musicplayer.util.T;
import java.util.ArrayList;
import java.util.List;

public final class Snapshot {
   public String id;
   public String title;
   public String artist;
   public String coverUrl;
   public long durationMs;
   public long posMs;
   public boolean playing;
   public List<LyricLine> lyrics = List.of();
   public boolean synced;
   private static List<LyricLine> demoLyrics;

   public Snapshot() {
   }

   public static Snapshot live() {
      PlayerController ctl = PlayerController.I;
      Track t = ctl.current;
      if (t != null && !ctl.idle) {
         Snapshot s = new Snapshot();
         s.id = t.id();
         s.title = t.title() == null ? "" : t.title();
         s.artist = t.artist() == null ? "" : t.artist();
         s.coverUrl = t.coverUrl();
         s.durationMs = t.durationMs();
         s.posMs = ctl.engine().positionMs();
         s.playing = ctl.engine().isPlaying();
         s.lyrics = ctl.lyrics;
         s.synced = !s.lyrics.isEmpty() && s.lyrics.get(0).timeMs() != Long.MAX_VALUE;
         return s;
      } else {
         return null;
      }
   }

   public static Snapshot liveOrDemo() {
      Snapshot s = live();
      return s != null ? s : demo();
   }

   public static Snapshot demo() {
      if (demoLyrics == null) {
         String[] text = new String[8];

         for (int i = 0; i < text.length; i++) {
            text[i] = i == 5 ? "\u266a" : T.get("demo.line." + i);
         }

         List<LyricLine> l = new ArrayList<>();

         for (int i = 0; i < text.length; i++) {
            l.add(new LyricLine(60000L + i * 4000L, text[i]));
         }

         demoLyrics = l;
      }

      Snapshot s = new Snapshot();
      s.id = "demo";
      s.title = T.get("demo.title");
      s.artist = T.get("demo.artist");
      s.durationMs = 215000L;
      s.posMs = 60000L + System.currentTimeMillis() % 32000L;
      s.playing = true;
      s.lyrics = demoLyrics;
      s.synced = true;
      return s;
   }

   public int lyricIndex() {
      return this.synced ? LrcParser.currentIndex(this.lyrics, this.posMs) : -1;
   }

   public double fraction() {
      return this.durationMs <= 0L ? 0.0 : Math.max(0.0, Math.min(1.0, (double)this.posMs / this.durationMs));
   }

   public static String fmt(long ms) {
      long s = Math.max(0L, ms) / 1000L;
      return s / 60L + ":" + String.format("%02d", s % 60L);
   }

   public String timeLabel() {
      return fmt(this.posMs) + " / " + fmt(this.durationMs);
   }
}
