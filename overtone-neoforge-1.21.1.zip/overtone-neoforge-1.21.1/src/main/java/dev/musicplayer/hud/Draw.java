package dev.musicplayer.hud;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.compat.Game;
import dev.musicplayer.config.HudConfig;

final class Draw {
   static HudBounds.Box lastBox;

   static boolean hidden(HudConfig cfg) {
      return cfg.hideWithGui && Game.guiOpen() || cfg.hideOnTab && Game.playerListHeld();
   }

   private Draw() {
   }

   static int argb(int rgb, int alpha) {
      return (Math.max(0, Math.min(255, alpha)) & 0xFF) << 24 | rgb & 16777215;
   }

   static int a255(float alpha) {
      return Math.round(255.0F * Math.max(0.0F, Math.min(1.0F, alpha)));
   }

   static int lerpRgb(int from, int to, float t) {
      int r = Math.round((from >> 16 & 0xFF) + ((to >> 16 & 0xFF) - (from >> 16 & 0xFF)) * t);
      int g = Math.round((from >> 8 & 0xFF) + ((to >> 8 & 0xFF) - (from >> 8 & 0xFF)) * t);
      int b = Math.round((from & 0xFF) + ((to & 0xFF) - (from & 0xFF)) * t);
      return r << 16 | g << 8 | b;
   }

   static float clampScale(float s) {
      return Math.max(0.5F, Math.min(2.0F, s));
   }

   static float easeOut(float t) {
      float u = 1.0F - Math.max(0.0F, Math.min(1.0F, t));
      return 1.0F - u * u * u;
   }

   static int[] begin(Canvas c, HudConfig.Anchor anchor, int ox, int oy, float scale, int w, int h, float alpha) {
      scale = clampScale(scale);
      int sw = Math.round(c.screenWidth() / scale);
      int sh = Math.round(c.screenHeight() / scale);
      int x = anchor.h < 0 ? ox : (anchor.h > 0 ? sw - w - ox : (sw - w) / 2 + ox);
      int y = anchor.v < 0 ? oy : (anchor.v > 0 ? sh - h - oy : (sh - h) / 2 + oy);
      lastBox = new HudBounds.Box(Math.round(x * scale), Math.round(y * scale), Math.round(w * scale), Math.round(h * scale), w, h, scale);
      int slide = Math.round((1.0F - alpha) * 8.0F);
      if (anchor.h != 0) {
         x += anchor.h < 0 ? -slide : slide;
      } else {
         y += anchor.v <= 0 ? -slide : slide;
      }

      c.push(scale);
      return new int[]{x, y};
   }

   static void roundedRect(Canvas c, int x, int y, int w, int h, int r, int color) {
      if (h > 0) {
         int start = 0;
         int runIn = inset(0, h, r);

         for (int row = 1; row <= h; row++) {
            int in = row < h ? inset(row, h, r) : -1;
            if (in != runIn) {
               c.rect(x + runIn, y + start, w - runIn * 2, row - start, color);
               start = row;
               runIn = in;
            }
         }
      }
   }

   static void roundedOutline(Canvas c, int x, int y, int w, int h, int r, int color) {
      int prev = -1;

      for (int row = 0; row < h; row++) {
         int in = inset(row, h, r);
         if (row != 0 && row != h - 1) {
            c.rect(x + in, y + row, 1, 1, color);
            c.rect(x + w - in - 1, y + row, 1, 1, color);
            if (prev >= 0 && prev != in) {
               c.rect(x + in, y + row, prev - in, 1, color);
               c.rect(x + w - prev, y + row, prev - in, 1, color);
            }
         } else {
            c.rect(x + in, y + row, w - in * 2, 1, color);
         }

         prev = in;
      }
   }

   private static int inset(int row, int height, int radius) {
      if (radius <= 0) {
         return 0;
      } else {
         double d = 0.0;
         if (row < radius) {
            d = radius - 0.5 - row;
         } else if (row >= height - radius) {
            d = row - (height - radius - 0.5);
         }

         if (d <= 0.0) {
            return 0;
         } else {
            double inner = radius * radius - d * d;
            return inner <= 0.0 ? radius : (int)Math.round(radius - Math.sqrt(inner));
         }
      }
   }

   static void panel(Canvas c, int x, int y, int w, int h, int opacityPercent, float alpha) {
      int pa = Math.round(255.0F * (opacityPercent / 100.0F) * alpha);
      int r = Math.min(8, h / 3);
      roundedRect(c, x, y, w, h, r, argb(1315866, pa));
      roundedOutline(c, x, y, w, h, r, argb(3816260, Math.round(pa * 0.8F)));
   }

   static void progress(Canvas c, int x, int y, int w, int h, double fraction, int accentRgb, float alpha) {
      if (w > 2) {
         int filled = (int)Math.round(w * Math.max(0.0, Math.min(1.0, fraction)));
         int back = argb(3816004, Math.round(200.0F * alpha));
         int fill = argb(accentRgb, a255(alpha));
         if (h >= 3) {
            roundedRect(c, x, y, w, h, h / 2, back);
            if (filled > 1) {
               roundedRect(c, x, y, filled, h, h / 2, fill);
            }
         } else {
            c.rect(x, y, w, h, back);
            if (filled > 0) {
               c.rect(x, y, filled, h, fill);
            }
         }
      }
   }
}
