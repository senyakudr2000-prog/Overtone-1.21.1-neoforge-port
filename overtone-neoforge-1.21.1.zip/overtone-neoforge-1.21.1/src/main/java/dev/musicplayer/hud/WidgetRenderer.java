package dev.musicplayer.hud;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.compat.Tex;
import dev.musicplayer.config.HudConfig;
import dev.musicplayer.model.LyricLine;
import dev.musicplayer.viz.Visualizer;
import java.util.List;

public final class WidgetRenderer {
   private static final Visualizer EQ = new Visualizer();
   private static final int PAD = 5;
   private static final int COVER = 32;
   private static final int GAP = 7;
   private static final int LINE = 11;
   private static final int MAX_TEXT = 140;
   private static final int BAR_COUNT = 5;
   private static final int BAR_W = 2;
   private static final int BAR_GAP = 2;
   private static final int BARS_W = 18;
   private static final int C_TITLE = 16777215;
   private static final int C_ARTIST = 11776947;
   private static final int C_TIME = 9211020;
   private static final int C_BARS = 14474460;
   private static final int V_BG = -267386864;
   private static final int V_BORDER_TOP = 1347420415;
   private static final int V_BORDER_BOTTOM = 1344798847;
   private static float alpha;
   private static boolean cardLyricsHidden;
   private static long lastNanos;
   private static String lastId;
   private static long changedAt;

   private WidgetRenderer() {
   }

   public static void render(Canvas c, boolean preview) {
      HudConfig cfg = HudConfig.get();
      HudBounds.widget = null;
      Snapshot s = preview ? Snapshot.liveOrDemo() : Snapshot.live();
      long now = System.nanoTime();
      float delta = lastNanos == 0L ? 0.0F : Math.min(0.1F, (float)(now - lastNanos) / 1.0E9F);
      lastNanos = now;
      if (s != null && !s.id.equals(lastId)) {
         lastId = s.id;
         changedAt = now;
      }

      boolean wanted = s != null && (preview || cfg.master && cfg.enabled && shouldShow(cfg, s, now));
      alpha = alpha + ((wanted ? 1.0F : 0.0F) - alpha) * Math.min(1.0F, delta * (wanted ? 4.5F : 3.0F));
      float a = preview ? 1.0F : alpha;
      if (a < 0.02F) {
         if (!preview) {
            alpha = 0.0F;
         }
      } else if (s != null) {
         if (cfg.showCover && s.coverUrl != null) {
            CoverArt.offerRemote(s.id, s.coverUrl);
         }

         Draw.lastBox = null;
         cardLyricsHidden = !preview && WorldLyricsRenderer.takesOver();
         switch (cfg.layout) {
            case CLASSIC:
               drawClassic(c, cfg, s, a, now);
               break;
            case BAR:
               drawBar(c, cfg, s, a, now);
               break;
            case COMPACT:
               drawCompact(c, cfg, s, a);
               break;
            case HOTBAR:
               drawHotbar(c, cfg, s, a, now);
               break;
            case VANILLA:
               drawVanilla(c, cfg, s, a, now);
               break;
            default:
               drawCard(c, cfg, s, a, now);
         }

         HudBounds.widget = Draw.lastBox;
      }
   }

   private static boolean shouldShow(HudConfig cfg, Snapshot s, long now) {
      if (Draw.hidden(cfg)) {
         return false;
      } else if (!cfg.showMode.timed()) {
         return true;
      } else {
         long window = cfg.showMode.seconds * 1000L;
         if (cfg.showOnSongStart) {
            if (s.posMs <= window) {
               return true;
            }

            if ((now - changedAt) / 1000000L <= window) {
               return true;
            }
         }

         return cfg.showOnSongEnd && s.durationMs > 0L && s.durationMs - s.posMs <= window;
      }
   }

   private static void drawCard(Canvas c, HudConfig cfg, Snapshot s, float a, long now) {
      int cover = cfg.showCover ? 40 : 0;
      int pad = 6;
      int tw = 150;
      int innerX = 6 + (cover > 0 ? cover + 8 : 0);
      int w = innerX + 150 + 6;
      int lyricIdx = s.lyricIndex();
      boolean lyr = cfg.cardLyrics && s.synced && lyricIdx >= 0 && !cardLyricsHidden;
      int top = Math.max(cover, 24);
      int barY = 6 + top + 6;
      int h = barY + 3 + (cfg.showTimestamps ? 4 + c.lineHeight() : 0) + 6;
      int lyrH = lyr ? 30 : 0;
      int[] o = Draw.begin(c, cfg.anchor, cfg.offsetX, cfg.offsetY, cfg.scale, w, h + lyrH, a);
      int x = o[0];
      int y = o[1];
      int accent = cfg.accentRgb();
      Draw.panel(c, x, y, w, h + lyrH, cfg.backgroundOpacity, a);
      c.rect(x + 1, y + 4, 2, h + lyrH - 8, Draw.argb(accent, Draw.a255(a)));
      if (cover > 0) {
         artwork(c, s, x + 6, y + 6, cover, a);
      }

      int textW = 150 - (cfg.showWaveform ? 24 : 0);
      c.text(c.trim(s.title, textW), x + innerX, y + 6 + 4, Draw.argb(16777215, Draw.a255(a)), true);
      c.text(c.trim(s.artist, textW), x + innerX, y + 6 + 4 + 11 + 2, Draw.argb(11776947, Draw.a255(a)), true);
      if (cfg.showWaveform) {
         equaliser(c, x + w - 6 - 18, y + 6 + 12, s, a, now, accent);
      }

      Draw.progress(c, x + 6, y + barY, w - 12, 3, s.fraction(), accent, a);
      if (cfg.showTimestamps) {
         int ty = y + barY + 6;
         c.text(Snapshot.fmt(s.posMs), x + 6, ty, Draw.argb(9211020, Draw.a255(a)), true);
         String total = Snapshot.fmt(s.durationMs);
         c.text(total, x + w - 6 - c.textWidth(total), ty, Draw.argb(9211020, Draw.a255(a)), true);
         if (!s.playing) {
            String p = "II";
            c.text(p, x + w / 2 - c.textWidth(p) / 2, ty, Draw.argb(accent, Draw.a255(a)), true);
         }
      }

      if (lyr) {
         int ly = y + h;
         c.rect(x + 6, ly - 1, w - 12, 1, Draw.argb(16777215, Math.round(40.0F * a)));
         int lw = w - 12;
         String cur = lyricText(s.lyrics, lyricIdx);
         c.text(c.trim(cur, lw), x + 6, ly + 4, Draw.argb(16777215, Draw.a255(a)), true);
         if (lyricIdx + 1 < s.lyrics.size()) {
            String nx = lyricText(s.lyrics, lyricIdx + 1);
            c.text(c.trim(nx, lw), x + 6, ly + 16, Draw.argb(9211020, Draw.a255(a)), true);
         }
      }

      c.pop();
   }

   private static void drawClassic(Canvas c, HudConfig cfg, Snapshot s, float a, long now) {
      int timeW = cfg.showTimestamps ? c.textWidth("88:88 / 88:88") : 0;
      String title = c.trim(s.title, 140);
      String artist = c.trim(s.artist, 140);
      int textW = Math.min(140, Math.max(Math.max(c.textWidth(title), c.textWidth(artist)), timeW));
      int w = 10 + textW;
      if (cfg.showCover) {
         w += 39;
      }

      if (cfg.showWaveform) {
         w += 25;
      }

      int h = 42;
      int[] o = Draw.begin(c, cfg.anchor, cfg.offsetX, cfg.offsetY, cfg.scale, w, h, a);
      int x = o[0];
      int y = o[1];
      Draw.panel(c, x, y, w, h, cfg.backgroundOpacity, a);
      int cx = x + 5;
      if (cfg.showCover) {
         artwork(c, s, cx, y + 5, 32, a);
         cx += 39;
      }

      int ty = y + 5 + 1;
      c.text(title, cx, ty, Draw.argb(16777215, Draw.a255(a)), true);
      c.text(artist, cx, ty + 11, Draw.argb(11776947, Draw.a255(a)), true);
      if (cfg.showTimestamps) {
         c.text(s.timeLabel(), cx, ty + 22, Draw.argb(9211020, Draw.a255(a)), true);
      }

      if (cfg.showWaveform) {
         equaliser(c, x + w - 5 - 18, y + h / 2, s, a, now, 14474460);
      }

      c.pop();
   }

   private static void drawBar(Canvas c, HudConfig cfg, Snapshot s, float a, long now) {
      int timeW = cfg.showTimestamps ? c.textWidth("88:88 / 88:88") : 0;
      String title = c.trim(s.title, 140);
      String artist = c.trim(s.artist, Math.max(40, 140 - (timeW > 0 ? timeW + 7 : 0)));
      int second = c.textWidth(artist) + (timeW > 0 ? 7 + timeW : 0);
      int textW = Math.min(140, Math.max(c.textWidth(title), Math.max(second, 80)));
      int w = 10 + textW;
      if (cfg.showCover) {
         w += 39;
      }

      if (cfg.showWaveform) {
         w += 25;
      }

      int h = 42;
      int[] o = Draw.begin(c, cfg.anchor, cfg.offsetX, cfg.offsetY, cfg.scale, w, h, a);
      int x = o[0];
      int y = o[1];
      Draw.panel(c, x, y, w, h, cfg.backgroundOpacity, a);
      int cx = x + 5;
      if (cfg.showCover) {
         artwork(c, s, cx, y + 5, 32, a);
         cx += 39;
      }

      int right = x + w - 5 - (cfg.showWaveform ? 25 : 0);
      c.text(title, cx, y + 5 + 2, Draw.argb(16777215, Draw.a255(a)), true);
      c.text(artist, cx, y + 5 + 2 + 11, Draw.argb(11776947, Draw.a255(a)), true);
      if (cfg.showTimestamps) {
         String t = s.timeLabel();
         c.text(t, right - c.textWidth(t), y + 5 + 2 + 11, Draw.argb(9211020, Draw.a255(a)), true);
      }

      if (cfg.showWaveform) {
         equaliser(c, x + w - 5 - 18, y + 5 + 8, s, a, now, 14474460);
      }

      Draw.progress(c, cx, y + h - 5 - 4, x + w - 5 - cx, 4, s.fraction(), cfg.accentRgb(), a);
      c.pop();
   }

   private static void drawCompact(Canvas c, HudConfig cfg, Snapshot s, float a) {
      int art = 16;
      int pad = 3;
      int h = 22;
      String dot = "\u00b7";
      String title = c.trim(s.title, 120);
      String artist = c.trim(s.artist, 90);
      String rest = "-" + Snapshot.fmt(Math.max(0L, s.durationMs - s.posMs));
      int restW = cfg.showTimestamps ? c.textWidth("-88:88") : 0;
      int textW = c.textWidth(title);
      if (!artist.isEmpty()) {
         textW += 5 + c.textWidth("\u00b7") + 5 + c.textWidth(artist);
      }

      int w = 6 + textW + (restW > 0 ? 8 + restW : 0) + (cfg.showCover ? 21 : 0);
      int[] o = Draw.begin(c, cfg.anchor, cfg.offsetX, cfg.offsetY, cfg.scale, w, 22, a);
      int x = o[0];
      int y = o[1];
      Draw.panel(c, x, y, w, 22, cfg.backgroundOpacity, a);
      int cx = x + 3;
      if (cfg.showCover) {
         artwork(c, s, cx, y + 3, 16, a);
         cx += 21;
      }

      int ty = y + 5;
      c.text(title, cx, ty, Draw.argb(s.playing ? 16777215 : 13027020, Draw.a255(a)), true);
      int after = cx + c.textWidth(title);
      if (!artist.isEmpty()) {
         c.text("\u00b7", after + 5, ty, Draw.argb(6513519, Draw.a255(a)), true);
         c.text(artist, after + 5 + c.textWidth("\u00b7") + 5, ty, Draw.argb(11776947, Draw.a255(a)), true);
      }

      if (cfg.showTimestamps) {
         c.text(rest, x + w - 3 - c.textWidth(rest), ty, Draw.argb(9211020, Draw.a255(a)), true);
      }

      Draw.progress(c, x + 3, y + 22 - 3 - 1, w - 6, 2, s.fraction(), cfg.accentRgb(), a);
      c.pop();
   }

   private static void drawHotbar(Canvas c, HudConfig cfg, Snapshot s, float a, long now) {
      String dot = "\u00b7";
      float sc = Draw.clampScale(cfg.scale);
      int avail = Math.round(c.screenWidth() / sc) - 20;
      String title = c.trim(s.title, Math.min(200, Math.round(avail * 0.4F)));
      String artist = c.trim(s.artist, Math.min(160, Math.round(avail * 0.25F)));
      String time = s.timeLabel();
      int titleW = c.textWidth(title);
      int dotW = c.textWidth("\u00b7");
      int artistW = artist.isEmpty() ? 0 : 5 + dotW + 5 + c.textWidth(artist);
      int timeW = cfg.showTimestamps ? 8 + c.textWidth("88:88 / 88:88") : 0;
      int w = titleW + artistW + timeW;
      int barsW = cfg.showWaveform ? 24 : 0;
      float scale = Draw.clampScale(cfg.scale);
      c.push(scale);
      int sw = Math.round(c.screenWidth() / scale);
      int sh = Math.round(c.screenHeight() / scale);
      int x = (sw - (w + barsW)) / 2;
      int y = sh - (Canvas.statusBarsVisible() ? 72 : 58) - cfg.offsetY + Math.round((1.0F - a) * 4.0F);
      int ta = Draw.a255(a);
      if (cfg.showWaveform) {
         equaliser(c, x, y + 4, s, a, now, 14474460);
         x += barsW;
      }

      c.text(title, x, y, Draw.argb(s.playing ? 16777215 : 13027020, ta), true);
      int after = x + titleW;
      if (!artist.isEmpty()) {
         c.text("\u00b7", after + 5, y, Draw.argb(9079446, ta), true);
         c.text(artist, after + 5 + dotW + 5, y, Draw.argb(11776947, ta), true);
      }

      if (cfg.showTimestamps) {
         int tw = c.textWidth(time);
         c.text(time, x + w - tw, y, Draw.argb(9211020, ta), true);
      }

      c.pop();
   }

   private static void drawVanilla(Canvas c, HudConfig cfg, Snapshot s, float a, long now) {
      int icon = 16;
      int line = 10;
      String title = c.trim(s.title, 140);
      String artist = c.trim(s.artist, 140);
      int timeW = cfg.showTimestamps ? c.textWidth("88:88 / 88:88") : 0;
      int lines = 2 + (cfg.showTimestamps ? 1 : 0);
      int textW = Math.max(Math.max(c.textWidth(title), c.textWidth(artist)), timeW);
      int cw = textW;
      if (cfg.showCover) {
         cw = textW + 20;
      }

      if (cfg.showWaveform) {
         cw += 24;
      }

      int ch = Math.max(lines * 10 - 2, cfg.showCover ? 16 : 0);
      int w = cw + 8;
      int h = ch + 8;
      int[] o = Draw.begin(c, cfg.anchor, cfg.offsetX, cfg.offsetY, cfg.scale, w, h, a);
      int cx = o[0] + 4;
      int cy = o[1] + 4;
      tooltipFrame(c, cx, cy, cw, ch, a);
      int tx = cx;
      if (cfg.showCover) {
         artwork(c, s, cx, cy, 16, a);
         tx = cx + 20;
      }

      int ta = Draw.a255(a);
      c.text(title, tx, cy, Draw.argb(16777215, ta), true);
      c.text(artist, tx, cy + 10, Draw.argb(11184810, ta), true);
      if (cfg.showTimestamps) {
         c.text(s.timeLabel(), tx, cy + 20, Draw.argb(5592405, ta), true);
      }

      if (cfg.showWaveform) {
         equaliser(c, cx + cw - 18, cy + ch / 2, s, a, now, 14474460);
      }

      c.pop();
   }

   private static void tooltipFrame(Canvas c, int x, int y, int w, int h, float a) {
      int bg = scaleAlpha(-267386864, a);
      c.rect(x - 3, y - 4, w + 6, 1, bg);
      c.rect(x - 3, y + h + 3, w + 6, 1, bg);
      c.rect(x - 3, y - 3, w + 6, h + 6, bg);
      c.rect(x - 4, y - 3, 1, h + 6, bg);
      c.rect(x + w + 3, y - 3, 1, h + 6, bg);
      int top = scaleAlpha(1347420415, a);
      int bottom = scaleAlpha(1344798847, a);
      int bh = h + 4;

      for (int row = 0; row < bh; row++) {
         int col = lerpArgb(top, bottom, bh <= 1 ? 0.0F : (float)row / (bh - 1));
         c.rect(x - 3, y - 2 + row, 1, 1, col);
         c.rect(x + w + 2, y - 2 + row, 1, 1, col);
      }

      c.rect(x - 3, y - 3, w + 6, 1, top);
      c.rect(x - 3, y + h + 2, w + 6, 1, bottom);
   }

   private static void artwork(Canvas c, Snapshot s, int x, int y, int size, float a) {
      Tex art = CoverArt.get(s.id);
      if (art != null) {
         c.texture(art, x, y, size, size, 64, a);
      } else {
         Draw.roundedRect(c, x, y, size, size, Math.max(3, size / 8), Draw.argb(2763314, Draw.a255(a)));
         if (size >= 16) {
            String note = "\u266a";
            c.text(note, x + (size - c.textWidth(note)) / 2, y + (size - c.lineHeight()) / 2 + 1, Draw.argb(6974072, Draw.a255(a)), false);
         }
      }
   }

   private static void equaliser(Canvas c, int x, int centerY, Snapshot s, float a, long nanos, int rgb) {
      double t = nanos / 1.0E9;
      HudConfig cfg = HudConfig.get();
      EQ.update(5, cfg.vizSensitivity, 40, true, false, false);
      if (s.playing && EQ.live()) {
         float[] lv = EQ.levels();

         for (int i = 0; i < 5; i++) {
            int bh = 3 + Math.round(lv[i] * 13.0F);
            c.rect(x + i * 4, centerY - bh / 2, 2, bh, Draw.argb(rgb, Math.round(230.0F * a)));
         }
      } else {
         for (int i = 0; i < 5; i++) {
            double ph = t * 6.0 + i * 1.3;
            double wave = s.playing ? Math.sin(ph) * 0.5 + Math.sin(ph * 0.6 + 1.1) * 0.5 : 0.0;
            int bh = s.playing ? (int)Math.round(5.0 + Math.abs(wave) * 11.0) : 4 + i % 2 * 2;
            c.rect(x + i * 4, centerY - bh / 2, 2, bh, Draw.argb(rgb, Math.round(230.0F * a)));
         }
      }
   }

   static String lyricText(List<LyricLine> lines, int idx) {
      if (idx >= 0 && idx < lines.size()) {
         String t = lines.get(idx).text();
         return t != null && !t.isBlank() ? t : "\u266a";
      } else {
         return "";
      }
   }

   private static int scaleAlpha(int argb, float a) {
      int al = Math.round((argb >>> 24 & 0xFF) * Math.max(0.0F, Math.min(1.0F, a)));
      return al << 24 | argb & 16777215;
   }

   private static int lerpArgb(int from, int to, float t) {
      int out = 0;

      for (int shift = 0; shift < 32; shift += 8) {
         int p = from >>> shift & 0xFF;
         int q = to >>> shift & 0xFF;
         out |= (Math.round(p + (q - p) * t) & 0xFF) << shift;
      }

      return out;
   }
}
