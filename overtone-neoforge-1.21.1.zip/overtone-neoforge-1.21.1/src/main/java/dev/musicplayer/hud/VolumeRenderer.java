package dev.musicplayer.hud;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.config.HudConfig;
import dev.musicplayer.controller.PlayerController;

public final class VolumeRenderer {
   private static final int PAD = 6;
   private static final int ICON_W = 13;
   private static final int ICON_H = 10;
   private static final int GAP = 6;
   private static final int C_TEXT = 16777215;
   private static final int C_ICON = 15132394;
   private static float alpha;
   private static long lastNanos;
   private static long pokedAt;
   private static boolean poked;

   private VolumeRenderer() {
   }

   public static void poke() {
      pokedAt = System.nanoTime();
      poked = true;
   }

   public static void render(Canvas c, boolean preview) {
      HudConfig cfg = HudConfig.get();
      HudBounds.volume = null;
      long now = System.nanoTime();
      float delta = lastNanos == 0L ? 0.0F : Math.min(0.1F, (float)(now - lastNanos) / 1.0E9F);
      lastNanos = now;
      boolean active = poked && (now - pokedAt) / 1.0E9 < cfg.volumeSeconds;
      boolean wanted = active && cfg.master && cfg.volumeEnabled && !Draw.hidden(cfg);
      alpha = alpha + ((wanted ? 1.0F : 0.0F) - alpha) * Math.min(1.0F, delta * (wanted ? 9.0F : 4.0F));
      float a = preview ? 1.0F : alpha;
      if (a < 0.02F) {
         if (!preview) {
            alpha = 0.0F;
         }
      } else {
         float vol = PlayerController.I.volume;
         int accent = cfg.accentRgb();
         Draw.lastBox = null;
         switch (cfg.volumeStyle) {
            case COMPACT:
               drawCompact(c, cfg, vol, a, accent);
               break;
            case VERTICAL:
               drawVertical(c, cfg, vol, a, accent);
               break;
            default:
               drawBar(c, cfg, vol, a, accent);
         }

         HudBounds.volume = Draw.lastBox;
      }
   }

   private static String percent(float vol) {
      return Math.round(vol * 100.0F) + "%";
   }

   private static void speaker(Canvas c, int x, int y, float vol, float a, int accent) {
      int col = Draw.argb(vol <= 0.0F ? 10132136 : 15132394, Draw.a255(a));
      c.rect(x, y + 3, 3, 4, col);
      c.rect(x + 3, y + 2, 1, 6, col);
      c.rect(x + 4, y + 1, 1, 8, col);
      c.rect(x + 5, y, 1, 10, col);
      if (!(vol <= 0.0F)) {
         int on = Draw.argb(accent, Draw.a255(a));
         int off = Draw.argb(5592415, Draw.a255(a));
         c.rect(x + 8, y + 3, 1, 4, vol > 0.0F ? on : off);
         c.rect(x + 10, y + 2, 1, 6, vol > 0.33F ? on : off);
         c.rect(x + 12, y + 1, 1, 8, vol > 0.66F ? on : off);
      } else {
         int red = Draw.argb(16734810, Draw.a255(a));

         for (int i = 0; i < 5; i++) {
            c.rect(x + 8 + i, y + 2 + i, 1, 1, red);
            c.rect(x + 8 + i, y + 6 - i, 1, 1, red);
         }
      }
   }

   private static void drawBar(Canvas c, HudConfig cfg, float vol, float a, int accent) {
      int barW = 72;
      int textW = cfg.volumePercent ? c.textWidth("100%") : 0;
      int w = 97 + (textW > 0 ? 6 + textW : 0) + 6;
      int h = 12 + Math.max(10, c.lineHeight());
      int[] o = Draw.begin(c, cfg.volumeAnchor, cfg.volumeOffsetX, cfg.volumeOffsetY, cfg.volumeScale, w, h, a);
      int x = o[0];
      int y = o[1];
      Draw.panel(c, x, y, w, h, cfg.volumeBackground, a);
      c.rect(x + 1, y + 4, 2, h - 8, Draw.argb(accent, Draw.a255(a)));
      speaker(c, x + 6, y + (h - 10) / 2, vol, a, accent);
      Draw.progress(c, x + 6 + 13 + 6, y + (h - 4) / 2, 72, 4, vol, accent, a);
      if (textW > 0) {
         String t = percent(vol);
         c.text(t, x + w - 6 - c.textWidth(t), y + (h - c.lineHeight()) / 2 + 1, Draw.argb(16777215, Draw.a255(a)), true);
      }

      c.pop();
   }

   private static void drawCompact(Canvas c, HudConfig cfg, float vol, float a, int accent) {
      int textW = cfg.volumePercent ? c.textWidth("100%") : 0;
      int w = 19 + (textW > 0 ? 6 + textW : 0) + 6;
      int h = 12 + Math.max(10, c.lineHeight());
      int[] o = Draw.begin(c, cfg.volumeAnchor, cfg.volumeOffsetX, cfg.volumeOffsetY, cfg.volumeScale, w, h, a);
      int x = o[0];
      int y = o[1];
      Draw.panel(c, x, y, w, h, cfg.volumeBackground, a);
      speaker(c, x + 6, y + (h - 10) / 2, vol, a, accent);
      if (textW > 0) {
         String t = percent(vol);
         c.text(t, x + w - 6 - c.textWidth(t), y + (h - c.lineHeight()) / 2 + 1, Draw.argb(16777215, Draw.a255(a)), true);
      }

      c.pop();
   }

   private static void drawVertical(Canvas c, HudConfig cfg, float vol, float a, int accent) {
      int trackH = 56;
      int trackW = 4;
      int textW = cfg.volumePercent ? c.textWidth("100%") : 0;
      int w = Math.max(13, textW) + 12;
      int h = 78 + (textW > 0 ? 6 + c.lineHeight() : 0) + 6;
      int[] o = Draw.begin(c, cfg.volumeAnchor, cfg.volumeOffsetX, cfg.volumeOffsetY, cfg.volumeScale, w, h, a);
      int x = o[0];
      int y = o[1];
      Draw.panel(c, x, y, w, h, cfg.volumeBackground, a);
      speaker(c, x + (w - 13) / 2, y + 6, vol, a, accent);
      int tx = x + (w - 4) / 2;
      int ty = y + 6 + 10 + 6;
      Draw.roundedRect(c, tx, ty, 4, 56, 2, Draw.argb(3816004, Math.round(200.0F * a)));
      int fill = Math.round(56.0F * Math.max(0.0F, Math.min(1.0F, vol)));
      if (fill > 0) {
         Draw.roundedRect(c, tx, ty + 56 - fill, 4, fill, 2, Draw.argb(accent, Draw.a255(a)));
      }

      if (textW > 0) {
         String t = percent(vol);
         c.text(t, x + (w - c.textWidth(t)) / 2, ty + 56 + 6, Draw.argb(16777215, Draw.a255(a)), true);
      }

      c.pop();
   }
}
