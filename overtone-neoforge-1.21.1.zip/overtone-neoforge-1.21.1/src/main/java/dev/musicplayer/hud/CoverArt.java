package dev.musicplayer.hud;

import dev.musicplayer.Env;
import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.compat.Tex;
import dev.musicplayer.compat.Textures;
import dev.musicplayer.local.LocalLibrary;
import com.mojang.blaze3d.platform.NativeImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class CoverArt {
   public static final int TEXTURE_SIZE = 64;
   public static final int BIG_SIZE = 256;
   private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).followRedirects(Redirect.NORMAL).build();
   private static final ExecutorService DOWNLOADER = Executors.newFixedThreadPool(1, runnable -> {
      Thread thread = new Thread(runnable, "musicplayer-art");
      thread.setDaemon(true);
      return thread;
   });
   private static final CoverArt.Cache SMALL = new CoverArt.Cache(64, 16, "cover_");
   private static final CoverArt.Cache BIG = new CoverArt.Cache(256, 8, "coverbig_");
   private static final long MAX_IMAGE_BYTES = 8388608L;
   private static final int MAX_CACHE_FILES = 300;
   private static volatile boolean pruned;

   private CoverArt() {
   }

   private static Path cacheDir() {
      return Env.configDir().resolve("musicplayer-cache");
   }

   private static Path cacheFile(String key, String url) {
      String safe = key.replaceAll("[^A-Za-z0-9_-]", "_");
      if (safe.length() > 60) {
         safe = safe.substring(0, 60);
      }

      return cacheDir().resolve(safe + "_" + Integer.toHexString(url.hashCode()) + ".img");
   }

   private static byte[] readCache(Path f) {
      try {
         if (Files.isRegularFile(f) && Files.size(f) <= 8388608L) {
            return Files.readAllBytes(f);
         }
      } catch (Exception var2) {
      }

      return null;
   }

   private static byte[] readLocal(String url) {
      try {
         URI uri = URI.create(url);
         if (!LocalLibrary.isCoverUri(uri)) {
            return null;
         } else {
            Path p = Path.of(uri);
            return Files.isRegularFile(p) && Files.size(p) <= 8388608L ? Files.readAllBytes(p) : null;
         }
      } catch (Exception var3) {
         return null;
      }
   }

   private static void writeCache(Path f, byte[] data) {
      try {
         Files.createDirectories(f.getParent());
         Files.write(f, data);
      } catch (Exception var3) {
      }
   }

   private static void pruneCache() {
      if (!pruned) {
         pruned = true;

         try {
            File[] files = cacheDir().toFile().listFiles();
            if (files == null || files.length <= 300) {
               return;
            }

            Arrays.sort(files, Comparator.comparingLong(File::lastModified));

            for (int i = 0; i < files.length - 300; i++) {
               files[i].delete();
            }
         } catch (Exception var2) {
         }
      }
   }

   public static Tex get(String key) {
      return key != null && !key.isBlank() ? SMALL.ready.get(key) : null;
   }

   public static Tex getBig(String key) {
      return key != null && !key.isBlank() ? BIG.ready.get(key) : null;
   }

   public static void offerRemote(String key, String url) {
      SMALL.offer(key, url);
   }

   public static void offerBig(String key, String url) {
      BIG.offer(key, url);
   }

   public static void tick() {
      SMALL.upload();
      BIG.upload();
   }

   private static HttpResponse<byte[]> fetch(String url) throws Exception {
      HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15L)).GET().build();
      return HTTP.send(request, BodyHandlers.ofByteArray());
   }

   private static void download(CoverArt.Cache cache, String key, String url) {
      try {
         try {
            pruneCache();
            Path file = cacheFile(key, url);
            byte[] body = url.startsWith("file:") ? readLocal(url) : readCache(file);
            if (body == null && url.startsWith("file:")) {
               return;
            }

            if (body == null) {
               HttpResponse<byte[]> response = fetch(url);
               if (response.statusCode() == 404 && url.contains("-t500x500.")) {
                  response = fetch(url.replace("-t500x500.", "-large."));
               }

               if (response.statusCode() != 200) {
                  MusicPlayerMod.LOGGER.warn("Album art request returned {} for {}", response.statusCode(), url);
                  return;
               }

               body = response.body();
               if (body.length > 8388608L) {
                  return;
               }

               writeCache(file, body);
            }

            int[] pixels = decodeRounded(body, cache.size);
            if (pixels == null) {
               return;
            }

            cache.decoded.put(key, pixels);
         } catch (Exception var9) {
            MusicPlayerMod.LOGGER.warn("Album art download failed", var9);
         }
      } finally {
         cache.inFlight.remove(key);
      }
   }

   /**
    * Decodes any image format that Minecraft's stb_image understands (PNG, JPEG, ...), center-crops it to a
    * square, scales it to size x size in plain Java and rounds the corners. No java.awt / ImageIO is used, because
    * Android launchers ship a Java runtime without the native imaging libraries.
    */
   private static int[] decodeRounded(byte[] body, int size) throws java.io.IOException {
      try (NativeImage image = NativeImage.read(new ByteArrayInputStream(body))) {
         int w = image.getWidth();
         int h = image.getHeight();
         if (w <= 0 || h <= 0) {
            return null;
         }

         int side = Math.min(w, h);
         int sx = (w - side) / 2;
         int sy = (h - side) / 2;
         double scale = (double)side / (double)size;
         int[] out = new int[size * size];

         for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
               double fx0 = sx + x * scale;
               double fy0 = sy + y * scale;
               double fx1 = fx0 + scale;
               double fy1 = fy0 + scale;
               int x0 = (int)Math.floor(fx0);
               int y0 = (int)Math.floor(fy0);
               int x1 = Math.min(w - 1, Math.max(x0, (int)Math.ceil(fx1) - 1));
               int y1 = Math.min(h - 1, Math.max(y0, (int)Math.ceil(fy1) - 1));
               x0 = Math.max(0, x0);
               y0 = Math.max(0, y0);
               double sa = 0.0;
               double sr = 0.0;
               double sg = 0.0;
               double sb = 0.0;
               double sw = 0.0;

               for (int py = y0; py <= y1; py++) {
                  double wy = Math.min(fy1, py + 1) - Math.max(fy0, py);
                  if (wy <= 0.0) {
                     wy = 1.0E-3;
                  }

                  for (int px = x0; px <= x1; px++) {
                     double wx = Math.min(fx1, px + 1) - Math.max(fx0, px);
                     if (wx <= 0.0) {
                        wx = 1.0E-3;
                     }

                     // NativeImage pixels are ABGR
                     int abgr = image.getPixelRGBA(px, py);
                     double wgt = wx * wy;
                     double alpha = (abgr >>> 24 & 0xFF) * wgt;
                     sa += alpha;
                     sr += (abgr & 0xFF) * alpha;
                     sg += (abgr >>> 8 & 0xFF) * alpha;
                     sb += (abgr >>> 16 & 0xFF) * alpha;
                     sw += wgt;
                  }
               }

               int a = sw <= 0.0 ? 0 : (int)Math.round(sa / sw);
               int r = sa <= 0.0 ? 0 : (int)Math.round(sr / sa);
               int g = sa <= 0.0 ? 0 : (int)Math.round(sg / sa);
               int b = sa <= 0.0 ? 0 : (int)Math.round(sb / sa);
               out[y * size + x] = a << 24 | r << 16 | g << 8 | b;
            }
         }

         int radius = size / 8;
         for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
               float coverage = cornerCoverage(x, y, size, radius);
               if (!(coverage >= 1.0F)) {
                  int index = y * size + x;
                  int argb = out[index];
                  int alpha = Math.round((argb >>> 24 & 0xFF) * coverage);
                  out[index] = alpha << 24 | argb & 16777215;
               }
            }
         }

         return out;
      }
   }

   private static float cornerCoverage(int x, int y, int size, int radius) {
      float cx = x + 0.5F;
      float cy = y + 0.5F;
      float dx = 0.0F;
      float dy = 0.0F;
      if (cx < radius) {
         dx = radius - cx;
      } else if (cx > size - radius) {
         dx = cx - (size - radius);
      }

      if (cy < radius) {
         dy = radius - cy;
      } else if (cy > size - radius) {
         dy = cy - (size - radius);
      }

      if (dx != 0.0F && dy != 0.0F) {
         float distance = (float)Math.sqrt(dx * dx + dy * dy);
         if (distance <= radius - 0.5F) {
            return 1.0F;
         } else {
            return distance >= radius + 0.5F ? 0.0F : radius + 0.5F - distance;
         }
      } else {
         return 1.0F;
      }
   }

   private static final class Cache {
      final int size;
      final int keep;
      final String prefix;
      final Map<String, Tex> ready = Collections.synchronizedMap(new LinkedHashMap<String, Tex>(16, 0.75F, true) {
         @Override
         protected boolean removeEldestEntry(Entry<String, Tex> eldest) {
            if (this.size() <= Cache.this.keep) {
               return false;
            } else {
               Textures.release(eldest.getValue());
               return true;
            }
         }
      });
      final Map<String, int[]> decoded = new ConcurrentHashMap<>();
      final Map<String, Boolean> inFlight = new ConcurrentHashMap<>();

      Cache(int size, int keep, String prefix) {
         this.size = size;
         this.keep = keep;
         this.prefix = prefix;
      }

      void offer(String key, String url) {
         if (key != null && url != null && !url.isBlank()) {
            if (!this.ready.containsKey(key) && !this.decoded.containsKey(key)) {
               if (this.inFlight.putIfAbsent(key, Boolean.TRUE) == null) {
                  CoverArt.DOWNLOADER.submit(() -> CoverArt.download(this, key, url));
               }
            }
         }
      }

      void upload() {
         if (!this.decoded.isEmpty()) {
            for (String key : this.decoded.keySet().toArray(new String[0])) {
               int[] pixels = this.decoded.remove(key);
               if (pixels != null) {
                  Tex id = Textures.upload(this.prefix + Integer.toHexString(key.hashCode()), pixels, this.size);
                  if (id != null) {
                     Tex previous = this.ready.put(key, id);
                     if (previous != null && !previous.equals(id)) {
                        Textures.release(previous);
                     }
                  }
               }
            }
         }
      }
   }
}
