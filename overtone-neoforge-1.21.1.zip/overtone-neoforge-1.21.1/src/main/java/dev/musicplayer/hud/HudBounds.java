package dev.musicplayer.hud;

import dev.musicplayer.config.HudConfig;

public final class HudBounds {
   public static volatile HudBounds.Box widget;
   public static volatile HudBounds.Box lyrics;
   public static volatile HudBounds.Box volume;
   public static volatile HudBounds.Box visualizer;

   private HudBounds() {
   }

   public static HudBounds.Placement place(HudBounds.Box b, int screenW, int screenH, int newX, int newY) {
      newX = Math.max(0, Math.min(Math.max(0, screenW - b.w), newX));
      newY = Math.max(0, Math.min(Math.max(0, screenH - b.h), newY));
      int cx = newX + b.w / 2;
      int cy = newY + b.h / 2;
      int h = cx < screenW / 3 ? -1 : (cx > screenW * 2 / 3 ? 1 : 0);
      int v = cy < screenH / 3 ? -1 : (cy > screenH * 2 / 3 ? 1 : 0);
      HudConfig.Anchor a = HudConfig.Anchor.of(h, v);
      int sw = Math.round(screenW / b.scale);
      int sh = Math.round(screenH / b.scale);
      int x = Math.round(newX / b.scale);
      int y = Math.round(newY / b.scale);
      int ox = a.h < 0 ? x : (a.h > 0 ? sw - b.rawW - x : x - (sw - b.rawW) / 2);
      int oy = a.v < 0 ? y : (a.v > 0 ? sh - b.rawH - y : y - (sh - b.rawH) / 2);
      return new HudBounds.Placement(a, ox, oy);
   }

   public static final class Box {
      public final int x;
      public final int y;
      public final int w;
      public final int h;
      public final int rawW;
      public final int rawH;
      public final float scale;

      Box(int x, int y, int w, int h, int rawW, int rawH, float scale) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
         this.rawW = rawW;
         this.rawH = rawH;
         this.scale = scale;
      }
   }

   public static final class Placement {
      public final HudConfig.Anchor anchor;
      public final int offsetX;
      public final int offsetY;

      Placement(HudConfig.Anchor anchor, int offsetX, int offsetY) {
         this.anchor = anchor;
         this.offsetX = offsetX;
         this.offsetY = offsetY;
      }
   }
}
