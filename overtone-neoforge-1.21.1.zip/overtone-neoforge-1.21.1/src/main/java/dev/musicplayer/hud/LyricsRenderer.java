package dev.musicplayer.hud;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.config.HudConfig;
import dev.musicplayer.lyrics.WordTimings;
import dev.musicplayer.model.LyricLine;
import java.util.List;

public final class LyricsRenderer {
   private static final int C_DIM = 10132136;
   private static float alpha;
   private static long lastNanos;
   private static List<LyricLine> lastLyrics;
   private static int lastIdx = -2;
   private static long changedAt;

   private LyricsRenderer() {
   }

   public static void render(Canvas c, boolean preview) {
      HudConfig cfg = HudConfig.get();
      HudBounds.lyrics = null;
      if (cfg.lyricsMode == HudConfig.LyricsMode.OFF) {
         alpha = 0.0F;
      } else {
         Snapshot s = Snapshot.live();
         if (preview && (s == null || !s.synced)) {
            s = Snapshot.demo();
         }

         long now = System.nanoTime();
         float delta = lastNanos == 0L ? 0.0F : Math.min(0.1F, (float)(now - lastNanos) / 1.0E9F);
         lastNanos = now;
         int idx = s == null ? -1 : s.lyricIndex();
         boolean karaoke = cfg.lyricsMode == HudConfig.LyricsMode.KARAOKE;
         boolean hasText = s != null && s.synced && (karaoke || idx >= 0);
         boolean wanted = hasText && (preview || cfg.master && !Draw.hidden(cfg) && !WorldLyricsRenderer.takesOver());
         alpha = alpha + ((wanted ? 1.0F : 0.0F) - alpha) * Math.min(1.0F, delta * (wanted ? 6.0F : 4.0F));
         float a = preview ? 1.0F : alpha;
         if (a < 0.02F) {
            if (!preview) {
               alpha = 0.0F;
            }
         } else if (s != null && s.synced) {
            if (s.lyrics != lastLyrics) {
               lastLyrics = s.lyrics;
               lastIdx = -2;
            }

            if (idx != lastIdx) {
               lastIdx = idx;
               changedAt = now;
            }

            float f = Draw.easeOut((float)(now - changedAt) / 1000000.0F / 280.0F);
            Draw.lastBox = null;
            if (karaoke) {
               drawKaraoke(c, cfg, s, idx, a, f);
            } else {
               drawSubtitle(c, cfg, s, idx, a, f);
            }

            HudBounds.lyrics = Draw.lastBox;
         }
      }
   }

   private static boolean drawWords(Canvas c, HudConfig cfg, Snapshot s, int li, int x, int ty, int w, int inner, float a) {
      LyricLine next = li + 1 < s.lyrics.size() ? s.lyrics.get(li + 1) : null;
      WordTimings wt = WordTimings.of(s.lyrics.get(li), next);
      if (wt != null && wt.words.length != 0) {
         int space = c.textWidth(" ");
         int total = 0;
         int[] ws = new int[wt.words.length];

         for (int i = 0; i < ws.length; i++) {
            ws[i] = c.textWidth(wt.words[i]);
            total += ws[i] + (i > 0 ? space : 0);
         }

         if (total > inner) {
            return false;
         } else {
            long pos = s.posMs - cfg.lyricsShiftMs;
            int sung = currentColor(cfg);
            int unsung = Draw.lerpRgb(10132136, 16777215, 0.6F);
            int px = x + (w - total) / 2;

            for (int i = 0; i < ws.length; i++) {
               float p = Math.max(0.0F, Math.min(1.0F, (float)(pos - wt.start[i]) / (float)Math.max(1L, wt.end[i] - wt.start[i])));
               p = p * p * (3.0F - 2.0F * p);
               int lift = p > 0.0F && p < 1.0F ? -1 : 0;
               c.text(wt.words[i], px, ty + lift, Draw.argb(Draw.lerpRgb(unsung, sung, p), Draw.a255(a)), cfg.lyricsShadow);
               px += ws[i] + space;
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private static int currentColor(HudConfig cfg) {
      return cfg.lyricsAccent ? cfg.accentRgb() : 16777215;
   }

   private static void drawSubtitle(Canvas c, HudConfig cfg, Snapshot s, int idx, float a, float f) {
      int pad = 6;
      int maxW = cfg.lyricsWidth;
      int inner = maxW - 12;
      int lh = c.lineHeight() + 3;
      List<String> cur = c.wrap(WidgetRenderer.lyricText(s.lyrics, idx), inner, 2);
      if (cur.isEmpty()) {
         cur = List.of("\u266a");
      }

      String next = idx + 1 < s.lyrics.size() ? c.trim(WidgetRenderer.lyricText(s.lyrics, idx + 1), inner) : null;
      int textW = 0;

      for (String l : cur) {
         textW = Math.max(textW, c.textWidth(l));
      }

      if (next != null) {
         textW = Math.max(textW, c.textWidth(next));
      }

      boolean bg = cfg.lyricsBackground > 0;
      int w = bg ? Math.max(textW + 12, Math.min(maxW, 160)) : textW;
      int rows = cur.size() + (next != null ? 1 : 0);
      int h = rows * lh - 3 + (bg ? 12 : 0);
      int[] o = Draw.begin(c, cfg.lyricsAnchor, cfg.lyricsOffsetX, cfg.lyricsOffsetY, cfg.lyricsScale, w, h, a);
      int x = o[0];
      int y = o[1];
      if (bg) {
         Draw.roundedRect(c, x, y, w, h, 5, Draw.argb(1052696, Math.round(255.0F * (cfg.lyricsBackground / 100.0F) * a)));
      }

      int ty = y + (bg ? 6 : 0) + Math.round((1.0F - f) * 3.0F);
      float curA = a * (0.35F + 0.65F * f);

      for (String l : cur) {
         c.text(l, x + (w - c.textWidth(l)) / 2, ty, Draw.argb(currentColor(cfg), Draw.a255(curA)), cfg.lyricsShadow);
         ty += lh;
      }

      if (next != null) {
         c.text(next, x + (w - c.textWidth(next)) / 2, ty, Draw.argb(10132136, Draw.a255(a * 0.8F)), cfg.lyricsShadow);
      }

      c.pop();
   }

   private static void drawKaraoke(Canvas c, HudConfig cfg, Snapshot s, int idx, float a, float f) {
      int pad = 8;
      int n = Math.max(3, cfg.lyricsLines);
      int mid = n / 2;
      int w = cfg.lyricsWidth;
      int slot = c.lineHeight() + 5;
      int h = n * slot - 5 + 16;
      int inner = w - 16;
      int[] o = Draw.begin(c, cfg.lyricsAnchor, cfg.lyricsOffsetX, cfg.lyricsOffsetY, cfg.lyricsScale, w, h, a);
      int x = o[0];
      int y = o[1];
      if (cfg.lyricsBackground > 0) {
         Draw.roundedRect(c, x, y, w, h, 6, Draw.argb(1052696, Math.round(255.0F * (cfg.lyricsBackground / 100.0F) * a)));
      }

      float shift = 1.0F - f;

      for (int r = 0; r < n; r++) {
         int li = idx + (r - mid);
         if (li >= 0 && li < s.lyrics.size()) {
            float d = Math.abs(r - mid + shift);
            float fade = Math.max(0.12F, 1.0F - 0.38F * d) * Math.max(0.0F, Math.min(1.0F, mid + 1 - d));
            if (!(fade <= 0.02F)) {
               int color = Draw.lerpRgb(10132136, currentColor(cfg), 1.0F - Math.min(1.0F, d));
               String t = c.trim(WidgetRenderer.lyricText(s.lyrics, li), inner);
               int ty = y + 8 + Math.round((r + shift) * slot);
               if (!cfg.lyricsWordKaraoke || li != idx || !drawWords(c, cfg, s, li, x, ty, w, inner, a * fade)) {
                  c.text(t, x + (w - c.textWidth(t)) / 2, ty, Draw.argb(color, Draw.a255(a * fade)), cfg.lyricsShadow);
               }
            }
         }
      }

      c.pop();
   }
}
