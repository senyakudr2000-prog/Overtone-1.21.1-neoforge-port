package dev.musicplayer.net;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.util.T;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.ProxySelector;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Builder;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLParameters;

public final class SafeHttp {
   private static final int MAX_REDIRECTS = 5;
   public static final String BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";
   private static final long LOG_EVERY_MS = 300000L;
   private static final long DEAD_FOR_MS = 30000L;
   private static final Map<String, Long> loggedAt = new ConcurrentHashMap<>();
   private static final Map<String, Long> deadUntil = new ConcurrentHashMap<>();
   private final HttpClient[] clients = new HttpClient[]{
      builder().build(),
      builder().version(Version.HTTP_1_1).sslParameters(tls12()).build(),
      builder().version(Version.HTTP_1_1).sslParameters(tls12()).proxy(ProxySelector.of(null)).build()
   };
   private volatile int preferred;
   private final Set<String> domains;

   private static Builder builder() {
      return HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8L)).followRedirects(Redirect.NEVER);
   }

   private static SSLParameters tls12() {
      SSLParameters p = new SSLParameters();
      p.setProtocols(new String[]{"TLSv1.2"});
      return p;
   }

   public SafeHttp(Set<String> domains) {
      this.domains = Set.copyOf(domains);
   }

   public boolean allowed(URI uri) {
      String scheme = uri.getScheme();
      String host = uri.getHost();
      if ("https".equalsIgnoreCase(scheme) && host != null) {
         host = host.toLowerCase(Locale.ROOT);

         for (String d : this.domains) {
            if (host.equals(d) || host.endsWith("." + d)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public HttpResponse<InputStream> open(String method, String url, Map<String, String> headers) throws IOException, InterruptedException {
      return this.open(method, url, headers, null);
   }

   public HttpResponse<InputStream> open(String method, String url, Map<String, String> headers, String body) throws IOException, InterruptedException {
      URI uri = URI.create(url);

      for (int hop = 0; hop <= 5; hop++) {
         if (!this.allowed(uri)) {
            throw new IOException(T.get("err.blocked_host", uri.getHost()));
         }

         java.net.http.HttpRequest.Builder rb = HttpRequest.newBuilder(uri)
            .timeout(Duration.ofSeconds(30L))
            .method(method, body == null ? BodyPublishers.noBody() : BodyPublishers.ofString(body));
         headers.forEach(rb::header);
         HttpResponse<InputStream> r = this.sendWithFallback(rb.build());
         int sc = r.statusCode();
         if (sc / 100 != 3) {
            return r;
         }

         String next = r.headers().firstValue("Location").orElseThrow(() -> new IOException(T.get("err.redirect")));
         r.body().close();
         uri = uri.resolve(next);
      }

      throw new IOException(T.get("err.too_many_redirects"));
   }

   private HttpResponse<InputStream> sendWithFallback(HttpRequest req) throws IOException, InterruptedException {
      String host = req.uri().getHost();
      Long dead = deadUntil.get(host);
      if (dead != null && System.currentTimeMillis() < dead) {
         throw new IOException(T.get("err.net_unreachable", host));
      } else {
         IOException first = null;
         int start = this.preferred;

         for (int k = 0; k < this.clients.length; k++) {
            int i = (start + k) % this.clients.length;

            try {
               HttpResponse<InputStream> r = this.clients[i].send(req, BodyHandlers.ofInputStream());
               this.preferred = i;
               return r;
            } catch (IOException var9) {
               if (!connectionProblem(var9)) {
                  throw var9;
               }

               if (first == null) {
                  first = var9;
               }
            }
         }

         long now = System.currentTimeMillis();
         deadUntil.put(host, now + 30000L);
         Long last = loggedAt.get(host);
         if (last == null || now - last > 300000L) {
            loggedAt.put(host, now);
            MusicPlayerMod.LOGGER.warn("Cannot connect to {}: {}", host, rootCause(first));
         }

         throw new IOException(T.get("err.net_unreachable", host));
      }
   }

   private static boolean connectionProblem(Throwable e) {
      for (Throwable t = e; t != null; t = t.getCause()) {
         if (t instanceof SSLException || t instanceof ConnectException || t instanceof HttpConnectTimeoutException) {
            return true;
         }
      }

      return false;
   }

   private static String rootCause(Throwable e) {
      while (e.getCause() != null) {
         e = e.getCause();
      }

      return e.toString();
   }

   public SafeHttp.Reply send(String method, String url, Map<String, String> headers) throws IOException, InterruptedException {
      return this.send(method, url, headers, null);
   }

   public SafeHttp.Reply send(String method, String url, Map<String, String> headers, String body) throws IOException, InterruptedException {
      HttpResponse<InputStream> r = this.open(method, url, headers, body);

      SafeHttp.Reply var7;
      try (InputStream in = r.body()) {
         var7 = new SafeHttp.Reply(r.statusCode(), new String(in.readNBytes(8388608), StandardCharsets.UTF_8));
      }

      return var7;
   }

   public String get(String url, Map<String, String> headers) throws IOException, InterruptedException {
      SafeHttp.Reply r = this.send("GET", url, headers);
      if (r.status() / 100 != 2) {
         throw new IOException("HTTP " + r.status());
      } else {
         return r.body();
      }
   }

   public JsonObject getJson(String url, Map<String, String> headers) throws IOException, InterruptedException {
      return JsonParser.parseString(this.get(url, headers)).getAsJsonObject();
   }

   public record Reply(int status, String body) {
   }
}
