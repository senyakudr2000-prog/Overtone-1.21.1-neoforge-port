package dev.musicplayer;

import java.nio.file.Path;

public final class Env {
   private static Path config;
   private static Path game;

   private Env() {
   }

   public static void init(Path configDir, Path gameDir) {
      config = configDir;
      game = gameDir;
   }

   public static Path configDir() {
      return config;
   }

   public static Path gameDir() {
      return game;
   }
}
