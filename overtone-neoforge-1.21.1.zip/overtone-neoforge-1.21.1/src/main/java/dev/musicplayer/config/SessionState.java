package dev.musicplayer.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.musicplayer.Env;
import dev.musicplayer.model.Track;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class SessionState {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static SessionState instance;
   private static volatile boolean dirty;
   private static volatile long lastWrite;
   public float volume = 0.8F;
   public float preMuteVolume = 0.5F;
   public String query = "";
   public SessionState.TrackData track;
   public String repeat = "OFF";
   public String platform;
   public boolean shuffle;
   public boolean helpSeen;
   public List<SessionState.TrackData> userQueue = new ArrayList<>();
   public List<SessionState.TrackData> results = new ArrayList<>();
   private static final int MAX_SAVED_RESULTS = 300;

   public SessionState() {
   }

   public static synchronized SessionState get() {
      if (instance == null) {
         instance = load();
      }

      return instance;
   }

   public List<Track> resultTracks() {
      List<Track> out = new ArrayList<>();
      if (this.results != null) {
         for (SessionState.TrackData d : this.results) {
            if (d != null && d.id != null) {
               out.add(d.toTrack());
            }
         }
      }

      return out;
   }

   public Track currentTrack() {
      return this.track != null && this.track.id != null ? this.track.toTrack() : null;
   }

   public void setTrack(Track t) {
      this.track = t == null ? null : SessionState.TrackData.of(t);
   }

   public List<Track> queueTracks() {
      List<Track> out = new ArrayList<>();
      if (this.userQueue != null) {
         for (SessionState.TrackData d : this.userQueue) {
            if (d != null && d.id != null) {
               out.add(d.toTrack());
            }
         }
      }

      return out;
   }

   public void setQueue(List<Track> list) {
      List<SessionState.TrackData> out = new ArrayList<>();

      for (Track t : list) {
         out.add(SessionState.TrackData.of(t));
      }

      this.userQueue = out;
   }

   public void setResults(List<Track> list) {
      List<SessionState.TrackData> out = new ArrayList<>();

      for (Track t : list.subList(0, Math.min(list.size(), 300))) {
         out.add(SessionState.TrackData.of(t));
      }

      this.results = out;
   }

   private static Path path() {
      return Env.configDir().resolve("musicplayer-session.json");
   }

   private static SessionState load() {
      SessionState s = null;

      try {
         Path p = path();
         if (Files.exists(p)) {
            s = (SessionState)GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), SessionState.class);
         }
      } catch (Exception var2) {
      }

      if (s == null) {
         s = new SessionState();
      }

      if (s.query == null) {
         s.query = "";
      }

      if (s.results == null) {
         s.results = new ArrayList<>();
      }

      if (s.userQueue == null) {
         s.userQueue = new ArrayList<>();
      }

      if (s.repeat == null) {
         s.repeat = "OFF";
      }

      s.volume = Math.max(0.0F, Math.min(1.0F, s.volume));
      s.preMuteVolume = Math.max(0.05F, Math.min(1.0F, s.preMuteVolume));
      return s;
   }

   public static void markDirty() {
      dirty = true;
   }

   public static void flushIfDirty(long minIntervalMs) {
      if (dirty && System.currentTimeMillis() - lastWrite >= minIntervalMs) {
         saveNow();
      }
   }

   public static synchronized void saveNow() {
      dirty = false;
      lastWrite = System.currentTimeMillis();

      try {
         Path p = path();
         Files.createDirectories(p.getParent());
         Files.writeString(p, GSON.toJson(get()), StandardCharsets.UTF_8);
      } catch (Exception var1) {
      }
   }

   public static final class TrackData {
      public String id;
      public String title;
      public String artist;
      public String album;
      public String coverUrl;
      public String provider;
      public long durationMs;

      public TrackData() {
      }

      public static SessionState.TrackData of(Track t) {
         SessionState.TrackData d = new SessionState.TrackData();
         d.id = t.id();
         d.title = t.title();
         d.artist = t.artist();
         d.album = t.album();
         d.coverUrl = t.coverUrl();
         d.provider = t.provider();
         d.durationMs = t.durationMs();
         return d;
      }

      public Track toTrack() {
         return new Track(this.id, this.title, this.artist, this.album, this.durationMs, this.coverUrl, this.provider == null ? "yandex" : this.provider);
      }
   }
}
