package dev.musicplayer.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.musicplayer.Env;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public final class PlayerConfig {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static PlayerConfig instance;
   public boolean syncAccent = true;
   public HudConfig.Accent accent = HudConfig.Accent.RASPBERRY;
   public int customAccent = -1;
   public int tint = 1;
   public int windowOpacity = 100;
   public int dim = 45;
   public int cornerRadius = 4;
   public int windowScale = 100;
   public int coverPx = 80;
   public boolean showCover = true;
   public boolean showLyrics = true;
   public boolean accentText = true;
   public boolean onlineLyrics = true;
   public boolean amllLyrics = true;
   public boolean kugouLyrics = false;
   public boolean prefetch = true;
   public int prefetchCount = 4;
   public boolean diskCache = true;
   public boolean useGameVolume = false;
   public String audioDevice = "";
   public boolean duckWhenInactive = false;
   public int keysVersion;
   public int settingsVersion;
   public Map<String, Integer> keys = new LinkedHashMap<>();
   public static final PlayerConfig DEFAULTS = new PlayerConfig();

   public PlayerConfig() {
   }

   public int accentRgb() {
      if (this.syncAccent) {
         return HudConfig.get().accentRgb();
      } else {
         return this.customAccent >= 0 ? this.customAccent : this.accent.rgb;
      }
   }

   public static PlayerConfig get() {
      if (instance == null) {
         instance = load();
      }

      return instance;
   }

   public static void resetToDefaults() {
      instance = new PlayerConfig();
      instance.save();
   }

   private static Path path() {
      return Env.configDir().resolve("musicplayer-player.json");
   }

   private static PlayerConfig load() {
      PlayerConfig c = null;

      try {
         Path p = path();
         if (Files.exists(p)) {
            c = (PlayerConfig)GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), PlayerConfig.class);
         }
      } catch (Exception var2) {
      }

      if (c == null) {
         c = new PlayerConfig();
      }

      c.sanitize();
      return c;
   }

   private void sanitize() {
      PlayerConfig d = new PlayerConfig();
      if (this.accent == null) {
         this.accent = d.accent;
      }

      if (this.customAccent < 0 || this.customAccent > 16777215) {
         this.customAccent = -1;
      }

      if (this.audioDevice == null) {
         this.audioDevice = "";
      }

      if (this.settingsVersion < 1) {
         this.useGameVolume = false;
         this.settingsVersion = 1;
      }

      if (this.keys == null) {
         this.keys = new LinkedHashMap<>();
      }

      this.windowScale = Math.max(70, Math.min(150, this.windowScale));
      this.coverPx = Math.max(40, Math.min(140, this.coverPx));
      this.tint = Math.max(0, Math.min(3, this.tint));
      this.dim = Math.max(0, Math.min(100, this.dim));
      this.windowOpacity = Math.max(20, Math.min(100, this.windowOpacity));
      this.prefetchCount = Math.max(1, Math.min(8, this.prefetchCount));
      this.cornerRadius = Math.max(0, Math.min(8, this.cornerRadius));
   }

   public void save() {
      try {
         Path p = path();
         Files.createDirectories(p.getParent());
         Files.writeString(p, GSON.toJson(this), StandardCharsets.UTF_8);
      } catch (Exception var2) {
      }
   }
}
