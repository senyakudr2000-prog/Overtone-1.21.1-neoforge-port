package dev.musicplayer.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.musicplayer.Env;
import dev.musicplayer.util.T;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class HudConfig {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static HudConfig instance;
   public boolean master = true;
   public boolean enabled = true;
   public HudConfig.Layout layout = HudConfig.Layout.CARD;
   public HudConfig.Anchor anchor = HudConfig.Anchor.TOP_LEFT;
   public int offsetX = 6;
   public int offsetY = 6;
   public float scale = 1.0F;
   public int backgroundOpacity = 88;
   public HudConfig.Accent accent = HudConfig.Accent.RASPBERRY;
   public int customAccent = -1;
   public HudConfig.ShowMode showMode = HudConfig.ShowMode.SECONDS_15;
   public boolean showOnSongStart = true;
   public boolean showOnSongEnd = true;
   public boolean showCover = true;
   public boolean showTimestamps = true;
   public boolean showWaveform = true;
   public boolean cardLyrics = true;
   public boolean hideWithGui = false;
   public boolean hideOnTab = false;
   public boolean volumeEnabled = true;
   public HudConfig.VolumeStyle volumeStyle = HudConfig.VolumeStyle.BAR;
   public HudConfig.Anchor volumeAnchor = HudConfig.Anchor.TOP_CENTER;
   public int volumeOffsetX = 0;
   public int volumeOffsetY = 14;
   public float volumeScale = 1.0F;
   public int volumeBackground = 88;
   public int volumeSeconds = 2;
   public boolean volumePercent = true;
   public boolean worldLyrics = false;
   public HudConfig.WorldMode worldMode = HudConfig.WorldMode.FOLLOW;
   public HudConfig.FollowStyle worldFollowStyle = HudConfig.FollowStyle.SCREEN;
   public HudConfig.WorldLayout worldLayout = HudConfig.WorldLayout.LINE;
   public float worldScale = 1.0F;
   public float worldDistance = 9.0F;
   public float worldHeight = 0.0F;
   public float worldSpread = 57.0F;
   public boolean worldSeeThrough = true;
   public boolean worldShadow = true;
   public HudConfig.WorldAnim worldAnim = HudConfig.WorldAnim.RISE;
   public HudConfig.WorldExit worldExit = HudConfig.WorldExit.FALL;
   public int worldLinger = 4;
   public HudConfig.WorldUnit worldUnit = HudConfig.WorldUnit.LETTERS;
   public int worldLetterMs = 35;
   public int worldAnimSpeed = 100;
   public int worldBounce = 100;
   public HudConfig.WorldColor worldColor = HudConfig.WorldColor.CLASSIC;
   public HudConfig.Accent worldAccent = HudConfig.Accent.RASPBERRY;
   public HudConfig.Accent worldAccent2 = HudConfig.Accent.BLUE;
   public HudConfig.WorldGlow worldGlow = HudConfig.WorldGlow.SUNG;
   public int worldGlowStrength = 60;
   public int worldGlowSize = 100;
   public HudConfig.LyricsMode lyricsMode = HudConfig.LyricsMode.SUBTITLE;
   public HudConfig.Anchor lyricsAnchor = HudConfig.Anchor.BOTTOM_CENTER;
   public int lyricsOffsetX = 0;
   public int lyricsOffsetY = 76;
   public float lyricsScale = 1.0F;
   public int lyricsWidth = 320;
   public int lyricsLines = 5;
   public int lyricsBackground = 40;
   public boolean lyricsAccent = true;
   public boolean lyricsShadow = true;
   public int lyricsShiftMs = 0;
   public boolean lyricsWordKaraoke = true;
   public boolean vizEnabled = true;
   public HudConfig.VizSource vizSource = HudConfig.VizSource.AUTO;
   public HudConfig.VizStyle vizStyle = HudConfig.VizStyle.BARS;
   public boolean vizStereo = true;
   public HudConfig.VizDirection vizDirection = HudConfig.VizDirection.AUTO;
   public HudConfig.VizColor vizColor = HudConfig.VizColor.GRADIENT;
   public int vizBars = 32;
   public int vizBarWidth = 3;
   public int vizGap = 1;
   public int vizHeight = 36;
   public int vizSensitivity = 100;
   public boolean vizAutoSens = true;
   public int vizSmoothing = 60;
   public boolean vizPeaks = true;
   public boolean vizHideIdle = true;
   public int vizBackground = 0;
   public HudConfig.Anchor vizAnchor = HudConfig.Anchor.BOTTOM_RIGHT;
   public int vizOffsetX = 6;
   public int vizOffsetY = 6;
   public float vizScale = 1.0F;
   public static final HudConfig DEFAULTS = new HudConfig();

   public HudConfig() {
   }

   public static String label(Enum<?> e) {
      return T.get("opt." + e.getDeclaringClass().getSimpleName().toLowerCase() + "." + e.name().toLowerCase());
   }

   public static <E extends Enum<E>> E prev(E e) {
      E[] all = (E[])e.getDeclaringClass().getEnumConstants();
      return all[(e.ordinal() + all.length - 1) % all.length];
   }

   public static <E extends Enum<E>> E next(E e) {
      E[] all = (E[])e.getDeclaringClass().getEnumConstants();
      return all[(e.ordinal() + 1) % all.length];
   }

   public int accentRgb() {
      return this.customAccent >= 0 ? this.customAccent : this.accent.rgb;
   }

   public static HudConfig get() {
      if (instance == null) {
         instance = load();
      }

      return instance;
   }

   public static void resetToDefaults() {
      instance = new HudConfig();
      instance.save();
   }

   private static Path path() {
      return Env.configDir().resolve("musicplayer-hud.json");
   }

   private static HudConfig load() {
      HudConfig c = null;

      try {
         Path p = path();
         if (Files.exists(p)) {
            c = (HudConfig)GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), HudConfig.class);
         }
      } catch (Exception var2) {
      }

      if (c == null) {
         c = new HudConfig();
      }

      c.sanitize();
      return c;
   }

   private void sanitize() {
      HudConfig d = new HudConfig();
      if (this.layout == null) {
         this.layout = d.layout;
      }

      if (this.anchor == null) {
         this.anchor = d.anchor;
      }

      if (this.accent == null) {
         this.accent = d.accent;
      }

      if (this.customAccent < 0 || this.customAccent > 16777215) {
         this.customAccent = -1;
      }

      if (this.showMode == null) {
         this.showMode = d.showMode;
      }

      if (this.lyricsMode == null) {
         this.lyricsMode = d.lyricsMode;
      }

      if (this.lyricsAnchor == null) {
         this.lyricsAnchor = d.lyricsAnchor;
      }

      if (this.volumeStyle == null) {
         this.volumeStyle = d.volumeStyle;
      }

      if (this.volumeAnchor == null) {
         this.volumeAnchor = d.volumeAnchor;
      }

      if (this.worldMode == null) {
         this.worldMode = d.worldMode;
      }

      if (this.worldFollowStyle == null) {
         this.worldFollowStyle = d.worldFollowStyle;
      }

      if (this.worldLayout == null) {
         this.worldLayout = d.worldLayout;
      }

      if (this.worldAnim == null) {
         this.worldAnim = d.worldAnim;
      }

      if (this.worldExit == null) {
         this.worldExit = d.worldExit;
      }

      if (this.worldUnit == null) {
         this.worldUnit = d.worldUnit;
      }

      if (this.worldColor == null) {
         this.worldColor = d.worldColor;
      }

      if (this.worldAccent == null) {
         this.worldAccent = d.worldAccent;
      }

      if (this.worldAccent2 == null) {
         this.worldAccent2 = d.worldAccent2;
      }

      if (this.worldGlow == null) {
         this.worldGlow = d.worldGlow;
      }

      if (this.vizSource == null) {
         this.vizSource = d.vizSource;
      }

      if (this.vizStyle == null) {
         this.vizStyle = d.vizStyle;
      }

      if (this.vizDirection == null) {
         this.vizDirection = d.vizDirection;
      }

      if (this.vizColor == null) {
         this.vizColor = d.vizColor;
      }

      if (this.vizAnchor == null) {
         this.vizAnchor = d.vizAnchor;
      }

      this.worldLinger = Math.max(1, Math.min(20, this.worldLinger));
      this.worldLetterMs = Math.max(5, Math.min(150, this.worldLetterMs));
      this.worldAnimSpeed = Math.max(25, Math.min(300, this.worldAnimSpeed));
      this.worldBounce = Math.max(0, Math.min(300, this.worldBounce));
      this.worldGlowStrength = Math.max(0, Math.min(100, this.worldGlowStrength));
      this.worldGlowSize = Math.max(50, Math.min(250, this.worldGlowSize));
      this.vizBars = Math.max(4, Math.min(96, this.vizBars));
      this.vizBarWidth = Math.max(1, Math.min(10, this.vizBarWidth));
      this.vizGap = Math.max(0, Math.min(6, this.vizGap));
      this.vizHeight = Math.max(8, Math.min(160, this.vizHeight));
      this.vizSensitivity = Math.max(10, Math.min(400, this.vizSensitivity));
      this.vizSmoothing = Math.max(0, Math.min(95, this.vizSmoothing));
      this.vizBackground = Math.max(0, Math.min(100, this.vizBackground));
      this.vizScale = Math.max(0.5F, Math.min(2.0F, this.vizScale));
      this.vizOffsetX = Math.max(-600, Math.min(600, this.vizOffsetX));
      this.vizOffsetY = Math.max(-600, Math.min(600, this.vizOffsetY));
      this.worldScale = Math.max(0.5F, Math.min(2.5F, this.worldScale));
      this.worldDistance = Math.max(3.0F, Math.min(30.0F, this.worldDistance));
      this.worldHeight = Math.max(-1.5F, Math.min(3.0F, this.worldHeight));
      this.worldSpread = Math.max(15.0F, Math.min(90.0F, this.worldSpread));
      this.volumeScale = Math.max(0.5F, Math.min(2.0F, this.volumeScale));
      this.volumeBackground = Math.max(0, Math.min(100, this.volumeBackground));
      this.volumeSeconds = Math.max(1, Math.min(10, this.volumeSeconds));
      this.scale = Math.max(0.5F, Math.min(2.0F, this.scale));
      this.lyricsScale = Math.max(0.5F, Math.min(2.0F, this.lyricsScale));
      this.backgroundOpacity = Math.max(0, Math.min(100, this.backgroundOpacity));
      this.lyricsBackground = Math.max(0, Math.min(100, this.lyricsBackground));
      this.lyricsWidth = Math.max(120, Math.min(600, this.lyricsWidth));
      this.lyricsShiftMs = Math.max(-5000, Math.min(5000, this.lyricsShiftMs));
      this.lyricsLines = Math.max(3, Math.min(9, this.lyricsLines));
      this.offsetX = Math.max(-600, Math.min(600, this.offsetX));
      this.offsetY = Math.max(-600, Math.min(600, this.offsetY));
   }

   public void save() {
      try {
         Path p = path();
         Files.createDirectories(p.getParent());
         Files.writeString(p, GSON.toJson(this), StandardCharsets.UTF_8);
      } catch (Exception var2) {
      }
   }

   public static enum Accent {
      RASPBERRY(16531307),
      YELLOW(16767821),
      GREEN(1947988),
      BLUE(5220607),
      PURPLE(10513407),
      ORANGE(16747069),
      WHITE(16777215);

      public final int rgb;

      private Accent(int rgb) {
         this.rgb = rgb;
      }
   }

   public static enum Anchor {
      TOP_LEFT(-1, -1),
      TOP_CENTER(0, -1),
      TOP_RIGHT(1, -1),
      MID_LEFT(-1, 0),
      CENTER(0, 0),
      MID_RIGHT(1, 0),
      BOTTOM_LEFT(-1, 1),
      BOTTOM_CENTER(0, 1),
      BOTTOM_RIGHT(1, 1);

      public final int h;
      public final int v;

      private Anchor(int h, int v) {
         this.h = h;
         this.v = v;
      }

      public static HudConfig.Anchor of(int h, int v) {
         for (HudConfig.Anchor a : values()) {
            if (a.h == h && a.v == v) {
               return a;
            }
         }

         return TOP_LEFT;
      }
   }

   public static enum FollowStyle {
      SCREEN,
      WORLD;

      private FollowStyle() {
      }
   }

   public static enum Layout {
      CARD,
      CLASSIC,
      BAR,
      COMPACT,
      HOTBAR,
      VANILLA;

      private Layout() {
      }
   }

   public static enum LyricsMode {
      OFF,
      SUBTITLE,
      KARAOKE;

      private LyricsMode() {
      }
   }

   public static enum ShowMode {
      ALWAYS(-1),
      SECONDS_15(15),
      SECONDS_5(5);

      public final int seconds;

      private ShowMode(int s) {
         this.seconds = s;
      }

      public boolean timed() {
         return this.seconds > 0;
      }
   }

   public static enum VizColor {
      ACCENT,
      GRADIENT,
      RAINBOW,
      WHITE;

      private VizColor() {
      }
   }

   public static enum VizDirection {
      AUTO,
      UP,
      DOWN;

      private VizDirection() {
      }
   }

   public static enum VizSource {
      AUTO,
      MOD,
      SYSTEM;

      private VizSource() {
      }
   }

   public static enum VizStyle {
      BARS,
      BLOCKS,
      MIRROR,
      WAVE;

      private VizStyle() {
      }
   }

   public static enum VolumeStyle {
      BAR,
      COMPACT,
      VERTICAL;

      private VolumeStyle() {
      }
   }

   public static enum WorldAnim {
      FLY,
      RISE,
      DROP,
      POP,
      WAVE,
      TYPE,
      SPIN,
      GLITCH;

      private WorldAnim() {
      }
   }

   public static enum WorldColor {
      CLASSIC,
      ACCENT,
      GRADIENT,
      RAINBOW,
      WHITE;

      private WorldColor() {
      }
   }

   public static enum WorldExit {
      FADE,
      FALL,
      SHATTER,
      FLOAT,
      WIND,
      SHRINK,
      SINK;

      private WorldExit() {
      }
   }

   public static enum WorldGlow {
      OFF,
      SUNG,
      ALL;

      private WorldGlow() {
      }
   }

   public static enum WorldLayout {
      LINE,
      SCATTER;

      private WorldLayout() {
      }
   }

   public static enum WorldMode {
      FOLLOW,
      FIXED;

      private WorldMode() {
      }
   }

   public static enum WorldUnit {
      WORDS,
      LETTERS;

      private WorldUnit() {
      }
   }
}
