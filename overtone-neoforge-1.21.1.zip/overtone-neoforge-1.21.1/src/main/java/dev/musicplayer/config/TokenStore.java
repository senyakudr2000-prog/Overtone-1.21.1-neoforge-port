package dev.musicplayer.config;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.musicplayer.Env;
import dev.musicplayer.util.T;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.List;

public final class TokenStore {
   private static final String ACCOUNTS = "yandexAccounts";
   private static final int MAX_ACCOUNTS = 12;

   private TokenStore() {
   }

   private static Path file() {
      return Env.configDir().resolve("musicplayer.json");
   }

   private static JsonObject read() {
      try {
         if (Files.exists(file())) {
            return JsonParser.parseString(Files.readString(file())).getAsJsonObject();
         }
      } catch (Exception var1) {
      }

      return new JsonObject();
   }

   private static void write(JsonObject o) {
      try {
         Files.createDirectories(file().getParent());
         Files.writeString(file(), o.toString());
         restrictToOwner(file());
      } catch (Exception var2) {
      }
   }

   private static void restrictToOwner(Path p) {
      try {
         Files.setPosixFilePermissions(p, PosixFilePermissions.fromString("rw-------"));
      } catch (IOException | UnsupportedOperationException var2) {
      }
   }

   public static synchronized String get(String key) {
      JsonObject o = read();
      return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : null;
   }

   public static synchronized void set(String key, String value) {
      JsonObject o = read();
      if (value == null) {
         o.remove(key);
      } else {
         o.addProperty(key, value);
      }

      write(o);
   }

   public static synchronized List<TokenStore.Account> accounts() {
      return readAccounts(read());
   }

   private static List<TokenStore.Account> readAccounts(JsonObject o) {
      List<TokenStore.Account> out = new ArrayList<>();

      try {
         if (!o.has("yandexAccounts") || !o.get("yandexAccounts").isJsonArray()) {
            return out;
         }

         for (JsonElement e : o.getAsJsonArray("yandexAccounts")) {
            if (e.isJsonObject()) {
               JsonObject a = e.getAsJsonObject();
               String token = str(a, "token");
               if (token != null && !token.isBlank()) {
                  out.add(new TokenStore.Account(str(a, "uid"), str(a, "name"), token));
               }
            }
         }
      } catch (Exception var6) {
      }

      return out;
   }

   private static String str(JsonObject o, String k) {
      return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : null;
   }

   private static void writeAccounts(JsonObject o, List<TokenStore.Account> list) {
      JsonArray arr = new JsonArray();

      for (TokenStore.Account a : list) {
         JsonObject j = new JsonObject();
         if (a.uid() != null) {
            j.addProperty("uid", a.uid());
         }

         if (a.name() != null) {
            j.addProperty("name", a.name());
         }

         j.addProperty("token", a.token());
         arr.add(j);
      }

      o.add("yandexAccounts", arr);
      write(o);
   }

   public static synchronized void putAccount(String uid, String name, String token) {
      if (token != null && !token.isBlank()) {
         JsonObject o = read();
         List<TokenStore.Account> list = readAccounts(o);
         list.removeIf(a -> uid != null && uid.equals(a.uid()) || token.equals(a.token()));
         list.add(0, new TokenStore.Account(uid, name, token));

         while (list.size() > 12) {
            list.remove(list.size() - 1);
         }

         writeAccounts(o, list);
      }
   }

   public static synchronized void removeAccountByUid(String uid) {
      if (uid != null) {
         JsonObject o = read();
         List<TokenStore.Account> list = readAccounts(o);
         if (list.removeIf(a -> uid.equals(a.uid()))) {
            writeAccounts(o, list);
         }
      }
   }

   public static synchronized void removeAccountByToken(String token) {
      if (token != null) {
         JsonObject o = read();
         List<TokenStore.Account> list = readAccounts(o);
         if (list.removeIf(a -> token.equals(a.token()))) {
            writeAccounts(o, list);
         }
      }
   }

   public record Account(String uid, String name, String token) {
      public String displayName() {
         if (this.name != null && !this.name.isBlank()) {
            return this.name;
         } else {
            return this.uid != null && !this.uid.isBlank() ? T.get("account.named", this.uid) : T.get("account.plain");
         }
      }
   }
}
