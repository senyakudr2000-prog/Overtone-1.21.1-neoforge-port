package dev.musicplayer.audio;

import dev.musicplayer.libs.jaad.aac.Decoder;
import dev.musicplayer.libs.jaad.aac.SampleBuffer;
import javax.sound.sampled.AudioFormat;

public final class AacPlayer extends StreamPlayer {
   public AacPlayer() {
      super(AacPlayer::open, "musicplayer-audio-aac");
   }

   private static StreamPlayer.Source open(byte[] raw, long startMs) throws Exception {
      Mp4Audio mp4 = Mp4Audio.parse(raw);
      return new AacPlayer.AacSource(mp4, startMs);
   }

   private static final class AacSource implements StreamPlayer.Source {
      private final Mp4Audio mp4;
      private final Decoder decoder;
      private final SampleBuffer pcm = new SampleBuffer();
      private int next;
      private boolean primed;
      private byte[] pending = new byte[0];
      private int pendingAt;
      private AudioFormat format;

      AacSource(Mp4Audio mp4, long startMs) throws Exception {
         this.mp4 = mp4;
         this.decoder = new Decoder(mp4.decoderConfig());
         int target = mp4.indexAt(startMs);
         this.next = Math.max(0, target - 1);
         this.primed = this.next == target;
         this.decodeNext();
         this.format = new AudioFormat(this.pcm.getSampleRate(), 16, this.pcm.getChannels(), true, false);
      }

      @Override
      public AudioFormat format() {
         return this.format;
      }

      @Override
      public int read(byte[] buf) throws Exception {
         while (this.pendingAt >= this.pending.length) {
            if (!this.decodeNext()) {
               return -1;
            }
         }

         int n = Math.min(buf.length, this.pending.length - this.pendingAt);
         System.arraycopy(this.pending, this.pendingAt, buf, 0, n);
         this.pendingAt += n;
         return n;
      }

      private boolean decodeNext() throws Exception {
         while (this.next < this.mp4.count()) {
            byte[] frame = this.mp4.frame(this.next++);

            try {
               this.decoder.decodeFrame(frame, this.pcm);
            } catch (Exception var3) {
               continue;
            }

            byte[] out = this.pcm.getData();
            if (out.length != 0) {
               if (this.primed) {
                  this.pending = toLittleEndian(out);
                  this.pendingAt = 0;
                  return true;
               }

               this.primed = true;
            }
         }

         this.pending = new byte[0];
         this.pendingAt = 0;
         return false;
      }

      private static byte[] toLittleEndian(byte[] be) {
         byte[] le = new byte[be.length & -2];

         for (int i = 0; i + 1 < le.length; i += 2) {
            le[i] = be[i + 1];
            le[i + 1] = be[i];
         }

         return le;
      }

      @Override
      public void close() {
      }
   }
}
