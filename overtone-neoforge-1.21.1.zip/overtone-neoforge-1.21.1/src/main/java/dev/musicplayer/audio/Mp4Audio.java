package dev.musicplayer.audio;

import dev.musicplayer.util.T;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public final class Mp4Audio {
   private final byte[] data;
   private byte[] config;
   private long timescale = 1000L;
   private int trackId = -1;
   private long defaultDuration;
   private long defaultSize;
   private long[] offsets = new long[2048];
   private int[] sizes = new int[2048];
   private long[] starts = new long[2048];
   private long clock;
   private int count;

   private Mp4Audio(byte[] data) {
      this.data = data;
   }

   public static Mp4Audio parse(byte[] data) throws IOException {
      Mp4Audio m = new Mp4Audio(data);
      m.walkTopLevel();
      if (m.config == null) {
         throw new IOException(T.get("err.no_aac"));
      } else if (m.count == 0) {
         throw new IOException(T.get("err.no_frames"));
      } else {
         return m;
      }
   }

   public static boolean looksLikeMp4(byte[] d) {
      if (d.length < 12) {
         return false;
      } else {
         String t = new String(d, 4, 4, StandardCharsets.ISO_8859_1);
         return t.equals("ftyp") || t.equals("styp") || t.equals("moov") || t.equals("moof");
      }
   }

   public byte[] decoderConfig() {
      return this.config;
   }

   public int count() {
      return this.count;
   }

   public byte[] frame(int i) {
      return Arrays.copyOfRange(this.data, (int)this.offsets[i], (int)this.offsets[i] + this.sizes[i]);
   }

   public long durationMs() {
      return this.clock * 1000L / this.timescale;
   }

   public int indexAt(long ms) {
      long target = ms * this.timescale / 1000L;
      int lo = 0;
      int hi = this.count - 1;

      while (lo < hi) {
         int mid = lo + hi + 1 >>> 1;
         if (this.starts[mid] <= target) {
            lo = mid;
         } else {
            hi = mid - 1;
         }
      }

      return lo;
   }

   private void walkTopLevel() {
      int pos = 0;

      while (pos + 8 <= this.data.length) {
         long size = this.u32(pos);
         int header = 8;
         if (size == 1L && pos + 16 <= this.data.length) {
            size = this.u64(pos + 8);
            header = 16;
         } else if (size == 0L) {
            size = this.data.length - pos;
         }

         if (size < header) {
            return;
         }

         long end = Math.min(pos + size, (long)this.data.length);
         String type = this.type(pos + 4);
         if (type.equals("moov")) {
            this.readMoov(pos + header, (int)end);
         } else if (type.equals("moof") && end == pos + size) {
            this.readMoof(pos, pos + header, (int)end);
         }

         pos = (int)end;
      }
   }

   private void readMoov(int start, int end) {
      int p = start;

      while (p + 8 <= end) {
         int size = (int)this.u32(p);
         if (size < 8 || p + size > end) {
            return;
         }

         String type = this.type(p + 4);
         if (type.equals("trak") && this.config == null) {
            this.readTrak(p + 8, p + size);
         } else if (type.equals("mvex")) {
            this.readMvex(p + 8, p + size);
         }

         p += size;
      }
   }

   private void readMvex(int start, int end) {
      int p = start;

      while (p + 8 <= end) {
         int size = (int)this.u32(p);
         if (size < 8 || p + size > end) {
            return;
         }

         if (this.type(p + 4).equals("trex") && this.u32(p + 12) == this.trackId) {
            this.defaultDuration = this.u32(p + 20);
            this.defaultSize = this.u32(p + 24);
         }

         p += size;
      }
   }

   private void readTrak(int start, int end) {
      int[] tkhd = this.child(start, end, "tkhd");
      int[] mdia = this.child(start, end, "mdia");
      if (tkhd != null && mdia != null) {
         int[] hdlr = this.child(mdia[0], mdia[1], "hdlr");
         if (hdlr != null && this.type(hdlr[0] + 8).equals("soun")) {
            int[] mdhd = this.child(mdia[0], mdia[1], "mdhd");
            int[] minf = this.child(mdia[0], mdia[1], "minf");
            int[] stbl = minf == null ? null : this.child(minf[0], minf[1], "stbl");
            int[] stsd = stbl == null ? null : this.child(stbl[0], stbl[1], "stsd");
            if (mdhd != null && stsd != null) {
               byte[] cfg = this.readEntryConfig(stsd[0] + 8, stsd[1]);
               if (cfg != null) {
                  this.trackId = (int)this.u32(tkhd[0] + (this.data[tkhd[0]] == 1 ? 20 : 12));
                  this.timescale = Math.max(1L, this.u32(mdhd[0] + (this.data[mdhd[0]] == 1 ? 20 : 12)));
                  this.config = cfg;
                  this.readFlatSamples(stbl[0], stbl[1]);
               }
            }
         }
      }
   }

   private byte[] readEntryConfig(int start, int end) {
      if (start + 36 <= end && this.type(start + 4).equals("mp4a")) {
         int version = (this.data[start + 8 + 8] & 255) << 8 | this.data[start + 8 + 9] & 255;
         int children = start + 8 + 28 + (version == 1 ? 16 : (version == 2 ? 36 : 0));
         int[] esds = this.child(children, start + (int)this.u32(start), "esds");
         return esds == null ? null : this.readDescriptors(esds[0] + 4, esds[1]);
      } else {
         return null;
      }
   }

   private byte[] readDescriptors(int pos, int end) {
      while (pos + 2 <= end) {
         int tag = this.data[pos++] & 255;
         int len = 0;

         for (int i = 0; i < 4 && pos < end; i++) {
            int b = this.data[pos++] & 255;
            len = len << 7 | b & 127;
            if ((b & 128) == 0) {
               break;
            }
         }

         int bodyEnd = Math.min(end, pos + len);
         if (tag == 5) {
            return Arrays.copyOfRange(this.data, pos, bodyEnd);
         }

         if (tag == 3) {
            int flags = this.data[pos + 2] & 255;
            int inner = pos + 3 + ((flags & 128) != 0 ? 2 : 0);
            if ((flags & 64) != 0) {
               inner += 1 + (this.data[inner] & 255);
            }

            if ((flags & 32) != 0) {
               inner += 2;
            }

            byte[] r = this.readDescriptors(inner, bodyEnd);
            if (r != null) {
               return r;
            }
         } else if (tag == 4) {
            byte[] r = this.readDescriptors(pos + 13, bodyEnd);
            if (r != null) {
               return r;
            }
         }

         pos = bodyEnd;
      }

      return null;
   }

   private void readFlatSamples(int start, int end) {
      int[] stsz = this.child(start, end, "stsz");
      int[] stsc = this.child(start, end, "stsc");
      int[] stts = this.child(start, end, "stts");
      int[] stco = this.child(start, end, "stco");
      int[] co64 = this.child(start, end, "co64");
      if (stsz != null && stsc != null && stts != null && (stco != null || co64 != null)) {
         int n = (int)this.u32(stsz[0] + 8);
         if (n > 0) {
            long fixed = this.u32(stsz[0] + 4);
            int chunks = (int)this.u32((stco != null ? stco : co64)[0] + 4);
            int runs = (int)this.u32(stsc[0] + 4);
            long[] durations = new long[n];
            int di = 0;
            int e = 0;
            int p = stts[0] + 8;

            for (int entries = (int)this.u32(stts[0] + 4); e < entries && di < n; p += 8) {
               long cnt = this.u32(p);
               long delta = this.u32(p + 4);

               for (long k = 0L; k < cnt && di < n; k++) {
                  durations[di++] = delta;
               }

               e++;
            }

            e = 0;

            for (int run = 0; run < runs && e < n; run++) {
               int rp = stsc[0] + 8 + run * 12;
               int firstChunk = (int)this.u32(rp);
               int perChunk = (int)this.u32(rp + 4);
               int lastChunk = run + 1 < runs ? (int)this.u32(rp + 12) - 1 : chunks;

               for (int c = firstChunk; c <= lastChunk && e < n; c++) {
                  long off = stco != null ? this.u32(stco[0] + 8 + (c - 1) * 4) : this.u64(co64[0] + 8 + (c - 1) * 8);

                  for (int k = 0; k < perChunk && e < n; e++) {
                     int size = fixed != 0L ? (int)fixed : (int)this.u32(stsz[0] + 12 + e * 4);
                     this.add(off, size, durations[e]);
                     off += size;
                     k++;
                  }
               }
            }
         }
      }
   }

   private void readMoof(int moofStart, int start, int end) {
      int p = start;

      while (p + 8 <= end) {
         int size = (int)this.u32(p);
         if (size < 8 || p + size > end) {
            return;
         }

         if (this.type(p + 4).equals("traf")) {
            this.readTraf(moofStart, p + 8, p + size);
         }

         p += size;
      }
   }

   private void readTraf(int moofStart, int start, int end) {
      int[] tfhd = this.child(start, end, "tfhd");
      if (tfhd != null) {
         int flags = (int)(this.u32(tfhd[0]) & 16777215L);
         if (this.u32(tfhd[0] + 4) == this.trackId) {
            int at = tfhd[0] + 8;
            long base = moofStart;
            long duration = this.defaultDuration;
            long size = this.defaultSize;
            if ((flags & 1) != 0) {
               base = this.u64(at);
               at += 8;
            }

            if ((flags & 2) != 0) {
               at += 4;
            }

            if ((flags & 8) != 0) {
               duration = this.u32(at);
               at += 4;
            }

            if ((flags & 16) != 0) {
               size = this.u32(at);
            }

            long cursor = base;
            int p = start;

            while (p + 8 <= end) {
               int boxSize = (int)this.u32(p);
               if (boxSize < 8 || p + boxSize > end) {
                  return;
               }

               if (this.type(p + 4).equals("trun")) {
                  cursor = this.readTrun(p + 8, base, cursor, duration, size);
               }

               p += boxSize;
            }
         }
      }
   }

   private long readTrun(int at, long base, long cursor, long defDuration, long defSize) {
      int flags = (int)(this.u32(at) & 16777215L);
      int samples = (int)this.u32(at + 4);
      at += 8;
      if ((flags & 1) != 0) {
         cursor = base + (int)this.u32(at);
         at += 4;
      }

      if ((flags & 4) != 0) {
         at += 4;
      }

      for (int i = 0; i < samples; i++) {
         long duration = defDuration;
         long size = defSize;
         if ((flags & 256) != 0) {
            duration = this.u32(at);
            at += 4;
         }

         if ((flags & 512) != 0) {
            size = this.u32(at);
            at += 4;
         }

         if ((flags & 1024) != 0) {
            at += 4;
         }

         if ((flags & 2048) != 0) {
            at += 4;
         }

         this.add(cursor, (int)size, duration);
         cursor += size;
      }

      return cursor;
   }

   private void add(long offset, int size, long duration) {
      if (size > 0 && offset >= 0L && offset + size <= this.data.length) {
         if (this.count == this.offsets.length) {
            int cap = this.count * 2;
            this.offsets = Arrays.copyOf(this.offsets, cap);
            this.sizes = Arrays.copyOf(this.sizes, cap);
            this.starts = Arrays.copyOf(this.starts, cap);
         }

         this.offsets[this.count] = offset;
         this.sizes[this.count] = size;
         this.starts[this.count] = this.clock;
         this.clock += duration;
         this.count++;
      }
   }

   private int[] child(int start, int end, String type) {
      int p = start;

      while (p + 8 <= end) {
         long size = this.u32(p);
         if (size < 8L || p + size > end) {
            return null;
         }

         if (this.type(p + 4).equals(type)) {
            return new int[]{p + 8, (int)(p + size)};
         }

         p += (int)size;
      }

      return null;
   }

   private long u32(int p) {
      return p + 4 > this.data.length
         ? 0L
         : (this.data[p] & 255L) << 24 | (this.data[p + 1] & 255) << 16 | (this.data[p + 2] & 255) << 8 | this.data[p + 3] & 255;
   }

   private long u64(int p) {
      return this.u32(p) << 32 | this.u32(p + 4);
   }

   private String type(int p) {
      return p + 4 > this.data.length ? "" : new String(this.data, p, 4, StandardCharsets.ISO_8859_1);
   }
}
