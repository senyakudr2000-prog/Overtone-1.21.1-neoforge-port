package dev.musicplayer.audio;

import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.config.PlayerConfig;
import dev.musicplayer.jlayer.Bitstream;
import dev.musicplayer.jlayer.BitstreamException;
import dev.musicplayer.jlayer.Decoder;
import dev.musicplayer.jlayer.DecoderException;
import dev.musicplayer.jlayer.Header;
import dev.musicplayer.jlayer.SampleBuffer;
import dev.musicplayer.util.T;
import dev.musicplayer.viz.Spectrum;
import java.io.ByteArrayInputStream;
import java.nio.BufferUnderflowException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.DataLine.Info;
import javax.sound.sampled.FloatControl.Type;

public final class Mp3Player implements AudioEngine {
   private byte[] data;
   private Runnable onEnd;
   private Mp3Player.Session session;
   private volatile boolean paused;
   private volatile float volume = 0.8F;
   private volatile long lastPositionMs;
   private volatile Consumer<Throwable> onError;

   public Mp3Player() {
   }

   @Override
   public void onError(Consumer<Throwable> c) {
      this.onError = c;
   }

   static SourceDataLine openLine(AudioFormat f) throws LineUnavailableException {
      int buf = Math.max(8192, (int)(f.getFrameSize() * f.getSampleRate() / 4.0F));
      try {
         return openJavaSoundLine(f, buf);
      } catch (Throwable javaSoundFailure) {
         // Android launchers (Zalith/Pojav/FCL) have no Java Sound backend: play through Minecraft's OpenAL instead.
         try {
            SourceDataLine al = OpenAlLine.create(f, buf);
            MusicPlayerMod.LOGGER.info("Audio: Java Sound is unavailable ({}), using OpenAL output", String.valueOf(javaSoundFailure.getMessage()));
            return al;
         } catch (Throwable openAlFailure) {
            MusicPlayerMod.LOGGER.warn("Audio: OpenAL fallback failed too", openAlFailure);
            if (javaSoundFailure instanceof LineUnavailableException lue) {
               throw lue;
            }

            throw new LineUnavailableException(String.valueOf(javaSoundFailure));
         }
      }
   }

   private static SourceDataLine openJavaSoundLine(AudioFormat f, int buf) throws LineUnavailableException {
      Info info = new Info(SourceDataLine.class, f, buf);
      Throwable first = null;
      String wanted = PlayerConfig.get().audioDevice;
      if (wanted != null && !wanted.isBlank()) {
         for (javax.sound.sampled.Mixer.Info mi : AudioSystem.getMixerInfo()) {
            if (mi.getName().equals(wanted)) {
               SourceDataLine l = tryOpen(mi, info, f, buf);
               if (l != null) {
                  return l;
               }
            }
         }

         MusicPlayerMod.LOGGER.warn("Audio: device '{}' is unavailable, using the system default", wanted);
      }

      try {
         SourceDataLine l = (SourceDataLine)AudioSystem.getLine(info);
         l.open(f, buf);
         return l;
      } catch (Throwable var11) {
         StringBuilder names = new StringBuilder();

         for (javax.sound.sampled.Mixer.Info mix : AudioSystem.getMixerInfo()) {
            names.append(names.length() == 0 ? "" : "; ").append(mix.getName());
            SourceDataLine lx = tryOpen(mix, info, f, buf);
            if (lx != null) {
               MusicPlayerMod.LOGGER.info("Audio: used mixer '{}'", mix.getName());
               return lx;
            }
         }

         throw new LineUnavailableException(T.get("err.no_audio_output", var11, names.length() == 0 ? T.get("err.none_found") : names));
      }
   }

   private static SourceDataLine tryOpen(javax.sound.sampled.Mixer.Info mi, Info info, AudioFormat f, int buf) {
      try {
         Mixer m = AudioSystem.getMixer(mi);
         if (!m.isLineSupported(info)) {
            return null;
         } else {
            SourceDataLine l = (SourceDataLine)m.getLine(info);
            l.open(f, buf);
            return l;
         }
      } catch (Throwable var6) {
         return null;
      }
   }

   public static List<String> outputDevices() {
      Info info = new Info(SourceDataLine.class, new AudioFormat(44100.0F, 16, 2, true, false));
      List<String> out = new ArrayList<>();

      for (javax.sound.sampled.Mixer.Info mi : AudioSystem.getMixerInfo()) {
         try {
            if (AudioSystem.getMixer(mi).isLineSupported(info) && !out.contains(mi.getName())) {
               out.add(mi.getName());
            }
         } catch (Throwable var7) {
         }
      }

      return out;
   }

   static boolean applyGain(SourceDataLine l, float volume) {
      try {
         if (!l.isControlSupported(Type.MASTER_GAIN)) {
            return false;
         } else {
            FloatControl c = (FloatControl)l.getControl(Type.MASTER_GAIN);
            float db = (float)(20.0 * Math.log10(Math.max(volume, 1.0E-4F)));
            c.setValue(Math.max(c.getMinimum(), Math.min(c.getMaximum(), db)));
            return true;
         }
      } catch (Exception var4) {
         return false;
      }
   }

   @Override
   public synchronized void play(byte[] mp3, long startMs, Runnable onEnd) {
      this.stop();
      this.data = mp3;
      this.onEnd = onEnd;
      this.paused = false;
      this.start(startMs);
   }

   @Override
   public synchronized void seek(long ms) {
      if (this.data != null) {
         this.stopSession();
         this.start(Math.max(0L, ms));
      }
   }

   @Override
   public synchronized void stop() {
      this.stopSession();
      this.data = null;
      this.lastPositionMs = 0L;
   }

   @Override
   public void pause() {
      this.paused = true;
   }

   @Override
   public void resume() {
      this.paused = false;
   }

   @Override
   public void setVolume(float v) {
      this.volume = Math.max(0.0F, Math.min(1.0F, v));
      Mp3Player.Session s = this.session;
      if (s != null) {
         s.applyVolume();
      }
   }

   @Override
   public boolean isPlaying() {
      Mp3Player.Session s = this.session;
      return s != null && s.alive && !this.paused;
   }

   @Override
   public long positionMs() {
      Mp3Player.Session s = this.session;
      return s == null ? this.lastPositionMs : s.position();
   }

   private void start(long startMs) {
      Mp3Player.Session s = new Mp3Player.Session(this.data, startMs, this.onEnd);
      this.session = s;
      Thread t = new Thread(s, "musicplayer-audio");
      t.setDaemon(true);
      t.start();
   }

   private void stopSession() {
      Mp3Player.Session s = this.session;
      if (s != null) {
         this.lastPositionMs = s.position();
         s.stop = true;

         try {
            SourceDataLine l = s.line;
            if (l != null) {
               l.stop();
               l.flush();
            }
         } catch (Exception var3) {
         }

         this.session = null;
      }
   }

   private final class Session implements Runnable {
      final byte[] mp3;
      final long baseTarget;
      final Runnable end;
      volatile boolean stop;
      volatile boolean alive = true;
      volatile SourceDataLine line;
      volatile long baseMs;
      volatile boolean softGain;

      Session(byte[] mp3, long baseTarget, Runnable end) {
         this.mp3 = mp3;
         this.baseTarget = baseTarget;
         this.end = end;
         this.baseMs = baseTarget;
      }

      private void startWatchdog(SourceDataLine l) {
         Thread wd = new Thread(() -> {
            try {
               Thread.sleep(2500L);
            } catch (InterruptedException var5) {
               return;
            }

            if (!this.stop && this.alive && !Mp3Player.this.paused) {
               long pos = l.getMicrosecondPosition();
               MusicPlayerMod.LOGGER.info("Audio: after 2.5 s position={} us, active={}, running={}", new Object[]{pos, l.isActive(), l.isRunning()});
               if (pos <= 0L) {
                  MusicPlayerMod.LOGGER.warn("Audio: line is open but not playing");
                  Consumer<Throwable> cb = Mp3Player.this.onError;
                  if (cb != null) {
                     cb.accept(new IllegalStateException(T.get("err.silent_output")));
                  }
               }
            }
         }, "musicplayer-audio-watchdog");
         wd.setDaemon(true);
         wd.start();
      }

      long position() {
         SourceDataLine l = this.line;
         return this.baseMs + (l == null ? 0L : l.getMicrosecondPosition() / 1000L);
      }

      void applyVolume() {
         try {
            SourceDataLine l = this.line;
            if (l == null) {
               return;
            }

            if (l.isControlSupported(Type.MASTER_GAIN)) {
               this.softGain = false;
               FloatControl c = (FloatControl)l.getControl(Type.MASTER_GAIN);
               float db = (float)(20.0 * Math.log10(Math.max(Mp3Player.this.volume, 1.0E-4F)));
               c.setValue(Math.max(c.getMinimum(), Math.min(c.getMaximum(), db)));
            } else {
               this.softGain = true;
            }
         } catch (Exception var4) {
         }
      }

      @Override
      public void run() {
         Bitstream bs = new Bitstream(new ByteArrayInputStream(this.mp3));
         Decoder dec = new Decoder();

         try {
            double skipped = 0.0;

            while (skipped < this.baseTarget) {
               try {
                  Header h = bs.readFrame();
                  if (h == null) {
                     break;
                  }

                  skipped += h.msPerFrame();
                  bs.closeFrame();
               } catch (BitstreamException var36) {
                  break;
               }
            }

            this.baseMs = (long)skipped;
            int badRun = 0;

            label275:
            while (true) {
               SampleBuffer out;
               while (true) {
                  Header h;
                  while (true) {
                     if (this.stop) {
                        break label275;
                     }

                     try {
                        h = bs.readFrame();
                        break;
                     } catch (BitstreamException var34) {
                        if (++badRun > 40) {
                           break label275;
                        }

                        try {
                           bs.closeFrame();
                        } catch (Throwable var33) {
                        }
                     }
                  }

                  if (h == null) {
                     break label275;
                  }

                  try {
                     out = (SampleBuffer)dec.decodeFrame(h, bs);
                     badRun = 0;
                     break;
                  } catch (IndexOutOfBoundsException | BufferUnderflowException | DecoderException var35) {
                     if (++badRun > 40) {
                        break label275;
                     }

                     try {
                        bs.closeFrame();
                     } catch (Throwable var32) {
                     }
                  }
               }

               if (this.line == null) {
                  AudioFormat f = new AudioFormat(dec.getOutputFrequency(), 16, dec.getOutputChannels(), true, false);
                  SourceDataLine l = Mp3Player.openLine(f);
                  this.line = l;
                  this.applyVolume();
                  l.start();
                  MusicPlayerMod.LOGGER
                     .info(
                        "Audio: line opened {} Hz, {} ch, buffer {} bytes, {}, gainControl={}",
                        new Object[]{f.getSampleRate(), f.getChannels(), l.getBufferSize(), l.getClass().getName(), !this.softGain}
                     );
                  this.startWatchdog(l);
               }

               for (; Mp3Player.this.paused && !this.stop; Thread.sleep(30L)) {
                  if (this.line.isRunning()) {
                     this.line.stop();
                  }
               }

               if (this.stop) {
                  break;
               }

               if (!this.line.isRunning()) {
                  this.line.start();
               }

               short[] s = out.getBuffer();
               int n = out.getBufferLength();
               AudioFormat lf = this.line.getFormat();
               Spectrum.feedPcm16(s, n, lf.getChannels(), lf.getSampleRate(), this.line.getBufferSize() - this.line.available() + n * 2);
               byte[] b = new byte[n * 2];
               float gain = this.softGain ? Mp3Player.this.volume : 1.0F;

               for (int i = 0; i < n; i++) {
                  short v = gain == 1.0F ? s[i] : (short)(s[i] * gain);
                  b[2 * i] = (byte)v;
                  b[2 * i + 1] = (byte)(v >> 8);
               }

               this.line.write(b, 0, b.length);
               bs.closeFrame();
            }

            if (!this.stop && this.line != null) {
               this.line.drain();
            }

            if (!this.stop && this.end != null) {
               Mp3Player.this.lastPositionMs = this.position();
               this.end.run();
            }
         } catch (Throwable var37) {
            if (!this.stop) {
               MusicPlayerMod.LOGGER.warn("Audio session failed", var37);
               Consumer<Throwable> cb = Mp3Player.this.onError;
               if (cb != null) {
                  cb.accept(var37);
               }
            }
         } finally {
            this.alive = false;

            try {
               if (this.line != null) {
                  this.line.stop();
                  this.line.close();
               }
            } catch (Exception var31) {
            }

            try {
               bs.close();
            } catch (Exception var30) {
            }
         }
      }
   }
}
