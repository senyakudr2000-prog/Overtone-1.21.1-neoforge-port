package dev.musicplayer.audio;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.Control;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Line;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL11;
import org.lwjgl.openal.ALC10;

/**
 * A {@link SourceDataLine} on top of the OpenAL context that Minecraft itself already runs.
 *
 * <p>Used only as a fallback when Java Sound has no output device, which is the normal situation on
 * Android launchers (Zalith / Pojav / FCL): their Java runtime ships no audio backend, but Minecraft's
 * own sound engine works through OpenAL Soft. PCM is queued to a dedicated source in the current context.
 */
final class OpenAlLine implements SourceDataLine {
   private static final java.util.concurrent.atomic.AtomicInteger OPEN_LINES = new java.util.concurrent.atomic.AtomicInteger();

   /** True while at least one OpenAL line is open (GameVolume uses it to avoid applying the master volume twice). */
   static boolean inUse() {
      return OPEN_LINES.get() > 0;
   }

   private static final int MAX_CHUNK_FRAMES = 4096;
   private static final int POOL = 24;

   private static final class Queued {
      final int id;
      int bytes;
      int frames;

      Queued(int id) {
         this.id = id;
      }
   }

   private final Object lock = new Object();
   private final AudioFormat format;
   private final int alFormat;
   private final int rate;
   private final int frameSize;
   private final int bufferSize;
   private final int source;
   private final ArrayDeque<Queued> free = new ArrayDeque<>();
   private final ArrayDeque<Queued> queue = new ArrayDeque<>();
   private final ByteBuffer scratch;
   private volatile boolean open = true;
   private volatile boolean running;
   private volatile int generation;
   private long processedFrames;
   private int queuedBytes;

   private OpenAlLine(AudioFormat f, int bufferBytes, int source, int[] ids, int alFormat) {
      this.format = f;
      this.alFormat = alFormat;
      this.rate = Math.round(f.getSampleRate());
      this.frameSize = f.getFrameSize();
      this.bufferSize = Math.max(bufferBytes, this.frameSize * 2048);
      this.source = source;
      for (int id : ids) {
         this.free.add(new Queued(id));
      }

      this.scratch = ByteBuffer.allocateDirect(this.frameSize * MAX_CHUNK_FRAMES).order(ByteOrder.nativeOrder());
   }

   /** Opens a line in Minecraft's current OpenAL context, or throws if that is not possible. */
   static OpenAlLine create(AudioFormat f, int bufferBytes) throws LineUnavailableException {
      if (f.getEncoding() != AudioFormat.Encoding.PCM_SIGNED || f.getSampleSizeInBits() != 16 || f.isBigEndian()) {
         throw new LineUnavailableException("OpenAL fallback supports 16-bit little-endian PCM only: " + f);
      }

      int channels = f.getChannels();
      if (channels != 1 && channels != 2) {
         throw new LineUnavailableException("OpenAL fallback supports mono or stereo only: " + f);
      }

      long ctx;
      try {
         ctx = ALC10.alcGetCurrentContext();
      } catch (Throwable t) {
         throw new LineUnavailableException("OpenAL is not available: " + t);
      }

      if (ctx == 0L) {
         throw new LineUnavailableException("Minecraft has no active OpenAL context (is sound disabled?)");
      }

      AL10.alGetError();
      int source = AL10.alGenSources();
      int[] ids = new int[POOL];
      int made = 0;
      try {
         for (; made < POOL; made++) {
            ids[made] = AL10.alGenBuffers();
         }

         if (AL10.alGetError() != AL10.AL_NO_ERROR) {
            throw new LineUnavailableException("OpenAL could not allocate a source or buffers");
         }
      } catch (LineUnavailableException e) {
         cleanup(source, ids, made);
         throw e;
      } catch (Throwable t) {
         cleanup(source, ids, made);
         throw new LineUnavailableException("OpenAL failed: " + t);
      }

      AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
      AL10.alSource3f(source, AL10.AL_POSITION, 0.0F, 0.0F, 0.0F);
      AL10.alSourcef(source, AL10.AL_ROLLOFF_FACTOR, 0.0F);
      AL10.alSourcef(source, AL10.AL_GAIN, 1.0F);
      OPEN_LINES.incrementAndGet();
      return new OpenAlLine(f, bufferBytes, source, ids, channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16);
   }

   private static void cleanup(int source, int[] ids, int made) {
      try {
         AL10.alDeleteSources(source);
         for (int i = 0; i < made; i++) {
            AL10.alDeleteBuffers(ids[i]);
         }
      } catch (Throwable ignored) {
      }
   }

   /** Moves finished buffers back to the free pool. Caller holds the lock. */
   private void reclaim() {
      int n = AL10.alGetSourcei(this.source, AL10.AL_BUFFERS_PROCESSED);
      while (n-- > 0 && !this.queue.isEmpty()) {
         AL10.alSourceUnqueueBuffers(this.source);
         Queued q = this.queue.poll();
         this.processedFrames += q.frames;
         this.queuedBytes -= q.bytes;
         this.free.add(q);
      }
   }

   private void ensurePlaying() {
      if (this.running && !this.queue.isEmpty()) {
         int state = AL10.alGetSourcei(this.source, AL10.AL_SOURCE_STATE);
         if (state != AL10.AL_PLAYING) {
            AL10.alSourcePlay(this.source);
         }
      }
   }

   @Override
   public int write(byte[] b, int off, int len) {
      int frames = len / this.frameSize;
      int end = off + frames * this.frameSize;
      int pos = off;
      int gen = this.generation;
      while (pos < end && this.open && gen == this.generation) {
         int chunk = Math.min(end - pos, this.frameSize * MAX_CHUNK_FRAMES);
         boolean queued = false;
         synchronized (this.lock) {
            if (!this.open) {
               break;
            }

            this.reclaim();
            if (!this.free.isEmpty() && (this.queuedBytes == 0 || this.queuedBytes + chunk <= this.bufferSize)) {
               Queued q = this.free.poll();
               this.scratch.clear();
               this.scratch.put(b, pos, chunk);
               this.scratch.flip();
               AL10.alBufferData(q.id, this.alFormat, this.scratch, this.rate);
               AL10.alSourceQueueBuffers(this.source, q.id);
               q.bytes = chunk;
               q.frames = chunk / this.frameSize;
               this.queue.add(q);
               this.queuedBytes += chunk;
               this.ensurePlaying();
               queued = true;
            } else {
               this.ensurePlaying();
            }
         }

         if (queued) {
            pos += chunk;
         } else {
            try {
               Thread.sleep(4L);
            } catch (InterruptedException e) {
               Thread.currentThread().interrupt();
               break;
            }
         }
      }

      return pos - off;
   }

   @Override
   public void drain() {
      while (this.open) {
         synchronized (this.lock) {
            if (!this.open) {
               return;
            }

            this.reclaim();
            if (this.queue.isEmpty()) {
               return;
            }

            this.ensurePlaying();
         }

         try {
            Thread.sleep(10L);
         } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
         }
      }
   }

   @Override
   public void flush() {
      synchronized (this.lock) {
         if (!this.open) {
            return;
         }

         this.generation++;
         AL10.alSourceStop(this.source);
         int n = AL10.alGetSourcei(this.source, AL10.AL_BUFFERS_QUEUED);
         while (n-- > 0 && !this.queue.isEmpty()) {
            AL10.alSourceUnqueueBuffers(this.source);
            this.free.add(this.queue.poll());
         }

         this.queue.clear();
         this.queuedBytes = 0;
      }
   }

   @Override
   public void start() {
      synchronized (this.lock) {
         if (this.open) {
            this.running = true;
            this.ensurePlaying();
         }
      }
   }

   @Override
   public void stop() {
      synchronized (this.lock) {
         this.running = false;
         if (this.open) {
            AL10.alSourcePause(this.source);
         }
      }
   }

   @Override
   public boolean isRunning() {
      return this.running;
   }

   @Override
   public boolean isActive() {
      return this.running && this.open;
   }

   @Override
   public AudioFormat getFormat() {
      return this.format;
   }

   @Override
   public int getBufferSize() {
      return this.bufferSize;
   }

   @Override
   public int available() {
      synchronized (this.lock) {
         if (!this.open) {
            return 0;
         }

         this.reclaim();
         return Math.max(0, this.bufferSize - this.queuedBytes);
      }
   }

   @Override
   public int getFramePosition() {
      return (int)this.getLongFramePosition();
   }

   @Override
   public long getLongFramePosition() {
      synchronized (this.lock) {
         if (!this.open) {
            return this.processedFrames;
         }

         this.reclaim();
         int offset = this.queue.isEmpty() ? 0 : Math.max(0, AL10.alGetSourcei(this.source, AL11.AL_SAMPLE_OFFSET));
         return this.processedFrames + offset;
      }
   }

   @Override
   public long getMicrosecondPosition() {
      return this.getLongFramePosition() * 1_000_000L / Math.max(1, this.rate);
   }

   @Override
   public float getLevel() {
      return -1.0F;
   }

   @Override
   public Line.Info getLineInfo() {
      return new DataLine.Info(SourceDataLine.class, this.format);
   }

   @Override
   public void open(AudioFormat f, int bufferSize) {
      throw new IllegalStateException("already open");
   }

   @Override
   public void open(AudioFormat f) {
      throw new IllegalStateException("already open");
   }

   @Override
   public void open() {
   }

   @Override
   public void close() {
      synchronized (this.lock) {
         if (!this.open) {
            return;
         }

         this.open = false;
         this.running = false;
         this.generation++;
         try {
            AL10.alSourceStop(this.source);
            int n = AL10.alGetSourcei(this.source, AL10.AL_BUFFERS_QUEUED);
            while (n-- > 0) {
               AL10.alSourceUnqueueBuffers(this.source);
            }

            AL10.alDeleteSources(this.source);
            for (Queued q : this.free) {
               AL10.alDeleteBuffers(q.id);
            }

            for (Queued q : this.queue) {
               AL10.alDeleteBuffers(q.id);
            }
         } catch (Throwable ignored) {
         }

         this.free.clear();
         this.queue.clear();
         this.queuedBytes = 0;
         OPEN_LINES.decrementAndGet();
      }
   }

   @Override
   public boolean isOpen() {
      return this.open;
   }

   @Override
   public Control[] getControls() {
      return new Control[0];
   }

   @Override
   public boolean isControlSupported(Control.Type type) {
      return false;
   }

   @Override
   public Control getControl(Control.Type type) {
      throw new IllegalArgumentException("Unsupported control type: " + type);
   }

   @Override
   public void addLineListener(LineListener listener) {
   }

   @Override
   public void removeLineListener(LineListener listener) {
   }
}
