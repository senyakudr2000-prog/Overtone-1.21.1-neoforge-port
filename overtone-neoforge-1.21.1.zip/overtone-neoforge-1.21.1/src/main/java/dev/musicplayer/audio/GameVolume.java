package dev.musicplayer.audio;

import dev.musicplayer.config.PlayerConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;

public final class GameVolume {
   private GameVolume() {
   }

   public static float factor() {
      PlayerConfig pc = PlayerConfig.get();
      Minecraft mc = Minecraft.getInstance();
      if (mc == null) {
         return 1.0F;
      } else if (!pc.duckWhenInactive || mc.isWindowActive() && !mc.isPaused()) {
         if (!pc.useGameVolume || mc.options == null) {
            return 1.0F;
         }

         // The OpenAL listener already applies the master volume, so only the music slider is added on top.
         float master = OpenAlLine.inUse() ? 1.0F : mc.options.getSoundSourceVolume(SoundSource.MASTER);
         return master * mc.options.getSoundSourceVolume(SoundSource.MUSIC);
      } else {
         return 0.0F;
      }
   }
}
