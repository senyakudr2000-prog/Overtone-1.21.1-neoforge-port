package dev.musicplayer.audio;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioFormat.Encoding;

public final class PcmPlayer extends StreamPlayer {
   public PcmPlayer() {
      super(PcmPlayer::open, "musicplayer-audio-pcm");
   }

   private static StreamPlayer.Source open(byte[] raw, long startMs) throws Exception {
      final AudioInputStream source = AudioSystem.getAudioInputStream(new ByteArrayInputStream(raw));
      AudioFormat base = source.getFormat();
      final AudioFormat pcm = new AudioFormat(
         Encoding.PCM_SIGNED, base.getSampleRate(), 16, base.getChannels(), base.getChannels() * 2, base.getSampleRate(), false
      );
      final AudioInputStream in = base.matches(pcm) ? source : AudioSystem.getAudioInputStream(pcm, source);
      long left = (long)((float)startMs * pcm.getFrameRate() / 1000.0) * pcm.getFrameSize();

      while (left > 0L) {
         long n = in.skip(left);
         if (n <= 0L) {
            break;
         }

         left -= n;
      }

      return new StreamPlayer.Source() {
         @Override
         public AudioFormat format() {
            return pcm;
         }

         @Override
         public int read(byte[] buf) throws IOException {
            return in.read(buf);
         }

         @Override
         public void close() {
            try {
               in.close();
               source.close();
            } catch (IOException var2) {
            }
         }
      };
   }
}
