package dev.musicplayer.audio;

import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.viz.Spectrum;
import java.util.function.Consumer;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.SourceDataLine;

public class StreamPlayer implements AudioEngine {
   private final StreamPlayer.Opener opener;
   private final String threadName;
   private byte[] data;
   private Runnable onEnd;
   private StreamPlayer.Session session;
   private volatile boolean paused;
   private volatile float volume = 0.8F;
   private volatile long lastPositionMs;
   private volatile Consumer<Throwable> onError;

   protected StreamPlayer(StreamPlayer.Opener opener, String threadName) {
      this.opener = opener;
      this.threadName = threadName;
   }

   @Override
   public void onError(Consumer<Throwable> c) {
      this.onError = c;
   }

   @Override
   public synchronized void play(byte[] encoded, long startMs, Runnable onEnd) {
      this.stop();
      this.data = encoded;
      this.onEnd = onEnd;
      this.paused = false;
      this.start(startMs);
   }

   @Override
   public synchronized void seek(long ms) {
      if (this.data != null) {
         this.stopSession();
         this.start(Math.max(0L, ms));
      }
   }

   @Override
   public synchronized void stop() {
      this.stopSession();
      this.data = null;
      this.lastPositionMs = 0L;
   }

   @Override
   public void pause() {
      this.paused = true;
   }

   @Override
   public void resume() {
      this.paused = false;
   }

   @Override
   public void setVolume(float v) {
      this.volume = Math.max(0.0F, Math.min(1.0F, v));
      StreamPlayer.Session s = this.session;
      if (s != null) {
         s.applyVolume();
      }
   }

   @Override
   public boolean isPlaying() {
      StreamPlayer.Session s = this.session;
      return s != null && s.alive && !this.paused;
   }

   @Override
   public long positionMs() {
      StreamPlayer.Session s = this.session;
      return s == null ? this.lastPositionMs : s.position();
   }

   private void start(long startMs) {
      StreamPlayer.Session s = new StreamPlayer.Session(this.data, startMs, this.onEnd);
      this.session = s;
      Thread t = new Thread(s, this.threadName);
      t.setDaemon(true);
      t.start();
   }

   private void stopSession() {
      StreamPlayer.Session s = this.session;
      if (s != null) {
         this.lastPositionMs = s.position();
         s.stop = true;

         try {
            SourceDataLine l = s.line;
            if (l != null) {
               l.stop();
               l.flush();
            }
         } catch (Exception var3) {
         }

         this.session = null;
      }
   }

   public interface Opener {
      StreamPlayer.Source open(byte[] var1, long var2) throws Exception;
   }

   private final class Session implements Runnable {
      final byte[] raw;
      final long startMs;
      final Runnable end;
      volatile boolean stop;
      volatile boolean alive = true;
      volatile SourceDataLine line;
      volatile boolean softGain;

      Session(byte[] raw, long startMs, Runnable end) {
         this.raw = raw;
         this.startMs = startMs;
         this.end = end;
      }

      long position() {
         SourceDataLine l = this.line;
         return this.startMs + (l == null ? 0L : l.getMicrosecondPosition() / 1000L);
      }

      void applyVolume() {
         SourceDataLine l = this.line;
         if (l != null) {
            this.softGain = !Mp3Player.applyGain(l, StreamPlayer.this.volume);
         }
      }

      @Override
      public void run() {
         try (StreamPlayer.Source src = StreamPlayer.this.opener.open(this.raw, this.startMs)) {
            AudioFormat format = src.format();
            SourceDataLine l = Mp3Player.openLine(format);
            this.line = l;
            this.applyVolume();
            l.start();
            this.pump(src, l, format.getFrameSize());
            if (!this.stop) {
               l.drain();
            }

            if (!this.stop && this.end != null) {
               StreamPlayer.this.lastPositionMs = this.position();
               this.end.run();
            }
         } catch (Throwable var16) {
            if (!this.stop) {
               MusicPlayerMod.LOGGER.warn("Audio session failed", var16);
               Consumer<Throwable> cb = StreamPlayer.this.onError;
               if (cb != null) {
                  cb.accept(var16);
               }
            }
         } finally {
            this.alive = false;

            try {
               SourceDataLine lx = this.line;
               if (lx != null) {
                  lx.stop();
                  lx.close();
               }
            } catch (Exception var13) {
            }
         }
      }

      private void pump(StreamPlayer.Source src, SourceDataLine l, int frameSize) throws Exception {
         byte[] buf = new byte[frameSize * 2048];

         int n;
         while (!this.stop && (n = src.read(buf)) > 0) {
            for (; StreamPlayer.this.paused && !this.stop; Thread.sleep(30L)) {
               if (l.isRunning()) {
                  l.stop();
               }
            }

            if (this.stop) {
               break;
            }

            if (!l.isRunning()) {
               l.start();
            }

            AudioFormat lf = l.getFormat();
            Spectrum.feedPcm16(buf, n, lf.getChannels(), lf.getSampleRate(), l.getBufferSize() - l.available() + n);
            if (this.softGain) {
               this.scale(buf, n, StreamPlayer.this.volume);
            }

            l.write(buf, 0, n);
         }
      }

      private void scale(byte[] b, int n, float gain) {
         for (int i = 0; i + 1 < n; i += 2) {
            short v = (short)(b[i] & 255 | b[i + 1] << 8);
            v = (short)(v * gain);
            b[i] = (byte)v;
            b[i + 1] = (byte)(v >> 8);
         }
      }
   }

   public interface Source extends AutoCloseable {
      AudioFormat format();

      int read(byte[] var1) throws Exception;

      @Override
      void close();
   }
}
