package dev.musicplayer.audio;

import java.util.function.Consumer;

public interface AudioEngine {
   void play(byte[] var1, long var2, Runnable var4);

   void seek(long var1);

   void stop();

   void pause();

   void resume();

   void setVolume(float var1);

   boolean isPlaying();

   long positionMs();

   void onError(Consumer<Throwable> var1);
}
