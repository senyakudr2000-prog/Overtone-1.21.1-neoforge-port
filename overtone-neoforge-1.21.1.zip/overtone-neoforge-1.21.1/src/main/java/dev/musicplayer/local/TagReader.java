package dev.musicplayer.local;

import dev.musicplayer.jlayer.Bitstream;
import dev.musicplayer.jlayer.BitstreamException;
import dev.musicplayer.jlayer.Header;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.SeekableByteChannel;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioSystem;

final class TagReader {
   private static final Charset CP1251 = Charset.forName("windows-1251");
   private static final int MAX_TAG_BYTES = 25165824;

   private TagReader() {
   }

   static TagReader.Tags read(Path file) {
      try {
         TagReader.Tags v2 = readV2(file);
         return v2 != null ? v2 : readV1(file);
      } catch (Exception var2) {
         return TagReader.Tags.EMPTY;
      }
   }

   static long durationMs(Path file, boolean mp3) {
      try {
         return mp3 ? mp3Duration(file) : pcmDuration(file);
      } catch (Exception var3) {
         return 0L;
      }
   }

   private static long mp3Duration(Path file) throws IOException {
      long var13;
      try (InputStream in = new BufferedInputStream(Files.newInputStream(file), 65536)) {
         Bitstream bs = new Bitstream(in);
         double ms = 0.0;
         int bad = 0;

         while (bad < 50) {
            try {
               Header h = bs.readFrame();
               if (h == null) {
                  break;
               }

               ms += h.msPerFrame();
               bs.closeFrame();
            } catch (BitstreamException var11) {
               bad++;

               try {
                  bs.closeFrame();
               } catch (Throwable var10) {
               }
            }
         }

         try {
            bs.close();
         } catch (BitstreamException var9) {
         }

         var13 = (long)ms;
      }

      return var13;
   }

   private static long pcmDuration(Path file) throws Exception {
      AudioFileFormat f = AudioSystem.getAudioFileFormat(file.toFile());
      long frames = f.getFrameLength();
      float rate = f.getFormat().getFrameRate();
      return frames > 0L && !(rate <= 0.0F) ? (long)(frames * 1000.0 / rate) : 0L;
   }

   private static TagReader.Tags readV2(Path file) throws IOException {
      byte[] tag;
      int version;
      int flags;
      try (InputStream in = Files.newInputStream(file)) {
         byte[] head = in.readNBytes(10);
         if (head.length < 10 || head[0] != 73 || head[1] != 68 || head[2] != 51) {
            return null;
         }

         version = head[3] & 255;
         flags = head[5] & 255;
         int size = synchsafe(head, 6);
         if (size <= 0 || size > 25165824 || version < 2 || version > 4) {
            return null;
         }

         tag = in.readNBytes(size);
      }

      if ((flags & 128) != 0 && version < 4) {
         tag = undoUnsync(tag);
      }

      int pos = 0;
      if ((flags & 64) != 0 && version >= 3 && tag.length >= 4) {
         pos = version == 4 ? synchsafe(tag, 0) : int32(tag, 0) + 4;
      }

      int idLen = version == 2 ? 3 : 4;
      int headLen = version == 2 ? 6 : 10;
      String title = "";
      String artist = "";
      String album = "";
      String lyrics = "";
      byte[] cover = null;

      while (pos + headLen <= tag.length) {
         String id = new String(tag, pos, idLen, StandardCharsets.ISO_8859_1);
         if (id.charAt(0) == 0) {
            break;
         }

         int size = version == 2 ? int24(tag, pos + 3) : (version == 4 ? synchsafe(tag, pos + 4) : int32(tag, pos + 4));
         int formatFlags = version == 2 ? 0 : (tag[pos + 8] & 255) << 8 | tag[pos + 9] & 255;
         int start = pos + headLen;
         int end = start + size;
         if (size < 0 || end > tag.length) {
            break;
         }

         pos = end;
         boolean unreadable = version == 3 ? (formatFlags & 192) != 0 : version == 4 && (formatFlags & 12) != 0;
         if (!unreadable) {
            byte[] body = Arrays.copyOfRange(tag, start, end);
            if (version == 4 && (formatFlags & 1) != 0 && body.length > 4) {
               body = Arrays.copyOfRange(body, 4, body.length);
            }

            if (version == 4 && (formatFlags & 2) != 0) {
               body = undoUnsync(body);
            }

            switch (id) {
               case "TIT2":
               case "TT2":
                  title = text(body);
                  break;
               case "TPE1":
               case "TP1":
                  artist = text(body);
                  break;
               case "TALB":
               case "TAL":
                  album = text(body);
                  break;
               case "USLT":
               case "ULT":
                  if (lyrics.isEmpty()) {
                     lyrics = lyricsText(body);
                  }
                  break;
               case "APIC":
               case "PIC":
                  if (cover == null) {
                     cover = picture(body, id.equals("PIC"));
                  }
            }
         }
      }

      return new TagReader.Tags(title, artist, album, cover, lyrics);
   }

   private static TagReader.Tags readV1(Path file) throws IOException {
      long size = Files.size(file);
      if (size < 128L) {
         return TagReader.Tags.EMPTY;
      } else {
         byte[] t = new byte[128];

         try (SeekableByteChannel ch = Files.newByteChannel(file)) {
            ch.position(size - 128L);
            ByteBuffer bb = ByteBuffer.wrap(t);

            while (bb.hasRemaining() && ch.read(bb) > 0) {
            }
         }

         return t[0] == 84 && t[1] == 65 && t[2] == 71
            ? new TagReader.Tags(v1Field(t, 3, 30), v1Field(t, 33, 30), v1Field(t, 63, 30), null, "")
            : TagReader.Tags.EMPTY;
      }
   }

   private static String v1Field(byte[] b, int from, int len) {
      int end = from;

      while (end < from + len && b[end] != 0) {
         end++;
      }

      return decode(Arrays.copyOfRange(b, from, end), 0).trim();
   }

   private static String text(byte[] body) {
      if (body.length < 2) {
         return "";
      } else {
         String s = decode(Arrays.copyOfRange(body, 1, body.length), body[0] & 255);
         int nul = s.indexOf(0);
         return (nul >= 0 ? s.substring(0, nul) : s).trim();
      }
   }

   private static String lyricsText(byte[] body) {
      if (body.length < 5) {
         return "";
      } else {
         int enc = body[0] & 255;
         int at = skipTerminated(body, 4, enc);
         return at >= body.length ? "" : decode(Arrays.copyOfRange(body, at, body.length), enc).trim();
      }
   }

   private static byte[] picture(byte[] body, boolean v22) {
      if (body.length < 8) {
         return null;
      } else {
         int enc = body[0] & 255;
         int at = 1;
         if (v22) {
            at += 3;
         } else {
            while (at < body.length && body[at] != 0) {
               at++;
            }

            at++;
         }

         at = skipTerminated(body, ++at, enc);
         return at >= body.length ? null : Arrays.copyOfRange(body, at, body.length);
      }
   }

   private static int skipTerminated(byte[] b, int from, int enc) {
      boolean wide = enc == 1 || enc == 2;

      for (int i = from; i < b.length; i += wide ? 2 : 1) {
         if (!wide && b[i] == 0) {
            return i + 1;
         }

         if (wide && i + 1 < b.length && b[i] == 0 && b[i + 1] == 0) {
            return i + 2;
         }
      }

      return b.length;
   }

   private static String decode(byte[] b, int enc) {
      return switch (enc) {
         case 1 -> new String(b, StandardCharsets.UTF_16);
         case 2 -> new String(b, StandardCharsets.UTF_16BE);
         case 3 -> new String(b, StandardCharsets.UTF_8);
         default -> new String(b, looksLikeCp1251(b) ? CP1251 : StandardCharsets.ISO_8859_1);
      };
   }

   private static boolean looksLikeCp1251(byte[] b) {
      int run = 0;

      for (byte x : b) {
         if (x < 0) {
            if (++run >= 3) {
               return true;
            }
         } else {
            run = 0;
         }
      }

      return false;
   }

   static String decodeText(byte[] raw) {
      int skip = raw.length >= 3 && (raw[0] & 255) == 239 && (raw[1] & 255) == 187 && (raw[2] & 255) == 191 ? 3 : 0;

      try {
         return StandardCharsets.UTF_8
            .newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(raw, skip, raw.length - skip))
            .toString();
      } catch (CharacterCodingException var3) {
         return new String(raw, skip, raw.length - skip, CP1251);
      }
   }

   private static int synchsafe(byte[] b, int at) {
      return (b[at] & 127) << 21 | (b[at + 1] & 127) << 14 | (b[at + 2] & 127) << 7 | b[at + 3] & 127;
   }

   private static int int32(byte[] b, int at) {
      return (b[at] & 0xFF) << 24 | (b[at + 1] & 0xFF) << 16 | (b[at + 2] & 0xFF) << 8 | b[at + 3] & 0xFF;
   }

   private static int int24(byte[] b, int at) {
      return (b[at] & 0xFF) << 16 | (b[at + 1] & 0xFF) << 8 | b[at + 2] & 0xFF;
   }

   private static byte[] undoUnsync(byte[] b) {
      ByteArrayOutputStream out = new ByteArrayOutputStream(b.length);

      for (int i = 0; i < b.length; i++) {
         out.write(b[i]);
         if ((b[i] & 255) == 255 && i + 1 < b.length && b[i + 1] == 0) {
            i++;
         }
      }

      return out.toByteArray();
   }

   record Tags(String title, String artist, String album, byte[] cover, String lyrics) {
      static final TagReader.Tags EMPTY = new TagReader.Tags("", "", "", null, "");
   }
}
