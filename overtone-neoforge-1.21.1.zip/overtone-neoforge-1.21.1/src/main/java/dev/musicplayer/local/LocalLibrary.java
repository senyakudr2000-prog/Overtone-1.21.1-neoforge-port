package dev.musicplayer.local;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.musicplayer.Env;
import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.model.Track;
import dev.musicplayer.util.T;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public final class LocalLibrary {
   public static final Set<String> MP3 = Set.of("mp3");
   public static final Set<String> PCM = Set.of("wav", "wave", "aif", "aiff", "au");
   private static final int MAX_DEPTH = 12;
   private static final int MAX_FILES = 50000;
   private static final long MAX_IMAGE_BYTES = 8388608L;
   private static final int MAX_RESULTS = 3000;
   private final Gson gson = new GsonBuilder().create();
   private final Map<String, LocalLibrary.Entry> byId = new ConcurrentHashMap<>();
   private final Map<Path, String> folderCovers = new ConcurrentHashMap<>();
   private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
      Thread t = new Thread(r, "musicplayer-local-index");
      t.setDaemon(true);
      t.setPriority(1);
      return t;
   });
   private final AtomicBoolean scanning = new AtomicBoolean();
   private final AtomicBoolean rescanAgain = new AtomicBoolean();
   private volatile List<LocalLibrary.Entry> sorted = List.of();
   private volatile List<String> sources = List.of();
   private volatile Set<String> excluded = Set.of();
   private volatile String progress = "";
   private volatile int version;
   private boolean loaded;

   public LocalLibrary() {
   }

   private static Path dir() {
      return Env.configDir().resolve("musicplayer-local");
   }

   private static Path coversDir() {
      return dir().resolve("covers");
   }

   public static Path defaultFolder() {
      return Env.gameDir().resolve("overtone-music");
   }

   public static boolean isCoverUri(URI uri) {
      try {
         return Path.of(uri).toAbsolutePath().normalize().startsWith(coversDir().toAbsolutePath().normalize());
      } catch (Exception var2) {
         return false;
      }
   }

   public static boolean isSupported(Path p) {
      String e = extension(p);
      return MP3.contains(e) || PCM.contains(e);
   }

   public static boolean isMp3(Path p) {
      return MP3.contains(extension(p));
   }

   private static String extension(Path p) {
      String n = p.getFileName() == null ? "" : p.getFileName().toString();
      int dot = n.lastIndexOf(46);
      return dot < 0 ? "" : n.substring(dot + 1).toLowerCase(Locale.ROOT);
   }

   private synchronized void ensureLoaded() {
      if (!this.loaded) {
         this.loaded = true;

         try {
            Path s = dir().resolve("sources.json");
            if (Files.exists(s)) {
               LocalLibrary.SourcesFile f = (LocalLibrary.SourcesFile)this.gson
                  .fromJson(Files.readString(s, StandardCharsets.UTF_8), LocalLibrary.SourcesFile.class);
               if (f != null && f.sources != null) {
                  this.sources = List.copyOf(f.sources);
               }

               if (f != null && f.excluded != null) {
                  this.excluded = Set.copyOf(f.excluded);
               }
            }

            Path i = dir().resolve("index.json");
            if (Files.exists(i)) {
               LocalLibrary.IndexFile fx = (LocalLibrary.IndexFile)this.gson
                  .fromJson(Files.readString(i, StandardCharsets.UTF_8), LocalLibrary.IndexFile.class);
               if (fx != null && fx.entries != null) {
                  for (LocalLibrary.Entry e : fx.entries) {
                     if (e != null && e.id != null && e.path != null) {
                        this.byId.put(e.id, e);
                     }
                  }
               }
            }
         } catch (Exception var7) {
            MusicPlayerMod.LOGGER.warn("Local library index is unreadable, it will be rebuilt", var7);
         }

         try {
            Files.createDirectories(defaultFolder());
         } catch (IOException var6) {
            MusicPlayerMod.LOGGER.warn("Cannot create {}: {}", defaultFolder(), var6.getMessage());
         }

         this.publish();
         this.rescan();
      }
   }

   public int size() {
      this.ensureLoaded();
      return this.byId.size();
   }

   public int version() {
      return this.version;
   }

   public String status() {
      this.ensureLoaded();
      String p = this.progress;
      if (!p.isEmpty()) {
         return p;
      } else {
         int n = this.byId.size();
         return n == 0 ? T.get("local.empty") : T.tracks(n);
      }
   }

   public Path pathOf(String id) {
      this.ensureLoaded();
      LocalLibrary.Entry e = id == null ? null : this.byId.get(id);
      return e == null ? null : Path.of(e.path);
   }

   public List<Track> search(String query) {
      this.ensureLoaded();
      String[] words = normalize(query == null ? "" : query).split(" ");
      List<Track> out = new ArrayList<>();

      for (LocalLibrary.Entry e : this.sorted) {
         if (out.size() >= 3000) {
            break;
         }

         if (matches(e, words)) {
            out.add(toTrack(e));
         }
      }

      return out;
   }

   private static boolean matches(LocalLibrary.Entry e, String[] words) {
      String hay = normalize(e.title + " " + e.artist + " " + e.album);

      for (String w : words) {
         if (!w.isEmpty() && !hay.contains(w)) {
            return false;
         }
      }

      return true;
   }

   private static String normalize(String s) {
      return s.toLowerCase(Locale.ROOT).replace('\u0451', '\u0435').trim();
   }

   private static Track toTrack(LocalLibrary.Entry e) {
      return new Track(e.id, e.title, e.artist, e.album == null ? "" : e.album, e.durationMs, e.cover, "local");
   }

   public synchronized int addPaths(List<Path> dropped) {
      this.ensureLoaded();
      List<String> next = new ArrayList<>(this.sources);
      Set<String> ex = new HashSet<>(this.excluded);
      int added = 0;

      for (Path p : dropped) {
         Path abs = p.toAbsolutePath().normalize();
         boolean ok = Files.isDirectory(abs) || Files.isRegularFile(abs) && isSupported(abs);
         if (ok) {
            if (ex.remove(abs.toString())) {
               added++;
            }

            if (!isCovered(next, abs)) {
               next.add(abs.toString());
               added++;
            }
         }
      }

      if (added > 0) {
         this.excluded = Set.copyOf(ex);
         this.sources = List.copyOf(next);
         this.saveSources();
         this.rescan();
      }

      return added;
   }

   private static boolean isCovered(List<String> sources, Path p) {
      for (String s : sources) {
         Path src = Path.of(s);
         if (p.equals(src) || Files.isDirectory(src) && p.startsWith(src)) {
            return true;
         }
      }

      return p.startsWith(defaultFolder().toAbsolutePath().normalize());
   }

   public void rescan() {
      this.ensureLoaded();
      if (this.scanning.compareAndSet(false, true)) {
         this.worker.execute(this::scan);
      } else {
         this.rescanAgain.set(true);
      }
   }

   public synchronized boolean remove(String id) {
      this.ensureLoaded();
      LocalLibrary.Entry e = id == null ? null : this.byId.remove(id);
      if (e == null) {
         return false;
      } else {
         Set<String> next = new HashSet<>(this.excluded);
         next.add(e.path);
         this.excluded = Set.copyOf(next);
         this.saveSources();
         this.publish();
         this.saveIndex();
         return true;
      }
   }

   private void scan() {
      try {
         this.folderCovers.clear();
         List<Path> files = this.collect();
         Set<String> seen = new HashSet<>();
         int done = 0;

         for (Path f : files) {
            this.progress = T.get("local.indexing", ++done, files.size());
            LocalLibrary.Entry e = this.entryFor(f);
            if (e != null) {
               seen.add(e.id);
               this.byId.put(e.id, e);
               if (done % 40 == 0) {
                  this.publish();
               }
            }
         }

         this.byId.keySet().retainAll(seen);
         this.publish();
         this.saveIndex();
      } catch (Throwable var10) {
         MusicPlayerMod.LOGGER.warn("Local library scan failed", var10);
      } finally {
         this.progress = "";
         this.scanning.set(false);
         if (this.rescanAgain.getAndSet(false)) {
            this.rescan();
         }
      }
   }

   private List<Path> collect() {
      List<Path> roots = new ArrayList<>();
      Path def = defaultFolder();
      if (Files.isDirectory(def)) {
         roots.add(def);
      }

      for (String s : this.sources) {
         roots.add(Path.of(s));
      }

      final Set<Path> out = new LinkedHashSet<>();

      for (Path root : roots) {
         if (out.size() >= 50000) {
            break;
         }

         if (Files.isRegularFile(root)) {
            if (isSupported(root) && !this.excluded.contains(root.toString())) {
               out.add(root);
            }
         } else if (Files.isDirectory(root)) {
            try {
               Files.walkFileTree(root, Set.of(), 12, new SimpleFileVisitor<Path>() {
                  public FileVisitResult visitFile(Path f, BasicFileAttributes a) {
                     Path abs = f.toAbsolutePath().normalize();
                     if (a.isRegularFile() && LocalLibrary.isSupported(f) && !LocalLibrary.this.excluded.contains(abs.toString())) {
                        out.add(abs);
                     }

                     return out.size() >= 50000 ? FileVisitResult.TERMINATE : FileVisitResult.CONTINUE;
                  }

                  public FileVisitResult visitFileFailed(Path f, IOException e) {
                     return FileVisitResult.CONTINUE;
                  }
               });
            } catch (IOException var7) {
            }
         }
      }

      return new ArrayList<>(out);
   }

   private LocalLibrary.Entry entryFor(Path f) {
      try {
         long size = Files.size(f);
         long mtime = Files.getLastModifiedTime(f).toMillis();
         String id = idOf(f);
         LocalLibrary.Entry old = this.byId.get(id);
         if (old != null && old.size == size && old.mtime == mtime) {
            return old;
         } else {
            boolean mp3 = isMp3(f);
            long duration = TagReader.durationMs(f, mp3);
            if (duration <= 0L && mp3) {
               duration = size * 8000L / 128000L;
            }

            if (duration <= 0L) {
               MusicPlayerMod.LOGGER.warn("Local library skipped {}: cannot read its duration", f.getFileName());
               return null;
            } else {
               TagReader.Tags tags = mp3 ? TagReader.read(f) : TagReader.Tags.EMPTY;
               String[] guess = fromFileName(f);
               LocalLibrary.Entry e = new LocalLibrary.Entry();
               e.id = id;
               e.path = f.toString();
               e.size = size;
               e.mtime = mtime;
               e.durationMs = duration;
               e.title = tags.title().isBlank() ? guess[1] : tags.title();
               e.artist = tags.artist().isBlank() ? guess[0] : tags.artist();
               e.album = tags.album();
               e.cover = this.storeCover(tags.cover(), f.getParent());
               return e;
            }
         }
      } catch (Exception var14) {
         MusicPlayerMod.LOGGER.debug("Skipping {}: {}", f, var14.toString());
         return null;
      }
   }

   private static String idOf(Path f) throws Exception {
      byte[] d = MessageDigest.getInstance("SHA-256").digest(f.toString().getBytes(StandardCharsets.UTF_8));
      StringBuilder sb = new StringBuilder("L");

      for (int i = 0; i < 8; i++) {
         sb.append(String.format("%02x", d[i]));
      }

      return sb.toString();
   }

   private static String[] fromFileName(Path f) {
      String n = f.getFileName().toString();
      int dot = n.lastIndexOf(46);
      if (dot > 0) {
         n = n.substring(0, dot);
      }

      n = n.replace('_', ' ').replaceFirst("^\\s*\\d{1,3}\\s*[.)\\-]\\s*", "").trim();
      int sep = n.indexOf(" - ");
      return sep > 0 && sep + 3 < n.length()
         ? new String[]{n.substring(0, sep).trim(), n.substring(sep + 3).trim()}
         : new String[]{"", n.isEmpty() ? f.getFileName().toString() : n};
   }

   private String storeCover(byte[] embedded, Path folder) {
      try {
         if (embedded != null && embedded.length != 0) {
            return this.writeCover(embedded);
         } else {
            String cached = folder == null ? null : this.folderCovers.get(folder);
            if (cached != null) {
               return cached.isEmpty() ? null : cached;
            } else {
               String uri = null;
               byte[] img = folder == null ? null : folderImage(folder);
               if (img != null) {
                  uri = this.writeCover(img);
               }

               if (folder != null) {
                  this.folderCovers.put(folder, uri == null ? "" : uri);
               }

               return uri;
            }
         }
      } catch (Exception var7) {
         return null;
      }
   }

   private static byte[] folderImage(Path folder) throws IOException {
      for (String name : new String[]{"cover", "folder", "front", "album"}) {
         for (String ext : new String[]{"jpg", "jpeg", "png"}) {
            Path p = folder.resolve(name + "." + ext);
            if (Files.isRegularFile(p) && Files.size(p) <= 8388608L) {
               return Files.readAllBytes(p);
            }
         }
      }

      return null;
   }

   private String writeCover(byte[] bytes) throws Exception {
      if (bytes.length > 8388608L) {
         return null;
      } else {
         byte[] d = MessageDigest.getInstance("SHA-1").digest(bytes);
         StringBuilder sb = new StringBuilder();

         for (byte b : d) {
            sb.append(String.format("%02x", b));
         }

         Path file = coversDir().resolve(sb + ".img");
         if (!Files.exists(file)) {
            Files.createDirectories(file.getParent());
            Files.write(file, bytes);
         }

         return file.toUri().toString();
      }
   }

   public String lyricsText(Path audio) {
      Path side = sideText(audio);

      try {
         if (side != null && Files.size(side) < 1048576L) {
            return TagReader.decodeText(Files.readAllBytes(side));
         }
      } catch (IOException var4) {
      }

      return isMp3(audio) ? TagReader.read(audio).lyrics() : "";
   }

   private static Path sideText(Path audio) {
      Path dir = audio.getParent();
      if (dir == null) {
         return null;
      } else {
         Set<String> want = nameKeys(audio);
         Path best = null;

         try (DirectoryStream<Path> files = Files.newDirectoryStream(dir)) {
            for (Path p : files) {
               String ext = extension(p);
               if ((ext.equals("lrc") || ext.equals("txt")) && !nameKeys(p).stream().noneMatch(want::contains) && (best == null || ext.equals("lrc"))) {
                  best = p;
               }
            }
         } catch (IOException var10) {
         }

         return best;
      }
   }

   private static Set<String> nameKeys(Path f) {
      String[] parts = fromFileName(f);
      Set<String> keys = new HashSet<>();
      keys.add(normalize(parts[0].isEmpty() ? parts[1] : parts[0] + " " + parts[1]).replaceAll("[^\\p{L}\\p{N}]+", " ").trim());
      keys.add(normalize(parts[1]).replaceAll("[^\\p{L}\\p{N}]+", " ").trim());
      keys.remove("");
      return keys;
   }

   private void publish() {
      List<LocalLibrary.Entry> list = new ArrayList<>(this.byId.values());
      list.sort(
         Comparator.<LocalLibrary.Entry, String>comparing(e -> normalize(e.artist == null ? "" : e.artist))
            .thenComparing(e -> normalize(e.title == null ? "" : e.title))
      );
      this.sorted = list;
      this.version++;
   }

   private void saveSources() {
      try {
         LocalLibrary.SourcesFile f = new LocalLibrary.SourcesFile();
         f.sources = new ArrayList<>(this.sources);
         f.excluded = new ArrayList<>(this.excluded);
         Files.createDirectories(dir());
         Files.writeString(dir().resolve("sources.json"), this.gson.toJson(f), StandardCharsets.UTF_8);
      } catch (IOException var2) {
         MusicPlayerMod.LOGGER.warn("Could not save local sources", var2);
      }
   }

   private void saveIndex() {
      try {
         LocalLibrary.IndexFile f = new LocalLibrary.IndexFile();
         f.entries = new ArrayList<>(this.byId.values());
         Files.createDirectories(dir());
         Path tmp = dir().resolve("index.json.tmp");
         Files.writeString(tmp, this.gson.toJson(f), StandardCharsets.UTF_8);
         Files.move(tmp, dir().resolve("index.json"), StandardCopyOption.REPLACE_EXISTING);
      } catch (IOException var3) {
         MusicPlayerMod.LOGGER.warn("Could not save local index", var3);
      }
   }

   static final class Entry {
      String id;
      String path;
      String title;
      String artist;
      String album;
      String cover;
      long size;
      long mtime;
      long durationMs;

      Entry() {
      }
   }

   private static final class IndexFile {
      List<LocalLibrary.Entry> entries = new ArrayList<>();

      private IndexFile() {
      }
   }

   private static final class SourcesFile {
      List<String> sources = new ArrayList<>();
      List<String> excluded = new ArrayList<>();

      private SourcesFile() {
      }
   }
}
