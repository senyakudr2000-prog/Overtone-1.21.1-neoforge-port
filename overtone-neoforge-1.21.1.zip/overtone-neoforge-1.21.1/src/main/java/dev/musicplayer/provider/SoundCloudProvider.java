package dev.musicplayer.provider;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.audio.AacPlayer;
import dev.musicplayer.audio.AudioEngine;
import dev.musicplayer.audio.Mp3Player;
import dev.musicplayer.audio.Mp4Audio;
import dev.musicplayer.config.TokenStore;
import dev.musicplayer.model.Platform;
import dev.musicplayer.model.Track;
import dev.musicplayer.net.SafeHttp;
import dev.musicplayer.util.Json;
import dev.musicplayer.util.T;
import dev.musicplayer.util.TrackNames;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SoundCloudProvider implements MusicProvider {
   private static final String API = "https://api-v2.soundcloud.com";
   private static final String CLIENT_ID_KEY = "soundcloudClientId2";
   private static final long MAX_TRACK_BYTES = 157286400L;
   private static final Pattern SCRIPT = Pattern.compile("<script[^>]+src=\"(https://[^\"]+\\.js)\"");
   private static final Pattern CLIENT_ID = Pattern.compile("client_id\\s*:\\s*\"([0-9a-zA-Z]{32})\"");
   private static final Pattern TOKEN = Pattern.compile("\\b\\d-\\d+-\\d+-[0-9A-Za-z]+\\b");
   private static final Pattern PROFILE = Pattern.compile("[A-Za-z0-9_-]{2,60}");
   private static final SafeHttp HTTP = new SafeHttp(Set.of("soundcloud.com", "sndcdn.com", "soundcloud.cloud"));
   private final Mp3Player mp3 = new Mp3Player();
   private final AacPlayer aac = new AacPlayer();
   private final AudioCache cache = AudioCache.shared();
   private final AtomicInteger generation = new AtomicInteger();
   private final Set<String> likedIds = ConcurrentHashMap.newKeySet();
   private final Map<String, long[]> progress = new ConcurrentHashMap<>();
   private volatile AudioEngine engine = this.mp3;
   private volatile String clientId = TokenStore.get("soundcloudClientId2");
   private volatile String token = TokenStore.get("soundcloudToken");
   private volatile String userId = TokenStore.get("soundcloudUserId");
   private volatile String userName = orEmpty(TokenStore.get("soundcloudName"));
   private volatile Runnable finished;

   public SoundCloudProvider() {
   }

   @Override
   public Platform platform() {
      return Platform.SOUNDCLOUD;
   }

   @Override
   public boolean isLoggedIn() {
      return true;
   }

   @Override
   public String accountName() {
      return this.isLinked() ? this.userName : "";
   }

   @Override
   public String likedLabel() {
      return T.get("liked.likes");
   }

   public boolean isLinked() {
      return this.userId != null;
   }

   public boolean canLike() {
      return this.token != null && this.userId != null;
   }

   @Override
   public boolean supportsLikes() {
      return this.canLike();
   }

   @Override
   public boolean isLiked(String trackId) {
      return this.likedIds.contains(trackId);
   }

   public CompletableFuture<Void> link(String input) {
      String text = input == null ? "" : URLDecoder.decode(input.trim(), StandardCharsets.UTF_8);
      if (text.isEmpty()) {
         return CompletableFuture.failedFuture(new IOException(T.get("err.empty_field")));
      } else {
         return looksLikeToken(text) ? this.linkToken(extractToken(text)) : this.linkProfile(text);
      }
   }

   private static boolean looksLikeToken(String s) {
      return s.contains("oauth_token") || TOKEN.matcher(s).find() || s.regionMatches(true, 0, "OAuth ", 0, 6);
   }

   private CompletableFuture<Void> linkProfile(String text) {
      String name = profileName(text);
      return !PROFILE.matcher(name).matches() ? CompletableFuture.failedFuture(new IOException(T.get("err.not_profile"))) : Background.run(() -> {
         JsonObject user = this.api("GET", "/resolve?url=" + enc("https://soundcloud.com/" + name));
         if (!"user".equals(Json.str(user, "kind"))) {
            throw new IOException(T.get("err.no_profile"));
         } else {
            this.store(String.valueOf(user.get("id").getAsLong()), Json.str(user, "username"), this.token);
            return null;
         }
      });
   }

   private CompletableFuture<Void> linkToken(String t) {
      String previous = this.token;
      this.token = t;
      return Background.run(() -> {
         try {
            JsonObject me = this.api("GET", "/me");
            this.store(String.valueOf(me.get("id").getAsLong()), Json.str(me, "username"), t);
         } catch (Exception var4) {
            this.token = previous;
            throw new IOException(T.get("err.token_rejected", var4.getMessage()));
         }

         this.refreshLikes();
         return null;
      });
   }

   private void store(String id, String name, String oauth) {
      this.userId = id;
      this.userName = name;
      this.token = oauth;
      TokenStore.set("soundcloudUserId", id);
      TokenStore.set("soundcloudName", name);
      TokenStore.set("soundcloudToken", oauth);
   }

   @Override
   public void logout() {
      this.userId = null;
      this.userName = "";
      this.token = null;
      this.likedIds.clear();
      TokenStore.set("soundcloudUserId", null);
      TokenStore.set("soundcloudName", null);
      TokenStore.set("soundcloudToken", null);
   }

   private void refreshLikes() {
      try {
         JsonObject r = this.api("GET", "/me/track_likes/ids?limit=5000");
         Set<String> ids = new HashSet<>();

         for (JsonElement e : r.getAsJsonArray("collection")) {
            ids.add(e.isJsonObject() ? String.valueOf(e.getAsJsonObject().get("id").getAsLong()) : e.getAsString());
         }

         this.likedIds.clear();
         this.likedIds.addAll(ids);
      } catch (Exception var5) {
         MusicPlayerMod.LOGGER.debug("SoundCloud likes list unavailable: {}", var5.getMessage());
      }
   }

   @Override
   public CompletableFuture<List<Track>> search(String query) {
      return Background.run(() -> tracks(this.api("GET", "/search/tracks?q=" + enc(query) + "&limit=40")));
   }

   @Override
   public CompletableFuture<List<Track>> likedTracks() {
      return Background.run(() -> {
         if (!this.isLinked()) {
            throw new IOException(T.get("err.likes_need_login"));
         } else {
            List<Track> list = tracks(this.api("GET", "/users/" + this.userId + "/track_likes?limit=200"));
            if (this.canLike()) {
               for (Track t : list) {
                  this.likedIds.add(t.id());
               }
            }

            return list;
         }
      });
   }

   @Override
   public CompletableFuture<Void> setLiked(Track t, boolean like) {
      return Background.run(() -> {
         if (!this.canLike()) {
            throw new IOException(T.get("err.likes_need_token"));
         } else {
            this.api(like ? "PUT" : "DELETE", "/users/" + this.userId + "/track_likes/" + t.id());
            if (like) {
               this.likedIds.add(t.id());
            } else {
               this.likedIds.remove(t.id());
            }

            return null;
         }
      });
   }

   private static List<Track> tracks(JsonObject page) {
      List<Track> out = new ArrayList<>();
      if (page.has("collection") && page.get("collection").isJsonArray()) {
         for (JsonElement e : page.getAsJsonArray("collection")) {
            if (e.isJsonObject()) {
               JsonObject o = e.getAsJsonObject();
               if (o.has("track") && o.get("track").isJsonObject()) {
                  o = o.getAsJsonObject("track");
               }

               if (o.has("id") && !Json.str(o, "title").isBlank() && !"BLOCK".equals(Json.str(o, "policy"))) {
                  out.add(parseTrack(o));
               }
            }
         }

         return out;
      } else {
         return out;
      }
   }

   private static Track parseTrack(JsonObject o) {
      JsonObject user = Json.obj(o, "user");
      String title = Json.str(o, "title").trim();
      String artist = Json.str(Json.obj(o, "publisher_metadata"), "artist").trim();
      if (artist.isEmpty()) {
         TrackNames.Parsed p = TrackNames.split(title, Json.str(user, "username"));
         artist = p.artist();
         title = p.title();
      } else {
         String prefix = artist + " - ";
         if (title.regionMatches(true, 0, prefix, 0, prefix.length())) {
            title = title.substring(prefix.length()).trim();
         }
      }

      String art = Json.str(o, "artwork_url");
      if (art.isEmpty()) {
         art = Json.str(user, "avatar_url");
      }

      String cover = art.isEmpty() ? null : art.replace("-large.", "-t500x500.");
      long duration = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsLong() : 0L;
      return new Track(String.valueOf(o.get("id").getAsLong()), title, artist, null, duration, cover, Platform.SOUNDCLOUD.id);
   }

   @Override
   public CompletableFuture<Void> play(Track t) {
      int my = this.generation.incrementAndGet();
      this.engine.stop();
      return Background.run(() -> {
         byte[] data = this.audio(t.id(), my);
         if (this.generation.get() != my) {
            return null;
         } else {
            AudioEngine e = (AudioEngine)(Mp4Audio.looksLikeMp4(data) ? this.aac : this.mp3);
            this.engine = e;
            e.play(data, 0L, () -> {
               Runnable r = this.finished;
               if (this.generation.get() == my && r != null) {
                  r.run();
               }
            });
            return null;
         }
      });
   }

   private byte[] audio(String id, int gen) throws Exception {
      String key = "sc_" + id;
      byte[] hit = this.cache.get(key);
      if (hit != null) {
         return hit;
      } else {
         this.progress.put(id, new long[]{0L, -1L});

         byte[] var6;
         try {
            byte[] data = this.download(id, gen);
            this.cache.put(key, data);
            var6 = data;
         } finally {
            this.progress.remove(id);
         }

         return var6;
      }
   }

   private byte[] download(String id, int gen) throws Exception {
      JsonObject info = this.api("GET", "/tracks/" + id);
      List<JsonObject> variants = variants(info);
      if (variants.isEmpty()) {
         MusicPlayerMod.LOGGER.warn("SoundCloud track {} has no usable stream; transcodings: {}", id, describe(info));
         throw new IOException(T.get("err.sc_no_stream"));
      } else {
         IOException failure = null;

         for (int round = 0; round < 2; round++) {
            if (round == 1) {
               this.refreshClientId();
            }

            for (JsonObject v : variants) {
               try {
                  return this.fetchVariant(v, id, gen);
               } catch (CancellationException var11) {
                  throw var11;
               } catch (RuntimeException | IOException var12) {
                  failure = var12 instanceof IOException io ? io : new IOException(var12.toString());
                  MusicPlayerMod.LOGGER
                     .warn(
                        "SoundCloud stream {} {} failed: {}",
                        new Object[]{Json.str(v, "preset"), Json.str(Json.obj(v, "format"), "protocol"), var12.getMessage()}
                     );
               }
            }
         }

         throw new IOException(T.get("err.stream_unavailable", failure.getMessage()));
      }
   }

   private static String describe(JsonObject info) {
      StringBuilder sb = new StringBuilder();
      JsonObject media = Json.obj(info, "media");
      if (media.has("transcodings")) {
         for (JsonElement e : media.getAsJsonArray("transcodings")) {
            sb.append(Json.str(e.getAsJsonObject(), "preset")).append('/').append(Json.str(Json.obj(e.getAsJsonObject(), "format"), "protocol")).append(' ');
         }
      }

      return sb.length() == 0 ? "none" : sb.toString().trim();
   }

   private JsonObject resolveStream(String transcodingUrl) throws Exception {
      String url = transcodingUrl + (transcodingUrl.contains("?") ? "&" : "?") + "client_id=" + this.clientId();
      return HTTP.getJson(url, this.headers());
   }

   private byte[] fetchVariant(JsonObject variant, String id, int gen) throws Exception {
      String stream = Json.str(this.resolveStream(variant.get("url").getAsString()), "url");
      if (stream.isEmpty()) {
         throw new IOException(T.get("err.empty_stream"));
      } else {
         return "hls".equals(Json.str(Json.obj(variant, "format"), "protocol")) ? this.downloadHls(stream, id, gen) : this.downloadFile(stream, id, gen);
      }
   }

   private static List<JsonObject> variants(JsonObject info) {
      JsonObject media = Json.obj(info, "media");
      JsonArray list = media.has("transcodings") ? media.getAsJsonArray("transcodings") : new JsonArray();
      List<JsonObject> out = new ArrayList<>();

      for (JsonElement e : list) {
         JsonObject t = e.getAsJsonObject();
         if (score(t) >= 0) {
            out.add(t);
         }
      }

      out.sort(Comparator.comparingInt(SoundCloudProvider::score));
      return out;
   }

   private static int score(JsonObject t) {
      JsonObject f = Json.obj(t, "format");
      String mime = Json.str(f, "mime_type");
      String protocol = Json.str(f, "protocol");
      boolean progressive = protocol.equals("progressive");
      boolean hls = protocol.equals("hls");
      boolean mp3 = mime.startsWith("audio/mpeg");
      boolean aacCodec = mime.startsWith("audio/mp4") && mime.contains("mp4a");
      int base;
      if (mp3 && progressive) {
         base = 0;
      } else if (mp3 && hls) {
         base = 1;
      } else if (aacCodec && progressive) {
         base = 2;
      } else {
         if (!aacCodec || !hls) {
            return -1;
         }

         base = 3;
      }

      boolean preview = t.has("snipped") && t.get("snipped").getAsBoolean() || Json.str(t, "url").contains("/preview/");
      return base + (preview ? 10 : 0);
   }

   private byte[] downloadFile(String url, String id, int gen) throws Exception {
      HttpResponse<InputStream> r = HTTP.open("GET", url, cdnHeaders());
      if (r.statusCode() / 100 != 2) {
         r.body().close();
         throw new IOException("HTTP " + r.statusCode());
      } else {
         long[] prog = this.progress.get(id);
         prog[1] = r.headers().firstValueAsLong("Content-Length").orElse(-1L);
         ByteArrayOutputStream out = new ByteArrayOutputStream();

         try (InputStream in = r.body()) {
            byte[] buf = new byte[32768];

            int n;
            while ((n = in.read(buf)) >= 0) {
               if (this.generation.get() != gen) {
                  throw new CancellationException("cancelled");
               }

               out.write(buf, 0, n);
               prog[0] = out.size();
               if (out.size() > 157286400L) {
                  throw new IOException(T.get("err.track_too_big"));
               }
            }
         }

         return out.toByteArray();
      }
   }

   private byte[] downloadHls(String playlistUrl, String id, int gen) throws Exception {
      String text = HTTP.get(playlistUrl, cdnHeaders());
      if (text.contains("#EXT-X-KEY") && !text.contains("METHOD=NONE")) {
         throw new IOException(T.get("err.encrypted"));
      } else {
         URI base = URI.create(playlistUrl);
         List<String> parts = new ArrayList<>();
         Matcher init = Pattern.compile("#EXT-X-MAP:[^\\n]*URI=\"([^\"]+)\"").matcher(text);
         if (init.find()) {
            parts.add(base.resolve(init.group(1)).toString());
         }

         for (String line : text.split("\\R")) {
            if (!line.isBlank() && !line.startsWith("#")) {
               parts.add(base.resolve(line.trim()).toString());
            }
         }

         if (parts.isEmpty()) {
            throw new IOException(T.get("err.empty_playlist"));
         } else {
            long[] prog = this.progress.get(id);
            prog[1] = parts.size();
            ByteArrayOutputStream out = new ByteArrayOutputStream();

            for (String part : parts) {
               if (this.generation.get() != gen) {
                  throw new CancellationException("cancelled");
               }

               HttpResponse<InputStream> r = HTTP.open("GET", part, cdnHeaders());

               try (InputStream in = r.body()) {
                  if (r.statusCode() / 100 != 2) {
                     throw new IOException("HTTP " + r.statusCode());
                  }

                  in.transferTo(out);
               }

               prog[0]++;
               if (out.size() > 157286400L) {
                  throw new IOException(T.get("err.track_too_big"));
               }
            }

            return out.toByteArray();
         }
      }
   }

   @Override
   public int loadPercent(String id) {
      long[] p = id == null ? null : this.progress.get(id);
      return p != null && p[1] > 0L ? (int)Math.min(100L, p[0] * 100L / p[1]) : -1;
   }

   @Override
   public boolean isCached(String id) {
      return id != null && this.cache.has("sc_" + id);
   }

   private JsonObject api(String method, String path) throws Exception {
      int attempt = 0;

      while (true) {
         String url = "https://api-v2.soundcloud.com" + path + (path.contains("?") ? "&" : "?") + "client_id=" + this.clientId();
         SafeHttp.Reply r = HTTP.send(method, url, this.headers());
         if (r.status() != 401 && r.status() != 403 || attempt != 0) {
            if (r.status() / 100 != 2) {
               throw new IOException("SoundCloud: HTTP " + r.status());
            } else {
               try {
                  JsonElement e = JsonParser.parseString(r.body());
                  return e.isJsonObject() ? e.getAsJsonObject() : new JsonObject();
               } catch (Exception var7) {
                  return new JsonObject();
               }
            }
         }

         this.refreshClientId();
         attempt++;
      }
   }

   private Map<String, String> headers() {
      Map<String, String> h = new HashMap<>(cdnHeaders());
      h.put("Accept", "application/json");
      String t = this.token;
      if (t != null) {
         h.put("Authorization", "OAuth " + t);
      }

      return h;
   }

   private static Map<String, String> cdnHeaders() {
      return Map.of("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36");
   }

   private String clientId() throws Exception {
      String id = this.clientId;
      return id != null ? id : this.refreshClientId();
   }

   private synchronized String refreshClientId() throws Exception {
      String html = HTTP.get("https://soundcloud.com/", cdnHeaders());
      List<String> scripts = new ArrayList<>();
      Matcher m = SCRIPT.matcher(html);

      while (m.find()) {
         scripts.add(m.group(1));
      }

      for (int i = scripts.size() - 1; i >= 0; i--) {
         Matcher c = CLIENT_ID.matcher(HTTP.get(scripts.get(i), cdnHeaders()));
         if (c.find()) {
            this.clientId = c.group(1);
            TokenStore.set("soundcloudClientId2", this.clientId);
            return this.clientId;
         }
      }

      throw new IOException(T.get("err.sc_changed"));
   }

   private static String profileName(String input) {
      String s = input.replaceFirst("(?i)^https?://", "").replaceFirst("(?i)^(www\\.|m\\.)?soundcloud\\.com/", "").replaceFirst("^@", "");
      int cut = 0;

      while (cut < s.length() && "/?#".indexOf(s.charAt(cut)) < 0) {
         cut++;
      }

      return s.substring(0, cut);
   }

   private static String extractToken(String s) {
      Matcher m = TOKEN.matcher(s);
      if (m.find()) {
         return m.group();
      } else {
         int i = s.indexOf("oauth_token=");
         if (i >= 0) {
            s = s.substring(i + "oauth_token=".length());
            int end = 0;

            while (end < s.length() && ";& \"".indexOf(s.charAt(end)) < 0) {
               end++;
            }

            s = s.substring(0, end);
         }

         return s.replaceFirst("(?i)^oauth\\s+", "").replace("\"", "").trim();
      }
   }

   @Override
   public void stop() {
      this.generation.incrementAndGet();
      this.mp3.stop();
      this.aac.stop();
   }

   @Override
   public void pause() {
      this.engine.pause();
   }

   @Override
   public void resume() {
      this.engine.resume();
   }

   @Override
   public void seek(long ms) {
      this.engine.seek(ms);
   }

   @Override
   public long positionMs() {
      return this.engine.positionMs();
   }

   @Override
   public boolean isPlaying() {
      return this.engine.isPlaying();
   }

   @Override
   public void setVolume(float v) {
      this.mp3.setVolume(v);
      this.aac.setVolume(v);
   }

   @Override
   public void onFinished(Runnable r) {
      this.finished = r;
   }

   @Override
   public void onAudioError(Consumer<String> sink) {
      Consumer<Throwable> report = Background.errorsTo(sink);
      this.mp3.onError(report);
      this.aac.onError(report);
   }

   private static String orEmpty(String s) {
      return s == null ? "" : s;
   }

   private static String enc(String s) {
      return URLEncoder.encode(s, StandardCharsets.UTF_8);
   }
}
