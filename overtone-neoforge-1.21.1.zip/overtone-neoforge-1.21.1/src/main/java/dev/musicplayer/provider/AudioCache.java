package dev.musicplayer.provider;

import dev.musicplayer.Env;
import dev.musicplayer.config.PlayerConfig;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

final class AudioCache {
   private static final long DEFAULT_MEM_CAP = 100663296L;
   private static final long DISK_CAP = 536870912L;
   private final LinkedHashMap<String, byte[]> mem = new LinkedHashMap<>(16, 0.75F, true);
   private long memBytes;
   private volatile Set<String> keep = Set.of();
   private volatile String pinned;
   private final Set<String> onDisk = ConcurrentHashMap.newKeySet();
   private final Path dir;
   private final long memCap;
   private static AudioCache lightweight;

   AudioCache() {
      this(100663296L);
   }

   static synchronized AudioCache shared() {
      if (lightweight == null) {
         lightweight = new AudioCache(25165824L);
      }

      return lightweight;
   }

   private AudioCache(long memCap) {
      this.memCap = memCap;
      Path d = null;

      try {
         d = Env.gameDir().resolve("musicplayer-cache");
      } catch (Throwable var5) {
      }

      this.dir = d;
      Thread t = new Thread(this::scan, "musicplayer-cache-scan");
      t.setDaemon(true);
      t.start();
   }

   private static String safe(String id) {
      return id.replaceAll("[^0-9A-Za-z_.-]", "_");
   }

   private Path file(String id) {
      return this.dir.resolve(safe(id) + ".mp3");
   }

   private boolean diskEnabled() {
      return this.dir != null && PlayerConfig.get().diskCache;
   }

   private void scan() {
      if (this.dir != null && Files.isDirectory(this.dir)) {
         try (Stream<Path> s = Files.list(this.dir)) {
            s.forEach(p -> {
               String n = p.getFileName().toString();
               if (n.endsWith(".part")) {
                  try {
                     Files.deleteIfExists(p);
                  } catch (IOException var4) {
                  }
               } else if (n.endsWith(".mp3")) {
                  this.onDisk.add(n.substring(0, n.length() - 4));
               }
            });
         } catch (IOException var6) {
         }

         this.prune();
      }
   }

   void setKeep(Set<String> ids, String current) {
      this.keep = ids;
      this.pinned = current;
   }

   boolean has(String id) {
      synchronized (this) {
         if (this.mem.containsKey(id)) {
            return true;
         }
      }

      return this.onDisk.contains(safe(id));
   }

   byte[] get(String id) {
      synchronized (this) {
         byte[] b = this.mem.get(id);
         if (b != null) {
            return b;
         }
      }

      if (this.dir != null && this.onDisk.contains(safe(id))) {
         try {
            Path f = this.file(id);
            byte[] data = Files.readAllBytes(f);

            try {
               Files.setLastModifiedTime(f, FileTime.fromMillis(System.currentTimeMillis()));
            } catch (IOException var5) {
            }

            if (data.length == 0) {
               this.onDisk.remove(safe(id));
               return null;
            } else {
               this.memPut(id, data);
               return data;
            }
         } catch (IOException var6) {
            this.onDisk.remove(safe(id));
            return null;
         }
      } else {
         return null;
      }
   }

   void put(String id, byte[] data) {
      this.memPut(id, data);
      if (this.diskEnabled()) {
         try {
            Files.createDirectories(this.dir);
            Path tmp = this.dir.resolve(safe(id) + ".part");
            Files.write(tmp, data);
            Files.move(tmp, this.file(id), StandardCopyOption.REPLACE_EXISTING);
            this.onDisk.add(safe(id));
            this.prune();
         } catch (IOException var4) {
         }
      }
   }

   private synchronized void memPut(String id, byte[] data) {
      byte[] old = this.mem.put(id, data);
      if (old != null) {
         this.memBytes -= old.length;
      }

      this.memBytes += data.length;

      for (int pass = 0; pass < 2 && this.memBytes > this.memCap && this.mem.size() > 1; pass++) {
         Iterator<Entry<String, byte[]>> it = this.mem.entrySet().iterator();

         while (it.hasNext() && this.memBytes > this.memCap && this.mem.size() > 1) {
            Entry<String, byte[]> e = it.next();
            String k = e.getKey();
            if (!k.equals(id) && !k.equals(this.pinned) && (pass != 0 || !this.keep.contains(k))) {
               this.memBytes = this.memBytes - e.getValue().length;
               it.remove();
            }
         }
      }
   }

   private void prune() {
      if (this.dir != null && Files.isDirectory(this.dir)) {
         try {
            label103: {
               try (Stream<Path> s = Files.list(this.dir)) {
                  List<Path> files = new ArrayList<>(s.filter(px -> px.toString().endsWith(".mp3")).toList());
                  long total = 0L;

                  for (Path p : files) {
                     total += Files.size(p);
                  }

                  if (total > 536870912L) {
                     files.sort(Comparator.comparingLong(px -> {
                        try {
                           return Files.getLastModifiedTime(px).toMillis();
                        } catch (IOException var2x) {
                           return 0L;
                        }
                     }));

                     for (Path p : files) {
                        if (total <= 536870912L) {
                           return;
                        }

                        String n = p.getFileName().toString();
                        String base = n.substring(0, n.length() - 4);
                        if (!base.equals(this.pinned == null ? null : safe(this.pinned))) {
                           boolean kept = false;
                           Iterator size = this.keep.iterator();

                           while (true) {
                              if (size.hasNext()) {
                                 String k = (String)size.next();
                                 if (!safe(k).equals(base)) {
                                    continue;
                                 }

                                 kept = true;
                              }

                              if (!kept) {
                                 long sizex = Files.size(p);
                                 Files.deleteIfExists(p);
                                 this.onDisk.remove(base);
                                 total -= sizex;
                              }
                              break;
                           }
                        }
                     }
                     break label103;
                  }
               }

               return;
            }
         } catch (IOException var14) {
         }
      }
   }

   synchronized void clear() {
      String keepId = this.pinned;
      this.mem.keySet().removeIf(k -> !k.equals(keepId));
      this.memBytes = 0L;

      for (byte[] b : this.mem.values()) {
         this.memBytes += b.length;
      }

      if (this.dir != null) {
         try (Stream<Path> s = Files.list(this.dir)) {
            s.forEach(p -> {
               try {
                  Files.deleteIfExists(p);
               } catch (IOException var2) {
               }
            });
         } catch (IOException var7) {
         }

         this.onDisk.clear();
      }
   }

   long diskMegabytes() {
      if (this.dir != null && Files.isDirectory(this.dir)) {
         try {
            long var9;
            try (Stream<Path> s = Files.list(this.dir)) {
               long t = 0L;

               for (Path p : s.toList()) {
                  t += Files.size(p);
               }

               var9 = t >> 20;
            }

            return var9;
         } catch (IOException var8) {
            return 0L;
         }
      } else {
         return 0L;
      }
   }
}
