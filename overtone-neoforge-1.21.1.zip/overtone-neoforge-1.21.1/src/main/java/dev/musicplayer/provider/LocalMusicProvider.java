package dev.musicplayer.provider;

import dev.musicplayer.audio.AudioEngine;
import dev.musicplayer.audio.Mp3Player;
import dev.musicplayer.audio.PcmPlayer;
import dev.musicplayer.local.LocalLibrary;
import dev.musicplayer.lyrics.LrcParser;
import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.Platform;
import dev.musicplayer.model.Track;
import dev.musicplayer.util.Browser;
import dev.musicplayer.util.T;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

public final class LocalMusicProvider implements MusicProvider {
   private static final long MAX_FILE_BYTES = 419430400L;
   private final LocalLibrary library = new LocalLibrary();
   private final Mp3Player mp3 = new Mp3Player();
   private final PcmPlayer pcm = new PcmPlayer();
   private final AtomicInteger generation = new AtomicInteger();
   private volatile AudioEngine engine = this.mp3;
   private volatile Runnable finished;
   private volatile float volume = 0.8F;

   public LocalMusicProvider() {
   }

   @Override
   public Platform platform() {
      return Platform.LOCAL;
   }

   @Override
   public boolean isLoggedIn() {
      return true;
   }

   @Override
   public String accountName() {
      return this.library.status();
   }

   @Override
   public void logout() {
   }

   @Override
   public String likedLabel() {
      return T.get("liked.library");
   }

   public void refresh() {
      this.library.rescan();
   }

   public int libraryVersion() {
      return this.library.version();
   }

   public boolean openFolder() {
      try {
         Path dir = LocalLibrary.defaultFolder();
         Files.createDirectories(dir);
         return Browser.openFolder(dir);
      } catch (IOException var2) {
         return false;
      }
   }

   public int addPaths(List<Path> paths) {
      return this.library.addPaths(paths);
   }

   public boolean remove(String trackId) {
      return this.library.remove(trackId);
   }

   @Override
   public CompletableFuture<List<Track>> search(String query) {
      return Background.run(() -> this.library.search(query));
   }

   @Override
   public CompletableFuture<List<Track>> likedTracks() {
      return Background.run(() -> this.library.search(""));
   }

   @Override
   public CompletableFuture<Void> play(Track t) {
      int my = this.generation.incrementAndGet();
      this.engine.stop();
      return Background.run(() -> {
         Path file = this.library.pathOf(t.id());
         if (file != null && Files.isRegularFile(file)) {
            if (Files.size(file) > 419430400L) {
               throw new IOException(T.get("err.file_too_big"));
            } else {
               byte[] data = Files.readAllBytes(file);
               if (this.generation.get() != my) {
                  return null;
               } else {
                  AudioEngine e = (AudioEngine)(LocalLibrary.isMp3(file) ? this.mp3 : this.pcm);
                  this.engine = e;
                  e.setVolume(this.volume);
                  e.play(data, 0L, () -> {
                     Runnable r = this.finished;
                     if (this.generation.get() == my && r != null) {
                        r.run();
                     }
                  });
                  return null;
               }
            }
         } else {
            throw new IOException(T.get("err.file_missing"));
         }
      });
   }

   @Override
   public void stop() {
      this.generation.incrementAndGet();
      this.mp3.stop();
      this.pcm.stop();
   }

   @Override
   public void pause() {
      this.engine.pause();
   }

   @Override
   public void resume() {
      this.engine.resume();
   }

   @Override
   public void seek(long ms) {
      this.engine.seek(ms);
   }

   @Override
   public long positionMs() {
      return this.engine.positionMs();
   }

   @Override
   public boolean isPlaying() {
      return this.engine.isPlaying();
   }

   @Override
   public void setVolume(float v) {
      this.volume = v;
      this.mp3.setVolume(v);
      this.pcm.setVolume(v);
   }

   @Override
   public void onFinished(Runnable r) {
      this.finished = r;
   }

   @Override
   public void onAudioError(Consumer<String> sink) {
      Consumer<Throwable> report = Background.errorsTo(sink);
      this.mp3.onError(report);
      this.pcm.onError(report);
   }

   @Override
   public CompletableFuture<List<LyricLine>> lyrics(Track t, boolean synced) {
      return Background.<List<LyricLine>>run(() -> {
         Path file = this.library.pathOf(t.id());
         if (file == null) {
            return List.of();
         } else {
            String text = this.library.lyricsText(file);
            if (text.isBlank()) {
               return List.of();
            } else {
               List<LyricLine> timed = LrcParser.parse(text);
               if (synced) {
                  return timed;
               } else {
                  return timed.isEmpty() ? LrcParser.plain(text) : List.of();
               }
            }
         }
      }).exceptionally(e -> List.of());
   }
}
