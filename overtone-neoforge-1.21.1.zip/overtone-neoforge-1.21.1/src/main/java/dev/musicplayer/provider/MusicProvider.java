package dev.musicplayer.provider;

import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.Platform;
import dev.musicplayer.model.Track;
import dev.musicplayer.util.T;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public interface MusicProvider {
   Platform platform();

   boolean isLoggedIn();

   String accountName();

   void logout();

   CompletableFuture<List<Track>> search(String var1);

   CompletableFuture<List<Track>> likedTracks();

   default String likedLabel() {
      return T.get("liked.favorites");
   }

   CompletableFuture<Void> play(Track var1);

   void stop();

   void pause();

   void resume();

   void seek(long var1);

   long positionMs();

   boolean isPlaying();

   void setVolume(float var1);

   void onFinished(Runnable var1);

   void onAudioError(Consumer<String> var1);

   default CompletableFuture<List<LyricLine>> lyrics(Track t, boolean synced) {
      return CompletableFuture.completedFuture(List.of());
   }

   default boolean supportsLikes() {
      return false;
   }

   default boolean isLiked(String trackId) {
      return false;
   }

   default CompletableFuture<Void> setLiked(Track t, boolean like) {
      return CompletableFuture.completedFuture(null);
   }

   default boolean isCached(String trackId) {
      return false;
   }

   default int loadPercent(String trackId) {
      return -1;
   }

   default void setPrefetch(String current, List<Track> upcoming, Set<String> keep) {
   }
}
