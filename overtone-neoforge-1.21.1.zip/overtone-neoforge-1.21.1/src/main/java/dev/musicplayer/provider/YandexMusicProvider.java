package dev.musicplayer.provider;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.musicplayer.MusicPlayerMod;
import dev.musicplayer.audio.Mp3Player;
import dev.musicplayer.config.PlayerConfig;
import dev.musicplayer.config.TokenStore;
import dev.musicplayer.lyrics.LrcParser;
import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.MusicEntity;
import dev.musicplayer.model.Page;
import dev.musicplayer.model.Platform;
import dev.musicplayer.model.Track;
import dev.musicplayer.util.Browser;
import dev.musicplayer.util.T;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpRequest.Builder;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class YandexMusicProvider implements MusicProvider {
   public static final String OAUTH_URL = "https://oauth.yandex.ru/authorize?response_type=token&client_id=23cabbbdc6cd418abb4b39c32c41195d";
   private static final int MAX_TRACK_BYTES = 125829120;
   private static final String API = "https://api.music.yandex.net";
   private static final String SIGN_SALT = "XGRlBW9FXlekgbPrRHuSiA";
   private static final String LYRICS_SIGN_KEY = "p93jhgh689SBReK6ghtw62";
   private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8L)).followRedirects(Redirect.NORMAL).build();
   private static final ExecutorService EXEC = Executors.newCachedThreadPool(r -> {
      Thread t = new Thread(r, "musicplayer-net");
      t.setDaemon(true);
      return t;
   });
   private volatile String token = TokenStore.get("yandexToken");
   private volatile String uid;
   private volatile String accountName = "";
   private final Set<String> likedIds = ConcurrentHashMap.newKeySet();
   private volatile boolean verified;
   private volatile CompletableFuture<Void> loginFuture;
   private final Mp3Player player = new Mp3Player();
   private final AtomicInteger generation = new AtomicInteger();
   private volatile Runnable finished;
   public static final String WAVE_SEED = "user:onyourwave";
   private static final Map<String, String> FULL_ID = new ConcurrentHashMap<>();
   private final AudioCache cache = new AudioCache();
   private final ConcurrentHashMap<String, CompletableFuture<byte[]>> inflight = new ConcurrentHashMap<>();
   private final ConcurrentHashMap<String, byte[]> partial = new ConcurrentHashMap<>();
   private final ConcurrentHashMap<String, long[]> progress = new ConcurrentHashMap<>();
   private final ConcurrentHashMap<String, Integer> failures = new ConcurrentHashMap<>();
   private volatile Set<String> desired = Set.of();
   private volatile String currentId;
   private volatile List<Track> prefetchList = List.of();
   private volatile boolean playLoading;
   private final Object prefetchLock = new Object();
   private Thread prefetchThread;
   private static final ScheduledExecutorService WATCHDOG = Executors.newSingleThreadScheduledExecutor(r -> {
      Thread t = new Thread(r, "musicplayer-net-wd");
      t.setDaemon(true);
      return t;
   });

   public YandexMusicProvider() {
      if (this.token != null) {
         this.verifyAsync();
      }
   }

   @Override
   public Platform platform() {
      return Platform.YANDEX;
   }

   @Override
   public boolean isLoggedIn() {
      return this.token != null && this.verified;
   }

   @Override
   public String accountName() {
      return this.accountName;
   }

   @Override
   public boolean supportsLikes() {
      return true;
   }

   @Override
   public boolean isLiked(String trackId) {
      return trackId != null && this.likedIds.contains(trackId);
   }

   private void readAccount(JsonObject result) {
      JsonObject acc = result.getAsJsonObject("account");
      this.uid = acc.get("uid").getAsString();
      String n = str(acc, "displayName");
      if (n.isEmpty()) {
         n = str(acc, "fullName");
      }

      if (n.isEmpty()) {
         n = str(acc, "login");
      }

      this.accountName = n;
   }

   private void refreshLikes() {
      async(() -> {
         JsonObject r = this.getResult("https://api.music.yandex.net/users/" + this.uid + "/likes/tracks");
         Set<String> ids = new HashSet<>();

         for (JsonElement e : r.getAsJsonObject("library").getAsJsonArray("tracks")) {
            ids.add(e.getAsJsonObject().get("id").getAsString());
         }

         this.likedIds.clear();
         this.likedIds.addAll(ids);
         return null;
      }).exceptionally(e -> null);
   }

   @Override
   public CompletableFuture<Void> setLiked(Track t, boolean like) {
      return async(
         () -> {
            String path = like ? "/likes/tracks/add-multiple" : "/likes/tracks/remove";
            HttpRequest req = this.base("https://api.music.yandex.net/users/" + this.uid + path)
               .header("Content-Type", "application/x-www-form-urlencoded")
               .POST(BodyPublishers.ofString("track-ids=" + enc(t.id())))
               .build();
            this.send(req);
            if (like) {
               this.likedIds.add(t.id());
            } else {
               this.likedIds.remove(t.id());
            }

            return null;
         }
      );
   }

   public CompletableFuture<Void> login() {
      Browser.open("https://oauth.yandex.ru/authorize?response_type=token&client_id=23cabbbdc6cd418abb4b39c32c41195d");
      this.loginFuture = new CompletableFuture<>();
      return this.loginFuture;
   }

   public CompletableFuture<Void> submitToken(String input) {
      String t = extractToken(input);
      if (t.isEmpty()) {
         return CompletableFuture.failedFuture(new IOException(T.get("err.empty_token")));
      } else {
         String old = this.token;
         this.token = t;
         return async(() -> {
            try {
               this.readAccount(this.getResult("https://api.music.yandex.net/account/status"));
            } catch (Exception var5) {
               this.token = old;
               String m = String.valueOf(var5.getMessage());
               if (m.contains("HTTP 401") || m.contains("HTTP 403")) {
                  TokenStore.removeAccountByToken(t);
               }

               throw var5;
            }

            this.verified = true;
            this.refreshLikes();
            TokenStore.set("yandexToken", this.token);
            TokenStore.putAccount(this.uid, this.accountName, this.token);
            CompletableFuture<Void> f = this.loginFuture;
            if (f != null) {
               f.complete(null);
            }

            return null;
         });
      }
   }

   private void verifyAsync() {
      async(() -> {
         this.readAccount(this.getResult("https://api.music.yandex.net/account/status"));
         this.verified = true;
         this.refreshLikes();
         TokenStore.putAccount(this.uid, this.accountName, this.token);
         return null;
      }).exceptionally(e -> {
         MusicPlayerMod.LOGGER.warn("Yandex token check failed", e);
         String m = String.valueOf(e.getMessage());
         if (m.contains("HTTP 401") || m.contains("HTTP 403")) {
            TokenStore.removeAccountByToken(this.token);
            this.token = null;
            TokenStore.set("yandexToken", null);
         }

         return null;
      });
   }

   private static String extractToken(String s) {
      if (s == null) {
         return "";
      } else {
         s = s.trim();
         int i = s.indexOf("access_token=");
         if (i >= 0) {
            s = s.substring(i + "access_token=".length());
            int amp = s.indexOf(38);
            if (amp >= 0) {
               s = s.substring(0, amp);
            }
         }

         return s.trim();
      }
   }

   @Override
   public void logout() {
      this.generation.incrementAndGet();
      this.desired = Set.of();
      this.currentId = null;
      this.prefetchList = List.of();
      this.playLoading = false;
      this.player.stop();
      this.token = null;
      this.uid = null;
      this.verified = false;
      this.accountName = "";
      this.likedIds.clear();
      TokenStore.set("yandexToken", null);
   }

   public List<TokenStore.Account> savedAccounts() {
      return TokenStore.accounts();
   }

   public void forgetAccount(TokenStore.Account a) {
      if (a != null) {
         if (a.uid() != null) {
            TokenStore.removeAccountByUid(a.uid());
         }

         TokenStore.removeAccountByToken(a.token());
      }
   }

   @Override
   public CompletableFuture<List<Track>> search(String query) {
      return async(() -> {
         JsonObject r = this.getResult("https://api.music.yandex.net/search?text=" + enc(query) + "&nocorrect=false&type=track&page=0");
         List<Track> out = new ArrayList<>();
         JsonObject tracks = r.getAsJsonObject("tracks");
         if (tracks != null && tracks.has("results")) {
            for (JsonElement e : tracks.getAsJsonArray("results")) {
               out.add(parseTrack(e.getAsJsonObject()));
            }

            return out;
         } else {
            return out;
         }
      });
   }

   public CompletableFuture<YandexMusicProvider.SearchAll> searchAll(String query) {
      return async(() -> {
         JsonObject r = this.getResult("https://api.music.yandex.net/search?text=" + enc(query) + "&nocorrect=false&type=all&page=0");
         List<Track> tracks = new ArrayList<>();

         for (JsonObject o : results(r, "tracks")) {
            tracks.add(parseTrack(o));
         }

         List<MusicEntity> artists = new ArrayList<>();
         List<MusicEntity> albums = new ArrayList<>();
         List<MusicEntity> playlists = new ArrayList<>(List.of(MusicEntity.MINE));

         for (JsonObject o : results(r, "artists")) {
            artists.add(artistOf(o));
         }

         for (JsonObject o : results(r, "albums")) {
            albums.add(albumOf(o));
         }

         for (JsonObject o : results(r, "playlists")) {
            MusicEntity p = playlistOf(o);
            if (p != null) {
               playlists.add(p);
            }
         }

         return new YandexMusicProvider.SearchAll(tracks, artists, albums, playlists);
      });
   }

   private static List<JsonObject> results(JsonObject r, String key) {
      List<JsonObject> out = new ArrayList<>();
      if (r.has(key) && r.get(key).isJsonObject()) {
         JsonObject block = r.getAsJsonObject(key);
         if (block.has("results") && block.get("results").isJsonArray()) {
            for (JsonElement e : block.getAsJsonArray("results")) {
               if (e.isJsonObject()) {
                  out.add(e.getAsJsonObject());
               }
            }

            return out;
         } else {
            return out;
         }
      } else {
         return out;
      }
   }

   private static String imageUrl(JsonObject o) {
      String uri = "";
      if (o.has("coverUri") && !o.get("coverUri").isJsonNull()) {
         uri = o.get("coverUri").getAsString();
      } else if (o.has("cover") && o.get("cover").isJsonObject()) {
         uri = str(o.getAsJsonObject("cover"), "uri");
      } else if (o.has("ogImage") && !o.get("ogImage").isJsonNull()) {
         uri = o.get("ogImage").getAsString();
      }

      return uri.isEmpty() ? null : "https://" + uri.replace("%%", "200x200");
   }

   private static String artistNames(JsonObject o) {
      List<String> names = new ArrayList<>();
      if (o.has("artists") && o.get("artists").isJsonArray()) {
         for (JsonElement a : o.getAsJsonArray("artists")) {
            if (a.isJsonObject()) {
               names.add(str(a.getAsJsonObject(), "name"));
            }
         }
      }

      return String.join(", ", names);
   }

   private static MusicEntity artistOf(JsonObject o) {
      return new MusicEntity(MusicEntity.Kind.ARTIST, str(o, "id"), str(o, "name"), T.get("entity.artist"), imageUrl(o));
   }

   private static MusicEntity albumOf(JsonObject o) {
      String by = artistNames(o);
      String year = str(o, "year");
      String sub = T.get("entity.album") + (by.isEmpty() ? "" : " \u00b7 " + by) + (year.isEmpty() ? "" : " \u00b7 " + year);
      String title = str(o, "title");
      String version = str(o, "version");
      return new MusicEntity(MusicEntity.Kind.ALBUM, str(o, "id"), version.isEmpty() ? title : title + " (" + version + ")", sub, imageUrl(o));
   }

   private static MusicEntity playlistOf(JsonObject o) {
      String uid = str(o, "uid");
      String kind = str(o, "kind");
      if (uid.isEmpty() && o.has("owner") && o.get("owner").isJsonObject()) {
         uid = str(o.getAsJsonObject("owner"), "uid");
      }

      if (!uid.isEmpty() && !kind.isEmpty()) {
         String owner = o.has("owner") && o.get("owner").isJsonObject() ? str(o.getAsJsonObject("owner"), "name") : "";
         if (owner.isEmpty() && o.has("owner") && o.get("owner").isJsonObject()) {
            owner = str(o.getAsJsonObject("owner"), "login");
         }

         String sub = T.get("entity.playlist")
            + (owner.isEmpty() ? "" : " \u00b7 " + owner)
            + (o.has("trackCount") ? " \u00b7 " + T.tracks(o.get("trackCount").getAsInt()) : "");
         return new MusicEntity(MusicEntity.Kind.PLAYLIST, uid + ":" + kind, str(o, "title"), sub, imageUrl(o));
      } else {
         return null;
      }
   }

   public CompletableFuture<Page> open(MusicEntity e) {
      return async(() -> {
         return switch (e.kind()) {
            case ARTIST -> this.openArtist(e);
            case ALBUM -> this.openAlbum(e);
            case PLAYLIST -> e.isMine() ? this.openMyPlaylists(e) : this.openPlaylist(e);
            case STATION -> throw new IllegalArgumentException("a station is started as a wave, not opened");
         };
      });
   }

   private Page openArtist(MusicEntity e) throws Exception {
      List<Track> tracks = new ArrayList<>();
      List<MusicEntity> albums = new ArrayList<>();
      JsonObject brief = this.getResult("https://api.music.yandex.net/artists/" + e.id() + "/brief-info");
      if (brief.has("popularTracks") && brief.get("popularTracks").isJsonArray()) {
         tracks.addAll(parseTracks(brief.getAsJsonArray("popularTracks")));
      }

      if (tracks.isEmpty()) {
         JsonObject t = this.getResult("https://api.music.yandex.net/artists/" + e.id() + "/tracks?page=0&page-size=50");
         if (t.has("tracks") && t.get("tracks").isJsonArray()) {
            tracks.addAll(parseTracks(t.getAsJsonArray("tracks")));
         }
      }

      JsonArray raw = null;

      try {
         JsonObject a = this.getResult("https://api.music.yandex.net/artists/" + e.id() + "/direct-albums?page=0&page-size=50&sort-by=year");
         if (a.has("albums") && a.get("albums").isJsonArray()) {
            raw = a.getAsJsonArray("albums");
         }
      } catch (IOException var8) {
      }

      if ((raw == null || raw.isEmpty()) && brief.has("albums") && brief.get("albums").isJsonArray()) {
         raw = brief.getAsJsonArray("albums");
      }

      if (raw != null) {
         for (JsonElement a : raw) {
            if (a.isJsonObject()) {
               albums.add(albumOf(a.getAsJsonObject()));
            }
         }
      }

      return new Page(e, tracks, albums);
   }

   private Page openAlbum(MusicEntity e) throws Exception {
      JsonObject r = this.getResult("https://api.music.yandex.net/albums/" + e.id() + "/with-tracks");
      List<Track> tracks = new ArrayList<>();
      if (r.has("volumes") && r.get("volumes").isJsonArray()) {
         for (JsonElement vol : r.getAsJsonArray("volumes")) {
            if (vol.isJsonArray()) {
               tracks.addAll(parseTracks(vol.getAsJsonArray()));
            }
         }
      }

      return new Page(e, tracks, List.of());
   }

   private Page openPlaylist(MusicEntity e) throws Exception {
      int colon = e.id().indexOf(58);
      JsonObject r = this.getResult(
         "https://api.music.yandex.net/users/" + e.id().substring(0, colon) + "/playlists/" + e.id().substring(colon + 1) + "?rich-tracks=true"
      );
      List<Track> tracks = new ArrayList<>();
      List<String> bare = new ArrayList<>();
      if (r.has("tracks") && r.get("tracks").isJsonArray()) {
         for (JsonElement el : r.getAsJsonArray("tracks")) {
            if (el.isJsonObject()) {
               JsonObject o = el.getAsJsonObject();
               if (o.has("track") && o.get("track").isJsonObject()) {
                  try {
                     tracks.add(parseTrack(o.getAsJsonObject("track")));
                  } catch (RuntimeException var10) {
                  }
               } else if (o.has("id")) {
                  bare.add(str(o, "albumId").isEmpty() ? str(o, "id") : str(o, "id") + ":" + str(o, "albumId"));
               }
            }
         }
      }

      if (tracks.isEmpty() && !bare.isEmpty()) {
         tracks.addAll(this.fetchTracks(bare.size() > 100 ? bare.subList(0, 100) : bare));
      }

      return new Page(e, tracks, List.of());
   }

   private Page openMyPlaylists(MusicEntity e) throws Exception {
      JsonArray arr = this.getResultArray("https://api.music.yandex.net/users/" + this.uid + "/playlists/list");
      List<MusicEntity> out = new ArrayList<>();

      for (JsonElement el : arr) {
         if (el.isJsonObject()) {
            MusicEntity p = playlistOf(el.getAsJsonObject());
            if (p != null) {
               out.add(p);
            }
         }
      }

      return new Page(e, List.of(), out);
   }

   private List<Track> fetchTracks(List<String> ids) throws Exception {
      HttpRequest req = this.base("https://api.music.yandex.net/tracks")
         .header("Content-Type", "application/x-www-form-urlencoded")
         .POST(BodyPublishers.ofString("track-ids=" + enc(String.join(",", ids))))
         .build();
      return parseTracks(this.send(req).getAsJsonArray("result"));
   }

   private static List<Track> parseTracks(JsonArray arr) {
      List<Track> out = new ArrayList<>();

      for (JsonElement el : arr) {
         if (el.isJsonObject() && el.getAsJsonObject().has("id")) {
            try {
               out.add(parseTrack(el.getAsJsonObject()));
            } catch (RuntimeException var5) {
            }
         }
      }

      return out;
   }

   @Override
   public CompletableFuture<List<Track>> likedTracks() {
      return async(
         () -> {
            JsonObject r = this.getResult("https://api.music.yandex.net/users/" + this.uid + "/likes/tracks");
            JsonArray arr = r.getAsJsonObject("library").getAsJsonArray("tracks");
            List<String> ids = new ArrayList<>();

            for (JsonElement e : arr) {
               JsonObject o = e.getAsJsonObject();
               String id = o.get("id").getAsString();
               ids.add(o.has("albumId") && !o.get("albumId").isJsonNull() ? id + ":" + o.get("albumId").getAsString() : id);
            }

            Collections.reverse(ids);
            if (ids.size() > 100) {
               ids = ids.subList(0, 100);
            }

            if (ids.isEmpty()) {
               return new ArrayList<>();
            } else {
               HttpRequest req = this.base("https://api.music.yandex.net/tracks")
                  .header("Content-Type", "application/x-www-form-urlencoded")
                  .POST(BodyPublishers.ofString("track-ids=" + enc(String.join(",", ids))))
                  .build();
               JsonArray full = this.send(req).getAsJsonArray("result");
               List<Track> out = new ArrayList<>();

               for (JsonElement e : full) {
                  out.add(parseTrack(e.getAsJsonObject()));
               }

               return out;
            }
         }
      );
   }

   @Override
   public CompletableFuture<List<LyricLine>> lyrics(Track t, boolean synced) {
      return YandexMusicProvider.<List<LyricLine>>async(
            () -> {
               if (this.token != null && this.verified) {
                  String ts = String.valueOf(System.currentTimeMillis() / 1000L);
                  JsonObject r = this.getResult(
                     "https://api.music.yandex.net/tracks/"
                        + t.id()
                        + "/lyrics?format="
                        + (synced ? "LRC" : "TEXT")
                        + "&timeStamp="
                        + ts
                        + "&sign="
                        + enc(lyricsSign(t.id() + ts))
                  );
                  String link = str(r, "downloadUrl");
                  if (link.isEmpty()) {
                     return List.of();
                  } else {
                     HttpResponse<String> body = HTTP.send(
                        HttpRequest.newBuilder(URI.create(link)).timeout(Duration.ofSeconds(15L)).GET().build(), BodyHandlers.ofString(StandardCharsets.UTF_8)
                     );
                     if (body.statusCode() != 200) {
                        return List.of();
                     } else {
                        return synced ? LrcParser.parse(body.body()) : LrcParser.plain(body.body());
                     }
                  }
               } else {
                  return List.of();
               }
            }
         )
         .exceptionally(e -> {
            MusicPlayerMod.LOGGER.debug("Yandex lyrics unavailable for {}: {}", t.id(), e.getMessage());
            return List.of();
         });
   }

   private static String lyricsSign(String data) throws Exception {
      Mac mac = Mac.getInstance("HmacSHA256");
      mac.init(new SecretKeySpec("p93jhgh689SBReK6ghtw62".getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
      return Base64.getEncoder().encodeToString(mac.doFinal(data.getBytes(StandardCharsets.UTF_8)));
   }

   public CompletableFuture<YandexMusicProvider.WaveBatch> waveStart(String seed) {
      return async(() -> this.newWaveSession(seed));
   }

   public CompletableFuture<List<MusicEntity>> waveStations() {
      String lang = Locale.getDefault().getLanguage().equals("ru") ? "ru" : "en";
      return async(() -> {
         List<MusicEntity> out = new ArrayList<>();

         for (JsonElement el : this.getResultArray("https://api.music.yandex.net/rotor/stations/list?language=" + lang)) {
            JsonObject st = el.getAsJsonObject().has("station") ? el.getAsJsonObject().getAsJsonObject("station") : null;
            if (st != null && st.has("id") && st.get("id").isJsonObject()) {
               JsonObject id = st.getAsJsonObject("id");
               String type = str(id, "type");
               String tag = str(id, "tag");
               String name = str(st, "name");
               if (!type.isEmpty() && !tag.isEmpty() && !name.isEmpty()) {
                  out.add(new MusicEntity(MusicEntity.Kind.STATION, type + ":" + tag, name, stationType(type), null));
               }
            }
         }

         return out;
      });
   }

   private static String stationType(String type) {
      return switch (type) {
         case "genre" -> T.get("station.genre");
         case "mood" -> T.get("station.mood");
         case "activity" -> T.get("station.activity");
         case "epoch" -> T.get("station.epoch");
         case "user" -> T.get("station.user");
         default -> T.get("station.other");
      };
   }

   private YandexMusicProvider.WaveBatch newWaveSession(String seed) throws Exception {
      JsonObject body = new JsonObject();
      JsonArray seeds = new JsonArray();
      seeds.add(seed);
      body.add("seeds", seeds);
      body.addProperty("includeTracksInResponse", true);
      JsonObject r = this.postJson("https://api.music.yandex.net/rotor/session/new", body).getAsJsonObject("result");
      String sid = str(r, "radioSessionId");
      if (sid.isEmpty()) {
         throw new IOException(T.get("err.wave_session"));
      } else {
         return readBatch(sid, r);
      }
   }

   public CompletableFuture<YandexMusicProvider.WaveBatch> waveMore(String sessionId, String seed, String lastTrackId) {
      return async(() -> {
         try {
            JsonObject body = new JsonObject();
            JsonArray queue = new JsonArray();
            queue.add(FULL_ID.getOrDefault(lastTrackId, lastTrackId));
            body.add("queue", queue);
            JsonObject r = this.postJson("https://api.music.yandex.net/rotor/session/" + sessionId + "/tracks", body).getAsJsonObject("result");
            YandexMusicProvider.WaveBatch b = readBatch(sessionId, r);
            if (!b.tracks().isEmpty()) {
               return b;
            }
         } catch (IOException var8) {
            MusicPlayerMod.LOGGER.warn("Wave /tracks failed, starting a fresh session: {}", var8.getMessage());
         }

         return this.newWaveSession(seed);
      });
   }

   private static YandexMusicProvider.WaveBatch readBatch(String sid, JsonObject r) {
      List<Track> out = new ArrayList<>();
      if (r.has("sequence") && r.get("sequence").isJsonArray()) {
         for (JsonElement e : r.getAsJsonArray("sequence")) {
            JsonObject o = e.getAsJsonObject();
            if (o.has("track") && o.get("track").isJsonObject()) {
               out.add(parseTrack(o.getAsJsonObject("track")));
            }
         }
      }

      return new YandexMusicProvider.WaveBatch(sid, str(r, "batchId"), out);
   }

   public void waveFeedback(String sessionId, String batchId, String type, String trackId, double playedSeconds) {
      if (sessionId != null && this.token != null) {
         async(() -> {
            JsonObject ev = new JsonObject();
            ev.addProperty("type", type);
            ev.addProperty("timestamp", Instant.now().toString());
            if (trackId != null) {
               ev.addProperty("trackId", trackId);
            }

            ev.addProperty("totalPlayedSeconds", Math.max(0.0, playedSeconds));
            JsonObject body = new JsonObject();
            body.add("event", ev);
            if (batchId != null && !batchId.isEmpty()) {
               body.addProperty("batchId", batchId);
            }

            this.postJson("https://api.music.yandex.net/rotor/session/" + sessionId + "/feedback", body);
            return null;
         }).exceptionally(e -> null);
      }
   }

   public CompletableFuture<Void> dislike(Track t) {
      return async(
         () -> {
            HttpRequest req = this.base("https://api.music.yandex.net/users/" + this.uid + "/dislikes/tracks/add-multiple")
               .header("Content-Type", "application/x-www-form-urlencoded")
               .POST(BodyPublishers.ofString("track-ids=" + enc(t.id())))
               .build();
            this.send(req);
            this.likedIds.remove(t.id());
            return null;
         }
      );
   }

   private JsonObject postJson(String url, JsonObject body) throws IOException, InterruptedException {
      return this.send(this.base(url).header("Content-Type", "application/json").POST(BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8)).build());
   }

   private static Track parseTrack(JsonObject t) {
      String title = str(t, "title");
      String version = str(t, "version");
      if (!version.isEmpty()) {
         title = title + " (" + version + ")";
      }

      List<String> artists = new ArrayList<>();
      if (t.has("artists")) {
         for (JsonElement a : t.getAsJsonArray("artists")) {
            artists.add(str(a.getAsJsonObject(), "name"));
         }
      }

      String album = null;
      if (t.has("albums") && t.getAsJsonArray("albums").size() > 0 && t.has("id") && t.getAsJsonArray("albums").get(0).getAsJsonObject().has("id")) {
         FULL_ID.put(t.get("id").getAsString(), t.get("id").getAsString() + ":" + t.getAsJsonArray("albums").get(0).getAsJsonObject().get("id").getAsString());
      }

      if (t.has("albums") && t.getAsJsonArray("albums").size() > 0) {
         album = str(t.getAsJsonArray("albums").get(0).getAsJsonObject(), "title");
      }

      long dur = t.has("durationMs") ? t.get("durationMs").getAsLong() : 0L;
      String cover = t.has("coverUri") && !t.get("coverUri").isJsonNull() ? "https://" + t.get("coverUri").getAsString().replace("%%", "400x400") : null;
      return new Track(t.get("id").getAsString(), title, String.join(", ", artists), album, dur, cover, "yandex");
   }

   @Override
   public CompletableFuture<Void> play(Track t) {
      int my = this.generation.incrementAndGet();
      this.player.stop();
      this.currentId = t.id();
      Set<String> d = new HashSet<>(this.desired);
      d.add(t.id());
      this.desired = d;
      this.playLoading = true;
      return async(() -> {
         Object var4;
         try {
            byte[] data = this.audio(t.id()).join();
            MusicPlayerMod.LOGGER.info("Track {}: {} bytes ready", t.id(), data.length);
            if (this.generation.get() == my) {
               this.player.play(data, 0L, () -> {
                  Runnable r = this.finished;
                  if (this.generation.get() == my && r != null) {
                     r.run();
                  }
               });
               return null;
            }

            var4 = null;
         } finally {
            if (this.generation.get() == my) {
               this.playLoading = false;
               this.wakePrefetch();
            }
         }

         return (Void)var4;
      });
   }

   private CompletableFuture<byte[]> audio(String id) {
      byte[] hit = this.cache.get(id);
      if (hit != null) {
         return CompletableFuture.completedFuture(hit);
      } else {
         CompletableFuture<byte[]> f = new CompletableFuture<>();
         CompletableFuture<byte[]> existing = this.inflight.putIfAbsent(id, f);
         if (existing != null) {
            return existing;
         } else {
            EXEC.execute(() -> {
               try {
                  byte[] data = this.downloadResumable(id);
                  this.cache.put(id, data);
                  this.failures.remove(id);
                  f.complete(data);
               } catch (Throwable var7) {
                  f.completeExceptionally(var7);
               } finally {
                  this.inflight.remove(id);
                  this.progress.remove(id);
               }
            });
            return f;
         }
      }
   }

   private boolean cancelled(String id) {
      return !id.equals(this.currentId) && !this.desired.contains(id);
   }

   private byte[] downloadResumable(String id) throws Exception {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] prev = this.partial.remove(id);
      if (prev != null) {
         out.write(prev);
      }

      long[] prog = new long[]{out.size(), -1L};
      this.progress.put(id, prog);
      int stalls = 0;

      while (!this.cancelled(id)) {
         int before = out.size();

         try {
            String url = this.resolveStreamUrl(id);
            Builder rb = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(30L)).GET();
            if (before > 0) {
               rb.header("Range", "bytes=" + before + "-");
            }

            HttpResponse<InputStream> r = HTTP.send(rb.build(), BodyHandlers.ofInputStream());
            int sc = r.statusCode();
            if (sc == 200 && before > 0) {
               out.reset();
            } else if (sc != 200 && sc != 206) {
               r.body().close();
               throw new IOException("HTTP " + sc);
            }

            long len = r.headers().firstValueAsLong("Content-Length").orElse(-1L);
            long total = len < 0L ? -1L : (sc == 206 ? out.size() + len : len);
            prog[1] = total;
            InputStream in = r.body();
            long[] last = new long[]{System.nanoTime()};
            ScheduledFuture<?> wd = WATCHDOG.scheduleAtFixedRate(() -> {
               if (System.nanoTime() - last[0] > 20000000000L) {
                  try {
                     in.close();
                  } catch (IOException var3x) {
                  }
               }
            }, 5L, 5L, TimeUnit.SECONDS);

            try {
               InputStream var18 = in;

               try {
                  byte[] buf = new byte[32768];

                  int n;
                  while ((n = in.read(buf)) >= 0) {
                     out.write(buf, 0, n);
                     prog[0] = out.size();
                     last[0] = System.nanoTime();
                     if (out.size() > 125829120) {
                        throw new IOException(T.get("err.track_too_big"));
                     }

                     if (this.cancelled(id)) {
                        this.partial.put(id, out.toByteArray());
                        throw new CancellationException("cancelled");
                     }
                  }
               } catch (Throwable var28) {
                  if (in != null) {
                     try {
                        var18.close();
                     } catch (Throwable var27) {
                        var28.addSuppressed(var27);
                     }
                  }

                  throw var28;
               }

               if (in != null) {
                  in.close();
               }
            } finally {
               wd.cancel(false);
            }

            if (total >= 0L && out.size() < total) {
               throw new IOException(T.get("err.connection_cut", out.size(), total));
            }

            return out.toByteArray();
         } catch (CancellationException var30) {
            throw var30;
         } catch (IOException var31) {
            stalls = out.size() > before ? 0 : stalls + 1;
            if (stalls > 6) {
               this.partial.put(id, out.toByteArray());
               throw var31;
            }

            MusicPlayerMod.LOGGER.warn("Download {} interrupted ({}), retry {}", new Object[]{id, var31.getMessage(), stalls});
            Thread.sleep(Math.min(5000L, 600L * (stalls + 1)));
         }
      }

      this.partial.put(id, out.toByteArray());
      throw new CancellationException("cancelled");
   }

   @Override
   public int loadPercent(String id) {
      long[] p = id == null ? null : this.progress.get(id);
      return p != null && p[1] > 0L ? (int)Math.min(100L, p[0] * 100L / p[1]) : -1;
   }

   @Override
   public boolean isCached(String id) {
      return id != null && this.cache.has(id);
   }

   public long cacheMegabytes() {
      return this.cache.diskMegabytes();
   }

   public void clearCache() {
      this.cache.clear();
   }

   @Override
   public void setPrefetch(String current, List<Track> upcoming, Set<String> keep) {
      Set<String> d = new HashSet<>();
      if (current != null) {
         d.add(current);
      }

      for (Track t : upcoming) {
         if (t.id() != null) {
            d.add(t.id());
         }
      }

      this.desired = d;
      this.currentId = current;
      Set<String> k = new HashSet<>(keep);
      k.addAll(d);
      this.cache.setKeep(k, current);
      this.partial.keySet().retainAll(k);
      this.prefetchList = List.copyOf(upcoming);
      this.wakePrefetch();
      synchronized (this) {
         if (this.prefetchThread == null) {
            this.prefetchThread = new Thread(this::prefetchLoop, "musicplayer-prefetch");
            this.prefetchThread.setDaemon(true);
            this.prefetchThread.start();
         }
      }
   }

   private void wakePrefetch() {
      synchronized (this.prefetchLock) {
         this.prefetchLock.notifyAll();
      }
   }

   private void prefetchLoop() {
      while (true) {
         Track next = null;

         try {
            synchronized (this.prefetchLock) {
               while (true) {
                  next = this.pickPrefetch();
                  if (next != null) {
                     break;
                  }

                  this.prefetchLock.wait(1500L);
               }
            }

            this.audio(next.id()).join();
         } catch (InterruptedException var7) {
            return;
         } catch (Throwable var8) {
            Throwable c = var8;

            while (c.getCause() != null) {
               c = c.getCause();
            }

            if (!(c instanceof CancellationException) && next != null) {
               this.failures.merge(next.id(), 1, Integer::sum);

               try {
                  Thread.sleep(3000L);
               } catch (InterruptedException var5) {
                  return;
               }
            }
         }
      }
   }

   private Track pickPrefetch() {
      if (PlayerConfig.get().prefetch && this.token != null && this.verified && !this.playLoading) {
         for (Track t : this.prefetchList) {
            if (t.id() != null && !this.cache.has(t.id()) && !this.inflight.containsKey(t.id()) && this.failures.getOrDefault(t.id(), 0) < 3) {
               return t;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private String resolveStreamUrl(String trackId) throws Exception {
      JsonArray variants = this.getResultArray("https://api.music.yandex.net/tracks/" + trackId + "/download-info");
      JsonObject best = null;

      for (JsonElement e : variants) {
         JsonObject o = e.getAsJsonObject();
         if ("mp3".equals(str(o, "codec")) && (best == null || o.get("bitrateInKbps").getAsInt() > best.get("bitrateInKbps").getAsInt())) {
            best = o;
         }
      }

      if (best == null) {
         throw new IOException(T.get("err.no_mp3"));
      } else {
         JsonObject x = this.send(this.base(best.get("downloadInfoUrl").getAsString() + "&format=json").GET().build());
         String host = x.get("host").getAsString();
         String path = x.get("path").getAsString();
         String ts = x.get("ts").getAsString();
         String s = x.get("s").getAsString();
         String sign = md5("XGRlBW9FXlekgbPrRHuSiA" + path.substring(1) + s);
         return "https://" + host + "/get-mp3/" + sign + "/" + ts + path;
      }
   }

   @Override
   public void stop() {
      this.generation.incrementAndGet();
      this.playLoading = false;
      this.player.stop();
   }

   @Override
   public void pause() {
      this.player.pause();
   }

   @Override
   public void resume() {
      this.player.resume();
   }

   @Override
   public void seek(long ms) {
      this.player.seek(ms);
   }

   @Override
   public long positionMs() {
      return this.player.positionMs();
   }

   @Override
   public boolean isPlaying() {
      return this.player.isPlaying();
   }

   @Override
   public void setVolume(float v) {
      this.player.setVolume(v);
   }

   @Override
   public void onFinished(Runnable r) {
      this.finished = r;
   }

   @Override
   public void onAudioError(Consumer<String> c) {
      this.player.onError(e -> {
         Throwable t = e;

         while (t.getCause() != null) {
            t = t.getCause();
         }

         String m = t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName();
         c.accept(m);
      });
   }

   private Builder base(String url) {
      return HttpRequest.newBuilder(URI.create(url))
         .timeout(Duration.ofSeconds(15L))
         .header("Authorization", "OAuth " + this.token)
         .header("X-Yandex-Music-Client", "YandexMusicAndroid/24023231")
         .header("User-Agent", "Yandex-Music-API");
   }

   private JsonObject send(HttpRequest req) throws IOException, InterruptedException {
      HttpResponse<String> r = HTTP.send(req, BodyHandlers.ofString(StandardCharsets.UTF_8));
      if (r.statusCode() == 401 || r.statusCode() == 403) {
         throw new IOException(T.get("err.token_invalid", r.statusCode()));
      } else if (r.statusCode() / 100 != 2) {
         String b = r.body() == null ? "" : r.body().replaceAll("\\s+", " ");
         throw new IOException(T.get("err.yandex_http", r.statusCode()) + (b.isEmpty() ? "" : " " + b.substring(0, Math.min(160, b.length()))));
      } else {
         return JsonParser.parseString(r.body()).getAsJsonObject();
      }
   }

   private JsonObject getResult(String url) throws Exception {
      return this.send(this.base(url).GET().build()).getAsJsonObject("result");
   }

   private JsonArray getResultArray(String url) throws Exception {
      return this.send(this.base(url).GET().build()).getAsJsonArray("result");
   }

   private static <T> CompletableFuture<T> async(Callable<T> c) {
      return CompletableFuture.supplyAsync(() -> {
         try {
            return c.call();
         } catch (Exception var2) {
            throw new CompletionException(var2);
         }
      }, EXEC);
   }

   private static String str(JsonObject o, String k) {
      return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
   }

   private static String enc(String s) {
      return URLEncoder.encode(s, StandardCharsets.UTF_8);
   }

   private static String md5(String s) throws Exception {
      byte[] d = MessageDigest.getInstance("MD5").digest(s.getBytes(StandardCharsets.UTF_8));
      StringBuilder sb = new StringBuilder();

      for (byte b : d) {
         sb.append(String.format("%02x", b));
      }

      return sb.toString();
   }

   public record SearchAll(List<Track> tracks, List<MusicEntity> artists, List<MusicEntity> albums, List<MusicEntity> playlists) {
   }

   public record WaveBatch(String sessionId, String batchId, List<Track> tracks) {
   }
}
