package dev.musicplayer.ui;

import dev.musicplayer.compat.Game;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;

public final class MenuIntegration {
   private static final int BTN_W = 86;
   private static final int BTN_H = 20;
   private static final int MARGIN = 6;

   private MenuIntegration() {
   }

   public static boolean isMenu(Screen s) {
      return s instanceof TitleScreen || s instanceof PauseScreen || s instanceof DisconnectedScreen;
   }

   public static Button button(Screen screen) {
      return Button.builder(Component.literal("\u266a Overtone"), b -> Game.open(new PlayerScreen(screen))).bounds(6, 6, 86, 20).build();
   }
}
