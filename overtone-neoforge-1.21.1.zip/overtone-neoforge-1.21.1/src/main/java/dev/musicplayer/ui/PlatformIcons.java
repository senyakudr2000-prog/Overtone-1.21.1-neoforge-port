package dev.musicplayer.ui;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.model.Platform;

final class PlatformIcons {
   private static final int WHITE = -1;
   private static final int INK = -15329766;

   private PlatformIcons() {
   }

   static void draw(Canvas g, Platform p, int x, int y, int size) {
      switch (p) {
         case YANDEX:
            yandex(g, x, y, size);
            break;
         case SOUNDCLOUD:
            soundcloud(g, x, y, size);
            break;
         case LOCAL:
            folder(g, x, y, size);
            break;
         case SPOTIFY:
            spotify(g, x, y, size);
      }
   }

   private static int u(float v, int size) {
      return Math.round(v * size / 24.0F);
   }

   private static void yandex(Canvas g, int x, int y, int s) {
      PlayerTheme.rrect(g, x, y, s, s, u(7.0F, s), -13312);
      PlayerTheme.circle(g, x + u(9.5F, s), y + u(16.5F, s), u(3.6F, s), -15329766);
      g.fill(x + u(11.8F, s), y + u(6.0F, s), x + u(14.0F, s), y + u(16.5F, s), -15329766);
      PlayerTheme.rrect(g, x + u(11.8F, s), y + u(5.5F, s), u(7.0F, s), u(3.0F, s), u(1.2F, s), -15329766);
   }

   private static void soundcloud(Canvas g, int x, int y, int s) {
      PlayerTheme.rrect(g, x, y, s, s, u(7.0F, s), -43776);
      int[] heights = new int[]{5, 8, 6};

      for (int i = 0; i < heights.length; i++) {
         int bx = x + u(3.2F + i * 2.2F, s);
         g.fill(bx, y + u(18.5F - heights[i], s), bx + Math.max(1, u(1.2F, s)), y + u(18.5F, s), -1);
      }

      PlayerTheme.rrect(g, x + u(9.5F, s), y + u(13.5F, s), u(11.0F, s), u(5.0F, s), u(2.5F, s), -1);
      PlayerTheme.circle(g, x + u(13.8F, s), y + u(12.8F, s), u(3.3F, s), -1);
      PlayerTheme.circle(g, x + u(17.4F, s), y + u(14.2F, s), u(2.6F, s), -1);
   }

   private static void folder(Canvas g, int x, int y, int s) {
      PlayerTheme.rrect(g, x, y, s, s, u(7.0F, s), -13315175);
      PlayerTheme.rrect(g, x + u(5.0F, s), y + u(6.5F, s), u(7.0F, s), u(4.0F, s), u(1.4F, s), -1);
      PlayerTheme.rrect(g, x + u(5.0F, s), y + u(8.6F, s), u(14.0F, s), u(9.4F, s), u(2.0F, s), -1);
   }

   private static void spotify(Canvas g, int x, int y, int s) {
      PlayerTheme.rrect(g, x, y, s, s, u(7.0F, s), -14829228);
      PlayerTheme.rrect(g, x + u(5.0F, s), y + u(7.0F, s), u(14.0F, s), Math.max(1, u(2.2F, s)), u(1.1F, s), -15329766);
      PlayerTheme.rrect(g, x + u(6.0F, s), y + u(11.0F, s), u(12.0F, s), Math.max(1, u(1.9F, s)), u(1.0F, s), -15329766);
      PlayerTheme.rrect(g, x + u(7.0F, s), y + u(14.6F, s), u(9.5F, s), Math.max(1, u(1.6F, s)), u(0.8F, s), -15329766);
   }
}
