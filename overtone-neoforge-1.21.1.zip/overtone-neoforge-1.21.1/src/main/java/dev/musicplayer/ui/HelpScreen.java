package dev.musicplayer.ui;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.compat.Game;
import dev.musicplayer.compat.KeyInput;
import dev.musicplayer.compat.ModScreen;
import dev.musicplayer.input.Hotkeys;
import dev.musicplayer.util.T;
import java.util.List;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

public class HelpScreen extends ModScreen {
   private static final String[] PAGE_IDS = new String[]{"quick", "yandex", "other", "keys", "faq"};
   private static final HelpScreen.Step[][] PAGES = new HelpScreen.Step[][]{
      {
            new HelpScreen.Step("quick.1", HelpScreen.Ill.KEY_M),
            new HelpScreen.Step("quick.2", HelpScreen.Ill.CARDS),
            new HelpScreen.Step("quick.3", HelpScreen.Ill.SEARCH),
            new HelpScreen.Step("quick.4", HelpScreen.Ill.KEYS)
      },
      {
            new HelpScreen.Step("yandex.1", HelpScreen.Ill.LOGIN_BTN),
            new HelpScreen.Step("yandex.2", HelpScreen.Ill.NONE),
            new HelpScreen.Step("yandex.3", HelpScreen.Ill.ADDRESS),
            new HelpScreen.Step("yandex.4", HelpScreen.Ill.PASTE)
      },
      {
            new HelpScreen.Step("other.1", HelpScreen.Ill.NONE),
            new HelpScreen.Step("other.2", HelpScreen.Ill.NONE),
            new HelpScreen.Step("other.3", HelpScreen.Ill.DROP),
            new HelpScreen.Step("other.4", HelpScreen.Ill.NONE)
      },
      null,
      {
            new HelpScreen.Step("faq.1", HelpScreen.Ill.NONE),
            new HelpScreen.Step("faq.2", HelpScreen.Ill.NONE),
            new HelpScreen.Step("faq.3", HelpScreen.Ill.NONE),
            new HelpScreen.Step("faq.4", HelpScreen.Ill.NONE)
      }
   };
   private static final int ILL_W = 118;
   private final Screen parent;
   private int page;
   private PlayerTheme th;
   private int px;
   private int py;
   private int pw;
   private int ph;
   private int mouseX;
   private int mouseY;
   private final int[] backBtn = new int[4];
   private final int[] nextBtn = new int[4];
   private Button nextHit;
   private Button backHit;
   private final Button[] dotHits = new Button[PAGES.length];

   public HelpScreen(Screen parent) {
      super(Component.literal("Overtone"));
      this.parent = parent;
   }

   protected void init() {
      this.pw = Math.min(this.width - 16, 460);
      this.ph = Math.min(this.height - 16, 320);
      this.px = (this.width - this.pw) / 2;
      this.py = (this.height - this.ph) / 2;
      this.nextHit = Hit.make(() -> this.go(1));
      this.backHit = Hit.make(() -> this.go(-1));
      this.addWidget(this.nextHit);
      this.addWidget(this.backHit);

      for (int i = 0; i < this.dotHits.length; i++) {
         int n = i;
         this.dotHits[i] = Hit.make(() -> this.page = n);
         this.addWidget(this.dotHits[i]);
      }
   }

   private void syncHits() {
      Hit.place(this.nextHit, this.nextBtn, true);
      Hit.place(this.backHit, this.backBtn, this.page > 0);
      int y = this.py + this.ph - 22 - 4;
      int x0 = this.px + (this.pw - PAGES.length * 14) / 2;

      for (int i = 0; i < this.dotHits.length; i++) {
         Hit.place(this.dotHits[i], x0 + i * 14, y, 14, 14, true);
      }
   }

   private boolean in(int[] r) {
      return this.mouseX >= r[0] && this.mouseX < r[0] + r[2] && this.mouseY >= r[1] && this.mouseY < r[1] + r[3];
   }

   private void go(int delta) {
      int n = this.page + delta;
      if (n >= 0) {
         if (n >= PAGES.length) {
            this.onClose();
         } else {
            this.page = n;
         }
      }
   }

   @Override
   protected boolean onClick(double ex, double ey, int button, boolean doubleClick) {
      this.mouseX = (int)ex;
      this.mouseY = (int)ey;
      if (this.in(this.nextBtn)) {
         this.go(1);
         return true;
      } else if (this.in(this.backBtn)) {
         this.go(-1);
         return true;
      } else {
         int dotsY = this.py + this.ph - 22;
         int x0 = this.px + (this.pw - PAGES.length * 14) / 2;
         int i = (this.mouseX - x0) / 14;
         if (this.mouseY >= dotsY - 4 && this.mouseY < dotsY + 10 && this.mouseX >= x0 && i < PAGES.length) {
            this.page = i;
            return true;
         } else {
            return super.onClick(ex, ey, button, doubleClick);
         }
      }
   }

   @Override
   protected boolean onKey(KeyInput event) {
      int k = event.key();
      if (k == 262 || k == 257) {
         this.go(1);
         return true;
      } else if (k == 263) {
         this.go(-1);
         return true;
      } else {
         return k != 32 && k != 335 ? super.onKey(event) : false;
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double sx, double sy) {
      this.go(sy < 0.0 ? 1 : -1);
      return true;
   }

   @Override
   protected void draw(Canvas g, int mx, int my, float delta) {
      this.mouseX = mx;
      this.mouseY = my;
      this.th = PlayerTheme.current();
      this.drawWidgets(g, mx, my, delta);
      g.fill(0, 0, this.width, this.height, this.th.dim);
      this.th.window(g, this.px, this.py, this.pw, this.ph);
      g.text(this.font, "\u266a Overtone", this.px + 14, this.py + 10, this.th.accent);
      String title = this.font.plainSubstrByWidth(T.get("help.page." + PAGE_IDS[this.page]), this.pw - 40 - this.font.width("\u266a Overtone"));
      g.text(this.font, title, this.px + this.pw - 14 - this.font.width(title), this.py + 10, -1);
      g.fill(this.px + 10, this.py + 26, this.px + this.pw - 10, this.py + 27, PlayerTheme.argb(16777215, 16));
      int top = this.py + 34;
      int bottom = this.py + this.ph - 36;
      if (PAGES[this.page] == null) {
         this.drawKeys(g, top, bottom);
      } else {
         this.drawSteps(g, PAGES[this.page], top, bottom);
      }

      this.drawFooter(g);
      this.syncHits();
   }

   private void drawSteps(Canvas g, HelpScreen.Step[] steps, int top, int bottom) {
      boolean faq = PAGE_IDS[this.page].equals("faq");
      boolean ill = this.pw >= 400;
      int rowH = Math.min(66, (bottom - top) / steps.length);
      int textX = this.px + 46;
      int textW = this.pw - 46 - 16 - (ill ? 126 : 0);
      int maxLines = Math.max(1, (rowH - 9 - 6) / (9 + 1));

      for (int i = 0; i < steps.length; i++) {
         HelpScreen.Step s = steps[i];
         int y = top + i * rowH;
         PlayerTheme.circle(g, this.px + 27, y + 11, 10, this.th.accent);
         String num = faq ? "?" : String.valueOf(i + 1);
         g.text(this.font, num, this.px + 27 - this.font.width(num) / 2, y + 7, -1);
         g.text(this.font, this.font.plainSubstrByWidth(T.get("help." + s.id + ".t"), textW), textX, y + 3, -1);
         List<FormattedCharSequence> lines = this.font.split(Component.literal(T.get("help." + s.id + ".d")), textW);

         for (int k = 0; k < Math.min(maxLines, lines.size()); k++) {
            g.text(this.font, lines.get(k), textX, y + 3 + 9 + 3 + k * (9 + 1), -4934464);
         }

         if (ill && s.ill != HelpScreen.Ill.NONE) {
            this.drawIllustration(g, s.ill, this.px + this.pw - 16 - 118, y, 118, rowH - 6);
         }

         if (i < steps.length - 1) {
            g.fill(textX, y + rowH - 3, this.px + this.pw - 16, y + rowH - 2, PlayerTheme.argb(16777215, 10));
         }
      }
   }

   private void drawKeys(Canvas g, int top, int bottom) {
      Hotkeys.Action[] all = Hotkeys.Action.values();
      int rowH = Math.min(22, (bottom - top - 30) / all.length);
      int colW = this.pw - 56;

      for (int i = 0; i < all.length; i++) {
         int y = top + i * rowH;
         String name = Hotkeys.keyName(all[i]);
         int capW = Math.max(22, this.font.width(name) + 12);
         g.text(this.font, this.font.plainSubstrByWidth(all[i].label(), colW - capW - 16), this.px + 28, y + 6, -4934464);
         this.keycap(g, this.px + 28 + colW - capW, y + 1, capW, 18, name);
      }

      List<FormattedCharSequence> lines = this.font.split(Component.literal(T.get("help.keys.note")), this.pw - 56);
      int ny = top + all.length * rowH + 6;

      for (int k = 0; k < Math.min(2, lines.size()); k++) {
         g.text(this.font, lines.get(k), this.px + 28, ny + k * (9 + 1), -9539972);
      }
   }

   private void keycap(Canvas g, int x, int y, int w, int h, String text) {
      PlayerTheme.rrect(g, x, y + 2, w, h, 4, PlayerTheme.argb(0, 120));
      PlayerTheme.rrect(g, x, y, w, h, 4, this.th.border);
      PlayerTheme.rrect(g, x + 1, y + 1, w - 2, h - 2, 3, this.th.trackBg);
      String t = this.font.plainSubstrByWidth(text, w - 4);
      g.text(this.font, t, x + (w - this.font.width(t)) / 2, y + (h - 9) / 2 + 1, -1);
   }

   private void drawIllustration(Canvas g, HelpScreen.Ill ill, int x, int y, int w, int h) {
      PlayerTheme.rrect(g, x, y, w, h, 5, this.th.panel2);
      int cy = y + h / 2;
      switch (ill) {
         case KEY_M: {
            this.keycap(g, x + 10, cy - 9, 24, 18, Hotkeys.keyName(Hotkeys.Action.OPEN_PLAYER));
            g.text(this.font, T.get("help.or"), x + 40, cy - 4, -9539972);
            String b = "\u266a Overtone";
            int bw = Math.min(w - 66, this.font.width(b) + 10);
            PlayerTheme.rrect(g, x + 56, cy - 8, bw, 16, 3, this.th.trackBg);
            g.text(this.font, this.font.plainSubstrByWidth(b, bw - 6), x + 59, cy - 4, -4934464);
            break;
         }
         case CARDS:
            int[] colors = new int[]{16763904, 16733440, 3462041};
            int cw = (w - 16) / 3;

            for (int i = 0; i < 3; i++) {
               int cx = x + 6 + i * (cw + 2);
               PlayerTheme.rrect(g, cx, cy - 14, cw, 28, 3, this.th.trackBg);
               PlayerTheme.circle(g, cx + cw / 2, cy - 4, 5, 0xFF000000 | colors[i]);
               g.fill(cx + 5, cy + 6, cx + cw - 5, cy + 8, -9539972);
            }
            break;
         case SEARCH:
            PlayerTheme.rrect(g, x + 8, cy - 18, w - 16, 14, 3, this.th.fieldBg);
            g.text(this.font, this.font.plainSubstrByWidth("Daft Punk", w - 26), x + 12, cy - 15, -4934464);
            PlayerTheme.rrect(g, x + 8, cy, w - 16, 12, 3, this.th.rowCurrent);
            PlayerTheme.circle(g, x + w - 18, cy + 6, 5, this.th.accent);
            PlayerTheme.iconPlay(g, x + w - 18, cy + 6, 6, -1);
            g.fill(x + 12, cy + 5, x + w - 38, cy + 7, this.th.accent);
            break;
         case KEYS:
            Hotkeys.Action[] row = new Hotkeys.Action[]{
               Hotkeys.Action.PREV, Hotkeys.Action.NEXT, Hotkeys.Action.PAUSE, Hotkeys.Action.VOL_DOWN, Hotkeys.Action.VOL_UP
            };
            int cx = x + 8;

            for (Hotkeys.Action a : row) {
               String n = Hotkeys.keyName(a);
               int cw = Math.max(16, this.font.width(n) + 8);
               this.keycap(g, cx, cy - 9, cw, 18, n);
               cx += cw + 3;
            }
            break;
         case LOGIN_BTN: {
            PlayerTheme.rrect(g, x + 8, cy - 10, w - 16, 20, 4, this.th.accent);
            String b = "1. " + T.get("help.btn.login");
            g.text(this.font, this.font.plainSubstrByWidth(b, w - 24), x + 14, cy - 4, -1);
            break;
         }
         case ADDRESS:
            PlayerTheme.rrect(g, x + 6, cy - 9, w - 12, 18, 9, this.th.fieldBg);
            PlayerTheme.rrect(g, x + 9, cy - 6, w - 18, 12, 6, PlayerTheme.argb(this.th.accentRgb, 90));
            g.text(this.font, this.font.plainSubstrByWidth("\u2026#access_token=y0_AgA\u2026", w - 28), x + 14, cy - 4, -1);
            this.keycap(g, x + 10, cy + 12, 28, 14, "Ctrl");
            this.keycap(g, x + 42, cy + 12, 14, 14, "C");
            break;
         case PASTE: {
            this.keycap(g, x + 8, cy - 22, 28, 14, "Ctrl");
            this.keycap(g, x + 40, cy - 22, 14, 14, "V");
            PlayerTheme.rrect(g, x + 8, cy - 4, w - 16, 12, 3, this.th.fieldBg);
            g.text(this.font, "\u2026access_token=\u2026", x + 12, cy - 2, -9539972);
            PlayerTheme.rrect(g, x + 8, cy + 11, w - 16, 12, 3, this.th.accent);
            String b = "2. " + T.get("help.btn.confirm");
            g.text(this.font, this.font.plainSubstrByWidth(b, w - 24), x + 12, cy + 13, -1);
            break;
         }
         case DROP:
            PlayerTheme.rrect(g, x + 14, cy - 14, 30, 24, 3, PlayerTheme.argb(3462041, 200));
            PlayerTheme.rrect(g, x + 14, cy - 17, 14, 5, 2, PlayerTheme.argb(3462041, 200));

            for (int i = 0; i < 5; i++) {
               g.fill(x + 58 + i, cy - 6 + i, x + 59 + i, cy - 5 + i + 1, -4934464);
            }

            g.fill(x + 58, cy - 6, x + 59, cy + 6, -4934464);
            PlayerTheme.rrect(g, x + 70, cy - 12, w - 80, 22, 3, this.th.trackBg);
            g.text(this.font, "\u266a", x + 70 + (w - 80 - this.font.width("\u266a")) / 2, cy - 4, this.th.accent);
      }
   }

   private void drawFooter(Canvas g) {
      int y = this.py + this.ph - 28;
      boolean last = this.page == PAGES.length - 1;
      String back = "\u2039 " + T.get("btn.back");
      String next = last ? T.get("btn.done") : T.get("btn.next") + " \u203a";
      int bw = this.font.width(back) + 20;
      int nw = this.font.width(next) + 20;
      this.backBtn[0] = this.px + 12;
      this.backBtn[1] = y;
      this.backBtn[2] = bw;
      this.backBtn[3] = 20;
      this.nextBtn[0] = this.px + this.pw - 12 - nw;
      this.nextBtn[1] = y;
      this.nextBtn[2] = nw;
      this.nextBtn[3] = 20;
      if (this.page > 0) {
         PlayerTheme.rrect(g, this.backBtn[0], y, bw, 20, 5, this.in(this.backBtn) ? this.th.hover : this.th.trackBg);
         g.text(this.font, back, this.backBtn[0] + 10, y + 6, -4934464);
      } else {
         this.backBtn[2] = 0;
      }

      PlayerTheme.rrect(g, this.nextBtn[0], y, nw, 20, 5, this.in(this.nextBtn) ? this.th.accentHover : this.th.accent);
      g.text(this.font, next, this.nextBtn[0] + 10, y + 6, -1);
      int x0 = this.px + (this.pw - PAGES.length * 14) / 2;

      for (int i = 0; i < PAGES.length; i++) {
         PlayerTheme.circle(g, x0 + i * 14 + 5, y + 10, i == this.page ? 4 : 3, i == this.page ? this.th.accent : -9539972);
      }
   }

   public void onClose() {
      Game.open(this.parent);
   }

   public boolean isPauseScreen() {
      return false;
   }

   private static enum Ill {
      NONE,
      KEY_M,
      CARDS,
      SEARCH,
      KEYS,
      LOGIN_BTN,
      ADDRESS,
      PASTE,
      DROP;

      private Ill() {
      }
   }

   private record Step(String id, HelpScreen.Ill ill) {
   }
}
