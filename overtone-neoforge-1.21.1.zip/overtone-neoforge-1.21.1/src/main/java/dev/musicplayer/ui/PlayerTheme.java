package dev.musicplayer.ui;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.compat.Tex;
import dev.musicplayer.config.PlayerConfig;
import dev.musicplayer.controller.PlayerController;
import dev.musicplayer.hud.CoverArt;
import dev.musicplayer.model.Track;
import dev.musicplayer.util.T;
import net.minecraft.client.gui.Font;

final class PlayerTheme {
   final int accent;
   final int accentHover;
   final int accentSoft;
   final int panelTop;
   final int panelBottom;
   final int panel2;
   final int fieldBg;
   final int trackBg;
   final int hover;
   final int rowCurrent;
   final int border;
   final int dim;
   final int radius;
   final int accentRgb;
   private final long key;
   static final int TEXT_MAIN = -1;
   static final int TEXT_MID = -4934464;
   static final int TEXT_DIM = -9539972;
   static final int WARN = -2052248;
   private static PlayerTheme cached;
   private static final String[] HEART = new String[]{".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};
   static final int HEART_W = 7;
   static final int HEART_H = 6;

   private PlayerTheme(PlayerConfig pc, long key) {
      this.key = key;
      this.accentRgb = pc.accentRgb() & 16777215;
      int bg = Math.round(pc.windowOpacity * 2.55F);
      float k = pc.tint * 0.05F;
      this.accent = 0xFF000000 | this.accentRgb;
      this.accentHover = 0xFF000000 | mix(this.accentRgb, 16777215, 0.2F);
      this.accentSoft = argb(this.accentRgb, 70);
      this.panelTop = argb(mix(1842471, this.accentRgb, k), bg);
      this.panelBottom = argb(mix(1052951, this.accentRgb, k * 0.6F), bg);
      this.panel2 = argb(mix(987157, this.accentRgb, k * 0.5F), bg);
      this.fieldBg = 0xFF000000 | mix(723984, this.accentRgb, k * 0.4F);
      this.trackBg = 0xFF000000 | mix(2895161, this.accentRgb, k * 0.8F);
      this.hover = 0xFF000000 | mix(2895161, this.accentRgb, k * 0.8F + 0.14F);
      this.rowCurrent = 0xFF000000 | mix(987157, this.accentRgb, 0.22F);
      this.border = argb(this.accentRgb, 110);
      this.dim = argb(0, Math.round(pc.dim * 2.55F));
      this.radius = pc.cornerRadius;
   }

   static PlayerTheme current() {
      PlayerConfig pc = PlayerConfig.get();
      long key = pc.accentRgb() & 16777215L | (long)pc.tint << 24 | (long)pc.dim << 26 | (long)pc.cornerRadius << 33 | (long)pc.windowOpacity << 37;
      if (cached == null || cached.key != key) {
         cached = new PlayerTheme(pc, key);
      }

      return cached;
   }

   void window(Canvas g, int x, int y, int w, int h) {
      ring(g, x - 1, y - 1, w + 2, h + 2, this.radius + 1, this.border);
      rrectV(g, x, y, w, h, this.radius, this.panelTop, this.panelBottom);
      g.fill(x + this.radius, y, x + w - this.radius, y + 2, this.accent);
   }

   static int argb(int rgb, int alpha) {
      return (Math.max(0, Math.min(255, alpha)) & 0xFF) << 24 | rgb & 16777215;
   }

   static int mix(int from, int to, float t) {
      t = Math.max(0.0F, Math.min(1.0F, t));
      int r = Math.round((from >> 16 & 0xFF) + ((to >> 16 & 0xFF) - (from >> 16 & 0xFF)) * t);
      int g = Math.round((from >> 8 & 0xFF) + ((to >> 8 & 0xFF) - (from >> 8 & 0xFF)) * t);
      int b = Math.round((from & 0xFF) + ((to & 0xFF) - (from & 0xFF)) * t);
      return r << 16 | g << 8 | b;
   }

   private static int inset(int row, int h, int r) {
      if (r <= 0) {
         return 0;
      } else {
         double d = 0.0;
         if (row < r) {
            d = r - 0.5 - row;
         } else if (row >= h - r) {
            d = row - (h - r - 0.5);
         }

         if (d <= 0.0) {
            return 0;
         } else {
            double inner = (double)r * r - d * d;
            return inner <= 0.0 ? r : (int)Math.round(r - Math.sqrt(inner));
         }
      }
   }

   static void rrect(Canvas g, int x, int y, int w, int h, int r, int color) {
      if (w > 0 && h > 0) {
         r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
         int i = 0;

         while (i < r) {
            int in = inset(i, h, r);
            if (in == 0) {
               break;
            }

            int j = i + 1;

            while (j < r && inset(j, h, r) == in) {
               j++;
            }

            g.fill(x + in, y + i, x + w - in, y + j, color);
            g.fill(x + in, y + h - j, x + w - in, y + h - i, color);
            i = j;
         }

         g.fill(x, y + i, x + w, y + h - i, color);
      }
   }

   static void rrectV(Canvas g, int x, int y, int w, int h, int r, int top, int bottom) {
      if (w > 0 && h > 0) {
         r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
         int start = 0;
         int runIn = inset(0, h, r);
         int runCol = gradient(top, bottom, 0, h);

         for (int row = 1; row <= h; row++) {
            int in = row < h ? inset(row, h, r) : -1;
            int col = row < h ? gradient(top, bottom, row, h) : 0;
            if (in != runIn || col != runCol) {
               g.fill(x + runIn, y + start, x + w - runIn, y + row, runCol);
               start = row;
               runIn = in;
               runCol = col;
            }
         }
      }
   }

   private static int gradient(int top, int bottom, int row, int h) {
      float t = h <= 1 ? 0.0F : (float)row / (h - 1);
      int a = Math.round((top >>> 24) + ((bottom >>> 24) - (top >>> 24)) * t);
      return argb(mix(top, bottom, t), a);
   }

   static void ring(Canvas g, int x, int y, int w, int h, int r, int color) {
      if (w > 0 && h > 0) {
         r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
         int top = r > 0 ? inset(0, h, r) : 0;
         g.fill(x + top, y, x + w - top, y + 1, color);
         g.fill(x + top, y + h - 1, x + w - top, y + h, color);

         for (int i = 1; i < r; i++) {
            int in = inset(i, h, r);
            int to = Math.max(in + 1, inset(i - 1, h, r));
            g.fill(x + in, y + i, x + to, y + i + 1, color);
            g.fill(x + w - to, y + i, x + w - in, y + i + 1, color);
            g.fill(x + in, y + h - 1 - i, x + to, y + h - i, color);
            g.fill(x + w - to, y + h - 1 - i, x + w - in, y + h - i, color);
         }

         int from = Math.max(r, 1);
         int until = h - from;
         g.fill(x, y + from, x + 1, y + until, color);
         g.fill(x + w - 1, y + from, x + w, y + until, color);
      }
   }

   static void circle(Canvas g, int cx, int cy, int r, int color) {
      if (r > 0) {
         int start = 0;
         int runHalf = circleHalf(r, 0);

         for (int k = 1; k <= 2 * r; k++) {
            int half = k < 2 * r ? circleHalf(r, k) : -1;
            if (half != runHalf) {
               if (runHalf > 0) {
                  g.fill(cx - runHalf, cy - r + start, cx + runHalf, cy - r + k, color);
               }

               start = k;
               runHalf = half;
            }
         }
      }
   }

   private static int circleHalf(int r, int k) {
      double yy = k - r + 0.5;
      return (int)Math.round(Math.sqrt(r * r - yy * yy));
   }

   static void tri(Canvas g, int x, int cy, int w, int h, boolean right, int color) {
      if (h > 0) {
         int top = cy - h / 2;
         int start = 0;
         int runW = triWidth(w, h, 0);

         for (int r = 1; r <= h; r++) {
            int cw = r < h ? triWidth(w, h, r) : -1;
            if (cw != runW) {
               if (right) {
                  g.fill(x, top + start, x + runW, top + r, color);
               } else {
                  g.fill(x + w - runW, top + start, x + w, top + r, color);
               }

               start = r;
               runW = cw;
            }
         }
      }
   }

   private static int triWidth(int w, int h, int r) {
      float t = 1.0F - Math.abs((r + 0.5F) / h * 2.0F - 1.0F);
      return Math.max(1, Math.round(w * t));
   }

   static void iconPlay(Canvas g, int cx, int cy, int h, int color) {
      int w = Math.round(h * 0.8F);
      tri(g, cx - w / 2 + 1, cy, w, h, true, color);
   }

   static void iconPause(Canvas g, int cx, int cy, int h, int color) {
      int bw = Math.max(2, h / 4);
      int gap = Math.max(2, h / 4);
      int x0 = cx - (bw * 2 + gap) / 2;
      g.fill(x0, cy - h / 2, x0 + bw, cy - h / 2 + h, color);
      g.fill(x0 + bw + gap, cy - h / 2, x0 + bw * 2 + gap, cy - h / 2 + h, color);
   }

   static void iconSkip(Canvas g, int cx, int cy, int h, int color, boolean forward) {
      int w = Math.round(h * 0.7F);
      int bar = 2;
      int x0 = cx - (w + bar + 1) / 2;
      if (forward) {
         tri(g, x0, cy, w, h, true, color);
         g.fill(x0 + w + 1, cy - h / 2, x0 + w + 1 + bar, cy - h / 2 + h, color);
      } else {
         g.fill(x0, cy - h / 2, x0 + bar, cy - h / 2 + h, color);
         tri(g, x0 + bar + 1, cy, w, h, false, color);
      }
   }

   static void iconVolume(Canvas g, int cx, int cy, int waves, int color) {
      g.fill(cx - 5, cy - 2, cx - 2, cy + 2, color);

      for (int i = 0; i < 4; i++) {
         g.fill(cx - 2 + i, cy - 2 - i, cx - 1 + i, cy + 2 + i, color);
      }

      if (waves >= 1) {
         g.fill(cx + 4, cy - 2, cx + 5, cy + 2, color);
      }

      if (waves >= 2) {
         g.fill(cx + 6, cy - 4, cx + 7, cy + 4, color);
      }

      if (waves == 0) {
         for (int i = 0; i < 4; i++) {
            g.fill(cx + 3 + i, cy - 2 + i, cx + 4 + i, cy - 1 + i, color);
            g.fill(cx + 3 + i, cy + 1 - i, cx + 4 + i, cy + 2 - i, color);
         }
      }
   }

   static void iconHeart(Canvas g, int x, int y, int color) {
      for (int row = 0; row < HEART.length; row++) {
         int rows = 1;

         while (row + rows < HEART.length && HEART[row + rows].equals(HEART[row])) {
            rows++;
         }

         String line = HEART[row];

         for (int col = 0; col < line.length(); col++) {
            if (line.charAt(col) == 'X') {
               int end = col;

               while (end < line.length() && line.charAt(end) == 'X') {
                  end++;
               }

               g.fill(x + col, y + row, x + end, y + row + rows, color);
               col = end;
            }
         }

         row += rows - 1;
      }
   }

   static void miniPreview(Canvas g, Font font, int x, int y, int w, int h) {
      PlayerTheme th = current();
      PlayerConfig pc = PlayerConfig.get();
      th.window(g, x, y, w, h);
      int pad = 7;
      int cs = pc.showCover ? h - 14 - 2 : 0;
      int cy = y + h / 2 + 1;
      if (cs > 0) {
         Track t = PlayerController.I.current;
         Tex art = t == null ? null : CoverArt.getBig(t.id());
         int cx0 = x + 7;
         int cy0 = y + 7 + 1;
         if (art != null) {
            g.texture(art, cx0, cy0, cs, cs, 256, 1.0F);
         } else {
            rrect(g, cx0, cy0, cs, cs, 4, th.trackBg);
            g.text(font, "\u266a", cx0 + (cs - font.width("\u266a")) / 2, cy0 + (cs - 9) / 2 + 1, -9539972);
         }
      }

      int textX = x + 7 + (cs > 0 ? cs + 8 : 0);
      int controlsLeft = x + w - 7 - 44 - 24 - 7;
      int textW = controlsLeft - 8 - textX;
      g.text(font, font.plainSubstrByWidth(T.get("demo.title"), textW), textX, y + 9, pc.accentText ? th.accent : -1);
      g.text(font, font.plainSubstrByWidth(T.get("demo.artist"), textW), textX, y + 20, -9539972);
      int by = y + h - 11;
      rrect(g, textX, by, textW, 4, 2, th.trackBg);
      int fill = textW * 4 / 10;
      rrect(g, textX, by, Math.max(4, fill), 4, 2, th.accent);
      circle(g, textX + fill, by + 2, 4, -1);
      int cxPlay = x + w - 7 - 44;
      circle(g, cxPlay - 24, cy, 7, th.trackBg);
      iconSkip(g, cxPlay - 24, cy, 6, -4934464, false);
      circle(g, cxPlay, cy, 10, th.accent);
      iconPlay(g, cxPlay, cy, 9, -1);
      circle(g, cxPlay + 24, cy, 7, th.trackBg);
      iconSkip(g, cxPlay + 24, cy, 6, -4934464, true);
   }
}
