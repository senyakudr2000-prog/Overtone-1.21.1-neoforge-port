package dev.musicplayer.ui;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.compat.Game;
import dev.musicplayer.compat.KeyInput;
import dev.musicplayer.compat.ModScreen;
import dev.musicplayer.config.HudConfig;
import dev.musicplayer.hud.HudBounds;
import dev.musicplayer.hud.LyricsRenderer;
import dev.musicplayer.hud.VisualizerRenderer;
import dev.musicplayer.hud.VolumeRenderer;
import dev.musicplayer.hud.WidgetRenderer;
import dev.musicplayer.util.T;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;

public class HudEditScreen extends ModScreen {
   private static final int SNAP = 3;
   private final Screen parent;
   private HudEditScreen.Target selected = HudEditScreen.Target.WIDGET;
   private HudEditScreen.Target dragging;
   private boolean gestureDecided;
   private double startX;
   private double startY;
   private double accX;
   private double accY;
   private int mouseX;
   private int mouseY;
   private boolean changed;

   public HudEditScreen(Screen parent) {
      super(T.component("edit.title"));
      this.parent = parent;
   }

   private static HudConfig cfg() {
      return HudConfig.get();
   }

   protected void init() {
      HudConfigScreen.OPEN = true;
      int cx = this.width / 2;
      int y = this.height - 28;
      this.addRenderableWidget(Button.builder(T.component("btn.done"), b -> this.onClose()).bounds(cx - 125, y, 120, 20).build());
      this.addRenderableWidget(Button.builder(T.component("edit.reset"), b -> this.resetPositions()).bounds(cx + 5, y, 120, 20).build());
   }

   private static HudBounds.Box box(HudEditScreen.Target t) {
      return switch (t) {
         case WIDGET -> HudBounds.widget;
         case LYRICS -> HudBounds.lyrics;
         case VOLUME -> HudBounds.volume;
         case VISUALIZER -> HudBounds.visualizer;
      };
   }

   private HudEditScreen.Target pick(double x, double y) {
      HudEditScreen.Target[] order = new HudEditScreen.Target[]{
         HudEditScreen.Target.VISUALIZER, HudEditScreen.Target.VOLUME, HudEditScreen.Target.LYRICS, HudEditScreen.Target.WIDGET
      };

      for (HudEditScreen.Target t : order) {
         HudBounds.Box b = box(t);
         if (b != null && x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) {
            return t;
         }
      }

      return null;
   }

   private void moveTo(HudEditScreen.Target t, int x, int y, boolean snap) {
      HudBounds.Box b = box(t);
      if (b != null) {
         if (snap && Math.abs(x + b.w / 2 - this.width / 2) <= 3) {
            x = this.width / 2 - b.w / 2;
         }

         HudBounds.Placement p = HudBounds.place(b, this.width, this.height, x, y);
         HudConfig c = cfg();
         switch (t) {
            case WIDGET:
               c.anchor = p.anchor;
               c.offsetX = p.offsetX;
               c.offsetY = p.offsetY;
               break;
            case LYRICS:
               c.lyricsAnchor = p.anchor;
               c.lyricsOffsetX = p.offsetX;
               c.lyricsOffsetY = p.offsetY;
               break;
            case VOLUME:
               c.volumeAnchor = p.anchor;
               c.volumeOffsetX = p.offsetX;
               c.volumeOffsetY = p.offsetY;
               break;
            case VISUALIZER:
               c.vizAnchor = p.anchor;
               c.vizOffsetX = p.offsetX;
               c.vizOffsetY = p.offsetY;
         }

         this.changed = true;
      }
   }

   private void nudge(HudEditScreen.Target t, int dx, int dy) {
      HudConfig c = cfg();
      switch (t) {
         case WIDGET:
            c.offsetX = c.offsetX + (c.anchor.h > 0 ? -dx : dx);
            c.offsetY = c.offsetY + (c.anchor.v > 0 ? -dy : dy);
            break;
         case LYRICS:
            c.lyricsOffsetX = c.lyricsOffsetX + (c.lyricsAnchor.h > 0 ? -dx : dx);
            c.lyricsOffsetY = c.lyricsOffsetY + (c.lyricsAnchor.v > 0 ? -dy : dy);
            break;
         case VOLUME:
            c.volumeOffsetX = c.volumeOffsetX + (c.volumeAnchor.h > 0 ? -dx : dx);
            c.volumeOffsetY = c.volumeOffsetY + (c.volumeAnchor.v > 0 ? -dy : dy);
            break;
         case VISUALIZER:
            c.vizOffsetX = c.vizOffsetX + (c.vizAnchor.h > 0 ? -dx : dx);
            c.vizOffsetY = c.vizOffsetY + (c.vizAnchor.v > 0 ? -dy : dy);
      }

      this.changed = true;
   }

   private void resetPositions() {
      HudConfig d = new HudConfig();
      HudConfig c = cfg();
      c.anchor = d.anchor;
      c.offsetX = d.offsetX;
      c.offsetY = d.offsetY;
      c.lyricsAnchor = d.lyricsAnchor;
      c.lyricsOffsetX = d.lyricsOffsetX;
      c.lyricsOffsetY = d.lyricsOffsetY;
      c.volumeAnchor = d.volumeAnchor;
      c.volumeOffsetX = d.volumeOffsetX;
      c.volumeOffsetY = d.volumeOffsetY;
      c.vizAnchor = d.vizAnchor;
      c.vizOffsetX = d.vizOffsetX;
      c.vizOffsetY = d.vizOffsetY;
      this.changed = true;
   }

   @Override
   protected boolean onDrag(double ex, double ey, int button, double dragX, double dragY) {
      this.mouseX = (int)ex;
      this.mouseY = (int)ey;
      if (!this.gestureDecided) {
         this.gestureDecided = true;
         HudEditScreen.Target t = this.pick(ex - dragX, ey - dragY);
         HudBounds.Box b = t == null ? null : box(t);
         if (b != null) {
            this.dragging = t;
            this.selected = t;
            this.startX = b.x;
            this.startY = b.y;
            this.accX = 0.0;
            this.accY = 0.0;
         }
      }

      if (this.dragging != null) {
         this.accX += dragX;
         this.accY += dragY;
         this.moveTo(this.dragging, (int)Math.round(this.startX + this.accX), (int)Math.round(this.startY + this.accY), true);
         return true;
      } else {
         return super.onDrag(ex, ey, button, dragX, dragY);
      }
   }

   @Override
   protected boolean onRelease(double ex, double ey, int button) {
      boolean was = this.dragging != null;
      this.dragging = null;
      this.gestureDecided = false;
      if (was) {
         this.saveIfChanged();
         return true;
      } else {
         return super.onRelease(ex, ey, button);
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double sx, double sy) {
      HudEditScreen.Target t = this.pick(mx, my);
      if (t == null) {
         return super.mouseScrolled(mx, my, sx, sy);
      } else {
         this.selected = t;
         float step = sy > 0.0 ? 0.05F : -0.05F;
         HudConfig c = cfg();
         switch (t) {
            case WIDGET:
               c.scale = stepScale(c.scale, step);
               break;
            case LYRICS:
               c.lyricsScale = stepScale(c.lyricsScale, step);
               break;
            case VOLUME:
               c.volumeScale = stepScale(c.volumeScale, step);
               break;
            case VISUALIZER:
               c.vizScale = stepScale(c.vizScale, step);
         }

         this.changed = true;
         return true;
      }
   }

   private static float stepScale(float cur, float step) {
      float v = Math.round((cur + step) * 20.0F) / 20.0F;
      return Math.max(0.5F, Math.min(2.0F, v));
   }

   @Override
   protected boolean onKey(KeyInput event) {
      int k = event.key();
      int dx = 0;
      int dy = 0;
      if (k == 263) {
         dx = -1;
      } else if (k == 262) {
         dx = 1;
      } else if (k == 265) {
         dy = -1;
      } else if (k == 264) {
         dy = 1;
      }

      if (dx != 0 || dy != 0) {
         this.nudge(this.selected, dx, dy);
         return true;
      } else if (k != 257 && k != 335) {
         return super.onKey(event);
      } else {
         this.onClose();
         return true;
      }
   }

   @Override
   protected void draw(Canvas g, int mx, int my, float delta) {
      this.mouseX = mx;
      this.mouseY = my;
      this.drawWidgets(g, mx, my, delta);
      Canvas c = g;
      WidgetRenderer.render(g, true);
      LyricsRenderer.render(g, true);
      VolumeRenderer.render(g, true);
      VisualizerRenderer.render(g, true);
      HudEditScreen.Target hover = this.dragging != null ? this.dragging : this.pick(mx, my);
      int accent = cfg().accentRgb();

      for (HudEditScreen.Target t : HudEditScreen.Target.values()) {
         HudBounds.Box b = box(t);
         if (b != null) {
            boolean hot = t == hover;
            int col = hot ? 0xFF000000 | accent : (t == this.selected ? -1593835521 : 1358954495);
            frame(c, b, col);
            int ly = b.y >= 12 ? b.y - 10 : b.y + b.h + 3;
            c.text(t.label(), b.x, ly, hot ? 0xFF000000 | accent : -3618608, true);
         }
      }

      int y = 8;
      y = this.lines(c, T.get("edit.help"), y);
      y = this.lines(c, T.get("edit.done"), y);
      if (cfg().layout == HudConfig.Layout.HOTBAR && HudBounds.widget == null) {
         y = this.lines(c, T.get("edit.hotbar"), y);
      }

      if (cfg().lyricsMode == HudConfig.LyricsMode.OFF) {
         this.lines(c, T.get("edit.lyrics_off"), y);
      }
   }

   private int lines(Canvas c, String text, int y) {
      for (String l : c.wrap(text, this.width - 40, 2)) {
         c.text(l, (this.width - c.textWidth(l)) / 2, y, -1644822, true);
         y += 11;
      }

      return y + 1;
   }

   private static void frame(Canvas c, HudBounds.Box b, int argb) {
      c.rect(b.x - 1, b.y - 1, b.w + 2, 1, argb);
      c.rect(b.x - 1, b.y + b.h, b.w + 2, 1, argb);
      c.rect(b.x - 1, b.y, 1, b.h, argb);
      c.rect(b.x + b.w, b.y, 1, b.h, argb);
   }

   private void saveIfChanged() {
      if (this.changed) {
         this.changed = false;
         cfg().save();
      }
   }

   public void removed() {
      this.saveIfChanged();
      super.removed();
   }

   public void onClose() {
      this.saveIfChanged();
      Game.open(this.parent);
   }

   public boolean isPauseScreen() {
      return false;
   }

   private static enum Target {
      WIDGET,
      LYRICS,
      VOLUME,
      VISUALIZER;

      private Target() {
      }

      String label() {
         return T.get("edit.target." + this.name().toLowerCase());
      }
   }
}
