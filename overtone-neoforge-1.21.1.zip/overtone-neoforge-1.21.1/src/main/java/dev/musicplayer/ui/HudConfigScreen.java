package dev.musicplayer.ui;

import dev.musicplayer.audio.Mp3Player;
import dev.musicplayer.compat.Canvas;
import dev.musicplayer.compat.Game;
import dev.musicplayer.compat.KeyInput;
import dev.musicplayer.compat.ModScreen;
import dev.musicplayer.config.HudConfig;
import dev.musicplayer.config.PlayerConfig;
import dev.musicplayer.controller.PlayerController;
import dev.musicplayer.hud.LyricsRenderer;
import dev.musicplayer.hud.VisualizerRenderer;
import dev.musicplayer.hud.VolumeRenderer;
import dev.musicplayer.hud.WidgetRenderer;
import dev.musicplayer.hud.WorldLyricsRenderer;
import dev.musicplayer.input.Hotkeys;
import dev.musicplayer.util.T;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

public class HudConfigScreen extends ModScreen {
   public static volatile boolean OPEN;
   private static final int SIDE_W = 92;
   private static final int PAD = 8;
   private static final int BAR_W = 5;
   private static final int HEADER_H = 28;
   private static final int FOOTER_H = 30;
   private static final HudConfig D = HudConfig.DEFAULTS;
   private static final PlayerConfig PD = PlayerConfig.DEFAULTS;
   private final Screen parent;
   private HudConfigScreen.Tab tab = HudConfigScreen.Tab.WIDGET;
   private final List<HudConfigScreen.Row> rows = new ArrayList<>();
   private final List<HudConfigScreen.Row> shown = new ArrayList<>();
   private int first;
   private int maxFirst;
   private HudConfigScreen.Row dragRow;
   private boolean dragBar;
   private Hotkeys.Action listening;
   private long lastDemo;
   private int px;
   private int py;
   private int pw;
   private int ph;
   private int cx;
   private int cw;
   private int bodyTop;
   private int bodyBottom;
   private int mouseX;
   private int mouseY;
   private PlayerTheme th;
   private final int[] guideBtn = new int[4];
   private final int[] doneBtn = new int[4];
   private Button doneHit;
   private Button guideHit;
   private final Button[] tabHits = new Button[HudConfigScreen.Tab.values().length];
   private final Button[] rowHits = new Button[24];
   private Canvas graphics;

   public HudConfigScreen(Screen parent) {
      super(Component.literal("Overtone"));
      this.parent = parent;
   }

   public static HudConfigScreen playerTab(Screen parent) {
      HudConfigScreen s = new HudConfigScreen(parent);
      s.tab = HudConfigScreen.Tab.PLAYER;
      return s;
   }

   private static HudConfig cfg() {
      return HudConfig.get();
   }

   private static PlayerConfig pcfg() {
      return PlayerConfig.get();
   }

   protected void init() {
      OPEN = true;
      this.rebuild();
      this.buildHits();
   }

   private Button hit(Button b) {
      this.addWidget(b);
      return b;
   }

   private boolean calm() {
      if (this.listening != null) {
         this.listening = null;
         return false;
      } else {
         return true;
      }
   }

   private void buildHits() {
      this.doneHit = this.hit(Hit.make(() -> {
         if (this.calm()) {
            this.onClose();
         }
      }));
      this.guideHit = this.hit(Hit.make(() -> {
         if (this.calm()) {
            Game.open(new HelpScreen(this));
         }
      }));
      HudConfigScreen.Tab[] tabs = HudConfigScreen.Tab.values();

      for (int i = 0; i < tabs.length; i++) {
         HudConfigScreen.Tab t = tabs[i];
         this.tabHits[i] = this.hit(Hit.make(() -> {
            if (this.calm() && this.tab != t) {
               this.tab = t;
               this.rebuild();
            }
         }));
      }

      for (int i = 0; i < this.rowHits.length; i++) {
         int k = i;
         this.rowHits[i] = this.hit(Hit.make(() -> {
            if (this.calm() && k < this.shown.size()) {
               HudConfigScreen.Row r = this.shown.get(k);
               if (r.press(0)) {
                  this.dragRow = r;
               }
            }
         }));
      }
   }

   private void syncHits() {
      Hit.place(this.doneHit, this.doneBtn, true);
      Hit.place(this.guideHit, this.guideBtn, true);

      for (int i = 0; i < this.tabHits.length; i++) {
         Hit.place(this.tabHits[i], this.px + 6, this.py + 28 + 4 + i * 22, 86, 20, true);
      }

      for (int i = 0; i < this.rowHits.length; i++) {
         if (i < this.shown.size()) {
            HudConfigScreen.Row r = this.shown.get(i);
            Hit.place(this.rowHits[i], r.x, r.y, r.w, r.h, true);
         } else {
            Hit.place(this.rowHits[i], 0, 0, 0, 0, false);
         }
      }
   }

   private void rebuild() {
      this.pw = Math.min(this.width - 16, 430);
      this.ph = Math.min(this.height - 16, 330);
      this.py = (this.height - this.ph) / 2;
      this.px = (this.width - this.pw) / 2;
      this.cx = this.px + 92 + 8;
      this.cw = this.pw - 92 - 16 - 5 - 3;
      this.bodyTop = this.py + 28;
      this.bodyBottom = this.py + this.ph - 30;
      this.rows.clear();
      this.shown.clear();
      this.first = 0;
      this.dragRow = null;
      this.listening = null;
      this.build();
      this.updateScrollLimit();
   }

   private void updateScrollLimit() {
      int room = this.bodyBottom - this.bodyTop - 4;
      int sum = 0;

      int f;
      for (f = this.rows.size(); f > 0 && sum + this.rows.get(f - 1).h <= room; f--) {
         sum += this.rows.get(f - 1).h;
      }

      this.maxFirst = f;
      this.first = Math.max(0, Math.min(this.first, this.maxFirst));
   }

   private void build() {
      HudConfig c = cfg();
      PlayerConfig p = pcfg();
      switch (this.tab) {
         case WIDGET:
            this.rows.add(this.toggle("widget_enabled", () -> c.enabled, v -> c.enabled = v));
            this.rows.add(this.choice("layout", () -> c.layout, v -> c.layout = v));
            this.rows.add(this.choice("show_mode", () -> c.showMode, v -> c.showMode = v));
            this.rows.add(this.toggle("show_on_start", () -> c.showOnSongStart, v -> c.showOnSongStart = v));
            this.rows.add(this.toggle("show_on_end", () -> c.showOnSongEnd, v -> c.showOnSongEnd = v));
            this.rows.add(this.header("look"));
            this.rows.add(this.swatches("accent", () -> c.accent, v -> {
               c.accent = v;
               c.customAccent = -1;
            }, () -> c.customAccent, v -> c.customAccent = v));
            this.rows.add(this.slider("scale", 0.5, 2.0, 0.05, D.scale, () -> c.scale, v -> c.scale = (float)v, HudConfigScreen::pct));
            this.rows
               .add(
                  this.slider(
                     "background", 0.0, 100.0, 5.0, D.backgroundOpacity, () -> c.backgroundOpacity, v -> c.backgroundOpacity = (int)v, HudConfigScreen::percent
                  )
               );
            this.rows.add(this.toggle("cover", () -> c.showCover, v -> c.showCover = v));
            this.rows.add(this.toggle("time", () -> c.showTimestamps, v -> c.showTimestamps = v));
            this.rows.add(this.toggle("equalizer", () -> c.showWaveform, v -> c.showWaveform = v));
            this.rows.add(this.header("position"));
            this.rows.add(this.anchors("position", () -> c.anchor, v -> c.anchor = v));
            this.rows.add(this.slider("offset_x", -100.0, 400.0, 1.0, D.offsetX, () -> c.offsetX, v -> c.offsetX = (int)v, HudConfigScreen::px));
            this.rows.add(this.slider("offset_y", -100.0, 400.0, 1.0, D.offsetY, () -> c.offsetY, v -> c.offsetY = (int)v, HudConfigScreen::px));
            this.rows.add(this.dragButton());
            break;
         case LYRICS:
            this.rows.add(this.choice("lyrics_mode", () -> c.lyricsMode, v -> c.lyricsMode = v));
            this.rows.add(this.toggle("card_lyrics", () -> c.cardLyrics, v -> c.cardLyrics = v));
            this.rows.add(this.toggle("word_karaoke", () -> c.lyricsWordKaraoke, v -> c.lyricsWordKaraoke = v));
            this.rows
               .add(this.slider("shift", -3000.0, 3000.0, 50.0, D.lyricsShiftMs, () -> c.lyricsShiftMs, v -> c.lyricsShiftMs = (int)v, HudConfigScreen::ms));
            this.rows.add(this.header("look"));
            this.rows.add(this.slider("scale", 0.5, 2.0, 0.05, D.lyricsScale, () -> c.lyricsScale, v -> c.lyricsScale = (float)v, HudConfigScreen::pct));
            this.rows.add(this.slider("width", 200.0, 600.0, 10.0, D.lyricsWidth, () -> c.lyricsWidth, v -> c.lyricsWidth = (int)v, HudConfigScreen::px));
            this.rows.add(this.slider("lines", 3.0, 9.0, 1.0, D.lyricsLines, () -> c.lyricsLines, v -> c.lyricsLines = (int)v, HudConfigScreen::num));
            this.rows
               .add(
                  this.slider(
                     "background", 0.0, 100.0, 5.0, D.lyricsBackground, () -> c.lyricsBackground, v -> c.lyricsBackground = (int)v, HudConfigScreen::percent
                  )
               );
            this.rows.add(this.toggle("lyrics_accent", () -> c.lyricsAccent, v -> c.lyricsAccent = v));
            this.rows.add(this.toggle("text_shadow", () -> c.lyricsShadow, v -> c.lyricsShadow = v));
            this.rows.add(this.header("position"));
            this.rows.add(this.anchors("position", () -> c.lyricsAnchor, v -> c.lyricsAnchor = v));
            this.rows
               .add(this.slider("offset_x", -100.0, 400.0, 1.0, D.lyricsOffsetX, () -> c.lyricsOffsetX, v -> c.lyricsOffsetX = (int)v, HudConfigScreen::px));
            this.rows
               .add(this.slider("offset_y", -100.0, 400.0, 1.0, D.lyricsOffsetY, () -> c.lyricsOffsetY, v -> c.lyricsOffsetY = (int)v, HudConfigScreen::px));
            this.rows.add(this.dragButton());
            break;
         case WORLD:
            this.rows.add(this.toggle("world_enabled", () -> c.worldLyrics, v -> c.worldLyrics = v));
            this.rows.add(this.choice("world_mode", () -> c.worldMode, v -> c.worldMode = v));
            this.rows.add(this.choice("follow", () -> c.worldFollowStyle, v -> c.worldFollowStyle = v));
            this.rows.add(this.choice("word_layout", () -> c.worldLayout, v -> c.worldLayout = v));
            this.rows.add(this.header("look"));
            this.rows.add(this.slider("size", 0.5, 2.5, 0.1, D.worldScale, () -> c.worldScale, v -> c.worldScale = (float)v, HudConfigScreen::pct));
            this.rows
               .add(this.slider("distance", 3.0, 30.0, 0.5, D.worldDistance, () -> c.worldDistance, v -> c.worldDistance = (float)v, HudConfigScreen::blocks));
            this.rows
               .add(this.slider("height", -1.5, 3.0, 0.1, D.worldHeight, () -> c.worldHeight, v -> c.worldHeight = (float)v, HudConfigScreen::blocksSigned));
            this.rows
               .add(this.slider("world_spread", 15.0, 90.0, 1.0, D.worldSpread, () -> c.worldSpread, v -> c.worldSpread = (float)v, HudConfigScreen::degrees));
            this.rows.add(this.toggle("see_through", () -> c.worldSeeThrough, v -> c.worldSeeThrough = v));
            this.rows.add(this.toggle("text_shadow", () -> c.worldShadow, v -> c.worldShadow = v));
            this.rows.add(this.button("demo", WorldLyricsRenderer::demo, false));
            this.rows.add(this.header("animation"));
            this.rows.add(this.choice("world_anim", () -> c.worldAnim, v -> c.worldAnim = v));
            this.rows.add(this.choice("world_unit", () -> c.worldUnit, v -> c.worldUnit = v));
            this.rows.add(this.choice("world_exit", () -> c.worldExit, v -> c.worldExit = v));
            this.rows
               .add(this.slider("world_linger", 1.0, 20.0, 1.0, D.worldLinger, () -> c.worldLinger, v -> c.worldLinger = (int)v, HudConfigScreen::seconds));
            this.rows
               .add(this.slider("world_letter_ms", 5.0, 150.0, 5.0, D.worldLetterMs, () -> c.worldLetterMs, v -> c.worldLetterMs = (int)v, HudConfigScreen::ms));
            this.rows
               .add(
                  this.slider(
                     "world_speed", 25.0, 300.0, 5.0, D.worldAnimSpeed, () -> c.worldAnimSpeed, v -> c.worldAnimSpeed = (int)v, HudConfigScreen::percent
                  )
               );
            this.rows
               .add(this.slider("world_bounce", 0.0, 300.0, 10.0, D.worldBounce, () -> c.worldBounce, v -> c.worldBounce = (int)v, HudConfigScreen::percent));
            this.rows.add(this.header("colors"));
            this.rows.add(this.choice("world_color", () -> c.worldColor, v -> c.worldColor = v));
            this.rows.add(this.plainSwatches("world_accent", () -> c.worldAccent, v -> c.worldAccent = v));
            this.rows.add(this.plainSwatches("world_accent2", () -> c.worldAccent2, v -> c.worldAccent2 = v));
            this.rows.add(this.choice("world_glow", () -> c.worldGlow, v -> c.worldGlow = v));
            this.rows
               .add(
                  this.slider(
                     "world_glow_strength",
                     0.0,
                     100.0,
                     5.0,
                     D.worldGlowStrength,
                     () -> c.worldGlowStrength,
                     v -> c.worldGlowStrength = (int)v,
                     HudConfigScreen::percent
                  )
               );
            this.rows
               .add(
                  this.slider(
                     "world_glow_size", 50.0, 250.0, 10.0, D.worldGlowSize, () -> c.worldGlowSize, v -> c.worldGlowSize = (int)v, HudConfigScreen::percent
                  )
               );
            this.rows.add(this.button("demo", WorldLyricsRenderer::demo, false));
            this.rows.add(this.note(T.get("note.world")));
            break;
         case VOLUME:
            this.rows.add(this.toggle("volume_enabled", () -> c.volumeEnabled, v -> c.volumeEnabled = v));
            this.rows.add(this.choice("volume_style", () -> c.volumeStyle, v -> c.volumeStyle = v));
            this.rows
               .add(this.slider("seconds", 1.0, 10.0, 1.0, D.volumeSeconds, () -> c.volumeSeconds, v -> c.volumeSeconds = (int)v, HudConfigScreen::seconds));
            this.rows.add(this.toggle("percent", () -> c.volumePercent, v -> c.volumePercent = v));
            this.rows.add(this.header("look"));
            this.rows.add(this.slider("scale", 0.5, 2.0, 0.05, D.volumeScale, () -> c.volumeScale, v -> c.volumeScale = (float)v, HudConfigScreen::pct));
            this.rows
               .add(
                  this.slider(
                     "background", 0.0, 100.0, 5.0, D.volumeBackground, () -> c.volumeBackground, v -> c.volumeBackground = (int)v, HudConfigScreen::percent
                  )
               );
            this.rows.add(this.header("position"));
            this.rows.add(this.anchors("position", () -> c.volumeAnchor, v -> c.volumeAnchor = v));
            this.rows
               .add(this.slider("offset_x", -100.0, 400.0, 1.0, D.volumeOffsetX, () -> c.volumeOffsetX, v -> c.volumeOffsetX = (int)v, HudConfigScreen::px));
            this.rows
               .add(this.slider("offset_y", -100.0, 400.0, 1.0, D.volumeOffsetY, () -> c.volumeOffsetY, v -> c.volumeOffsetY = (int)v, HudConfigScreen::px));
            this.rows.add(this.dragButton());
            this.rows.add(this.note(T.get("note.volume")));
            break;
         case VISUALIZER:
            this.rows.add(this.toggle("viz_enabled", () -> c.vizEnabled, v -> c.vizEnabled = v));
            this.rows.add(this.choice("viz_source", () -> c.vizSource, v -> c.vizSource = v));
            this.rows.add(this.choice("viz_style", () -> c.vizStyle, v -> c.vizStyle = v));
            this.rows.add(this.toggle("viz_stereo", () -> c.vizStereo, v -> c.vizStereo = v));
            this.rows.add(this.choice("viz_direction", () -> c.vizDirection, v -> c.vizDirection = v));
            this.rows.add(this.choice("viz_color", () -> c.vizColor, v -> c.vizColor = v));
            this.rows.add(this.swatches("accent", () -> c.accent, v -> {
               c.accent = v;
               c.customAccent = -1;
            }, () -> c.customAccent, v -> c.customAccent = v));
            this.rows.add(this.toggle("viz_peaks", () -> c.vizPeaks, v -> c.vizPeaks = v));
            this.rows.add(this.toggle("viz_hide_idle", () -> c.vizHideIdle, v -> c.vizHideIdle = v));
            this.rows.add(this.header("viz_sound"));
            this.rows.add(this.toggle("viz_autosens", () -> c.vizAutoSens, v -> c.vizAutoSens = v));
            this.rows
               .add(
                  this.slider(
                     "viz_sensitivity", 10.0, 400.0, 10.0, D.vizSensitivity, () -> c.vizSensitivity, v -> c.vizSensitivity = (int)v, HudConfigScreen::percent
                  )
               );
            this.rows
               .add(this.slider("viz_smoothing", 0.0, 95.0, 5.0, D.vizSmoothing, () -> c.vizSmoothing, v -> c.vizSmoothing = (int)v, HudConfigScreen::percent));
            this.rows.add(this.header("look"));
            this.rows.add(this.slider("viz_bars", 4.0, 96.0, 1.0, D.vizBars, () -> c.vizBars, v -> c.vizBars = (int)v, HudConfigScreen::num));
            this.rows.add(this.slider("viz_bar_width", 1.0, 10.0, 1.0, D.vizBarWidth, () -> c.vizBarWidth, v -> c.vizBarWidth = (int)v, HudConfigScreen::px));
            this.rows.add(this.slider("viz_gap", 0.0, 6.0, 1.0, D.vizGap, () -> c.vizGap, v -> c.vizGap = (int)v, HudConfigScreen::px));
            this.rows.add(this.slider("viz_height", 8.0, 160.0, 2.0, D.vizHeight, () -> c.vizHeight, v -> c.vizHeight = (int)v, HudConfigScreen::px));
            this.rows.add(this.slider("scale", 0.5, 2.0, 0.05, D.vizScale, () -> c.vizScale, v -> c.vizScale = (float)v, HudConfigScreen::pct));
            this.rows
               .add(this.slider("background", 0.0, 100.0, 5.0, D.vizBackground, () -> c.vizBackground, v -> c.vizBackground = (int)v, HudConfigScreen::percent));
            this.rows.add(this.header("position"));
            this.rows.add(this.anchors("position", () -> c.vizAnchor, v -> c.vizAnchor = v));
            this.rows.add(this.slider("offset_x", -100.0, 400.0, 1.0, D.vizOffsetX, () -> c.vizOffsetX, v -> c.vizOffsetX = (int)v, HudConfigScreen::px));
            this.rows.add(this.slider("offset_y", -100.0, 400.0, 1.0, D.vizOffsetY, () -> c.vizOffsetY, v -> c.vizOffsetY = (int)v, HudConfigScreen::px));
            this.rows.add(this.dragButton());
            this.rows.add(this.note(T.get("note.visualizer")));
            break;
         case PLAYER:
            this.rows.add(new HudConfigScreen.PreviewRow());
            this.rows.add(this.toggle("sync_accent", () -> p.syncAccent, v -> p.syncAccent = v));
            this.rows.add(this.swatches("accent", () -> p.syncAccent ? c.accent : p.accent, v -> {
               p.syncAccent = false;
               p.accent = v;
               p.customAccent = -1;
            }, () -> p.syncAccent ? c.customAccent : p.customAccent, v -> {
               p.syncAccent = false;
               p.customAccent = v;
            }));
            this.rows
               .add(this.slider("window_size", 70.0, 150.0, 5.0, PD.windowScale, () -> p.windowScale, v -> p.windowScale = (int)v, HudConfigScreen::percent));
            this.rows.add(this.slider("corner", 0.0, 8.0, 1.0, PD.cornerRadius, () -> p.cornerRadius, v -> p.cornerRadius = (int)v, HudConfigScreen::num));
            this.rows.add(this.slider("tint", 0.0, 3.0, 1.0, PD.tint, () -> p.tint, v -> p.tint = (int)v, v -> Math.round(v * 5.0) + "%"));
            this.rows
               .add(this.slider("opacity", 20.0, 100.0, 5.0, PD.windowOpacity, () -> p.windowOpacity, v -> p.windowOpacity = (int)v, HudConfigScreen::percent));
            this.rows.add(this.slider("dim", 0.0, 100.0, 5.0, PD.dim, () -> p.dim, v -> p.dim = (int)v, HudConfigScreen::percent));
            this.rows.add(this.toggle("cover", () -> p.showCover, v -> p.showCover = v));
            this.rows.add(this.slider("cover_size", 40.0, 140.0, 4.0, PD.coverPx, () -> p.coverPx, v -> p.coverPx = (int)v, HudConfigScreen::px));
            this.rows.add(this.toggle("lyrics_in_player", () -> p.showLyrics, v -> p.showLyrics = v));
            this.rows.add(this.toggle("accent_title", () -> p.accentText, v -> p.accentText = v));
            this.rows.add(this.button("reset_player", () -> {
               PlayerConfig.resetToDefaults();
               this.rebuild();
            }, true));
            break;
         case KEYS:
            for (Hotkeys.Action a : Hotkeys.Action.values()) {
               this.rows.add(new HudConfigScreen.KeyRow(a));
            }

            this.rows.add(this.button("reset_keys", () -> {
               Hotkeys.resetAll();
               this.listening = null;
            }, true));
            this.rows.add(this.note(T.get("note.keys")));
            break;
         case GENERAL:
            this.rows.add(this.toggle("master", () -> c.master, v -> c.master = v));
            this.rows.add(this.toggle("hide_with_gui", () -> c.hideWithGui, v -> c.hideWithGui = v));
            this.rows.add(this.toggle("hide_on_tab", () -> c.hideOnTab, v -> c.hideOnTab = v));
            this.rows.add(this.header("sound"));
            this.rows.add(this.toggle("game_volume", () -> p.useGameVolume, v -> p.useGameVolume = v));
            this.rows.add(new HudConfigScreen.ButtonRow("audio_device", () -> {
               String d = p.audioDevice == null ? "" : p.audioDevice;
               return T.get("set.audio_device", d.isEmpty() ? T.get("audio_device.auto") : d);
            }, () -> {
               List<String> all = new ArrayList<>();
               all.add("");
               all.addAll(Mp3Player.outputDevices());
               int i = all.indexOf(p.audioDevice == null ? "" : p.audioDevice);
               p.audioDevice = all.get((i + 1) % all.size());
            }, false));
            this.rows.add(this.toggle("duck", () -> p.duckWhenInactive, v -> p.duckWhenInactive = v));
            this.rows.add(this.header("loading"));
            this.rows.add(this.toggle("prefetch", () -> p.prefetch, v -> {
               p.prefetch = v;
               PlayerController.I.refreshPrefetch();
            }));
            this.rows.add(this.slider("prefetch_count", 1.0, 8.0, 1.0, PD.prefetchCount, () -> p.prefetchCount, v -> {
               p.prefetchCount = (int)v;
               PlayerController.I.refreshPrefetch();
            }, HudConfigScreen::num));
            this.rows.add(this.toggle("disk_cache", () -> p.diskCache, v -> p.diskCache = v));
            this.rows
               .add(
                  new HudConfigScreen.ButtonRow(
                     "clear_cache",
                     () -> T.get("btn.clear_cache", PlayerController.I.yandex.cacheMegabytes()),
                     () -> PlayerController.I.yandex.clearCache(),
                     false
                  )
               );
            this.rows.add(this.toggle("online_lyrics", () -> p.onlineLyrics, v -> p.onlineLyrics = v));
            this.rows.add(this.toggle("amll_lyrics", () -> p.amllLyrics, v -> p.amllLyrics = v));
            this.rows.add(this.toggle("kugou_lyrics", () -> p.kugouLyrics, v -> p.kugouLyrics = v));
            this.rows.add(this.button("open_folder", () -> PlayerController.I.openLocalFolder(), false));
            this.rows.add(this.header("other"));
            this.rows.add(this.button("guide", () -> Game.open(new HelpScreen(this)), false));
            this.rows.add(this.button("reset_hud", () -> {
               HudConfig.resetToDefaults();
               this.rebuild();
            }, true));
            this.rows.add(this.note(T.get("about", "Overtone", "chifir4ik, PabJlo")));
      }
   }

   private static String pct(double v) {
      return Math.round(v * 100.0) + "%";
   }

   private static String percent(double v) {
      return Math.round(v) + "%";
   }

   private static String px(double v) {
      return Math.round(v) + " px";
   }

   private static String num(double v) {
      return String.valueOf(Math.round(v));
   }

   private static String seconds(double v) {
      return Math.round(v) + " " + T.get("unit.s");
   }

   private static String ms(double v) {
      return (v > 0.0 ? "+" : "") + Math.round(v) + " " + T.get("unit.ms");
   }

   private static String blocks(double v) {
      return String.format(Locale.ROOT, "%.1f", v);
   }

   private static String blocksSigned(double v) {
      return String.format(Locale.ROOT, "%+.1f", v);
   }

   private Canvas g() {
      return this.graphics;
   }

   private void touched() {
      if (this.tab == HudConfigScreen.Tab.WORLD) {
         long now = System.currentTimeMillis();
         if (now - this.lastDemo >= 700L) {
            this.lastDemo = now;
            WorldLyricsRenderer.demo();
         }
      }
   }

   private HudConfigScreen.Row toggle(String id, final BooleanSupplier get, final Consumer<Boolean> set) {
      return new HudConfigScreen.Row(id, 24) {
         @Override
         void draw(boolean hover) {
            this.label(T.get("set." + this.id), this.w - 46);
            boolean on = get.getAsBoolean();
            int sx = this.x + this.w - 34;
            int sy = this.y + (this.h - 14) / 2;
            PlayerTheme.rrect(
               HudConfigScreen.this.g(),
               sx,
               sy,
               34,
               14,
               7,
               on ? HudConfigScreen.this.th.accent : (hover ? HudConfigScreen.this.th.hover : HudConfigScreen.this.th.trackBg)
            );
            PlayerTheme.circle(HudConfigScreen.this.g(), on ? sx + 27 : sx + 7, sy + 7, 5, -1);
         }

         @Override
         boolean press(int button) {
            set.accept(!get.getAsBoolean());
            HudConfigScreen.this.touched();
            return false;
         }
      };
   }

   private HudConfigScreen.Row slider(
      String id,
      final double min,
      final double max,
      final double step,
      final double def,
      final DoubleSupplier get,
      final DoubleConsumer set,
      final DoubleFunction<String> fmt
   ) {
      return new HudConfigScreen.Row(id, 34) {
         @Override
         void draw(boolean hover) {
            double v = get.getAsDouble();
            String value = fmt.apply(v);
            int vw = HudConfigScreen.this.font.width(value);
            HudConfigScreen.this.g()
               .text(HudConfigScreen.this.font, HudConfigScreen.this.font.plainSubstrByWidth(T.get("set." + this.id), this.w - vw - 10), this.x, this.y + 3, -1);
            HudConfigScreen.this.g().text(HudConfigScreen.this.font, value, this.x + this.w - vw, this.y + 3, HudConfigScreen.this.th.accent);
            int ty = this.y + 21;
            boolean hot = hover || HudConfigScreen.this.dragRow == this;
            PlayerTheme.rrect(HudConfigScreen.this.g(), this.x, ty - 2, this.w, 4, 2, HudConfigScreen.this.th.trackBg);
            double t = Math.max(0.0, Math.min(1.0, (v - min) / (max - min)));
            int fill = (int)Math.round(this.w * t);
            if (fill > 0) {
               PlayerTheme.rrect(HudConfigScreen.this.g(), this.x, ty - 2, Math.max(4, fill), 4, 2, HudConfigScreen.this.th.accent);
            }

            int dx = this.x + (int)Math.round(this.w * (def - min) / (max - min));
            HudConfigScreen.this.g().fill(dx, ty - 4, dx + 1, ty + 4, PlayerTheme.argb(16777215, 70));
            PlayerTheme.circle(
               HudConfigScreen.this.g(), Math.max(this.x + 4, Math.min(this.x + this.w - 4, this.x + fill)), ty, hot ? 6 : 5, HudConfigScreen.this.th.accent
            );
            PlayerTheme.circle(HudConfigScreen.this.g(), Math.max(this.x + 4, Math.min(this.x + this.w - 4, this.x + fill)), ty, hot ? 3 : 2, -1);
         }

         @Override
         boolean press(int button) {
            if (button == 1) {
               set.accept(def);
               HudConfigScreen.this.touched();
               return false;
            } else {
               this.drag();
               return true;
            }
         }

         @Override
         void drag() {
            double t = Math.max(0.0, Math.min(1.0, (double)(HudConfigScreen.this.mouseX - this.x) / this.w));
            double v = min + Math.round(t * (max - min) / step) * step;
            set.accept(Math.max(min, Math.min(max, v)));
            HudConfigScreen.this.touched();
         }
      };
   }

   private <E extends Enum<E>> HudConfigScreen.Row choice(String id, final Supplier<E> get, final Consumer<E> set) {
      return new HudConfigScreen.Row(id, 24) {
         @Override
         void draw(boolean hover) {
            int pillW = Math.min(150, this.w / 2 + 10);
            this.label(T.get("set." + this.id), this.w - pillW - 8);
            int sx = this.x + this.w - pillW;
            int sy = this.y + 2;
            PlayerTheme.rrect(
               HudConfigScreen.this.g(),
               sx,
               sy,
               pillW,
               20,
               Math.min(HudConfigScreen.this.th.radius + 1, 10),
               hover ? HudConfigScreen.this.th.hover : HudConfigScreen.this.th.trackBg
            );
            String v = HudConfigScreen.this.font.plainSubstrByWidth(HudConfig.label(get.get()), pillW - 26);
            HudConfigScreen.this.g().text(HudConfigScreen.this.font, v, sx + (pillW - HudConfigScreen.this.font.width(v)) / 2, sy + 6, -1);
            int ay = sy + 10;
            PlayerTheme.tri(HudConfigScreen.this.g(), sx + 6, ay, 4, 7, false, hover ? HudConfigScreen.this.th.accent : -9539972);
            PlayerTheme.tri(HudConfigScreen.this.g(), sx + pillW - 10, ay, 4, 7, true, hover ? HudConfigScreen.this.th.accent : -9539972);
         }

         @Override
         boolean press(int button) {
            int pillW = Math.min(150, this.w / 2 + 10);
            int sx = this.x + this.w - pillW;
            if (HudConfigScreen.this.mouseX >= sx && HudConfigScreen.this.mouseX < sx + pillW / 2) {
               set.accept(HudConfig.prev(get.get()));
            } else {
               set.accept(HudConfig.next(get.get()));
            }

            HudConfigScreen.this.touched();
            return false;
         }
      };
   }

   private HudConfigScreen.Row swatches(
      String id, final Supplier<HudConfig.Accent> get, final Consumer<HudConfig.Accent> set, final IntSupplier custom, final IntConsumer setCustom
   ) {
      return new HudConfigScreen.Row(id, 28) {
         private static final int R = 6;
         private static final int GAP = 5;
         private final int count = HudConfig.Accent.values().length + 1;

         private int left() {
            return this.x + this.w - this.count * 17 + 5;
         }

         @Override
         void draw(boolean hover) {
            this.label(T.get("set." + this.id), this.left() - this.x - 8);
            HudConfig.Accent cur = get.get();
            int own = custom.getAsInt();
            int sx = this.left();
            int cym = this.y + this.h / 2;

            for (HudConfig.Accent a : HudConfig.Accent.values()) {
               if (own < 0 && a == cur) {
                  PlayerTheme.circle(HudConfigScreen.this.g(), sx + 6, cym, 8, -1);
               }

               PlayerTheme.circle(HudConfigScreen.this.g(), sx + 6, cym, 6, 0xFF000000 | a.rgb);
               sx += 17;
            }

            if (own >= 0) {
               PlayerTheme.circle(HudConfigScreen.this.g(), sx + 6, cym, 8, -1);
            }

            PlayerTheme.circle(HudConfigScreen.this.g(), sx + 6, cym, 6, own >= 0 ? 0xFF000000 | own : -7697774);
         }

         @Override
         boolean press(int button) {
            int i = (HudConfigScreen.this.mouseX - this.left()) / 17;
            HudConfig.Accent[] all = HudConfig.Accent.values();
            if (HudConfigScreen.this.mouseX < this.left() || i < 0) {
               return false;
            } else if (i < all.length) {
               set.accept(all[i]);
               return false;
            } else {
               int start = custom.getAsInt() >= 0 ? custom.getAsInt() : get.get().rgb;
               Game.open(new ColorPickerScreen(HudConfigScreen.this, start, setCustom));
               return false;
            }
         }
      };
   }

   private HudConfigScreen.Row plainSwatches(String id, final Supplier<HudConfig.Accent> get, final Consumer<HudConfig.Accent> set) {
      return new HudConfigScreen.Row(id, 28) {
         private static final int R = 6;
         private static final int GAP = 5;
         private final int count = HudConfig.Accent.values().length;

         private int left() {
            return this.x + this.w - this.count * 17 + 5;
         }

         @Override
         void draw(boolean hover) {
            this.label(T.get("set." + this.id), this.left() - this.x - 8);
            HudConfig.Accent cur = get.get();
            int sx = this.left();
            int cym = this.y + this.h / 2;

            for (HudConfig.Accent a : HudConfig.Accent.values()) {
               if (a == cur) {
                  PlayerTheme.circle(HudConfigScreen.this.g(), sx + 6, cym, 8, -1);
               }

               PlayerTheme.circle(HudConfigScreen.this.g(), sx + 6, cym, 6, 0xFF000000 | a.rgb);
               sx += 17;
            }
         }

         @Override
         boolean press(int button) {
            int i = (HudConfigScreen.this.mouseX - this.left()) / 17;
            HudConfig.Accent[] all = HudConfig.Accent.values();
            if (HudConfigScreen.this.mouseX >= this.left() && i >= 0 && i < all.length) {
               set.accept(all[i]);
               return false;
            } else {
               return false;
            }
         }
      };
   }

   private static String degrees(double v) {
      return Math.round(v) + "\u00b0";
   }

   private HudConfigScreen.Row anchors(String id, final Supplier<HudConfig.Anchor> get, final Consumer<HudConfig.Anchor> set) {
      return new HudConfigScreen.Row(id, 50) {
         private static final int CELL = 14;
         private static final int GAP = 2;

         private int left() {
            return this.x + this.w - 46;
         }

         @Override
         void draw(boolean hover) {
            this.label(T.get("set." + this.id) + ": " + HudConfig.label(get.get()), this.left() - this.x - 8);
            HudConfig.Anchor cur = get.get();

            for (HudConfig.Anchor a : HudConfig.Anchor.values()) {
               int ax = this.left() + (a.h + 1) * 16;
               int ay = this.y + 3 + (a.v + 1) * 16;
               boolean over = HudConfigScreen.this.mouseX >= ax
                  && HudConfigScreen.this.mouseX < ax + 14
                  && HudConfigScreen.this.mouseY >= ay
                  && HudConfigScreen.this.mouseY < ay + 14;
               PlayerTheme.rrect(
                  HudConfigScreen.this.g(),
                  ax,
                  ay,
                  14,
                  14,
                  3,
                  a == cur ? HudConfigScreen.this.th.accent : (over ? HudConfigScreen.this.th.hover : HudConfigScreen.this.th.trackBg)
               );
            }
         }

         @Override
         boolean press(int button) {
            for (HudConfig.Anchor a : HudConfig.Anchor.values()) {
               int ax = this.left() + (a.h + 1) * 16;
               int ay = this.y + 3 + (a.v + 1) * 16;
               if (HudConfigScreen.this.mouseX >= ax
                  && HudConfigScreen.this.mouseX < ax + 14
                  && HudConfigScreen.this.mouseY >= ay
                  && HudConfigScreen.this.mouseY < ay + 14) {
                  set.accept(a);
                  break;
               }
            }

            return false;
         }
      };
   }

   private HudConfigScreen.Row header(final String key) {
      return new HudConfigScreen.Row(null, 22) {
         @Override
         void draw(boolean hover) {
            String text = T.get("section." + key).toUpperCase(Locale.ROOT);
            HudConfigScreen.this.g().text(HudConfigScreen.this.font, text, this.x, this.y + 11, HudConfigScreen.this.th.accent);
            int lx = this.x + HudConfigScreen.this.font.width(text) + 6;
            HudConfigScreen.this.g().fill(lx, this.y + 15, this.x + this.w, this.y + 16, PlayerTheme.argb(16777215, 22));
         }
      };
   }

   private HudConfigScreen.Row note(String text) {
      final List<FormattedCharSequence> lines = this.font.split(Component.literal(text), this.cw);
      return new HudConfigScreen.Row(null, lines.size() * (9 + 2) + 10) {
         @Override
         void draw(boolean hover) {
            for (int i = 0; i < lines.size(); i++) {
               HudConfigScreen.this.g().text(HudConfigScreen.this.font, lines.get(i), this.x, this.y + 6 + i * (9 + 2), -9539972);
            }
         }
      };
   }

   private HudConfigScreen.Row button(String id, Runnable action, boolean confirm) {
      return new HudConfigScreen.ButtonRow(id, () -> T.get("btn." + id), action, confirm);
   }

   private HudConfigScreen.Row dragButton() {
      return new HudConfigScreen.ButtonRow("drag", () -> T.get("btn.drag"), () -> Game.open(new HudEditScreen(this)), false);
   }

   private boolean in(int[] r, double mx, double my) {
      return mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3];
   }

   @Override
   protected boolean onClick(double ex, double ey, int rawButton, boolean doubleClick) {
      this.mouseX = (int)ex;
      this.mouseY = (int)ey;
      int button = doubleClick ? 1 : 0;
      if (this.listening != null) {
         this.listening = null;
         return true;
      } else if (this.in(this.doneBtn, this.mouseX, this.mouseY)) {
         this.onClose();
         return true;
      } else if (this.in(this.guideBtn, this.mouseX, this.mouseY)) {
         Game.open(new HelpScreen(this));
         return true;
      } else {
         HudConfigScreen.Tab[] tabs = HudConfigScreen.Tab.values();

         for (int i = 0; i < tabs.length; i++) {
            int ty = this.py + 28 + 4 + i * 22;
            if (this.mouseX >= this.px + 6 && this.mouseX < this.px + 92 && this.mouseY >= ty && this.mouseY < ty + 20) {
               if (this.tab != tabs[i]) {
                  this.tab = tabs[i];
                  this.rebuild();
               }

               return true;
            }
         }

         if (this.maxFirst > 0
            && this.mouseX >= this.cx + this.cw + 2
            && this.mouseX < this.cx + this.cw + 3 + 5 + 4
            && this.mouseY >= this.bodyTop
            && this.mouseY < this.bodyBottom) {
            this.dragBar = true;
            this.scrollToMouse();
            return true;
         } else {
            for (HudConfigScreen.Row r : this.shown) {
               if (r.inside(this.mouseX, this.mouseY)) {
                  if (r.press(button)) {
                     this.dragRow = r;
                  }

                  return true;
               }
            }

            return super.onClick(ex, ey, rawButton, doubleClick);
         }
      }
   }

   @Override
   protected boolean onDrag(double ex, double ey, int button, double dragX, double dragY) {
      this.mouseX = (int)ex;
      this.mouseY = (int)ey;
      if (this.dragBar) {
         this.scrollToMouse();
         return true;
      } else if (this.dragRow != null) {
         this.dragRow.drag();
         return true;
      } else {
         return super.onDrag(ex, ey, button, dragX, dragY);
      }
   }

   @Override
   protected boolean onRelease(double ex, double ey, int button) {
      this.mouseX = (int)ex;
      this.mouseY = (int)ey;
      boolean was = this.dragRow != null || this.dragBar;
      if (this.dragRow != null) {
         this.lastDemo = 0L;
         this.touched();
      }

      this.dragRow = null;
      this.dragBar = false;
      return was || super.onRelease(ex, ey, button);
   }

   private void scrollToMouse() {
      double t = (double)(this.mouseY - this.bodyTop) / (this.bodyBottom - this.bodyTop);
      this.first = Math.max(0, Math.min(this.maxFirst, (int)Math.round(t * this.maxFirst)));
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double sx, double sy) {
      if (mx >= this.px + 92 && mx < this.px + this.pw) {
         this.first = Math.max(0, Math.min(this.maxFirst, this.first + (sy < 0.0 ? 1 : -1)));
         return true;
      } else {
         return super.mouseScrolled(mx, my, sx, sy);
      }
   }

   @Override
   protected boolean onKey(KeyInput event) {
      int k = event.key();
      if (this.listening == null) {
         return k != 32 && k != 257 && k != 335 ? super.onKey(event) : false;
      } else {
         Hotkeys.Action a = this.listening;
         this.listening = null;
         if (k != 256) {
            Hotkeys.setKey(a, k != 261 && k != 259 ? k : -1);
         }

         return true;
      }
   }

   @Override
   protected void draw(Canvas g, int mx, int my, float delta) {
      this.mouseX = mx;
      this.mouseY = my;
      this.graphics = g;
      this.th = PlayerTheme.current();
      this.drawWidgets(g, mx, my, delta);
      this.drawPreview(g);
      this.drawPanel(g);
      this.syncHits();
   }

   private void drawPreview(Canvas g) {
      if (this.tab != HudConfigScreen.Tab.WORLD) {
         if (this.tab == HudConfigScreen.Tab.VOLUME) {
            VolumeRenderer.render(g, true);
         } else if (this.tab == HudConfigScreen.Tab.VISUALIZER) {
            VisualizerRenderer.render(g, true);
         } else {
            if (this.tab == HudConfigScreen.Tab.WIDGET || this.tab == HudConfigScreen.Tab.LYRICS) {
               WidgetRenderer.render(g, true);
               LyricsRenderer.render(g, true);
            }
         }
      }
   }

   private void drawPanel(Canvas g) {
      this.th.window(g, this.px, this.py, this.pw, this.ph);
      this.drawHeader(g);
      PlayerTheme.rrect(g, this.px + 4, this.py + 28, 86, this.ph - 28 - 4, Math.max(0, this.th.radius - 1), this.th.panel2);
      this.drawTabs(g);
      this.drawRows(g);
      this.drawFooter(g);
   }

   private void drawHeader(Canvas g) {
      g.text(this.font, "\u266a Overtone", this.px + 12, this.py + 10, this.th.accent);
      g.text(
         this.font,
         this.font.plainSubstrByWidth(T.get("settings"), this.pw / 4),
         this.px + 14 + this.font.width("\u266a Overtone") + 6,
         this.py + 10,
         -9539972
      );
      String guide = T.get("btn.guide_short");
      int gw = this.font.width(guide) + 16;
      this.pill(g, this.guideBtn, this.px + this.pw - 10 - gw, this.py + 5, gw, guide);
      g.fill(this.px + 10, this.py + 28 - 2, this.px + this.pw - 10, this.py + 28 - 1, PlayerTheme.argb(16777215, 16));
   }

   private void pill(Canvas g, int[] rect, int x, int y, int w, String text) {
      rect[0] = x;
      rect[1] = y;
      rect[2] = w;
      rect[3] = 16;
      boolean hover = this.in(rect, this.mouseX, this.mouseY);
      PlayerTheme.rrect(g, x, y, w, 16, 8, hover ? this.th.hover : this.th.trackBg);
      g.text(this.font, text, x + 8, y + 4, hover ? -1 : -4934464);
   }

   private void drawTabs(Canvas g) {
      HudConfigScreen.Tab[] tabs = HudConfigScreen.Tab.values();

      for (int i = 0; i < tabs.length; i++) {
         int ty = this.py + 28 + 4 + i * 22;
         int tx = this.px + 6;
         int tw = 84;
         boolean active = tabs[i] == this.tab;
         boolean hover = this.mouseX >= tx && this.mouseX < tx + tw && this.mouseY >= ty && this.mouseY < ty + 20;
         if (active) {
            PlayerTheme.rrect(g, tx, ty, tw, 20, 4, this.th.rowCurrent);
         } else if (hover) {
            PlayerTheme.rrect(g, tx, ty, tw, 20, 4, this.th.hover);
         }

         if (active) {
            g.fill(tx, ty + 3, tx + 2, ty + 17, this.th.accent);
         }

         String name = this.font.plainSubstrByWidth(T.get("tab." + tabs[i].name().toLowerCase(Locale.ROOT)), tw - 14);
         g.text(this.font, name, tx + 8, ty + 6, active ? this.th.accent : (hover ? -1 : -4934464));
      }
   }

   private void drawRows(Canvas g) {
      this.shown.clear();
      int y = this.bodyTop + 2;

      for (int i = this.first; i < this.rows.size(); i++) {
         HudConfigScreen.Row r = this.rows.get(i);
         if (y + r.h > this.bodyBottom) {
            break;
         }

         r.x = this.cx;
         r.y = y;
         r.w = this.cw;
         this.shown.add(r);
         r.draw(r.inside(this.mouseX, this.mouseY) && this.dragRow == null || this.dragRow == r);
         y += r.h;
      }

      if (this.maxFirst > 0) {
         int bx = this.cx + this.cw + 3;
         int top = this.bodyTop + 2;
         int trackH = this.bodyBottom - this.bodyTop - 4;
         PlayerTheme.rrect(g, bx, top, 5, trackH, 2, this.th.fieldBg);
         int thumbH = Math.max(16, trackH * this.shown.size() / Math.max(1, this.rows.size()));
         int thumbY = top + (trackH - thumbH) * this.first / this.maxFirst;
         PlayerTheme.rrect(g, bx, thumbY, 5, thumbH, 2, this.dragBar ? this.th.accentHover : this.th.accent);
      }
   }

   private void drawFooter(Canvas g) {
      int fy = this.py + this.ph - 30;
      g.fill(this.px + 92, fy, this.px + this.pw - 10, fy + 1, PlayerTheme.argb(16777215, 16));
      int dw = this.font.width(T.get("btn.done")) + 24;
      this.doneBtn[0] = this.px + this.pw - 10 - dw;
      this.doneBtn[1] = fy + 5;
      this.doneBtn[2] = dw;
      this.doneBtn[3] = 20;
      boolean hover = this.in(this.doneBtn, this.mouseX, this.mouseY);
      PlayerTheme.rrect(g, this.doneBtn[0], this.doneBtn[1], dw, 20, Math.min(this.th.radius + 1, 10), hover ? this.th.accentHover : this.th.accent);
      g.text(this.font, T.get("btn.done"), this.doneBtn[0] + 12, this.doneBtn[1] + 6, -1);
      String text = T.get("hint.default");

      for (HudConfigScreen.Row r : this.shown) {
         if (r.inside(this.mouseX, this.mouseY) && r.hint() != null) {
            text = r.hint();
            break;
         }
      }

      int hintX = this.px + 92 + 8;
      int hintW = this.doneBtn[0] - hintX - 8;
      List<FormattedCharSequence> lines = this.font.split(Component.literal(text), hintW);

      for (int i = 0; i < Math.min(2, lines.size()); i++) {
         g.text(this.font, lines.get(i), hintX, fy + 5 + i * (9 + 1), -9539972);
      }
   }

   public void removed() {
      OPEN = false;
      cfg().save();
      pcfg().save();
      super.removed();
   }

   public void onClose() {
      Game.open(this.parent);
   }

   public boolean isPauseScreen() {
      return false;
   }

   private final class ButtonRow extends HudConfigScreen.Row {
      private final Supplier<String> label;
      private final Runnable action;
      private final boolean confirm;
      private boolean armed;
      private long armedAt;

      ButtonRow(String id, Supplier<String> label, Runnable action, boolean confirm) {
         super(id, 26);
         this.label = label;
         this.action = action;
         this.confirm = confirm;
      }

      @Override
      void draw(boolean hover) {
         if (this.armed && System.currentTimeMillis() - this.armedAt > 3000L) {
            this.armed = false;
         }

         int by = this.y + 2;
         int bg = this.armed ? HudConfigScreen.this.th.accent : (hover ? HudConfigScreen.this.th.hover : HudConfigScreen.this.th.trackBg);
         PlayerTheme.rrect(HudConfigScreen.this.g(), this.x, by, this.w, 22, Math.min(HudConfigScreen.this.th.radius + 1, 10), bg);
         String text = HudConfigScreen.this.font.plainSubstrByWidth(this.armed ? T.get("btn.confirm") : this.label.get(), this.w - 12);
         HudConfigScreen.this.g().text(HudConfigScreen.this.font, text, this.x + (this.w - HudConfigScreen.this.font.width(text)) / 2, by + 7, -1);
      }

      @Override
      boolean press(int button) {
         if (this.confirm && !this.armed) {
            this.armed = true;
            this.armedAt = System.currentTimeMillis();
            return false;
         } else {
            this.armed = false;
            this.action.run();
            return false;
         }
      }
   }

   private final class KeyRow extends HudConfigScreen.Row {
      private final Hotkeys.Action action;

      KeyRow(Hotkeys.Action action) {
         super("key", 24);
         this.action = action;
      }

      @Override
      String hint() {
         return T.get("hint.key");
      }

      @Override
      void draw(boolean hover) {
         int pillW = 124;
         this.label(this.action.label(), this.w - pillW - 8);
         int sx = this.x + this.w - pillW;
         int sy = this.y + 2;
         boolean on = HudConfigScreen.this.listening == this.action;
         if (on) {
            PlayerTheme.rrect(
               HudConfigScreen.this.g(), sx - 1, sy - 1, pillW + 2, 22, Math.min(HudConfigScreen.this.th.radius + 2, 11), HudConfigScreen.this.th.accent
            );
         }

         PlayerTheme.rrect(
            HudConfigScreen.this.g(),
            sx,
            sy,
            pillW,
            20,
            Math.min(HudConfigScreen.this.th.radius + 1, 10),
            on ? HudConfigScreen.this.th.fieldBg : (hover ? HudConfigScreen.this.th.hover : HudConfigScreen.this.th.trackBg)
         );
         String v = HudConfigScreen.this.font.plainSubstrByWidth(on ? T.get("keys.press") : Hotkeys.keyName(this.action), pillW - 10);
         int color = on ? HudConfigScreen.this.th.accent : (Hotkeys.isDefault(this.action) ? -1 : HudConfigScreen.this.th.accent);
         HudConfigScreen.this.g().text(HudConfigScreen.this.font, v, sx + (pillW - HudConfigScreen.this.font.width(v)) / 2, sy + 6, color);
      }

      @Override
      boolean press(int button) {
         HudConfigScreen.this.listening = this.action;
         return false;
      }
   }

   private final class PreviewRow extends HudConfigScreen.Row {
      PreviewRow() {
         super("preview", 72);
      }

      @Override
      void draw(boolean hover) {
         PlayerTheme.miniPreview(HudConfigScreen.this.g(), HudConfigScreen.this.font, this.x, this.y + 4, this.w, 62);
      }
   }

   private abstract class Row {
      final String id;
      final int h;
      int x;
      int y;
      int w;

      Row(String id, int h) {
         this.id = id;
         this.h = h;
      }

      abstract void draw(boolean var1);

      boolean press(int button) {
         return false;
      }

      void drag() {
      }

      String hint() {
         return this.id == null ? null : T.get("hint." + this.id);
      }

      void label(String text, int maxW) {
         HudConfigScreen.this.g()
            .text(HudConfigScreen.this.font, HudConfigScreen.this.font.plainSubstrByWidth(text, maxW), this.x, this.y + (this.h - 9) / 2 + 1, -1);
      }

      boolean inside(double mx, double my) {
         return mx >= this.x && mx < this.x + this.w && my >= this.y && my < this.y + this.h;
      }
   }

   private static enum Tab {
      WIDGET,
      LYRICS,
      WORLD,
      VOLUME,
      VISUALIZER,
      PLAYER,
      KEYS,
      GENERAL;

      private Tab() {
      }
   }
}
