package dev.musicplayer.ui;

import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

final class Hit {
   private Hit() {
   }

   static Button make(Runnable action) {
      Button b = new Hit.HitButton(action);
      b.active = false;
      return b;
   }

   static void place(Button b, int[] r, boolean on) {
      place(b, r[0], r[1], r[2], r[3], on);
   }

   static void place(Button b, int x, int y, int w, int h, boolean on) {
      if (b != null) {
         b.setX(x);
         b.setY(y);
         b.setWidth(Math.max(0, w));
         if (b instanceof Hit.HitButton hb) {
            hb.resize(Math.max(0, h));
         }

         b.active = on && w > 0 && h > 0;
      }
   }

   private static final class HitButton extends Button {
      HitButton(Runnable action) {
         super(0, 0, 0, 0, Component.empty(), press -> action.run(), DEFAULT_NARRATION);
      }

      void resize(int h) {
         this.height = h;
      }
   }
}
