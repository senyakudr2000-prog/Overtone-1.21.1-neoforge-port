package dev.musicplayer.ui;

import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

final class GuiFit {
   private static double saved = -1.0;
   private static double applied;

   private GuiFit() {
   }

   static void fit(Screen screen, int needW, int needH) {
      Window w = Minecraft.getInstance().getWindow();
      double cur = w.getGuiScale();
      if (saved < 0.0 || cur != applied) {
         saved = cur;
      }

      double want = Math.floor(Math.min((double)w.getWidth() / needW, (double)w.getHeight() / needH));
      want = Math.max(1.0, Math.min(saved, want));
      if (want != cur) {
         w.setGuiScale(want);
      }

      applied = w.getGuiScale();
      screen.width = w.getGuiScaledWidth();
      screen.height = w.getGuiScaledHeight();
   }

   static void restore() {
      if (!(saved < 0.0)) {
         Minecraft.getInstance().getWindow().setGuiScale(saved);
         saved = -1.0;
      }
   }
}
