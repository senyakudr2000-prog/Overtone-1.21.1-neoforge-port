package dev.musicplayer.ui;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.compat.Game;
import dev.musicplayer.compat.KeyInput;
import dev.musicplayer.compat.ModScreen;
import dev.musicplayer.compat.Tex;
import dev.musicplayer.config.PlayerConfig;
import dev.musicplayer.config.SessionState;
import dev.musicplayer.config.TokenStore;
import dev.musicplayer.controller.PlayerController;
import dev.musicplayer.hud.CoverArt;
import dev.musicplayer.input.Hotkeys;
import dev.musicplayer.lyrics.LrcParser;
import dev.musicplayer.model.LyricLine;
import dev.musicplayer.model.MusicEntity;
import dev.musicplayer.model.Page;
import dev.musicplayer.model.Platform;
import dev.musicplayer.model.Track;
import dev.musicplayer.provider.MusicProvider;
import dev.musicplayer.util.Browser;
import dev.musicplayer.util.T;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

public class PlayerScreen extends ModScreen {
   private static final int BASE_W = 560;
   private static final int BASE_H = 330;
   private static final int ROW_H = 24;
   private static final int VOL_BAR_W = 64;
   private static final int VOL_GROUP_W = 120;
   private final PlayerController ctl = PlayerController.I;
   private final List<PlayerScreen.Btn> btns = new ArrayList<>();
   private PlayerConfig pc;
   private PlayerTheme th;
   private EditBox searchBox;
   private EditBox tokenBox;
   private EditBox field;
   private int fx;
   private int fy;
   private int fw;
   private int fh;
   private int px;
   private int py;
   private int pw;
   private int ph;
   private int lw;
   private int rx;
   private int rw;
   private int lx;
   private int listTop;
   private int rows;
   private int by;
   private int cy;
   private int coverPx;
   private int lyTop;
   private int lyBottom;
   private int volGroupX;
   private int volBarX;
   private int page = 0;
   private boolean queueMode;
   private PlayerScreen.Mode built = PlayerScreen.Mode.PICKER;
   private boolean pickerOpen;
   private boolean linkOpen;
   private int accountBuilt;
   private boolean draggingVolume;
   private boolean draggingSeek;
   private boolean addAccountMode;
   private int chipEnd;
   private List<TokenStore.Account> savedAccounts = List.of();
   private String animTrackId;
   private long animStart;
   private double seekFrac;
   private int mouseX;
   private int mouseY;
   private int builtSig;
   private int pageHeaderY;
   private final int[] artistRect = new int[4];
   private final int[] albumRect = new int[4];
   private Button artistHit;
   private Button albumHit;
   private List<LyricLine> wrappedFor;
   private List<List<FormattedCharSequence>> wrapped = List.of();
   private int[] tops = new int[0];
   private int totalH;
   private int wrapW = -1;
   private double scrollPx = 0.0;
   private double manualPx = 0.0;
   private final long openStart = System.nanoTime();
   private long builtAt = this.openStart;
   private long lastFrameNs;
   private float dt = 0.016F;
   private final float[] rowGlow = new float[64];
   private float seekGlow;
   private final Screen parent;
   private boolean helpChecked;
   private static final int MAX_ACCOUNT_ROWS = 4;
   private static final int CARD_H = 52;
   private static final int CARD_GAP = 10;
   private int headerButtonsW;
   private static final int ACT_W = 16;
   private static final int[] WAVE_PALETTE = new int[]{16747069, 16731533, 10509567, 4033535, 3135171};

   public PlayerScreen(Screen parent) {
      super(Component.translatable("screen.musicplayer.title"));
      this.parent = parent;
   }

   protected void init() {
      this.pc = PlayerConfig.get();
      float k = this.pc.windowScale / 100.0F;
      GuiFit.fit(this, Math.round(560.0F * k) + 16, Math.round(330.0F * k) + 16);
      this.pw = Math.min(this.width - 16, Math.round(560.0F * k));
      this.ph = Math.min(this.height - 16, Math.round(330.0F * k));
      this.px = (this.width - this.pw) / 2;
      this.py = (this.height - this.ph) / 2;
      this.lw = Math.min(Math.round(this.pw * 0.29F), this.pw / 3);
      this.rx = this.px + this.lw + 32;
      this.rw = this.pw - this.lw - 32 - 14;
      this.built = this.modeNow();
      this.builtAt = System.nanoTime();
      this.accountBuilt = this.accountState();
      String oldQuery = this.searchBox != null ? this.searchBox.getValue() : SessionState.get().query;
      this.searchBox = null;
      this.tokenBox = null;
      this.field = null;
      this.btns.clear();
      this.artistHit = Hit.make(() -> {
         if (this.ctl.current != null) {
            this.page = 0;
            this.queueMode = false;
            this.ctl.openArtistOf(this.ctl.current);
         }
      });
      this.albumHit = Hit.make(() -> {
         if (this.ctl.current != null) {
            this.page = 0;
            this.queueMode = false;
            this.ctl.openAlbumOf(this.ctl.current);
         }
      });
      this.addWidget(this.artistHit);
      this.addWidget(this.albumHit);
      switch (this.built) {
         case MAIN:
            this.buildMain(oldQuery);
            break;
         case LOGIN:
            this.buildLogin();
            break;
         case PICKER:
            this.buildPicker();
      }
   }

   private int accountState() {
      return this.ctl.soundcloud.canLike() ? 2 : (this.ctl.soundcloud.isLinked() ? 1 : 0);
   }

   private PlayerScreen.Mode modeNow() {
      if (this.ctl.platform == null || this.pickerOpen) {
         return PlayerScreen.Mode.PICKER;
      } else if (this.linkOpen) {
         return PlayerScreen.Mode.LOGIN;
      } else {
         return this.ctl.ready() ? PlayerScreen.Mode.MAIN : PlayerScreen.Mode.LOGIN;
      }
   }

   private PlayerScreen.Btn btn(PlayerScreen.Kind kind, int x, int y, int w, int h, String label, PlayerScreen.Icon icon, DoubleConsumer click) {
      PlayerScreen.Btn b = new PlayerScreen.Btn(kind, x, y, w, h);
      b.label = label;
      b.icon = icon;
      b.click = click;
      this.btns.add(b);
      Button hit = Button.builder(Component.empty(), press -> {
         if (b.visible.getAsBoolean() && b.enabled.getAsBoolean()) {
            b.click.accept(this.mouseX);
         }
      }).bounds(x, y, w, h).build();
      this.addWidget(hit);
      return b;
   }

   private EditBox styledField(int x, int y, int w, int h, String hint) {
      this.fx = x;
      this.fy = y;
      this.fw = w;
      this.fh = h;
      EditBox box = new EditBox(this.font, x + 6, y + (h - 9) / 2, w - 12, 10, Component.empty());
      box.setBordered(false);
      box.setHint(Component.literal(hint));
      return box;
   }

   private void buildLogin() {
      if (this.ctl.platform == Platform.YANDEX) {
         List<TokenStore.Account> saved = this.ctl.yandex.savedAccounts();
         this.savedAccounts = saved;
         if (saved.isEmpty()) {
            this.addAccountMode = true;
         }

         if (this.addAccountMode) {
            this.buildTokenForm(
               T.get("login.open_yandex"),
               "https://oauth.yandex.ru/authorize?response_type=token&client_id=23cabbbdc6cd418abb4b39c32c41195d",
               T.get("login.paste_hint"),
               this.ctl::submitToken,
               saved.isEmpty() ? null : "\u2039 " + T.get("login.back_saved"),
               () -> {
                  this.addAccountMode = false;
                  this.rebuildWidgets();
               }
            );
         } else {
            this.buildAccountList(saved);
         }
      } else if (this.ctl.platform == Platform.SOUNDCLOUD) {
         this.buildTokenForm(
            T.get("login.open_soundcloud"), "https://soundcloud.com/", T.get("login.sc_hint"), this.ctl::linkSoundCloud, "\u2039 " + T.get("btn.back"), () -> {
               this.linkOpen = false;
               this.rebuildWidgets();
            }
         );
      } else if (this.ctl.platform == Platform.SPOTIFY) {
         this.buildTokenForm(
            T.get("login.open_spotify"),
            "https://developer.spotify.com/dashboard",
            T.get("login.sp_hint"),
            this.ctl::loginSpotify,
            "\u2039 " + T.get("btn.back"),
            () -> {
               this.pickerOpen = true;
               this.rebuildWidgets();
            }
         );
         this.tokenBox.setValue(this.ctl.spotify.savedClientId());
      }

      this.addSettingsButton();
   }

   private void buildPicker() {
      this.addSettingsButton();
      Platform[] all = Platform.values();
      int cardW = this.pw - 28;
      int x0 = this.px + 14;
      int y0 = this.py + 66;
      int step = Math.max(40, Math.min(62, (this.ph - 66 - 34) / all.length));
      int cardH = Math.min(52, step - 6);

      for (int i = 0; i < all.length; i++) {
         Platform pl = all[i];
         int y = y0 + i * step;
         PlayerScreen.Btn card = this.btn(PlayerScreen.Kind.CARD, x0, y, cardW, cardH, "", PlayerScreen.Icon.NONE, mx -> this.choose(pl));
         card.plat = pl;
         card.order = i;
         card.enabled = () -> this.ctl.has(pl);
      }

      if (this.ctl.platform != null) {
         this.btn(PlayerScreen.Kind.GHOST, this.px + 14, this.py + this.ph - 28, 70, 16, "\u2039 " + T.get("btn.back"), PlayerScreen.Icon.NONE, mx -> {
            this.pickerOpen = false;
            this.rebuildWidgets();
         });
      }
   }

   private void buildSoundCloudAccountButtons(int lx, int lw) {
      boolean linked = this.ctl.soundcloud.isLinked();
      boolean canLike = this.ctl.soundcloud.canLike();
      if (!linked) {
         this.btn(PlayerScreen.Kind.GHOST, lx, this.py + 78, lw, 22, T.get("player.sc_login"), PlayerScreen.Icon.NONE, mx -> {
            this.linkOpen = true;
            this.rebuildWidgets();
         });
      } else if (canLike) {
         this.btn(PlayerScreen.Kind.GHOST, lx, this.py + 78, lw, 22, T.get("player.sc_logout"), PlayerScreen.Icon.NONE, mx -> {
            this.ctl.soundcloud.logout();
            this.rebuildWidgets();
         });
      } else {
         int half = (lw - 4) / 2;
         this.btn(PlayerScreen.Kind.GHOST, lx, this.py + 78, half, 22, T.get("player.logout"), PlayerScreen.Icon.NONE, mx -> {
            this.ctl.soundcloud.logout();
            this.rebuildWidgets();
         });
         this.btn(PlayerScreen.Kind.GHOST, lx + half + 4, this.py + 78, lw - half - 4, 22, T.get("player.likes"), PlayerScreen.Icon.NONE, mx -> {
            this.linkOpen = true;
            this.rebuildWidgets();
         });
      }
   }

   private void choose(Platform pl) {
      this.pickerOpen = false;
      this.linkOpen = false;
      this.page = 0;
      this.queueMode = false;
      this.addAccountMode = false;
      this.ctl.selectPlatform(pl);
      this.rebuildWidgets();
   }

   private void buildAccountList(List<TokenStore.Account> saved) {
      int cx = this.px + this.pw / 2;
      int w = 280;
      int xBtn = 24;
      int gap = 4;
      int mainW = w - xBtn - gap;
      int left = cx - w / 2;
      int y = this.py + 56;
      int n = Math.min(4, saved.size());

      for (int i = 0; i < n; i++) {
         TokenStore.Account a = saved.get(i);
         String label = this.font.plainSubstrByWidth(a.displayName(), mainW - 16);
         this.btn(PlayerScreen.Kind.PRIMARY, left, y, mainW, 20, label, PlayerScreen.Icon.NONE, mx -> this.ctl.loginSaved(a));
         this.btn(PlayerScreen.Kind.GHOST, left + mainW + gap, y, xBtn, 20, "x", PlayerScreen.Icon.NONE, mx -> {
            this.ctl.yandex.forgetAccount(a);
            this.rebuildWidgets();
         });
         y += 26;
      }

      this.btn(PlayerScreen.Kind.GHOST, left, y + 6, w, 20, "+ " + T.get("login.add_account"), PlayerScreen.Icon.NONE, mx -> {
         this.addAccountMode = true;
         this.rebuildWidgets();
      });
   }

   private void buildTokenForm(String openLabel, String openUrl, String hint, Consumer<String> submit, String backLabel, Runnable back) {
      int cx = this.px + this.pw / 2;
      int w = 280;
      this.btn(PlayerScreen.Kind.PRIMARY, cx - w / 2, this.py + 92, w, 20, "1. " + openLabel, PlayerScreen.Icon.NONE, mx -> Browser.open(openUrl));
      this.tokenBox = this.styledField(cx - w / 2, this.py + 138, w, 22, hint);
      this.tokenBox.setMaxLength(4096);
      this.field = this.tokenBox;
      this.addRenderableWidget(this.tokenBox);
      this.btn(
         PlayerScreen.Kind.PRIMARY,
         cx - w / 2,
         this.py + 168,
         w,
         20,
         "2. " + T.get("login.confirm"),
         PlayerScreen.Icon.NONE,
         mx -> submit.accept(this.tokenBox.getValue())
      );
      if (back != null) {
         this.btn(PlayerScreen.Kind.GHOST, cx - w / 2, this.py + 214, w, 18, backLabel, PlayerScreen.Icon.NONE, mx -> back.run());
      }
   }

   private void addSettingsButton() {
      String label = T.get("settings");
      int w = this.font.width(label) + 16;
      this.btn(
         PlayerScreen.Kind.GHOST,
         this.px + this.pw - 12 - w,
         this.py + 5,
         w,
         16,
         label,
         PlayerScreen.Icon.NONE,
         mx -> Game.open(HudConfigScreen.playerTab(this))
      );
      this.headerButtonsW = w;
      int hw = 16;
      this.btn(
         PlayerScreen.Kind.GHOST, this.px + this.pw - 12 - w - 4 - hw, this.py + 5, hw, 16, "?", PlayerScreen.Icon.NONE, mx -> Game.open(new HelpScreen(this))
      );
      this.headerButtonsW = w + 4 + hw;
      int titleEnd = this.px + 14 + this.font.width("\u266a Overtone");
      this.chipEnd = titleEnd;
      if (this.built != PlayerScreen.Mode.PICKER && this.ctl.platform != null) {
         Platform pl = this.ctl.platform;
         int cw = this.font.width(pl.title()) + 28;
         int cx = titleEnd + 8;
         PlayerScreen.Btn chip = this.btn(PlayerScreen.Kind.CHIP, cx, this.py + 5, cw, 16, pl.title(), PlayerScreen.Icon.NONE, mx -> {
            this.pickerOpen = true;
            this.rebuildWidgets();
         });
         chip.plat = pl;
         this.chipEnd = cx + cw;
      }

      MusicProvider ap = this.ctl.active();
      if (this.built == PlayerScreen.Mode.MAIN && ap != null && ap.platform().needsLogin) {
         String out = T.get("player.logout");
         int ow = this.font.width(out) + 16;
         this.btn(PlayerScreen.Kind.GHOST, this.px + this.pw - 12 - this.headerButtonsW - 4 - ow, this.py + 5, ow, 16, out, PlayerScreen.Icon.NONE, mx -> {
            this.page = 0;
            this.queueMode = false;
            this.addAccountMode = false;
            this.ctl.logout();
         });
         this.headerButtonsW += 4 + ow;
      }
   }

   private void buildMain(String oldQuery) {
      this.addSettingsButton();
      this.lx = this.px + 12;
      int sbW = 50;
      MusicProvider ap = this.ctl.active();
      boolean likes = ap.supportsLikes();
      this.searchBox = this.styledField(
         this.lx, this.py + 34, this.lw - sbW - 4, 18, T.get(this.ctl.platform == Platform.LOCAL ? "player.search_local" : "player.search")
      );
      this.searchBox.setMaxLength(100);
      this.searchBox.setValue(oldQuery == null ? "" : oldQuery);
      this.field = this.searchBox;
      this.addRenderableWidget(this.searchBox);
      this.btn(PlayerScreen.Kind.PRIMARY, this.lx + this.lw - sbW, this.py + 34, sbW, 18, T.get("player.find"), PlayerScreen.Icon.NONE, mx -> this.doSearch());
      int qW = 66;
      this.btn(
         PlayerScreen.Kind.GHOST,
         this.lx,
         this.py + 56,
         this.lw - qW - 4,
         18,
         ap.likedLabel(),
         likes ? PlayerScreen.Icon.HEART : PlayerScreen.Icon.NONE,
         mx -> {
            this.page = 0;
            this.queueMode = false;
            this.ctl.loadLiked();
         }
      );
      this.btn(PlayerScreen.Kind.GHOST, this.lx + this.lw - qW, this.py + 56, qW, 18, T.get("player.queue"), PlayerScreen.Icon.QUEUE, mx -> {
         this.page = 0;
         this.queueMode = !this.queueMode;
      });
      if (this.ctl.platform == Platform.YANDEX) {
         this.btn(PlayerScreen.Kind.WAVE, this.lx, this.py + 78, this.lw, 22, "", PlayerScreen.Icon.WAVE, mx -> {
            this.page = 0;
            this.queueMode = false;
            this.ctl.toggleWave();
         });
      } else if (this.ctl.platform == Platform.SOUNDCLOUD) {
         this.buildSoundCloudAccountButtons(this.lx, this.lw);
      } else if (this.ctl.platform == Platform.LOCAL) {
         int half = (this.lw - 4) / 2;
         this.btn(PlayerScreen.Kind.GHOST, this.lx, this.py + 78, half, 22, T.get("player.folder"), PlayerScreen.Icon.NONE, mx -> this.ctl.openLocalFolder());
         this.btn(
            PlayerScreen.Kind.GHOST,
            this.lx + half + 4,
            this.py + 78,
            this.lw - half - 4,
            22,
            T.get("player.refresh"),
            PlayerScreen.Icon.NONE,
            mx -> this.ctl.local.refresh()
         );
      }

      this.builtSig = this.viewSig();
      int top = this.py + 106;
      Page pg = this.ctl.page();
      this.pageHeaderY = top;
      if (pg != null) {
         this.btn(PlayerScreen.Kind.GHOST, this.lx, top, 54, 18, "\u2039 " + T.get("btn.back"), PlayerScreen.Icon.NONE, mx -> this.ctl.back());
         if (!pg.tracks().isEmpty()) {
            this.btn(
               PlayerScreen.Kind.PRIMARY,
               this.lx + this.lw - 74,
               top,
               74,
               18,
               "\u25b6 " + T.get("browse.play_all"),
               PlayerScreen.Icon.NONE,
               mx -> this.ctl.playAll(this.ctl.page())
            );
         }

         top += 22;
      }

      List<PlayerController.Tab> tabs = this.visibleTabs();
      if (!tabs.isEmpty()) {
         int cols = 2;
         int tw = (this.lw - 2) / cols;

         for (int i = 0; i < tabs.size(); i++) {
            PlayerController.Tab tb = tabs.get(i);
            PlayerScreen.Btn b = this.btn(
               PlayerScreen.Kind.GHOST, this.lx + i % cols * (tw + 2), top + i / cols * 18, tw, 16, this.tabLabel(tb), PlayerScreen.Icon.NONE, mx -> {
                  this.ctl.tab = tb;
                  this.page = 0;
                  if (tb == PlayerController.Tab.STATIONS) {
                     this.ctl.loadStations();
                  }
               }
            );
            b.on = () -> this.ctl.tab == tb;
         }

         top += (tabs.size() + cols - 1) / cols * 18 + 2;
      }

      this.listTop = top;
      int listBottom = this.py + this.ph - 34;
      this.rows = Math.max(1, (listBottom - this.listTop) / 24);

      for (int i = 0; i < this.rows; i++) {
         int row = i;
         int ry = this.listTop + i * 24;
         this.rowButton(this.lx, ry, this.lw - 32 - 4, () -> {
            int idx = this.page * this.rows + row;
            if (this.queueMode) {
               this.ctl.playQueued(idx);
            } else if (this.waveShown()) {
               this.ctl.playWaveIndex(idx);
            } else {
               List<?> list = this.items();
               if (idx < list.size()) {
                  if (list.get(idx) instanceof MusicEntity e) {
                     if (e.kind() == MusicEntity.Kind.STATION) {
                        this.ctl.startStation(e);
                     } else {
                        this.ctl.open(e);
                     }
                  } else {
                     Page pg2 = this.ctl.page();
                     List<Track> source = pg2 != null && pg2.tracks() == list ? pg2.tracks() : this.ctl.results;
                     this.ctl.playFrom(source, idx);
                  }
               }
            }
         });
         this.rowButton(this.lx + this.lw - 32 - 2, ry, 16, () -> {
            int idx = this.page * this.rows + row;
            if (this.queueMode) {
               this.ctl.queueMoveUp(idx);
            } else if (this.trackAt(idx) != null) {
               this.ctl.addToQueue(this.trackAt(idx));
            }
         });
         this.rowButton(this.lx + this.lw - 16, ry, 16, () -> {
            int idx = this.page * this.rows + row;
            if (this.queueMode) {
               this.ctl.queueRemove(idx);
            } else if (this.trackAt(idx) != null) {
               this.ctl.playNext(this.trackAt(idx));
            }
         });
      }

      PlayerScreen.Btn prevPage = this.btn(
         PlayerScreen.Kind.GHOST, this.lx, this.py + this.ph - 28, 34, 18, "", PlayerScreen.Icon.LEFT, mx -> this.page = Math.max(0, this.page - 1)
      );
      prevPage.enabled = () -> this.page > 0;
      PlayerScreen.Btn nextPage = this.btn(
         PlayerScreen.Kind.GHOST,
         this.lx + this.lw - 34,
         this.py + this.ph - 28,
         34,
         18,
         "",
         PlayerScreen.Icon.RIGHT,
         mx -> this.page = Math.min(this.maxPage(), this.page + 1)
      );
      nextPage.enabled = () -> this.page < this.maxPage();
      this.coverPx = this.pc.showCover ? Math.min(this.pc.coverPx, Math.max(40, this.ph - 190)) : 0;
      this.by = this.py + this.ph - 62;
      this.cy = this.py + this.ph - 24;
      this.lyTop = this.py + 30 + Math.max(this.coverPx, 44) + 10;
      this.lyBottom = this.by - 12;
      PlayerScreen.Btn seek = this.btn(PlayerScreen.Kind.BAR, this.rx, this.by - 6, this.rw, 14, "", PlayerScreen.Icon.NONE, mx -> {
         Track t = this.ctl.current;
         if (t != null) {
            this.draggingSeek = true;
            this.seekFrac = clamp01((mx - this.rx) / this.rw);
         }
      });
      seek.enabled = () -> this.ctl.current != null && !this.ctl.idle;
      int mw1 = 64;
      int mw2 = 84;
      int mgap = 6;
      int mx0 = this.rx + (this.rw - mw1 - mw2 - mgap) / 2;
      this.btn(PlayerScreen.Kind.GHOST, mx0, this.by + 8, mw1, 12, "", PlayerScreen.Icon.SHUFFLE, mx -> this.ctl.toggleShuffle());
      this.btn(PlayerScreen.Kind.GHOST, mx0 + mw1 + mgap, this.by + 8, mw2, 12, "", PlayerScreen.Icon.REPEAT, mx -> this.ctl.cycleRepeat());
      PlayerScreen.Btn like = this.btn(
         PlayerScreen.Kind.CIRCLE, this.rx + this.rw - 18, this.py + 32, 18, 18, "", PlayerScreen.Icon.LIKE, mx -> this.ctl.toggleLike()
      );
      like.enabled = () -> this.ctl.canLike(this.ctl.current);
      like.visible = () -> this.ctl.canLike(this.ctl.current);
      PlayerScreen.Btn dis = this.btn(
         PlayerScreen.Kind.CIRCLE, this.rx + this.rw - 40, this.py + 32, 18, 18, "", PlayerScreen.Icon.DISLIKE, mx -> this.ctl.waveDislike()
      );
      dis.enabled = () -> this.ctl.current != null && this.ctl.waveActive;
      dis.visible = () -> this.ctl.waveActive;
      int groupCx = this.rx + (this.rw - 120) / 2;
      int x = groupCx - 82;
      BooleanSupplier hasTrack = () -> this.ctl.current != null;
      BooleanSupplier playing = () -> this.ctl.current != null && !this.ctl.idle;
      this.btn(PlayerScreen.Kind.GHOST, x, this.cy - 9, 30, 18, "-10", PlayerScreen.Icon.NONE, mx -> this.ctl.seekBy(-10000L)).enabled = playing;
      x += 38;
      this.btn(PlayerScreen.Kind.CIRCLE, x, this.cy - 11, 22, 22, "", PlayerScreen.Icon.PREV, mx -> this.ctl.prev()).enabled = hasTrack;
      x += 30;
      this.btn(PlayerScreen.Kind.CIRCLE_BIG, x, this.cy - 14, 28, 28, "", PlayerScreen.Icon.PLAY, mx -> this.ctl.togglePause()).enabled = hasTrack;
      x += 36;
      this.btn(PlayerScreen.Kind.CIRCLE, x, this.cy - 11, 22, 22, "", PlayerScreen.Icon.NEXT, mx -> this.ctl.next()).enabled = hasTrack;
      x += 30;
      this.btn(PlayerScreen.Kind.GHOST, x, this.cy - 9, 30, 18, "+10", PlayerScreen.Icon.NONE, mx -> this.ctl.seekBy(10000L)).enabled = playing;
      this.volGroupX = this.rx + this.rw - 120;
      this.btn(PlayerScreen.Kind.CIRCLE, this.volGroupX, this.cy - 9, 18, 18, "", PlayerScreen.Icon.VOL, mx -> this.ctl.toggleMute());
      this.volBarX = this.volGroupX + 24;
      this.btn(PlayerScreen.Kind.BAR, this.volBarX, this.cy - 7, 64, 14, "", PlayerScreen.Icon.NONE, mx -> {
         this.draggingVolume = true;
         this.setVolumeFromMouse(mx);
      });
   }

   private void rowButton(int x, int y, int w, Runnable action) {
      Button b = Button.builder(Component.empty(), press -> action.run()).bounds(x, y, w, 22).build();
      this.addWidget(b);
   }

   private List<?> items() {
      if (this.queueMode) {
         return this.ctl.queueSnapshot();
      } else if (this.waveShown()) {
         return this.ctl.waveSnapshot();
      } else {
         Page pg = this.ctl.page();
         if (pg != null) {
            if (pg.tracks().isEmpty()) {
               return pg.entities();
            } else if (pg.entities().isEmpty()) {
               return pg.tracks();
            } else {
               return this.ctl.tab == PlayerController.Tab.ALBUMS ? pg.entities() : pg.tracks();
            }
         } else if (this.ctl.platform == Platform.YANDEX) {
            return switch (this.ctl.tab) {
               case ARTISTS -> this.ctl.artists;
               case ALBUMS -> this.ctl.albums;
               case PLAYLISTS -> this.ctl.playlists;
               case STATIONS -> this.ctl.stations;
               default -> this.ctl.results;
            };
         } else if (this.ctl.platform == Platform.SPOTIFY) {
            return switch (this.ctl.tab) {
               case PLAYLISTS -> this.ctl.playlists;
               default -> this.ctl.results;
            };
         } else {
            return this.ctl.results;
         }
      }
   }

   private Track hoveredTrack() {
      return this.mouseX >= this.lx && this.mouseX < this.lx + this.lw && this.mouseY >= this.listTop
         ? this.trackAt(this.page * this.rows + (this.mouseY - this.listTop) / 24)
         : null;
   }

   private Track trackAt(int idx) {
      List<?> list = this.items();
      return idx >= 0 && idx < list.size() && list.get(idx) instanceof Track t ? t : null;
   }

   private List<PlayerController.Tab> visibleTabs() {
      if (!this.queueMode && !this.waveShown() && (this.ctl.platform == Platform.YANDEX || this.ctl.platform == Platform.SPOTIFY)) {
         Page pg = this.ctl.page();
         if (pg != null) {
            return !pg.tracks().isEmpty() && !pg.entities().isEmpty() ? List.of(PlayerController.Tab.TRACKS, PlayerController.Tab.ALBUMS) : List.of();
         } else {
            return this.ctl.platform == Platform.SPOTIFY
               ? List.of(PlayerController.Tab.TRACKS, PlayerController.Tab.PLAYLISTS)
               : List.of(
                  PlayerController.Tab.TRACKS,
                  PlayerController.Tab.ARTISTS,
                  PlayerController.Tab.ALBUMS,
                  PlayerController.Tab.PLAYLISTS,
                  PlayerController.Tab.STATIONS
               );
         }
      } else {
         return List.of();
      }
   }

   private String tabLabel(PlayerController.Tab tb) {
      boolean inPage = this.ctl.page() != null;

      return switch (tb) {
         case ARTISTS -> T.get("browse.artists");
         case ALBUMS -> T.get("browse.albums");
         case PLAYLISTS -> T.get("browse.playlists");
         case STATIONS -> T.get("browse.stations");
         case TRACKS -> T.get(inPage ? "browse.popular" : "browse.tracks");
      };
   }

   private int viewSig() {
      return System.identityHashCode(this.ctl.page()) * 31 + this.visibleTabs().size() * 7 + (this.queueMode ? 1 : 0) + (this.waveShown() ? 2 : 0);
   }

   private boolean waveShown() {
      return this.ctl.waveActive && this.ctl.waveView;
   }

   private void doSearch() {
      if (this.searchBox != null) {
         this.page = 0;
         SessionState.get().query = this.searchBox.getValue();
         SessionState.markDirty();
         this.ctl.search(this.searchBox.getValue());
      }
   }

   private int maxPage() {
      return Math.max(0, (this.items().size() - 1) / Math.max(1, this.rows));
   }

   private void setVolumeFromMouse(double mx) {
      this.ctl.setVolume((float)clamp01((mx - this.volBarX) / 64.0));
   }

   private static boolean hit(int mx, int my, int x, int y, int w, int h) {
      return w > 0 && mx >= x && mx < x + w && my >= y && my < y + h;
   }

   private static void setRect(int[] r, int x, int y, int w, int h) {
      r[0] = x;
      r[1] = y;
      r[2] = w;
      r[3] = h;
   }

   @Override
   protected boolean onClick(double ex, double ey, int button, boolean doubleClick) {
      this.mouseX = (int)ex;
      this.mouseY = (int)ey;
      if (this.built == PlayerScreen.Mode.MAIN && this.ctl.current != null) {
         if (hit(this.mouseX, this.mouseY, this.artistRect[0], this.artistRect[1], this.artistRect[2], this.artistRect[3])) {
            this.page = 0;
            this.queueMode = false;
            this.ctl.openArtistOf(this.ctl.current);
            return true;
         }

         if (hit(this.mouseX, this.mouseY, this.albumRect[0], this.albumRect[1], this.albumRect[2], this.albumRect[3])) {
            this.page = 0;
            this.queueMode = false;
            this.ctl.openAlbumOf(this.ctl.current);
            return true;
         }
      }

      return super.onClick(ex, ey, button, doubleClick);
   }

   private static double clamp01(double v) {
      return Math.max(0.0, Math.min(1.0, v));
   }

   public void removed() {
      if (this.searchBox != null) {
         SessionState.get().query = this.searchBox.getValue();
         SessionState.markDirty();
      }

      GuiFit.restore();
      super.removed();
   }

   public void tick() {
      if (!this.helpChecked) {
         this.helpChecked = true;
         SessionState st = SessionState.get();
         if (!st.helpSeen) {
            st.helpSeen = true;
            SessionState.markDirty();
            Game.open(new HelpScreen(this));
            return;
         }
      }

      int account = this.accountState();
      if (this.linkOpen && account != this.accountBuilt) {
         this.linkOpen = false;
      }

      if (this.modeNow() != this.built || account != this.accountBuilt || this.built == PlayerScreen.Mode.MAIN && this.viewSig() != this.builtSig) {
         this.rebuildWidgets();
      }
   }

   @Override
   protected boolean onDrag(double ex, double ey, int button, double dragX, double dragY) {
      this.mouseX = (int)ex;
      this.mouseY = (int)ey;
      if (this.draggingVolume) {
         this.setVolumeFromMouse(this.mouseX);
         return true;
      } else if (this.draggingSeek) {
         this.seekFrac = clamp01((this.mouseX - this.rx) / this.rw);
         return true;
      } else {
         return super.onDrag(ex, ey, button, dragX, dragY);
      }
   }

   @Override
   protected boolean onRelease(double ex, double ey, int button) {
      this.draggingVolume = false;
      if (this.draggingSeek) {
         this.draggingSeek = false;
         Track t = this.ctl.current;
         if (t != null) {
            this.ctl.seekTo((long)(this.seekFrac * t.durationMs()));
         }

         return true;
      } else {
         return super.onRelease(ex, ey, button);
      }
   }

   @Override
   public boolean mouseScrolled(double mx0, double my0, double sx, double sy) {
      double mx = this.mouseX;
      double my = this.mouseY;
      if (this.built == PlayerScreen.Mode.MAIN) {
         if (mx >= this.volGroupX && mx < this.volGroupX + 120 && my >= this.cy - 12 && my < this.cy + 12) {
            this.ctl.changeVolume(sy > 0.0 ? 0.05F : -0.05F);
            return true;
         }

         if (mx < this.rx - 8) {
            if (sy < 0.0) {
               this.page = Math.min(this.maxPage(), this.page + 1);
            } else if (sy > 0.0) {
               this.page = Math.max(0, this.page - 1);
            }

            return true;
         }
      }

      int viewH = this.lyBottom - this.lyTop;
      this.manualPx = Math.max(0.0, Math.min((double)Math.max(0, this.totalH - viewH), this.manualPx - sy * 30.0));
      return super.mouseScrolled(mx, my, sx, sy);
   }

   @Override
   protected boolean onKey(KeyInput event) {
      int key = event.key();
      boolean searching = this.searchBox != null && this.searchBox.isFocused();
      boolean typing = searching || this.tokenBox != null && this.tokenBox.isFocused();
      if (typing) {
         if (!searching || key != 257 && key != 335) {
            return super.onKey(event);
         } else {
            this.doSearch();
            return true;
         }
      } else {
         if (key == 261 && this.ctl.platform == Platform.LOCAL && !this.queueMode) {
            Track hovered = this.hoveredTrack();
            if (hovered != null) {
               this.ctl.removeLocal(hovered);
               return true;
            }
         }

         Hotkeys.Action a = Hotkeys.actionFor(event);
         if (a == Hotkeys.Action.OPEN_PLAYER) {
            this.onClose();
            return true;
         } else if (a == null || this.built != PlayerScreen.Mode.MAIN && a.isTransport()) {
            return super.onKey(event);
         } else {
            Hotkeys.perform(a, this);
            return true;
         }
      }
   }

   @Override
   protected void draw(Canvas g, int mx, int my, float delta) {
      this.mouseX = mx;
      this.mouseY = my;
      long frameNs = System.nanoTime();
      this.dt = this.lastFrameNs == 0L ? 0.016F : Math.min(0.1F, (float)(frameNs - this.lastFrameNs) / 1.0E9F);
      this.lastFrameNs = frameNs;
      this.th = PlayerTheme.current();
      int r = this.th.radius;
      float ot = Math.min(1.0F, (float)(System.nanoTime() - this.openStart) / 2.6E8F);
      float oe = 1.0F - (1.0F - ot) * (1.0F - ot) * (1.0F - ot);
      int dimA = Math.round((this.th.dim >>> 24) * oe);
      g.fill(0, 0, this.width, this.height, dimA << 24 | this.th.dim & 16777215);
      boolean opening = oe < 1.0F;
      if (opening) {
         float sc = 0.94F + 0.06F * oe;
         float ccx = this.px + this.pw / 2.0F;
         float ccy = this.py + this.ph / 2.0F;
         g.pushMatrix();
         g.translate(ccx, ccy + (1.0F - oe) * 12.0F);
         g.scale(sc, sc);
         g.translate(-ccx, -ccy);
      }

      this.th.window(g, this.px, this.py, this.pw, this.ph);
      g.fill(this.px + 10, this.py + 24, this.px + this.pw - 10, this.py + 25, PlayerTheme.argb(16777215, 16));
      String title = "\u266a Overtone";
      g.text(this.font, title, this.px + 14, this.py + 9, this.th.accent);
      int leftEnd = this.chipEnd;
      MusicProvider ap = this.ctl.active();
      String acc = ap != null && this.built != PlayerScreen.Mode.PICKER ? ap.accountName() : "";
      if (!acc.isEmpty()) {
         String shownAcc = this.font.plainSubstrByWidth("\u00b7 " + acc, Math.max(30, this.pw / 6));
         g.text(this.font, shownAcc, this.chipEnd + 6, this.py + 9, -9539972);
         leftEnd = this.chipEnd + 6 + this.font.width(shownAcc);
      }

      this.drawStatus(g, leftEnd);
      switch (this.built) {
         case MAIN:
            this.renderMain(g);
            break;
         case LOGIN:
            this.renderLogin(g);
            break;
         case PICKER:
            this.renderPicker(g);
      }

      boolean mainNow = this.built == PlayerScreen.Mode.MAIN && this.ctl.current != null;
      Hit.place(this.artistHit, this.artistRect, mainNow);
      Hit.place(this.albumHit, this.albumRect, mainNow);
      this.drawField(g);

      for (PlayerScreen.Btn b : this.btns) {
         this.drawBtn(g, b);
      }

      this.drawWidgets(g, mx, my, delta);
      float shown = Math.min(1.0F, (float)(System.nanoTime() - this.builtAt) / 1.8E8F);
      if (!opening && shown < 1.0F && this.built != PlayerScreen.Mode.PICKER) {
         PlayerTheme.rrect(
            g, this.px, this.py + 26, this.pw, this.ph - 26, r, PlayerTheme.argb(this.th.panelBottom, Math.round(200.0F * (1.0F - shown) * (1.0F - shown)))
         );
      }

      if (opening) {
         float inv = 1.0F - oe;
         PlayerTheme.rrect(g, this.px - 1, this.py - 1, this.pw + 2, this.ph + 2, r + 1, PlayerTheme.argb(1184538, Math.round(255.0F * inv * inv)));
         g.popMatrix();
      }
   }

   private float smooth(float current, boolean on) {
      return current + ((on ? 1.0F : 0.0F) - current) * (1.0F - (float)Math.exp(-this.dt * 16.0F));
   }

   private static int blend(int from, int to, float t) {
      return 0xFF000000 | PlayerTheme.mix(from, to, t);
   }

   private static int fade(int argb, float k) {
      return Math.round((argb >>> 24) * Math.max(0.0F, Math.min(1.0F, k))) << 24 | argb & 16777215;
   }

   private void drawField(Canvas g) {
      if (this.field != null) {
         int br = Math.min(this.th.radius, 4);
         PlayerTheme.rrect(g, this.fx - 1, this.fy - 1, this.fw + 2, this.fh + 2, br + 1, this.field.isFocused() ? this.th.accent : this.th.trackBg);
         PlayerTheme.rrect(g, this.fx, this.fy, this.fw, this.fh, br, this.th.fieldBg);
      }
   }

   private void drawStatus(Canvas g, int leftEnd) {
      String st = this.ctl.status;
      if (!st.isEmpty()) {
         int pct = this.ctl.loadingPercent();
         if (pct >= 0 && st.equals(T.get("status.loading_track"))) {
            st = st + " " + pct + "%";
         }

         int rightEdge = this.px + this.pw - 12 - this.headerButtonsW - 8;
         int room = Math.max(40, rightEdge - leftEnd - 10);
         if (this.font.width(st) <= room) {
            g.text(this.font, st, rightEdge - this.font.width(st), this.py + 9, -2052248);
         } else {
            List<FormattedCharSequence> lines = this.font.split(Component.literal(st), this.pw - 40);
            int y = this.py + 29;
            int shownLines = Math.min(2, lines.size());
            PlayerTheme.rrect(g, this.px + 14, y - 3, this.pw - 28, shownLines * (9 + 1) + 5, 4, PlayerTheme.argb(0, 170));

            for (int i = 0; i < shownLines; i++) {
               g.text(this.font, lines.get(i), this.px + 20, y + i * (9 + 1), -2052248);
            }
         }
      }
   }

   private void renderPicker(Canvas g) {
      int cx = this.px + this.pw / 2;
      this.center(g, T.get("picker.title"), cx, this.py + 34, -1);
      this.center(g, T.get("picker.sub"), cx, this.py + 46, -9539972);
      this.center(g, T.get("picker.privacy"), cx, this.py + this.ph - 20, -9539972);
   }

   private void renderLogin(Canvas g) {
      int cx = this.px + this.pw / 2;
      if (this.ctl.platform == Platform.SOUNDCLOUD) {
         this.center(g, T.get("login.sc_title"), cx, this.py + 34, -1);
         this.center(g, T.get("login.sc_1"), cx, this.py + 50, -4934464);
         this.center(g, T.get("login.sc_2"), cx, this.py + 62, -4934464);
         this.center(g, T.get("login.sc_privacy"), cx, this.py + 198, -9539972);
      } else if (this.ctl.platform == Platform.SPOTIFY) {
         this.center(g, T.get("login.sp_title"), cx, this.py + 30, -1);
         this.center(g, T.get("login.sp_1"), cx, this.py + 44, -4934464);
         this.center(g, "Redirect URI: http://127.0.0.1:43821/callback", cx, this.py + 56, -1);
         this.center(g, T.get("login.sp_2"), cx, this.py + 68, -4934464);
         this.center(g, T.get("login.sp_3"), cx, this.py + 80, -4934464);
         this.center(g, T.get("login.sp_privacy"), cx, this.py + 198, -9539972);
      } else if (this.ctl.platform == Platform.YANDEX) {
         if (!this.addAccountMode) {
            this.center(g, T.get("login.choose"), cx, this.py + 36, -1);
            this.center(g, T.get("login.saved_sub"), cx, this.py + 46, -9539972);
            int n = Math.min(4, this.savedAccounts.size());
            int more = this.savedAccounts.size() - n;
            if (more > 0) {
               this.center(g, T.get("login.more", more, n), cx, this.py + 56 + n * 26 + 34, -9539972);
            }

            this.center(g, T.get("login.forget"), cx, this.py + this.ph - 20, -9539972);
         } else {
            this.center(g, T.get("login.ya_title"), cx, this.py + 36, -1);
            this.center(g, T.get("login.ya_1"), cx, this.py + 52, -4934464);
            this.center(g, T.get("login.ya_2"), cx, this.py + 64, -4934464);
            this.center(g, T.get("login.ya_privacy"), cx, this.py + 198, -9539972);
         }
      }
   }

   private void renderMain(Canvas g) {
      PlayerTheme.rrect(g, this.px + 8, this.py + 26, this.lw + 8, this.ph - 34, Math.max(0, this.th.radius - 2), this.th.panel2);
      this.drawList(g);
      this.center(g, this.page + 1 + " / " + (this.maxPage() + 1), this.lx + this.lw / 2, this.py + this.ph - 24, -9539972);
      this.drawVolume(g);
      Track t = this.ctl.current;
      if (t == null) {
         setRect(this.artistRect, 0, 0, 0, 0);
         setRect(this.albumRect, 0, 0, 0, 0);
         int midY = this.py + 40 + (this.by - this.py - 40) / 2 - 8;
         if (this.ctl.platform == Platform.LOCAL) {
            this.center(g, T.get("player.drop"), this.rx + this.rw / 2, midY, -4934464);
            this.center(g, T.get("player.drop2"), this.rx + this.rw / 2, midY + 12, -9539972);
         } else {
            this.center(g, T.get("player.empty"), this.rx + this.rw / 2, midY, -4934464);
         }

         this.drawProgress(g, null);
      } else {
         long nowNs = System.nanoTime();
         if (t.id() != null && !t.id().equals(this.animTrackId)) {
            this.animTrackId = t.id();
            this.animStart = nowNs;
         }

         float ap = Math.min(1.0F, (float)(nowNs - this.animStart) / 4.5E8F);
         float ae = 1.0F - (1.0F - ap) * (1.0F - ap) * (1.0F - ap);
         int slide = Math.round((1.0F - ae) * 14.0F);
         int aa = Math.max(5, Math.round(255.0F * ae));
         double secs = nowNs / 1.0E9;
         boolean wave = this.ctl.waveActive;
         int textX = this.rx;
         if (this.coverPx > 0) {
            CoverArt.offerBig(t.id(), t.coverUrl());
            Tex art = CoverArt.getBig(t.id());
            int cs = Math.round(this.coverPx * (0.9F + 0.1F * ae));
            int cx0 = this.rx + (this.coverPx - cs) / 2;
            int cy0 = this.py + 32 + (this.coverPx - cs) / 2;
            if (wave && this.ctl.engine().isPlaying()) {
               this.drawWaveGlow(g, this.rx, this.py + 32, this.coverPx, secs);
            }

            PlayerTheme.rrect(g, cx0 + 2, cy0 + 4, cs, cs, 8, PlayerTheme.argb(0, Math.round(85.0F * ae)));
            if (art != null) {
               g.texture(art, cx0, cy0, cs, cs, 256, ae);
            } else {
               PlayerTheme.rrect(g, cx0, cy0, cs, cs, 8, this.th.trackBg);
               this.center(g, "\u266a", cx0 + cs / 2, cy0 + (cs - 9) / 2 + 1, -9539972);
            }

            textX = this.rx + this.coverPx + 14;
         }

         int availW = this.rx + this.rw - textX - (wave ? 46 : 24);
         float ts = this.coverPx >= 60 ? 1.5F : 1.0F;
         int titleColor = PlayerTheme.argb(this.pc.accentText ? this.th.accent : -1, aa);
         int midColor = PlayerTheme.argb(-4934464, aa);
         int dimColor = PlayerTheme.argb(-9539972, aa);
         boolean showBadge = wave && this.coverPx >= 60;
         int blockH = Math.round(9.0F * ts) + 4 + 9 + (this.coverPx >= 60 ? 2 + 9 : 0) + (showBadge ? 16 : 0);
         int ty = this.py + 32 + Math.max(0, (Math.max(this.coverPx, 44) - blockH) / 2);
         g.push(ts);
         g.text(g.trim(nz(t.title()), Math.round(availW / ts)), Math.round((textX + slide) / ts), Math.round(ty / ts), titleColor, true);
         g.pop();
         int ay = ty + Math.round(9.0F * ts) + 4;
         String artistText = this.font.plainSubstrByWidth(nz(t.artist()), availW);
         boolean yandexTrack = t.provider() == null || "yandex".equals(t.provider());
         boolean overArtist = yandexTrack && hit(this.mouseX, this.mouseY, textX, ay, this.font.width(artistText), 9);
         g.text(this.font, artistText, textX + slide, ay, overArtist ? this.th.accent : midColor);
         setRect(this.artistRect, yandexTrack && !artistText.isEmpty() ? textX : 0, ay, this.font.width(artistText), 9);
         int nextY = ay + 9 + 2;
         setRect(this.albumRect, 0, 0, 0, 0);
         if (this.coverPx >= 60 && t.album() != null && !t.album().isBlank()) {
            String albumText = this.font.plainSubstrByWidth(t.album(), availW);
            boolean overAlbum = yandexTrack && hit(this.mouseX, this.mouseY, textX, nextY, this.font.width(albumText), 9);
            g.text(this.font, albumText, textX + slide, nextY, overAlbum ? this.th.accent : dimColor);
            if (yandexTrack) {
               setRect(this.albumRect, textX, nextY, this.font.width(albumText), 9);
            }

            nextY += 9 + 2;
         }

         if (showBadge) {
            String bl = T.get("player.wave");
            int bw = this.font.width(bl) + 14;
            this.drawWaveGradient(g, textX + slide, nextY + 3, bw, 11, 5, aa, secs * 0.35);
            g.text(this.font, bl, textX + slide + 7, nextY + 5, PlayerTheme.argb(16777215, aa));
         }

         if (this.pc.showLyrics && this.lyBottom - this.lyTop > 24) {
            this.renderLyrics(g);
         }

         this.drawProgress(g, t);
      }
   }

   private void renderLyrics(Canvas g) {
      PlayerTheme.rrect(g, this.rx - 4, this.lyTop - 4, this.rw + 8, this.lyBottom - this.lyTop + 8, 4, PlayerTheme.argb(this.th.panel2, 150));
      int midX = this.rx + this.rw / 2;
      if (this.ctl.idle) {
         this.center(g, T.get("player.press_play"), midX, (this.lyTop + this.lyBottom) / 2 - 4, -9539972);
      } else {
         List<LyricLine> src = this.ctl.lyrics;
         if (src.isEmpty()) {
            this.center(g, T.get(this.ctl.lyricsLoading ? "player.lyrics_loading" : "player.lyrics_none"), midX, (this.lyTop + this.lyBottom) / 2 - 4, -9539972);
         } else {
            this.ensureWrapped(src);
            long pos = this.ctl.engine().positionMs();
            boolean synced = src.get(0).timeMs() != Long.MAX_VALUE;
            int cur = synced ? LrcParser.currentIndex(src, pos) : -1;
            int lh = 9 + 2;
            int viewH = this.lyBottom - this.lyTop;
            double target = synced ? (cur >= 0 ? this.tops[cur] + this.wrapped.get(cur).size() * lh / 2.0 : 0.0) : this.manualPx;
            this.scrollPx = this.scrollPx + (target - this.scrollPx) * (1.0 - Math.exp(-this.dt * 10.0));
            int origin = synced ? this.lyTop + viewH / 2 : this.lyTop + 4;

            for (int i = 0; i < this.wrapped.size(); i++) {
               int y = origin + this.tops[i] - (int)this.scrollPx;
               int h = this.wrapped.get(i).size() * lh;
               if (y >= this.lyTop && y + h <= this.lyBottom) {
                  int color;
                  if (!synced) {
                     color = -4934464;
                  } else if (i == cur) {
                     color = this.th.accent;
                  } else {
                     float near = Math.max(0.0F, 1.0F - Math.abs(i - cur) / 4.0F);
                     color = 0xFF000000 | PlayerTheme.mix(-9539972, -4934464, near);
                  }

                  for (int k = 0; k < this.wrapped.get(i).size(); k++) {
                     g.text(this.font, this.wrapped.get(i).get(k), this.rx + 4, y + k * lh, color);
                  }
               }
            }
         }
      }
   }

   private void drawProgress(Canvas g, Track t) {
      long dur = t == null ? 0L : Math.max(1L, t.durationMs());
      long pos = t != null && !this.ctl.idle ? this.ctl.engine().positionMs() : 0L;
      if (this.draggingSeek) {
         pos = (long)(this.seekFrac * dur);
      }

      boolean hover = t != null
         && !this.ctl.idle
         && (this.draggingSeek || this.mouseX >= this.rx && this.mouseX < this.rx + this.rw && this.mouseY >= this.by - 6 && this.mouseY < this.by + 10);
      this.seekGlow = this.smooth(this.seekGlow, hover);
      int bh = 4 + Math.round(this.seekGlow * 2.0F);
      int barY = this.by + 2 - bh / 2;
      PlayerTheme.rrect(g, this.rx, barY, this.rw, bh, bh / 2, this.th.trackBg);
      int fill = dur == 0L ? 0 : (int)(this.rw * Math.min(1.0, (double)pos / dur));
      if (fill > 0) {
         PlayerTheme.rrect(g, this.rx, barY, Math.max(bh, fill), bh, bh / 2, this.th.accent);
      }

      if (t != null) {
         int kx = Math.max(this.rx + 4, Math.min(this.rx + this.rw - 4, this.rx + fill));
         PlayerTheme.circle(g, kx, this.by + 2, 5 + Math.round(this.seekGlow), this.th.accent);
         PlayerTheme.circle(g, kx, this.by + 2, 2 + Math.round(this.seekGlow), -1);
      }

      g.text(this.font, fmt(pos), this.rx, this.by + 10, -4934464);
      String d = fmt(dur);
      g.text(this.font, d, this.rx + this.rw - this.font.width(d), this.by + 10, -9539972);
      if (hover) {
         long hoverMs = (long)(clamp01((double)(this.mouseX - this.rx) / this.rw) * dur);
         String s = fmt(hoverMs);
         int sx = Math.max(this.rx, Math.min(this.rx + this.rw - this.font.width(s) - 8, this.mouseX - this.font.width(s) / 2 - 4));
         PlayerTheme.rrect(g, sx, this.by - 20, this.font.width(s) + 8, 12, 3, this.th.fieldBg);
         g.text(this.font, s, sx + 4, this.by - 18, -1);
      }
   }

   private void drawVolume(Canvas g) {
      int bh = 4;
      int barY = this.cy - bh / 2;
      PlayerTheme.rrect(g, this.volBarX, barY, 64, bh, 2, this.th.trackBg);
      int fill = Math.round(64.0F * this.ctl.volume);
      if (fill > 0) {
         PlayerTheme.rrect(g, this.volBarX, barY, Math.max(bh, fill), bh, 2, this.th.accent);
      }

      PlayerTheme.circle(g, Math.max(this.volBarX + 3, Math.min(this.volBarX + 64 - 3, this.volBarX + fill)), this.cy, 4, -1);
      g.text(this.font, Math.round(this.ctl.volume * 100.0F) + "%", this.volBarX + 64 + 6, this.cy - 9 / 2 + 1, -9539972);
   }

   private void drawList(Canvas g) {
      List<?> res = this.items();
      Page pg = this.ctl.page();
      if (pg != null) {
         String title = this.font
            .plainSubstrByWidth(pg.source().isMine() ? T.get("entity.mine") : pg.source().title(), this.lw - 54 - (pg.tracks().isEmpty() ? 0 : 74) - 12);
         g.text(this.font, title, this.lx + 60, this.pageHeaderY + 5, -1);
      }

      if (res.isEmpty()) {
         boolean local = this.ctl.platform == Platform.LOCAL;
         this.center(
            g,
            T.get(
               this.queueMode
                  ? "player.queue_empty"
                  : (!this.ctl.waveLoading && !this.ctl.stationsLoading ? (local ? "player.no_files" : "player.tracks_here") : "player.wave_loading")
            ),
            this.lx + this.lw / 2,
            this.listTop + 14,
            -9539972
         );
         if (this.queueMode) {
            this.center(g, T.get("player.queue_hint"), this.lx + this.lw / 2, this.listTop + 28, -9539972);
         } else if (local) {
            this.center(g, T.get("player.drop_short"), this.lx + this.lw / 2, this.listTop + 28, -9539972);
         }
      } else {
         this.page = Math.max(0, Math.min(this.page, this.maxPage()));
         Track cur = this.ctl.current;
         String curId = cur == null ? null : cur.id();
         int textW = this.lw - 18 - 32;

         for (int i = 0; i < this.rows; i++) {
            int idx = this.page * this.rows + i;
            if (idx >= res.size()) {
               break;
            }

            Object item = res.get(idx);
            Track t = item instanceof Track tr ? tr : null;
            int y = this.listTop + i * 24;
            boolean isCur = t != null && t.id() != null && t.id().equals(curId);
            boolean hov = this.mouseX >= this.lx && this.mouseX < this.lx + this.lw && this.mouseY >= y && this.mouseY < y + 24 - 2;
            this.rowGlow[i] = this.smooth(this.rowGlow[i], hov && !isCur);
            if (isCur) {
               PlayerTheme.rrect(g, this.lx, y, this.lw, 22, 4, this.th.rowCurrent);
               this.drawEqualizer(g, this.lx + 5, y + 4, 14, this.ctl.engine().isPlaying());
            } else if (this.rowGlow[i] > 0.02F) {
               PlayerTheme.rrect(g, this.lx, y, this.lw, 22, 4, blend(this.th.panel2, this.th.hover, this.rowGlow[i]));
            }

            if (t == null) {
               this.drawEntityRow(g, (MusicEntity)item, y, hov);
            } else {
               int tx = isCur ? this.lx + 16 : this.lx + 8;
               int tw = isCur ? textW - 8 : textW;
               g.text(this.font, this.font.plainSubstrByWidth(nz(t.title()), tw), tx, y + 3, isCur ? this.th.accent : -1);
               g.text(this.font, this.font.plainSubstrByWidth(nz(t.artist()), tw), tx, y + 3 + 9, -9539972);
               if (!hov && !isCur && this.ctl.provider(t).isCached(t.id())) {
                  PlayerTheme.circle(g, this.lx + this.lw - 16 - 4, y + 11, 2, PlayerTheme.argb(this.th.accentRgb, 150));
               }

               if (hov || isCur) {
                  String a1 = this.queueMode ? "^" : "+";
                  String a2 = this.queueMode ? "x" : ">";
                  int ax1 = this.lx + this.lw - 32 - 2;
                  int ax2 = this.lx + this.lw - 16;
                  boolean h1 = this.mouseX >= ax1 && this.mouseX < ax1 + 16 && this.mouseY >= y && this.mouseY < y + 24 - 2;
                  boolean h2 = this.mouseX >= ax2 && this.mouseX < ax2 + 16 && this.mouseY >= y && this.mouseY < y + 24 - 2;
                  PlayerTheme.rrect(g, ax1 + 1, y + 3, 14, 16, 3, h1 ? this.th.accent : this.th.trackBg);
                  PlayerTheme.rrect(g, ax2 + 1, y + 3, 14, 16, 3, h2 ? this.th.accent : this.th.trackBg);
                  this.center(g, a1, ax1 + 8, y + (22 - 9) / 2 + 1, -1);
                  this.center(g, a2, ax2 + 8, y + (22 - 9) / 2 + 1, -1);
               }
            }
         }
      }
   }

   private void drawEntityRow(Canvas g, MusicEntity e, int y, boolean hov) {
      int size = 18;
      boolean artist = e.kind() == MusicEntity.Kind.ARTIST;
      boolean playing = e.kind() == MusicEntity.Kind.STATION && this.ctl.waveActive && e.id().equals(this.ctl.waveSeed);
      int box = !e.isMine() && !playing ? PlayerTheme.argb(this.th.accentRgb, hov ? 160 : 110) : this.th.accent;
      if (artist) {
         PlayerTheme.circle(g, this.lx + 4 + size / 2, y + 2 + size / 2, size / 2, box);
      } else {
         PlayerTheme.rrect(g, this.lx + 4, y + 2, size, size, 4, box);
      }

      String letter = e.isMine() ? "\u2605" : (e.title().isEmpty() ? "?" : e.title().substring(0, 1).toUpperCase());
      g.text(this.font, letter, this.lx + 4 + (size - this.font.width(letter)) / 2, y + 2 + (size - 9) / 2 + 1, -1);
      int tx = this.lx + size + 10;
      int tw = this.lw - size - 16;
      String title = e.isMine() ? T.get("entity.mine") : e.title();
      String sub = e.isMine() ? T.get("entity.mine_sub") : e.subtitle();
      g.text(this.font, this.font.plainSubstrByWidth(title, tw), tx, y + 3, hov ? this.th.accent : -1);
      g.text(this.font, this.font.plainSubstrByWidth(sub, tw), tx, y + 3 + 9, -9539972);
   }

   private void drawBtn(Canvas g, PlayerScreen.Btn b) {
      if (b.kind != PlayerScreen.Kind.BAR) {
         if (b.visible.getAsBoolean()) {
            if (b.kind == PlayerScreen.Kind.WAVE) {
               this.drawWaveButton(g, b);
            } else if (b.kind == PlayerScreen.Kind.CARD) {
               this.drawCard(g, b);
            } else if (b.kind == PlayerScreen.Kind.CHIP) {
               this.drawChip(g, b);
            } else {
               boolean enabled = b.enabled.getAsBoolean();
               boolean hov = enabled && b.contains(this.mouseX, this.mouseY);
               b.glow = this.smooth(b.glow, hov);
               int br = Math.min(this.th.radius + 1, b.h / 2);
               int cxB = b.x + b.w / 2;
               int cyB = b.y + b.h / 2;
               switch (b.kind) {
                  case PRIMARY: {
                     int bg = !enabled ? this.th.trackBg : blend(this.th.accent, this.th.accentHover, b.glow);
                     PlayerTheme.rrect(g, b.x, b.y + 1, b.w, b.h, br, 1140850688);
                     PlayerTheme.rrect(g, b.x, b.y, b.w, b.h, br, bg);
                     this.center(g, b.label, cxB, b.y + (b.h - 9) / 2 + 1, -1);
                     break;
                  }
                  case GHOST:
                     PlayerTheme.rrect(g, b.x, b.y, b.w, b.h, br, blend(this.th.trackBg, this.th.hover, b.glow));
                     int fg = !enabled ? -9539972 : blend(-4934464, -1, b.glow);
                     if (b.on.getAsBoolean()) {
                        fg = this.th.accent;
                     }

                     String label = b.label;
                     switch (b.icon) {
                        case SHUFFLE:
                           label = T.get("player.shuffle");
                           if (this.ctl.shuffle) {
                              fg = this.th.accent;
                           }
                           break;
                        case REPEAT:
                           label = T.get("player.repeat", T.get("repeat." + this.ctl.repeat.name().toLowerCase()));
                           if (this.ctl.repeat != PlayerController.Repeat.OFF) {
                              fg = this.th.accent;
                           }
                           break;
                        case QUEUE:
                           label = T.get("player.queue") + " " + this.ctl.queueSnapshot().size();
                           if (this.queueMode) {
                              fg = this.th.accent;
                           }
                     }

                     if (b.icon == PlayerScreen.Icon.HEART) {
                        int tw = this.font.width(b.label);
                        int gx = cxB - (13 + tw) / 2;
                        PlayerTheme.iconHeart(g, gx, cyB - 3, this.th.accent);
                        g.text(this.font, b.label, gx + 7 + 6, b.y + (b.h - 9) / 2 + 1, fg);
                     } else if (b.icon != PlayerScreen.Icon.LEFT && b.icon != PlayerScreen.Icon.RIGHT) {
                        this.center(g, label, cxB, b.y + (b.h - 9) / 2 + 1, fg);
                     } else {
                        PlayerTheme.tri(g, cxB - 2, cyB, 5, 9, b.icon == PlayerScreen.Icon.RIGHT, fg);
                     }
                     break;
                  case CIRCLE:
                  case CIRCLE_BIG: {
                     boolean big = b.kind == PlayerScreen.Kind.CIRCLE_BIG;
                     int r = b.w / 2;
                     int bg = big
                        ? (!enabled ? this.th.trackBg : blend(this.th.accent, this.th.accentHover, b.glow))
                        : blend(this.th.trackBg, this.th.hover, b.glow);
                     if (big) {
                        PlayerTheme.circle(g, cxB, cyB + 1, r, 1140850688);
                     }

                     PlayerTheme.circle(g, cxB, cyB, r, bg);
                     int fg = !big && !hov ? (enabled ? -4934464 : -9539972) : -1;
                     this.drawIcon(g, b.icon, cxB, cyB, fg);
                  }
               }
            }
         }
      }
   }

   private void drawChip(Canvas g, PlayerScreen.Btn b) {
      b.glow = this.smooth(b.glow, b.contains(this.mouseX, this.mouseY));
      PlayerTheme.rrect(g, b.x, b.y, b.w, b.h, Math.min(this.th.radius + 1, b.h / 2), blend(this.th.trackBg, this.th.hover, b.glow));
      PlatformIcons.draw(g, b.plat, b.x + 3, b.y + 2, 12);
      g.text(this.font, b.label, b.x + 19, b.y + (b.h - 9) / 2 + 1, blend(-4934464, -1, b.glow));
   }

   private float cardEnter(int order) {
      float ms = (float)(System.nanoTime() - this.builtAt) / 1000000.0F - order * 60.0F;
      float e = Math.max(0.0F, Math.min(1.0F, ms / 240.0F));
      return 1.0F - (1.0F - e) * (1.0F - e) * (1.0F - e);
   }

   private void drawCard(Canvas g, PlayerScreen.Btn b) {
      Platform pl = b.plat;
      b.glow = this.smooth(b.glow, b.contains(this.mouseX, this.mouseY));
      float enter = this.cardEnter(b.order);
      if (!(enter < 0.06F)) {
         boolean sliding = enter < 1.0F;
         if (sliding) {
            g.pushMatrix();
            g.translate(0.0F, (1.0F - enter) * 10.0F);
         }

         int y = b.y - Math.round(b.glow * 2.0F);
         int br = Math.min(this.th.radius + 3, 10);
         if (pl == this.ctl.platform) {
            PlayerTheme.rrect(g, b.x - 1, y - 1, b.w + 2, b.h + 2, br + 1, fade(this.th.accent, enter));
         } else if (b.glow > 0.03F) {
            PlayerTheme.rrect(g, b.x - 1, y - 1, b.w + 2, b.h + 2, br + 1, PlayerTheme.argb(this.th.accentRgb, Math.round(120.0F * b.glow)));
         }

         PlayerTheme.rrect(g, b.x, y, b.w, b.h, br, fade(blend(this.th.trackBg, this.th.hover, b.glow), enter));
         int size = 30;
         int ix = b.x + 11;
         PlatformIcons.draw(g, pl, ix, y + (b.h - size) / 2, size);
         int tx = ix + size + 11;
         int tw = b.w - (tx - b.x) - 20;
         int ty = y + (b.h - 9 * 2 - 3) / 2;
         g.text(this.font, this.font.plainSubstrByWidth(pl.title(), tw), tx, ty, fade(-1, enter));
         g.text(this.font, this.font.plainSubstrByWidth(this.cardSubtitle(pl), tw), tx, ty + 9 + 3, fade(-9539972, enter));
         if (this.cardReady(pl)) {
            boolean live = this.ctl.current != null && this.ctl.provider(this.ctl.current) == this.ctl.provider(pl) && this.ctl.engine().isPlaying();
            int alpha = live ? 170 + (int)(85.0 * Math.sin(System.nanoTime() / 1.0E9 * 4.0)) : 255;
            PlayerTheme.circle(g, b.x + b.w - 12, y + b.h / 2, 3, PlayerTheme.argb(4906624, alpha));
         }

         if (sliding) {
            g.popMatrix();
         }
      }
   }

   private boolean cardReady(Platform pl) {
      MusicProvider pr = this.ctl.provider(pl);
      return pr != null && pr.isLoggedIn();
   }

   private String cardSubtitle(Platform pl) {
      MusicProvider pr = this.ctl.provider(pl);
      if (pr == null) {
         return "";
      } else if (!pl.needsLogin) {
         return pr.accountName().isBlank() ? T.get("card.no_account") : pr.accountName();
      } else if (!pr.isLoggedIn()) {
         return T.get("card.need_login");
      } else {
         return pr.accountName().isBlank() ? T.get("card.logged_in") : pr.accountName();
      }
   }

   private void drawIcon(Canvas g, PlayerScreen.Icon icon, int cx, int cy, int color) {
      switch (icon) {
         case PLAY:
            if (this.ctl.engine().isPlaying()) {
               PlayerTheme.iconPause(g, cx, cy, 11, color);
            } else {
               PlayerTheme.iconPlay(g, cx, cy, 12, color);
            }
            break;
         case LIKE:
            PlayerTheme.iconHeart(g, cx - 3, cy - 3, this.ctl.isLiked(this.ctl.current) ? this.th.accent : color);
            break;
         case DISLIKE:
            for (int i = 0; i < 6; i++) {
               g.fill(cx - 3 + i, cy - 3 + i, cx - 2 + i, cy - 2 + i, color);
               g.fill(cx - 3 + i, cy + 2 - i, cx - 2 + i, cy + 3 - i, color);
            }
            break;
         case PREV:
            PlayerTheme.iconSkip(g, cx, cy, 8, color, false);
            break;
         case NEXT:
            PlayerTheme.iconSkip(g, cx, cy, 8, color, true);
            break;
         case VOL:
            float v = this.ctl.volume;
            PlayerTheme.iconVolume(g, cx - 1, cy, v <= 0.0F ? 0 : (v < 0.5F ? 1 : 2), color);
      }
   }

   private static int wavePaletteAt(double t) {
      int n = WAVE_PALETTE.length;
      t -= Math.floor(t / n) * n;
      int i = (int)t;
      return PlayerTheme.mix(WAVE_PALETTE[i], WAVE_PALETTE[(i + 1) % n], (float)(t - i));
   }

   private void drawWaveGradient(Canvas g, int x, int y, int w, int h, int r, int alpha, double phase) {
      if (w > 0 && h > 0) {
         r = Math.max(0, Math.min(r, Math.min(w, h) / 2));

         for (int col = 0; col < w; col++) {
            double d = 0.0;
            if (col < r) {
               d = r - 0.5 - col;
            } else if (col >= w - r) {
               d = col - (w - r - 0.5);
            }

            int in = d <= 0.0 ? 0 : (int)Math.round(r - Math.sqrt(Math.max(0.0, r * r - d * d)));
            double t = phase * WAVE_PALETTE.length + (double)col / Math.max(1, w) * 2.2;
            int shade = (int)Math.round(Math.sin((double)col / w * Math.PI) * 18.0);
            int rgb = PlayerTheme.mix(wavePaletteAt(t), 16777215, shade / 255.0F * 2.0F);
            g.fill(x + col, y + in, x + col + 1, y + h - in, PlayerTheme.argb(rgb, alpha));
         }
      }
   }

   private void drawWaveButton(Canvas g, PlayerScreen.Btn b) {
      boolean hov = b.contains(this.mouseX, this.mouseY);
      boolean on = this.ctl.waveActive;
      double secs = System.nanoTime() / 1.0E9;
      int r = Math.min(this.th.radius + 3, b.h / 2);
      if (on || hov) {
         float pulse = on ? (float)(0.5 + 0.5 * Math.sin(secs * 2.4)) : 0.4F;

         for (int e = 3; e >= 1; e--) {
            PlayerTheme.rrect(
               g,
               b.x - e,
               b.y - e,
               b.w + e * 2,
               b.h + e * 2,
               r + e,
               PlayerTheme.argb(wavePaletteAt(secs * 0.35 * WAVE_PALETTE.length), Math.round((10.0F + 22.0F * pulse) / e))
            );
         }
      }

      this.drawWaveGradient(g, b.x, b.y, b.w, b.h, r, hov ? 255 : 235, secs * 0.18);
      boolean playing = on && this.ctl.engine().isPlaying();
      int bx = b.x + 9;
      int base = b.y + b.h - 6;

      for (int i = 0; i < 4; i++) {
         double k = playing ? 0.5 + 0.5 * Math.sin(secs * (5.0 + i * 1.7) + i * 1.3) : 0.25;
         int bh = 3 + (int)Math.round(k * (b.h - 12));
         g.fill(bx + i * 3, base - bh, bx + i * 3 + 2, base, -1);
      }

      String label;
      if (this.ctl.waveLoading) {
         int dots = (int)(secs * 3.0) % 4;
         label = T.get("player.wave_starting") + ".".repeat(dots);
      } else {
         label = T.get(on && this.ctl.waveView ? "player.wave_stop" : "player.wave");
      }

      int tx = b.x + b.w / 2 + 6;
      int ty = b.y + (b.h - 9) / 2 + 1;
      g.text(this.font, label, tx - this.font.width(label) / 2 + 1, ty + 1, 1711276032);
      g.text(this.font, label, tx - this.font.width(label) / 2, ty, -1);
   }

   private void drawWaveGlow(Canvas g, int x, int y, int size, double secs) {
      float pulse = (float)(0.5 + 0.5 * Math.sin(secs * 2.0));
      int rgb = wavePaletteAt(secs * 0.5);

      for (int e = 7; e >= 1; e--) {
         float spread = e * (0.75F + 0.25F * pulse);
         int a = Math.round((7 - e + 1) * (2.2F + 2.6F * pulse));
         int gx = Math.round(spread);
         PlayerTheme.rrect(g, x - gx, y - gx, size + gx * 2, size + gx * 2, 8 + gx, PlayerTheme.argb(rgb, a));
      }
   }

   private void drawEqualizer(Canvas g, int x, int y, int h, boolean playing) {
      double secs = System.nanoTime() / 1.0E9;

      for (int i = 0; i < 3; i++) {
         double k = playing ? 0.5 + 0.5 * Math.sin(secs * (6.0 + i * 2.1) + i * 1.9) : 0.2;
         int bh = 2 + (int)Math.round(k * (h - 2));
         g.fill(x + i * 3, y + h - bh, x + i * 3 + 2, y + h, this.th.accent);
      }
   }

   private void ensureWrapped(List<LyricLine> src) {
      int w = this.rw - 8;
      if (src != this.wrappedFor || w != this.wrapW) {
         this.wrapped = new ArrayList<>();
         this.tops = new int[src.size()];
         int y = 0;
         int lh = 9 + 2;

         for (int i = 0; i < src.size(); i++) {
            List<FormattedCharSequence> l = new ArrayList<>(this.font.split(Component.literal(src.get(i).text()), w));
            if (l.isEmpty()) {
               l.add(FormattedCharSequence.EMPTY);
            }

            this.wrapped.add(l);
            this.tops[i] = y;
            y += l.size() * lh + 8;
         }

         this.totalH = y;
         this.wrappedFor = src;
         this.wrapW = w;
         this.manualPx = 0.0;
         this.scrollPx = 0.0;
      }
   }

   private void center(Canvas g, String s, int cx, int y, int color) {
      String fit = this.font.width(s) > this.pw - 24 ? this.font.plainSubstrByWidth(s, this.pw - 24) : s;
      g.text(this.font, fit, cx - this.font.width(fit) / 2, y, color);
   }

   private static String nz(String s) {
      return s == null ? "" : s;
   }

   private static String fmt(long ms) {
      long s = Math.max(0L, ms) / 1000L;
      return s / 60L + ":" + String.format("%02d", s % 60L);
   }

   public void onFilesDrop(List<Path> files) {
      if (this.ctl.addLocalPaths(files)) {
         this.pickerOpen = false;
         this.addAccountMode = false;
         this.queueMode = false;
         this.page = 0;
      }
   }

   public void onClose() {
      Game.open(this.parent);
   }

   public boolean isPauseScreen() {
      return false;
   }

   private static final class Btn {
      final PlayerScreen.Kind kind;
      final int x;
      final int y;
      final int w;
      final int h;
      String label = "";
      PlayerScreen.Icon icon = PlayerScreen.Icon.NONE;
      Platform plat;
      float glow;
      int order;
      DoubleConsumer click = mx -> {};
      BooleanSupplier enabled = () -> true;
      BooleanSupplier visible = () -> true;
      BooleanSupplier on = () -> false;

      Btn(PlayerScreen.Kind kind, int x, int y, int w, int h) {
         this.kind = kind;
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      boolean contains(double mx, double my) {
         return mx >= this.x && mx < this.x + this.w && my >= this.y && my < this.y + this.h;
      }
   }

   private static enum Icon {
      NONE,
      PLAY,
      PREV,
      NEXT,
      VOL,
      HEART,
      LEFT,
      RIGHT,
      LIKE,
      SHUFFLE,
      REPEAT,
      QUEUE,
      WAVE,
      DISLIKE;

      private Icon() {
      }
   }

   private static enum Kind {
      PRIMARY,
      GHOST,
      CIRCLE,
      CIRCLE_BIG,
      BAR,
      WAVE,
      CARD,
      CHIP;

      private Kind() {
      }
   }

   private static enum Mode {
      PICKER,
      LOGIN,
      MAIN;

      private Mode() {
      }
   }
}
