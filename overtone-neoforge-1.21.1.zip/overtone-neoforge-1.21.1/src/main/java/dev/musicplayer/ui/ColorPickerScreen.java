package dev.musicplayer.ui;

import dev.musicplayer.compat.Canvas;
import dev.musicplayer.compat.Game;
import dev.musicplayer.compat.KeyInput;
import dev.musicplayer.compat.ModScreen;
import dev.musicplayer.util.T;
import java.util.function.IntConsumer;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class ColorPickerScreen extends ModScreen {
   private static final int SIZE = 120;
   private static final int CELL = 4;
   private static final int CELLS = 30;
   private static final int HUE_W = 14;
   private static final int PW = 196;
   private static final int PH = 232;
   private final Screen parent;
   private final IntConsumer onPick;
   private float hue;
   private float sat;
   private float val;
   private EditBox hex;
   private boolean syncing;
   private int dragging;
   private PlayerTheme th;
   private int px;
   private int py;
   private int sx;
   private int sy;
   private int hx;
   private int mouseX;
   private int mouseY;
   private final int[] okBtn = new int[4];
   private final int[] cancelBtn = new int[4];

   public ColorPickerScreen(Screen parent, int rgb, IntConsumer onPick) {
      super(Component.literal(T.get("picker.title")));
      this.parent = parent;
      this.onPick = onPick;
      float[] hsv = toHsv(rgb);
      this.hue = hsv[0];
      this.sat = hsv[1];
      this.val = hsv[2];
   }

   protected void init() {
      this.px = (this.width - 196) / 2;
      this.py = (this.height - 232) / 2;
      this.sx = this.px + 16;
      this.sy = this.py + 34;
      this.hx = this.sx + 120 + 12;
      int fy = this.sy + 120 + 14;
      this.hex = new EditBox(this.font, this.px + 16 + 48 + 6, fy + 5, 104, 10, Component.empty());
      this.hex.setBordered(false);
      this.hex.setMaxLength(7);
      this.hex.setFilter(s -> s.matches("#?[0-9a-fA-F]*"));
      this.hex.setResponder(this::typed);
      this.addRenderableWidget(this.hex);
      this.showHex();
   }

   private int rgb() {
      return toRgb(this.hue, this.sat, this.val);
   }

   private void showHex() {
      this.syncing = true;
      this.hex.setValue(String.format("#%06X", this.rgb()));
      this.syncing = false;
   }

   private void typed(String text) {
      if (!this.syncing) {
         String d = text.startsWith("#") ? text.substring(1) : text;
         if (d.length() == 6) {
            float[] hsv = toHsv(Integer.parseInt(d, 16));
            if (hsv[1] > 0.01F && hsv[2] > 0.01F) {
               this.hue = hsv[0];
            }

            this.sat = hsv[1];
            this.val = hsv[2];
         }
      }
   }

   @Override
   protected void draw(Canvas g, int mx, int my, float delta) {
      this.mouseX = mx;
      this.mouseY = my;
      this.th = PlayerTheme.current();
      g.fill(0, 0, this.width, this.height, this.th.dim);
      this.th.window(g, this.px, this.py, 196, 232);
      g.text(this.font, T.get("picker.title"), this.px + 16, this.py + 12, this.th.accent);

      for (int cx = 0; cx < 30; cx++) {
         for (int cy = 0; cy < 30; cy++) {
            int c = toRgb(this.hue, (cx + 0.5F) / 30.0F, 1.0F - (cy + 0.5F) / 30.0F);
            g.fill(this.sx + cx * 4, this.sy + cy * 4, this.sx + (cx + 1) * 4, this.sy + (cy + 1) * 4, 0xFF000000 | c);
         }
      }

      int kx = this.sx + Math.round(this.sat * 120.0F);
      int ky = this.sy + Math.round((1.0F - this.val) * 120.0F);
      PlayerTheme.circle(g, kx, ky, 5, -1);
      PlayerTheme.circle(g, kx, ky, 3, 0xFF000000 | this.rgb());

      for (int i = 0; i < 30; i++) {
         g.fill(this.hx, this.sy + i * 4, this.hx + 14, this.sy + (i + 1) * 4, 0xFF000000 | toRgb((i + 0.5F) / 30.0F, 1.0F, 1.0F));
      }

      int hy = this.sy + Math.round(this.hue * 120.0F);
      g.fill(this.hx - 2, hy - 1, this.hx + 14 + 2, hy + 2, -1);
      int fy = this.sy + 120 + 14;
      PlayerTheme.rrect(g, this.px + 16, fy, 48, 20, 4, 0xFF000000 | this.rgb());
      PlayerTheme.rrect(g, this.px + 16 + 54, fy, 110, 20, 4, this.th.fieldBg);
      this.drawWidgets(g, mx, my, delta);
      int by = this.py + 232 - 32;
      int bw = 78;
      this.button(g, this.okBtn, this.px + 16, by, bw, T.get("picker.ok"), true);
      this.button(g, this.cancelBtn, this.px + 16 + bw + 8, by, bw, T.get("picker.cancel"), false);
   }

   private void button(Canvas g, int[] rect, int x, int y, int w, String label, boolean primary) {
      rect[0] = x;
      rect[1] = y;
      rect[2] = w;
      rect[3] = 20;
      boolean hover = inside(rect, this.mouseX, this.mouseY);
      int bg = primary ? (hover ? this.th.accentHover : this.th.accent) : (hover ? this.th.hover : this.th.trackBg);
      PlayerTheme.rrect(g, x, y, w, 20, 5, bg);
      g.text(this.font, label, x + (w - this.font.width(label)) / 2, y + 6, -1);
   }

   private static boolean inside(int[] r, int x, int y) {
      return x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3];
   }

   private void pickSquare(int mx, int my) {
      this.sat = clamp((mx - this.sx) / 120.0F);
      this.val = 1.0F - clamp((my - this.sy) / 120.0F);
      this.showHex();
   }

   private void pickHue(int my) {
      this.hue = Math.min(0.999F, clamp((my - this.sy) / 120.0F));
      this.showHex();
   }

   private void confirm() {
      this.onPick.accept(this.rgb());
      Game.open(this.parent);
   }

   @Override
   protected boolean onClick(double x, double y, int button, boolean doubleClick) {
      int mx = (int)x;
      int my = (int)y;
      if (mx >= this.sx && mx < this.sx + 120 && my >= this.sy && my < this.sy + 120) {
         this.dragging = 1;
         this.pickSquare(mx, my);
         return true;
      } else if (mx >= this.hx && mx < this.hx + 14 && my >= this.sy && my < this.sy + 120) {
         this.dragging = 2;
         this.pickHue(my);
         return true;
      } else if (inside(this.okBtn, mx, my)) {
         this.confirm();
         return true;
      } else if (inside(this.cancelBtn, mx, my)) {
         this.onClose();
         return true;
      } else {
         return super.onClick(x, y, button, doubleClick);
      }
   }

   @Override
   protected boolean onDrag(double x, double y, int button, double dx, double dy) {
      if (this.dragging == 1) {
         this.pickSquare((int)x, (int)y);
         return true;
      } else if (this.dragging == 2) {
         this.pickHue((int)y);
         return true;
      } else {
         return super.onDrag(x, y, button, dx, dy);
      }
   }

   @Override
   protected boolean onRelease(double x, double y, int button) {
      this.dragging = 0;
      return super.onRelease(x, y, button);
   }

   @Override
   protected boolean onKey(KeyInput event) {
      if (event.key() != 257 && event.key() != 335) {
         return super.onKey(event);
      } else {
         this.confirm();
         return true;
      }
   }

   public void onClose() {
      Game.open(this.parent);
   }

   public boolean isPauseScreen() {
      return false;
   }

   private static float clamp(float v) {
      return Math.max(0.0F, Math.min(1.0F, v));
   }

   static int toRgb(float h, float s, float v) {
      float c = v * s;
      float hh = h * 6.0F;
      float x = c * (1.0F - Math.abs(hh % 2.0F - 1.0F));
      float m = v - c;
      float r;
      float g;
      float b;
      switch ((int)hh % 6) {
         case 0:
            r = c;
            g = x;
            b = 0.0F;
            break;
         case 1:
            r = x;
            g = c;
            b = 0.0F;
            break;
         case 2:
            r = 0.0F;
            g = c;
            b = x;
            break;
         case 3:
            r = 0.0F;
            g = x;
            b = c;
            break;
         case 4:
            r = x;
            g = 0.0F;
            b = c;
            break;
         default:
            r = c;
            g = 0.0F;
            b = x;
      }

      return Math.round((r + m) * 255.0F) << 16 | Math.round((g + m) * 255.0F) << 8 | Math.round((b + m) * 255.0F);
   }

   static float[] toHsv(int rgb) {
      float r = (rgb >> 16 & 0xFF) / 255.0F;
      float g = (rgb >> 8 & 0xFF) / 255.0F;
      float b = (rgb & 0xFF) / 255.0F;
      float max = Math.max(r, Math.max(g, b));
      float min = Math.min(r, Math.min(g, b));
      float d = max - min;
      float h = d == 0.0F ? 0.0F : (max == r ? (g - b) / d % 6.0F / 6.0F : (max == g ? ((b - r) / d + 2.0F) / 6.0F : ((r - g) / d + 4.0F) / 6.0F));
      return new float[]{h < 0.0F ? h + 1.0F : h, max == 0.0F ? 0.0F : d / max, max};
   }
}
