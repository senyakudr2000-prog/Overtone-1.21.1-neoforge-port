package dev.musicplayer.viz;

import dev.musicplayer.MusicPlayerMod;
import java.io.InputStream;
import java.lang.ProcessBuilder.Redirect;
import java.util.Locale;

public final class SystemCapture {
   private static final int RATE = 48000;
   private static Process process;
   private static boolean unavailable = !System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("linux");

   private SystemCapture() {
   }

   public static boolean available() {
      return !unavailable;
   }

   static synchronized void setRunning(boolean on) {
      Spectrum.useSystem(on && !unavailable);
      if (on && !unavailable) {
         if (process == null || !process.isAlive()) {
            start();
         }
      } else if (process != null) {
         process.destroy();
         process = null;
      }
   }

   private static void start() {
      try {
         Process p = new ProcessBuilder(
               "parec", "-d", "@DEFAULT_MONITOR@", "--format=s16le", "--rate=48000", "--channels=2", "--latency-msec=20", "--client-name=Overtone"
            )
            .redirectError(Redirect.DISCARD)
            .start();
         process = p;
         Thread t = new Thread(() -> pump(p), "musicplayer-capture");
         t.setDaemon(true);
         t.start();
         MusicPlayerMod.LOGGER.info("Visualizer: capturing system audio via parec");
      } catch (Exception var21) {
         unavailable = true;
         Spectrum.useSystem(false);
         MusicPlayerMod.LOGGER.warn("Visualizer: system audio capture unavailable ({}), install pulseaudio-utils / pipewire-pulse", var21.getMessage());
      }
   }

   private static void pump(Process p) {
      byte[] buf = new byte[1920];

      try (InputStream in = p.getInputStream()) {
         while (in.readNBytes(buf, 0, buf.length) == buf.length) {
            Spectrum.feedSystem(buf, buf.length, 2, 48000.0F);
         }
      } catch (Exception var7) {
      }
   }
}
