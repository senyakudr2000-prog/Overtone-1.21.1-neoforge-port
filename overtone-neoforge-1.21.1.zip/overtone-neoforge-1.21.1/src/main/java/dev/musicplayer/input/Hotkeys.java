package dev.musicplayer.input;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Key;
import dev.musicplayer.compat.Game;
import dev.musicplayer.compat.KeyInput;
import dev.musicplayer.compat.Keys;
import dev.musicplayer.config.HudConfig;
import dev.musicplayer.config.PlayerConfig;
import dev.musicplayer.controller.PlayerController;
import dev.musicplayer.hud.VolumeRenderer;
import dev.musicplayer.hud.WorldLyricsRenderer;
import dev.musicplayer.ui.HudConfigScreen;
import dev.musicplayer.ui.PlayerScreen;
import dev.musicplayer.util.T;
import java.util.Map.Entry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class Hotkeys {
   public static final float VOLUME_STEP = 0.05F;
   private static final int KEYS_VERSION = 3;
   private static final int UNBOUND = -1;
   private static final KeyMapping[] MAPPINGS = new KeyMapping[Hotkeys.Action.values().length];

   private Hotkeys() {
   }

   public static void create() {
      for (Hotkeys.Action a : Hotkeys.Action.values()) {
         MAPPINGS[a.ordinal()] = Keys.create(a.translationKey, a.defaultKey);
      }
   }

   public static KeyMapping[] mappings() {
      return (KeyMapping[])MAPPINGS.clone();
   }

   public static void onClientStarted() {
      PlayerConfig pc = PlayerConfig.get();
      boolean dirty = false;
      if (pc.keys != null && !pc.keys.isEmpty()) {
         for (Entry<String, Integer> e : pc.keys.entrySet()) {
            Hotkeys.Action a;
            try {
               a = Hotkeys.Action.valueOf(e.getKey());
            } catch (Exception var8) {
               continue;
            }

            KeyMapping km = MAPPINGS[a.ordinal()];
            if (km != null && e.getValue() != null) {
               km.setKey(e.getValue() == -1 ? InputConstants.UNKNOWN : Keys.key(e.getValue()));
            }
         }

         pc.keys.clear();
         dirty = true;
      }

      if (pc.keysVersion < 3) {
         for (Hotkeys.Action ax : Hotkeys.Action.values()) {
            KeyMapping km = MAPPINGS[ax.ordinal()];
            boolean reset = pc.keysVersion < 2 || ax == Hotkeys.Action.TOGGLE_HUD;
            if (km != null && reset) {
               km.setKey(km.getKey());
            }
         }

         pc.keysVersion = 3;
         dirty = true;
      }

      if (dirty) {
         pc.save();
         KeyMapping.resetMapping();
         save();
      }
   }

   public static void tick() {
      boolean inWorld = Game.screen() == null;

      for (Hotkeys.Action a : Hotkeys.Action.values()) {
         KeyMapping km = MAPPINGS[a.ordinal()];
         if (km != null) {
            while (km.consumeClick()) {
               if (inWorld) {
                  perform(a, null);
               }
            }
         }
      }
   }

   public static Hotkeys.Action actionFor(KeyInput event) {
      for (Hotkeys.Action a : Hotkeys.Action.values()) {
         KeyMapping km = MAPPINGS[a.ordinal()];
         if (km != null && !km.isUnbound() && event.matches(km)) {
            return a;
         }
      }

      return null;
   }

   public static boolean handleOnMenu(Screen screen, KeyInput event) {
      Hotkeys.Action a = actionFor(event);
      if (a != null && a != Hotkeys.Action.TOGGLE_HUD && a != Hotkeys.Action.WORLD_LYRICS) {
         perform(a, screen);
         return true;
      } else {
         return false;
      }
   }

   public static void perform(Hotkeys.Action a, Screen menu) {
      switch (a) {
         case OPEN_PLAYER:
            Game.open(new PlayerScreen(menu));
            break;
         case HUD_SETTINGS:
            Game.open(new HudConfigScreen(menu));
            break;
         case TOGGLE_HUD: {
            HudConfig c = HudConfig.get();
            c.master = !c.master;
            c.save();
            break;
         }
         case WORLD_LYRICS: {
            HudConfig c = HudConfig.get();
            c.worldLyrics = !c.worldLyrics;
            c.save();
            WorldLyricsRenderer.toast(T.get(c.worldLyrics ? "toast.world_on" : "toast.world_off"));
            break;
         }
         default:
            transport(a);
      }
   }

   private static void transport(Hotkeys.Action a) {
      PlayerController ctl = PlayerController.I;
      if (ctl.engine().isLoggedIn()) {
         switch (a) {
            case PREV:
               ctl.prev();
               break;
            case NEXT:
               ctl.next();
               break;
            case PAUSE:
               ctl.togglePause();
               break;
            case VOL_UP:
               ctl.changeVolume(0.05F);
               poke();
               break;
            case VOL_DOWN:
               ctl.changeVolume(-0.05F);
               poke();
         }
      }
   }

   private static void poke() {
      if (Game.screen() == null) {
         VolumeRenderer.poke();
      }
   }

   public static void setKey(Hotkeys.Action a, int code) {
      KeyMapping km = MAPPINGS[a.ordinal()];
      if (km != null) {
         Key key = code == -1 ? InputConstants.UNKNOWN : Keys.key(code);
         if (code != -1) {
            for (Hotkeys.Action other : Hotkeys.Action.values()) {
               KeyMapping o = MAPPINGS[other.ordinal()];
               if (other != a && o != null && !o.isUnbound() && o.saveString().equals(key.getName())) {
                  o.setKey(InputConstants.UNKNOWN);
               }
            }
         }

         km.setKey(key);
         KeyMapping.resetMapping();
         save();
      }
   }

   public static void reset(Hotkeys.Action a) {
      KeyMapping km = MAPPINGS[a.ordinal()];
      if (km != null) {
         setKey(a, km.getKey().getValue());
      }
   }

   public static void resetAll() {
      for (Hotkeys.Action a : Hotkeys.Action.values()) {
         KeyMapping km = MAPPINGS[a.ordinal()];
         if (km != null) {
            km.setKey(km.getKey());
         }
      }

      KeyMapping.resetMapping();
      save();
   }

   private static void save() {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.options != null) {
         mc.options.save();
      }
   }

   public static String keyName(Hotkeys.Action a) {
      KeyMapping km = MAPPINGS[a.ordinal()];
      return km != null && !km.isUnbound() ? km.getTranslatedKeyMessage().getString() : T.get("keys.unbound");
   }

   public static boolean isDefault(Hotkeys.Action a) {
      KeyMapping km = MAPPINGS[a.ordinal()];
      return km != null && km.isDefault();
   }

   public static enum Action {
      OPEN_PLAYER("open", 77),
      TOGGLE_HUD("toggle_hud", InputConstants.UNKNOWN.getValue()),
      HUD_SETTINGS("hud_settings", 75),
      PREV("prev", 91),
      NEXT("next", 93),
      PAUSE("pause", 59),
      VOL_UP("vol_up", 61),
      VOL_DOWN("vol_down", 45),
      WORLD_LYRICS("world_lyrics", 74);

      public final int defaultKey;
      final String translationKey;

      private Action(String id, int defaultKey) {
         this.defaultKey = defaultKey;
         this.translationKey = "key.musicplayer." + id;
      }

      public String label() {
         return Component.translatable(this.translationKey).getString();
      }

      public boolean isTransport() {
         return this == PREV || this == NEXT || this == PAUSE || this == VOL_UP || this == VOL_DOWN;
      }
   }
}
