package dev.musicplayer.libs.jaad.aac.syntax;

import dev.musicplayer.libs.jaad.aac.AACException;
import dev.musicplayer.libs.jaad.aac.SampleFrequency;
import dev.musicplayer.libs.jaad.aac.sbr.SBR;

public abstract class Element implements Constants {
   private int elementInstanceTag;
   private SBR sbr;

   public Element() {
   }

   protected void readElementInstanceTag(BitStream in) throws AACException {
      this.elementInstanceTag = in.readBits(4);
   }

   public int getElementInstanceTag() {
      return this.elementInstanceTag;
   }

   void decodeSBR(BitStream in, SampleFrequency sf, int count, boolean stereo, boolean crc, boolean downSampled, boolean smallFrames) throws AACException {
      if (this.sbr == null) {
         this.sbr = new SBR(smallFrames, this.elementInstanceTag == 1, sf, downSampled);
      }

      this.sbr.decode(in, count);
   }

   boolean isSBRPresent() {
      return this.sbr != null;
   }

   SBR getSBR() {
      return this.sbr;
   }
}
