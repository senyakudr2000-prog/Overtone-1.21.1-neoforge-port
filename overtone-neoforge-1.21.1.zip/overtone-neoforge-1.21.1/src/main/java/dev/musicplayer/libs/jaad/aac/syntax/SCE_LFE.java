package dev.musicplayer.libs.jaad.aac.syntax;

import dev.musicplayer.libs.jaad.aac.AACException;
import dev.musicplayer.libs.jaad.aac.DecoderConfig;

class SCE_LFE extends Element {
   private final ICStream ics;

   SCE_LFE(int frameLength) {
      this.ics = new ICStream(frameLength);
   }

   void decode(BitStream in, DecoderConfig conf) throws AACException {
      this.readElementInstanceTag(in);
      this.ics.decode(in, false, conf);
   }

   public ICStream getICStream() {
      return this.ics;
   }
}
