package dev.musicplayer.libs.jaad.aac.syntax;

import dev.musicplayer.libs.jaad.aac.AACException;

class DSE extends Element {
   private byte[] dataStreamBytes;

   DSE() {
   }

   void decode(BitStream in) throws AACException {
      boolean byteAlign = in.readBool();
      int count = in.readBits(8);
      if (count == 255) {
         count += in.readBits(8);
      }

      if (byteAlign) {
         in.byteAlign();
      }

      this.dataStreamBytes = new byte[count];

      for (int i = 0; i < count; i++) {
         this.dataStreamBytes[i] = (byte)in.readBits(8);
      }
   }
}
