package dev.musicplayer.libs.jaad.aac.sbr;

import java.util.Arrays;

class SynthesisFilterbank implements FilterbankTable {
   private static final float[][] qmf32_pre_twiddle = new float[][]{
      {0.9999247F, -0.012271538F},
      {0.99932235F, -0.036807224F},
      {0.9981181F, -0.061320737F},
      {0.9963126F, -0.08579731F},
      {0.993907F, -0.110222206F},
      {0.99090266F, -0.1345807F},
      {0.9873014F, -0.15885815F},
      {0.9831055F, -0.18303989F},
      {0.9783174F, -0.20711137F},
      {0.97293997F, -0.2310581F},
      {0.96697646F, -0.25486565F},
      {0.9604305F, -0.2785197F},
      {0.953306F, -0.30200595F},
      {0.9456073F, -0.3253103F},
      {0.937339F, -0.34841868F},
      {0.9285061F, -0.3713172F},
      {0.9191139F, -0.39399204F},
      {0.909168F, -0.41642955F},
      {0.8986745F, -0.43861625F},
      {0.88763964F, -0.46053872F},
      {0.8760701F, -0.48218378F},
      {0.86397284F, -0.50353837F},
      {0.8513552F, -0.52458966F},
      {0.8382247F, -0.545325F},
      {0.8245893F, -0.5657318F},
      {0.81045717F, -0.58579785F},
      {0.7958369F, -0.60551107F},
      {0.7807372F, -0.6248595F},
      {0.76516724F, -0.64383155F},
      {0.7491364F, -0.6624158F},
      {0.7326543F, -0.680601F},
      {0.71573085F, -0.69837624F}
   };
   private float[] v;
   private int v_index;
   private final int channels;

   public SynthesisFilterbank(int channels) {
      this.channels = channels;
      this.v = new float[2 * channels * 20];
      this.v_index = 0;
   }

   public void reset() {
      Arrays.fill(this.v, 0.0F);
   }

   void sbr_qmf_synthesis_32(SBR sbr, float[][][] X, float[] output) {
      float[] x1 = new float[32];
      float[] x2 = new float[32];
      float scale = 0.015625F;
      int out = 0;

      for (int l = 0; l < sbr.numTimeSlotsRate; l++) {
         for (int k = 0; k < 32; k++) {
            x1[k] = X[l][k][0] * qmf32_pre_twiddle[k][0] - X[l][k][1] * qmf32_pre_twiddle[k][1];
            x2[k] = X[l][k][1] * qmf32_pre_twiddle[k][0] + X[l][k][0] * qmf32_pre_twiddle[k][1];
            x1[k] *= scale;
            x2[k] *= scale;
         }

         this.DCT4_32(x1, x1);
         this.DST4_32(x2, x2);

         for (int n = 0; n < 32; n++) {
            this.v[this.v_index + n] = this.v[this.v_index + 640 + n] = -x1[n] + x2[n];
            this.v[this.v_index + 63 - n] = this.v[this.v_index + 640 + 63 - n] = x1[n] + x2[n];
         }

         for (int var11 = 0; var11 < 32; var11++) {
            output[out++] = this.v[this.v_index + var11] * qmf_c[2 * var11]
               + this.v[this.v_index + 96 + var11] * qmf_c[64 + 2 * var11]
               + this.v[this.v_index + 128 + var11] * qmf_c[128 + 2 * var11]
               + this.v[this.v_index + 224 + var11] * qmf_c[192 + 2 * var11]
               + this.v[this.v_index + 256 + var11] * qmf_c[256 + 2 * var11]
               + this.v[this.v_index + 352 + var11] * qmf_c[320 + 2 * var11]
               + this.v[this.v_index + 384 + var11] * qmf_c[384 + 2 * var11]
               + this.v[this.v_index + 480 + var11] * qmf_c[448 + 2 * var11]
               + this.v[this.v_index + 512 + var11] * qmf_c[512 + 2 * var11]
               + this.v[this.v_index + 608 + var11] * qmf_c[576 + 2 * var11];
         }

         this.v_index -= 64;
         if (this.v_index < 0) {
            this.v_index = 576;
         }
      }
   }

   void sbr_qmf_synthesis_64(SBR sbr, float[][][] X, float[] output) {
      float[] in_real1 = new float[32];
      float[] in_imag1 = new float[32];
      float[] out_real1 = new float[32];
      float[] out_imag1 = new float[32];
      float[] in_real2 = new float[32];
      float[] in_imag2 = new float[32];
      float[] out_real2 = new float[32];
      float[] out_imag2 = new float[32];
      float scale = 0.015625F;
      int out = 0;

      for (int l = 0; l < sbr.numTimeSlotsRate; l++) {
         float[][] pX = X[l];
         in_imag1[31] = scale * pX[1][0];
         in_real1[0] = scale * pX[0][0];
         in_imag2[31] = scale * pX[62][1];
         in_real2[0] = scale * pX[63][1];

         for (int k = 1; k < 31; k++) {
            in_imag1[31 - k] = scale * pX[2 * k + 1][0];
            in_real1[k] = scale * pX[2 * k][0];
            in_imag2[31 - k] = scale * pX[63 - (2 * k + 1)][1];
            in_real2[k] = scale * pX[63 - 2 * k][1];
         }

         in_imag1[0] = scale * pX[63][0];
         in_real1[31] = scale * pX[62][0];
         in_imag2[0] = scale * pX[0][1];
         in_real2[31] = scale * pX[1][1];
         DCT.dct4_kernel(in_real1, in_imag1, out_real1, out_imag1);
         DCT.dct4_kernel(in_real2, in_imag2, out_real2, out_imag2);
         int pring_buffer_1 = this.v_index;
         int pring_buffer_3 = pring_buffer_1 + 1280;

         for (int n = 0; n < 32; n++) {
            this.v[pring_buffer_1 + 2 * n] = this.v[pring_buffer_3 + 2 * n] = out_real2[n] - out_real1[n];
            this.v[pring_buffer_1 + 127 - 2 * n] = this.v[pring_buffer_3 + 127 - 2 * n] = out_real2[n] + out_real1[n];
            this.v[pring_buffer_1 + 2 * n + 1] = this.v[pring_buffer_3 + 2 * n + 1] = out_imag2[31 - n] + out_imag1[31 - n];
            this.v[pring_buffer_1 + 127 - (2 * n + 1)] = this.v[pring_buffer_3 + 127 - (2 * n + 1)] = out_imag2[31 - n] - out_imag1[31 - n];
         }

         pring_buffer_1 = this.v_index;

         for (int var20 = 0; var20 < 64; var20++) {
            output[out++] = this.v[pring_buffer_1 + var20 + 0] * qmf_c[var20 + 0]
               + this.v[pring_buffer_1 + var20 + 192] * qmf_c[var20 + 64]
               + this.v[pring_buffer_1 + var20 + 256] * qmf_c[var20 + 128]
               + this.v[pring_buffer_1 + var20 + 448] * qmf_c[var20 + 192]
               + this.v[pring_buffer_1 + var20 + 512] * qmf_c[var20 + 256]
               + this.v[pring_buffer_1 + var20 + 704] * qmf_c[var20 + 320]
               + this.v[pring_buffer_1 + var20 + 768] * qmf_c[var20 + 384]
               + this.v[pring_buffer_1 + var20 + 960] * qmf_c[var20 + 448]
               + this.v[pring_buffer_1 + var20 + 1024] * qmf_c[var20 + 512]
               + this.v[pring_buffer_1 + var20 + 1216] * qmf_c[var20 + 576];
         }

         this.v_index -= 128;
         if (this.v_index < 0) {
            this.v_index = 1152;
         }
      }
   }

   private void DCT4_32(float[] y, float[] x) {
      float f0 = x[15] - x[16];
      float f1 = x[15] + x[16];
      float f2 = 0.70710677F * f1;
      float f3 = 0.70710677F * f0;
      float f4 = x[8] - x[23];
      float f5 = x[8] + x[23];
      float f6 = 0.70710677F * f5;
      float f7 = 0.70710677F * f4;
      float f8 = x[12] - x[19];
      float f9 = x[12] + x[19];
      float f10 = 0.70710677F * f9;
      float f11 = 0.70710677F * f8;
      float f12 = x[11] - x[20];
      float f13 = x[11] + x[20];
      float f14 = 0.70710677F * f13;
      float f15 = 0.70710677F * f12;
      float f16 = x[14] - x[17];
      float f17 = x[14] + x[17];
      float f18 = 0.70710677F * f17;
      float f19 = 0.70710677F * f16;
      float f20 = x[9] - x[22];
      float f21 = x[9] + x[22];
      float f22 = 0.70710677F * f21;
      float f23 = 0.70710677F * f20;
      float f24 = x[13] - x[18];
      float f25 = x[13] + x[18];
      float f26 = 0.70710677F * f25;
      float f27 = 0.70710677F * f24;
      float f28 = x[10] - x[21];
      float f29 = x[10] + x[21];
      float f30 = 0.70710677F * f29;
      float f31 = 0.70710677F * f28;
      float f32 = x[0] - f2;
      float f33 = x[0] + f2;
      float f34 = x[31] - f3;
      float f35 = x[31] + f3;
      float f36 = x[7] - f6;
      float f37 = x[7] + f6;
      float f38 = x[24] - f7;
      float f39 = x[24] + f7;
      float f40 = x[3] - f10;
      float f41 = x[3] + f10;
      float f42 = x[28] - f11;
      float f43 = x[28] + f11;
      float f44 = x[4] - f14;
      float f45 = x[4] + f14;
      float f46 = x[27] - f15;
      float f47 = x[27] + f15;
      float f48 = x[1] - f18;
      float f49 = x[1] + f18;
      float f50 = x[30] - f19;
      float f51 = x[30] + f19;
      float f52 = x[6] - f22;
      float f53 = x[6] + f22;
      float f54 = x[25] - f23;
      float f55 = x[25] + f23;
      float f56 = x[2] - f26;
      float f57 = x[2] + f26;
      float f58 = x[29] - f27;
      float f59 = x[29] + f27;
      float f60 = x[5] - f30;
      float f61 = x[5] + f30;
      float f62 = x[26] - f31;
      float f63 = x[26] + f31;
      float f64 = f39 + f37;
      float f65 = -0.5411961F * f39;
      float f66 = 0.9238795F * f64;
      float f67 = 1.306563F * f37;
      float f68 = f65 + f66;
      float f69 = f67 - f66;
      float f70 = f38 + f36;
      float f71 = 1.306563F * f38;
      float f72 = -0.38268343F * f70;
      float f73 = 0.5411961F * f36;
      float f74 = f71 + f72;
      float f75 = f73 - f72;
      float f76 = f47 + f45;
      float f77 = -0.5411961F * f47;
      float f78 = 0.9238795F * f76;
      float f79 = 1.306563F * f45;
      float f80 = f77 + f78;
      float f81 = f79 - f78;
      float f82 = f46 + f44;
      float f83 = 1.306563F * f46;
      float f84 = -0.38268343F * f82;
      float f85 = 0.5411961F * f44;
      float f86 = f83 + f84;
      float f87 = f85 - f84;
      float f88 = f55 + f53;
      float f89 = -0.5411961F * f55;
      float f90 = 0.9238795F * f88;
      float f91 = 1.306563F * f53;
      float f92 = f89 + f90;
      float f93 = f91 - f90;
      float f94 = f54 + f52;
      float f95 = 1.306563F * f54;
      float f96 = -0.38268343F * f94;
      float f97 = 0.5411961F * f52;
      float f98 = f95 + f96;
      float f99 = f97 - f96;
      float f100 = f63 + f61;
      float f101 = -0.5411961F * f63;
      float f102 = 0.9238795F * f100;
      float f103 = 1.306563F * f61;
      float f104 = f101 + f102;
      float f105 = f103 - f102;
      float f106 = f62 + f60;
      float f107 = 1.306563F * f62;
      float f108 = -0.38268343F * f106;
      float f109 = 0.5411961F * f60;
      float f110 = f107 + f108;
      float f111 = f109 - f108;
      float f112 = f33 - f68;
      float f113 = f33 + f68;
      float f114 = f35 - f69;
      float f115 = f35 + f69;
      float f116 = f32 - f74;
      float f117 = f32 + f74;
      float f118 = f34 - f75;
      float f119 = f34 + f75;
      float f120 = f41 - f80;
      float f121 = f41 + f80;
      float f122 = f43 - f81;
      float f123 = f43 + f81;
      float f124 = f40 - f86;
      float f125 = f40 + f86;
      float f126 = f42 - f87;
      float f127 = f42 + f87;
      float f128 = f49 - f92;
      float f129 = f49 + f92;
      float f130 = f51 - f93;
      float f131 = f51 + f93;
      float f132 = f48 - f98;
      float f133 = f48 + f98;
      float f134 = f50 - f99;
      float f135 = f50 + f99;
      float f136 = f57 - f104;
      float f137 = f57 + f104;
      float f138 = f59 - f105;
      float f139 = f59 + f105;
      float f140 = f56 - f110;
      float f141 = f56 + f110;
      float f142 = f58 - f111;
      float f143 = f58 + f111;
      float f144 = f123 + f121;
      float f145 = -0.78569496F * f123;
      float f146 = 0.98078525F * f144;
      float f147 = 1.1758755F * f121;
      float f148 = f145 + f146;
      float f149 = f147 - f146;
      float f150 = f127 + f125;
      float f151 = 0.27589938F * f127;
      float f152 = 0.55557024F * f150;
      float f153 = 1.3870399F * f125;
      float f154 = f151 + f152;
      float f155 = f153 - f152;
      float f156 = f122 + f120;
      float f157 = 1.1758755F * f122;
      float f158 = -0.19509032F * f156;
      float f159 = 0.78569496F * f120;
      float f160 = f157 + f158;
      float f161 = f159 - f158;
      float f162 = f126 + f124;
      float f163 = 1.3870399F * f126;
      float f164 = -0.8314696F * f162;
      float f165 = -0.27589938F * f124;
      float f166 = f163 + f164;
      float f167 = f165 - f164;
      float f168 = f139 + f137;
      float f169 = -0.78569496F * f139;
      float f170 = 0.98078525F * f168;
      float f171 = 1.1758755F * f137;
      float f172 = f169 + f170;
      float f173 = f171 - f170;
      float f174 = f143 + f141;
      float f175 = 0.27589938F * f143;
      float f176 = 0.55557024F * f174;
      float f177 = 1.3870399F * f141;
      float f178 = f175 + f176;
      float f179 = f177 - f176;
      float f180 = f138 + f136;
      float f181 = 1.1758755F * f138;
      float f182 = -0.19509032F * f180;
      float f183 = 0.78569496F * f136;
      float f184 = f181 + f182;
      float f185 = f183 - f182;
      float f186 = f142 + f140;
      float f187 = 1.3870399F * f142;
      float f188 = -0.8314696F * f186;
      float f189 = -0.27589938F * f140;
      float f190 = f187 + f188;
      float f191 = f189 - f188;
      float f192 = f113 - f148;
      float f193 = f113 + f148;
      float f194 = f115 - f149;
      float f195 = f115 + f149;
      float f196 = f117 - f154;
      float f197 = f117 + f154;
      float f198 = f119 - f155;
      float f199 = f119 + f155;
      float f200 = f112 - f160;
      float f201 = f112 + f160;
      float f202 = f114 - f161;
      float f203 = f114 + f161;
      float f204 = f116 - f166;
      float f205 = f116 + f166;
      float f206 = f118 - f167;
      float f207 = f118 + f167;
      float f208 = f129 - f172;
      float f209 = f129 + f172;
      float f210 = f131 - f173;
      float f211 = f131 + f173;
      float f212 = f133 - f178;
      float f213 = f133 + f178;
      float f214 = f135 - f179;
      float f215 = f135 + f179;
      float f216 = f128 - f184;
      float f217 = f128 + f184;
      float f218 = f130 - f185;
      float f219 = f130 + f185;
      float f220 = f132 - f190;
      float f221 = f132 + f190;
      float f222 = f134 - f191;
      float f223 = f134 + f191;
      float f224 = f211 + f209;
      float f225 = -0.89716756F * f211;
      float f226 = 0.9951847F * f224;
      float f227 = 1.0932019F * f209;
      float f228 = f225 + f226;
      float f229 = f227 - f226;
      float f230 = f215 + f213;
      float f231 = -0.41052452F * f215;
      float f232 = 0.8819213F * f230;
      float f233 = 1.353318F * f213;
      float f234 = f231 + f232;
      float f235 = f233 - f232;
      float f236 = f219 + f217;
      float f237 = 0.13861717F * f219;
      float f238 = 0.6343933F * f236;
      float f239 = 1.4074037F * f217;
      float f240 = f237 + f238;
      float f241 = f239 - f238;
      float f242 = f223 + f221;
      float f243 = 0.66665566F * f223;
      float f244 = 0.29028466F * f242;
      float f245 = 1.247225F * f221;
      float f246 = f243 + f244;
      float f247 = f245 - f244;
      float f248 = f210 + f208;
      float f249 = 1.0932019F * f210;
      float f250 = -0.09801714F * f248;
      float f251 = 0.89716756F * f208;
      float f252 = f249 + f250;
      float f253 = f251 - f250;
      float f254 = f214 + f212;
      float f255 = 1.353318F * f214;
      float f256 = -0.47139674F * f254;
      float f257 = 0.41052452F * f212;
      float f258 = f255 + f256;
      float f259 = f257 - f256;
      float f260 = f218 + f216;
      float f261 = 1.4074037F * f218;
      float f262 = -0.77301043F * f260;
      float f263 = -0.13861717F * f216;
      float f264 = f261 + f262;
      float f265 = f263 - f262;
      float f266 = f222 + f220;
      float f267 = 1.247225F * f222;
      float f268 = -0.95694035F * f266;
      float f269 = -0.66665566F * f220;
      float f270 = f267 + f268;
      float f271 = f269 - f268;
      float f272 = f193 - f228;
      float f273 = f193 + f228;
      float f274 = f195 - f229;
      float f275 = f195 + f229;
      float f276 = f197 - f234;
      float f277 = f197 + f234;
      float f278 = f199 - f235;
      float f279 = f199 + f235;
      float f280 = f201 - f240;
      float f281 = f201 + f240;
      float f282 = f203 - f241;
      float f283 = f203 + f241;
      float f284 = f205 - f246;
      float f285 = f205 + f246;
      float f286 = f207 - f247;
      float f287 = f207 + f247;
      float f288 = f192 - f252;
      float f289 = f192 + f252;
      float f290 = f194 - f253;
      float f291 = f194 + f253;
      float f292 = f196 - f258;
      float f293 = f196 + f258;
      float f294 = f198 - f259;
      float f295 = f198 + f259;
      float f296 = f200 - f264;
      float f297 = f200 + f264;
      float f298 = f202 - f265;
      float f299 = f202 + f265;
      float f300 = f204 - f270;
      float f301 = f204 + f270;
      float f302 = f206 - f271;
      float f303 = f206 + f271;
      float f304 = f275 + f273;
      float f305 = -0.9751576F * f275;
      float f306 = 0.9996988F * f304;
      float f307 = 1.02424F * f273;
      y[0] = f305 + f306;
      y[31] = f307 - f306;
      float f310 = f279 + f277;
      float f311 = -0.87006885F * f279;
      float f312 = 0.99247956F * f310;
      float f313 = 1.1148902F * f277;
      y[2] = f311 + f312;
      y[29] = f313 - f312;
      float f316 = f283 + f281;
      float f317 = -0.7566009F * f283;
      float f318 = 0.9757021F * f316;
      float f319 = 1.1948034F * f281;
      y[4] = f317 + f318;
      y[27] = f319 - f318;
      float f322 = f287 + f285;
      float f323 = -0.63584644F * f287;
      float f324 = 0.94952816F * f322;
      float f325 = 1.2632099F * f285;
      y[6] = f323 + f324;
      y[25] = f325 - f324;
      float f328 = f291 + f289;
      float f329 = -0.5089684F * f291;
      float f330 = 0.9142098F * f328;
      float f331 = 1.3194511F * f289;
      y[8] = f329 + f330;
      y[23] = f331 - f330;
      float f334 = f295 + f293;
      float f335 = -0.3771888F * f295;
      float f336 = 0.87008697F * f334;
      float f337 = 1.3629851F * f293;
      y[10] = f335 + f336;
      y[21] = f337 - f336;
      float f340 = f299 + f297;
      float f341 = -0.24177662F * f299;
      float f342 = 0.8175848F * f340;
      float f343 = 1.393393F * f297;
      y[12] = f341 + f342;
      y[19] = f343 - f342;
      float f346 = f303 + f301;
      float f347 = -0.104036F * f303;
      float f348 = 0.7572088F * f346;
      float f349 = 1.4103817F * f301;
      y[14] = f347 + f348;
      y[17] = f349 - f348;
      float f352 = f274 + f272;
      float f353 = 0.034706537F * f274;
      float f354 = 0.68954057F * f352;
      float f355 = 1.4137876F * f272;
      y[16] = f353 + f354;
      y[15] = f355 - f354;
      float f358 = f278 + f276;
      float f359 = 0.17311484F * f278;
      float f360 = 0.6152316F * f358;
      float f361 = 1.403578F * f276;
      y[18] = f359 + f360;
      y[13] = f361 - f360;
      float f364 = f282 + f280;
      float f365 = 0.30985594F * f282;
      float f366 = 0.53499764F * f364;
      float f367 = 1.3798512F * f280;
      y[20] = f365 + f366;
      y[11] = f367 - f366;
      float f370 = f286 + f284;
      float f371 = 0.44361296F * f286;
      float f372 = 0.44961134F * f370;
      float f373 = 1.3428357F * f284;
      y[22] = f371 + f372;
      y[9] = f373 - f372;
      float f376 = f290 + f288;
      float f377 = 0.57309777F * f290;
      float f378 = 0.35989505F * f376;
      float f379 = 1.2928878F * f288;
      y[24] = f377 + f378;
      y[7] = f379 - f378;
      float f382 = f294 + f292;
      float f383 = 0.6970633F * f294;
      float f384 = 0.26671275F * f382;
      float f385 = 1.2304888F * f292;
      y[26] = f383 + f384;
      y[5] = f385 - f384;
      float f388 = f298 + f296;
      float f389 = 0.81431574F * f298;
      float f390 = 0.17096189F * f388;
      float f391 = 1.1562395F * f296;
      y[28] = f389 + f390;
      y[3] = f391 - f390;
      float f394 = f302 + f300;
      float f395 = 0.9237259F * f302;
      float f396 = 0.07356457F * f394;
      float f397 = 1.070855F * f300;
      y[30] = f395 + f396;
      y[1] = f397 - f396;
   }

   private void DST4_32(float[] y, float[] x) {
      float f0 = x[0] - x[1];
      float f1 = x[2] - x[1];
      float f2 = x[2] - x[3];
      float f3 = x[4] - x[3];
      float f4 = x[4] - x[5];
      float f5 = x[6] - x[5];
      float f6 = x[6] - x[7];
      float f7 = x[8] - x[7];
      float f8 = x[8] - x[9];
      float f9 = x[10] - x[9];
      float f10 = x[10] - x[11];
      float f11 = x[12] - x[11];
      float f12 = x[12] - x[13];
      float f13 = x[14] - x[13];
      float f14 = x[14] - x[15];
      float f15 = x[16] - x[15];
      float f16 = x[16] - x[17];
      float f17 = x[18] - x[17];
      float f18 = x[18] - x[19];
      float f19 = x[20] - x[19];
      float f20 = x[20] - x[21];
      float f21 = x[22] - x[21];
      float f22 = x[22] - x[23];
      float f23 = x[24] - x[23];
      float f24 = x[24] - x[25];
      float f25 = x[26] - x[25];
      float f26 = x[26] - x[27];
      float f27 = x[28] - x[27];
      float f28 = x[28] - x[29];
      float f29 = x[30] - x[29];
      float f30 = x[30] - x[31];
      float f31 = 0.70710677F * f15;
      float f32 = x[0] - f31;
      float f33 = x[0] + f31;
      float f34 = f7 + f23;
      float f35 = 1.306563F * f7;
      float f36 = -0.9238795F * f34;
      float f37 = -0.5411961F * f23;
      float f38 = f35 + f36;
      float f39 = f37 - f36;
      float f40 = f33 - f39;
      float f41 = f33 + f39;
      float f42 = f32 - f38;
      float f43 = f32 + f38;
      float f44 = f11 - f19;
      float f45 = f11 + f19;
      float f46 = 0.70710677F * f45;
      float f47 = f3 - f46;
      float f48 = f3 + f46;
      float f49 = 0.70710677F * f44;
      float f50 = f49 - f27;
      float f51 = f49 + f27;
      float f52 = f51 + f48;
      float f53 = -0.78569496F * f51;
      float f54 = 0.98078525F * f52;
      float f55 = 1.1758755F * f48;
      float f56 = f53 + f54;
      float f57 = f55 - f54;
      float f58 = f50 + f47;
      float f59 = -0.27589938F * f50;
      float f60 = 0.8314696F * f58;
      float f61 = 1.3870399F * f47;
      float f62 = f59 + f60;
      float f63 = f61 - f60;
      float f64 = f41 - f56;
      float f65 = f41 + f56;
      float f66 = f43 - f62;
      float f67 = f43 + f62;
      float f68 = f42 - f63;
      float f69 = f42 + f63;
      float f70 = f40 - f57;
      float f71 = f40 + f57;
      float f72 = f5 - f9;
      float f73 = f5 + f9;
      float f74 = f13 - f17;
      float f75 = f13 + f17;
      float f76 = f21 - f25;
      float f77 = f21 + f25;
      float f78 = 0.70710677F * f75;
      float f79 = f1 - f78;
      float f80 = f1 + f78;
      float f81 = f73 + f77;
      float f82 = 1.306563F * f73;
      float f83 = -0.9238795F * f81;
      float f84 = -0.5411961F * f77;
      float f85 = f82 + f83;
      float f86 = f84 - f83;
      float f87 = f80 - f86;
      float f88 = f80 + f86;
      float f89 = f79 - f85;
      float f90 = f79 + f85;
      float f91 = 0.70710677F * f74;
      float f92 = f29 - f91;
      float f93 = f29 + f91;
      float f94 = f76 + f72;
      float f95 = 1.306563F * f76;
      float f96 = -0.9238795F * f94;
      float f97 = -0.5411961F * f72;
      float f98 = f95 + f96;
      float f99 = f97 - f96;
      float f100 = f93 - f99;
      float f101 = f93 + f99;
      float f102 = f92 - f98;
      float f103 = f92 + f98;
      float f104 = f101 + f88;
      float f105 = -0.89716756F * f101;
      float f106 = 0.9951847F * f104;
      float f107 = 1.0932019F * f88;
      float f108 = f105 + f106;
      float f109 = f107 - f106;
      float f110 = f90 - f103;
      float f111 = -0.66665566F * f103;
      float f112 = 0.95694035F * f110;
      float f113 = 1.247225F * f90;
      float f114 = f112 - f111;
      float f115 = f113 - f112;
      float f116 = f102 + f89;
      float f117 = -0.41052452F * f102;
      float f118 = 0.8819213F * f116;
      float f119 = 1.353318F * f89;
      float f120 = f117 + f118;
      float f121 = f119 - f118;
      float f122 = f87 - f100;
      float f123 = -0.13861717F * f100;
      float f124 = 0.77301043F * f122;
      float f125 = 1.4074037F * f87;
      float f126 = f124 - f123;
      float f127 = f125 - f124;
      float f128 = f65 - f108;
      float f129 = f65 + f108;
      float f130 = f67 - f114;
      float f131 = f67 + f114;
      float f132 = f69 - f120;
      float f133 = f69 + f120;
      float f134 = f71 - f126;
      float f135 = f71 + f126;
      float f136 = f70 - f127;
      float f137 = f70 + f127;
      float f138 = f68 - f121;
      float f139 = f68 + f121;
      float f140 = f66 - f115;
      float f141 = f66 + f115;
      float f142 = f64 - f109;
      float f143 = f64 + f109;
      float f144 = f0 + f30;
      float f145 = 1.0478631F * f0;
      float f146 = -0.99879545F * f144;
      float f147 = -0.9497278F * f30;
      float f148 = f145 + f146;
      float f149 = f147 - f146;
      float f150 = f4 + f26;
      float f151 = 1.2130114F * f4;
      float f152 = -0.97003126F * f150;
      float f153 = -0.7270511F * f26;
      float f154 = f151 + f152;
      float f155 = f153 - f152;
      float f156 = f8 + f22;
      float f157 = 1.3315444F * f8;
      float f158 = -0.9039893F * f156;
      float f159 = -0.4764342F * f22;
      float f160 = f157 + f158;
      float f161 = f159 - f158;
      float f162 = f12 + f18;
      float f163 = 1.3989068F * f12;
      float f164 = -0.8032075F * f162;
      float f165 = -0.20750822F * f18;
      float f166 = f163 + f164;
      float f167 = f165 - f164;
      float f168 = f16 + f14;
      float f169 = 1.41251F * f16;
      float f170 = -0.671559F * f168;
      float f171 = 0.06939217F * f14;
      float f172 = f169 + f170;
      float f173 = f171 - f170;
      float f174 = f20 + f10;
      float f175 = 1.3718313F * f20;
      float f176 = -0.51410276F * f174;
      float f177 = 0.34362587F * f10;
      float f178 = f175 + f176;
      float f179 = f177 - f176;
      float f180 = f24 + f6;
      float f181 = 1.2784339F * f24;
      float f182 = -0.33688986F * f180;
      float f183 = 0.6046542F * f6;
      float f184 = f181 + f182;
      float f185 = f183 - f182;
      float f186 = f28 + f2;
      float f187 = 1.1359069F * f28;
      float f188 = -0.14673047F * f186;
      float f189 = 0.842446F * f2;
      float f190 = f187 + f188;
      float f191 = f189 - f188;
      float f192 = f149 - f173;
      float f193 = f149 + f173;
      float f194 = f148 - f172;
      float f195 = f148 + f172;
      float f196 = f155 - f179;
      float f197 = f155 + f179;
      float f198 = f154 - f178;
      float f199 = f154 + f178;
      float f200 = f161 - f185;
      float f201 = f161 + f185;
      float f202 = f160 - f184;
      float f203 = f160 + f184;
      float f204 = f167 - f191;
      float f205 = f167 + f191;
      float f206 = f166 - f190;
      float f207 = f166 + f190;
      float f208 = f192 + f194;
      float f209 = 1.1758755F * f192;
      float f210 = -0.98078525F * f208;
      float f211 = -0.78569496F * f194;
      float f212 = f209 + f210;
      float f213 = f211 - f210;
      float f214 = f196 + f198;
      float f215 = 1.3870399F * f196;
      float f216 = -0.55557024F * f214;
      float f217 = 0.27589938F * f198;
      float f218 = f215 + f216;
      float f219 = f217 - f216;
      float f220 = f200 + f202;
      float f221 = 0.78569496F * f200;
      float f222 = 0.19509032F * f220;
      float f223 = 1.1758755F * f202;
      float f224 = f221 + f222;
      float f225 = f223 - f222;
      float f226 = f204 + f206;
      float f227 = -0.27589938F * f204;
      float f228 = 0.8314696F * f226;
      float f229 = 1.3870399F * f206;
      float f230 = f227 + f228;
      float f231 = f229 - f228;
      float f232 = f193 - f201;
      float f233 = f193 + f201;
      float f234 = f195 - f203;
      float f235 = f195 + f203;
      float f236 = f197 - f205;
      float f237 = f197 + f205;
      float f238 = f199 - f207;
      float f239 = f199 + f207;
      float f240 = f213 - f225;
      float f241 = f213 + f225;
      float f242 = f212 - f224;
      float f243 = f212 + f224;
      float f244 = f219 - f231;
      float f245 = f219 + f231;
      float f246 = f218 - f230;
      float f247 = f218 + f230;
      float f248 = f232 + f234;
      float f249 = 1.306563F * f232;
      float f250 = -0.9238795F * f248;
      float f251 = -0.5411961F * f234;
      float f252 = f249 + f250;
      float f253 = f251 - f250;
      float f254 = f236 + f238;
      float f255 = 0.5411961F * f236;
      float f256 = 0.38268343F * f254;
      float f257 = 1.306563F * f238;
      float f258 = f255 + f256;
      float f259 = f257 - f256;
      float f260 = f240 + f242;
      float f261 = 1.306563F * f240;
      float f262 = -0.9238795F * f260;
      float f263 = -0.5411961F * f242;
      float f264 = f261 + f262;
      float f265 = f263 - f262;
      float f266 = f244 + f246;
      float f267 = 0.5411961F * f244;
      float f268 = 0.38268343F * f266;
      float f269 = 1.306563F * f246;
      float f270 = f267 + f268;
      float f271 = f269 - f268;
      float f272 = f233 - f237;
      float f273 = f233 + f237;
      float f274 = f235 - f239;
      float f275 = f235 + f239;
      float f276 = f253 - f259;
      float f277 = f253 + f259;
      float f278 = f252 - f258;
      float f279 = f252 + f258;
      float f280 = f241 - f245;
      float f281 = f241 + f245;
      float f282 = f243 - f247;
      float f283 = f243 + f247;
      float f284 = f265 - f271;
      float f285 = f265 + f271;
      float f286 = f264 - f270;
      float f287 = f264 + f270;
      float f288 = f272 - f274;
      float f289 = f272 + f274;
      float f290 = 0.70710677F * f288;
      float f291 = 0.70710677F * f289;
      float f292 = f276 - f278;
      float f293 = f276 + f278;
      float f294 = 0.70710677F * f292;
      float f295 = 0.70710677F * f293;
      float f296 = f280 - f282;
      float f297 = f280 + f282;
      float f298 = 0.70710677F * f296;
      float f299 = 0.70710677F * f297;
      float f300 = f284 - f286;
      float f301 = f284 + f286;
      float f302 = 0.70710677F * f300;
      float f303 = 0.70710677F * f301;
      float f304 = f129 - f273;
      float f305 = f129 + f273;
      float f306 = f131 - f281;
      float f307 = f131 + f281;
      float f308 = f133 - f285;
      float f309 = f133 + f285;
      float f310 = f135 - f277;
      float f311 = f135 + f277;
      float f312 = f137 - f295;
      float f313 = f137 + f295;
      float f314 = f139 - f303;
      float f315 = f139 + f303;
      float f316 = f141 - f299;
      float f317 = f141 + f299;
      float f318 = f143 - f291;
      float f319 = f143 + f291;
      float f320 = f142 - f290;
      float f321 = f142 + f290;
      float f322 = f140 - f298;
      float f323 = f140 + f298;
      float f324 = f138 - f302;
      float f325 = f138 + f302;
      float f326 = f136 - f294;
      float f327 = f136 + f294;
      float f328 = f134 - f279;
      float f329 = f134 + f279;
      float f330 = f132 - f287;
      float f331 = f132 + f287;
      float f332 = f130 - f283;
      float f333 = f130 + f283;
      float f334 = f128 - f275;
      float f335 = f128 + f275;
      y[31] = 0.5001506F * f305;
      y[30] = 0.50135845F * f307;
      y[29] = 0.5037887F * f309;
      y[28] = 0.50747114F * f311;
      y[27] = 0.51245147F * f313;
      y[26] = 0.5187927F * f315;
      y[25] = 0.5265773F * f317;
      y[24] = 0.53590983F * f319;
      y[23] = 0.5469204F * f321;
      y[22] = 0.5597698F * f323;
      y[21] = 0.5746552F * f325;
      y[20] = 0.5918185F * f327;
      y[19] = 0.61155736F * f329;
      y[18] = 0.63423896F * f331;
      y[17] = 0.6603198F * f333;
      y[16] = 0.6903721F * f335;
      y[15] = 0.72512054F * f334;
      y[14] = 0.76549417F * f332;
      y[13] = 0.8127021F * f330;
      y[12] = 0.8683447F * f328;
      y[11] = 0.9345836F * f326;
      y[10] = 1.0144082F * f324;
      y[9] = 1.1120716F * f322;
      y[8] = 1.2338327F * f320;
      y[7] = 1.3892939F * f318;
      y[6] = 1.5939723F * f316;
      y[5] = 1.874676F * f314;
      y[4] = 2.2820501F * f312;
      y[3] = 2.9246285F * f310;
      y[2] = 4.084611F * f308;
      y[1] = 6.7967505F * f306;
      y[0] = 20.373878F * f304;
   }
}
