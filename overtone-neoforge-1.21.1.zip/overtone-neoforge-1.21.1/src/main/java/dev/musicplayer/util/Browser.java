package dev.musicplayer.util;

import dev.musicplayer.MusicPlayerMod;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public final class Browser {
   private Browser() {
   }

   public static void open(String url) {
      if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
         if (!launch(url, "rundll32", "url.dll,FileProtocolHandler")) {
            copyToClipboard(url);
         }
      }
   }

   /** No browser to launch (e.g. Android launchers): put the link on the clipboard and tell the player. */
   private static void copyToClipboard(String url) {
      try {
         net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
         mc.execute(() -> {
            mc.keyboardHandler.setClipboard(url);
            net.minecraft.client.gui.components.toasts.SystemToast.addOrUpdate(
               mc.getToasts(),
               net.minecraft.client.gui.components.toasts.SystemToast.SystemToastId.PERIODIC_NOTIFICATION,
               net.minecraft.network.chat.Component.literal("Overtone"),
               net.minecraft.network.chat.Component.literal(dev.musicplayer.util.T.get("link.copied")));
         });
      } catch (Throwable t) {
         MusicPlayerMod.LOGGER.warn("Could not copy {} to the clipboard", url, t);
      }
   }

   public static boolean openFolder(Path dir) {
      if (dir == null) {
         return false;
      } else {
         Path abs = dir.toAbsolutePath().normalize();
         if (!Files.isDirectory(abs)) {
            return false;
         } else {
            String os = System.getProperty("os.name", "").toLowerCase();
            if (os.contains("win") && launch(abs.toString(), "rundll32", "url.dll,FileProtocolHandler")) {
               return true;
            } else {
               return os.contains("win") ? launch(abs.toString(), "explorer") : launch(abs.toString());
            }
         }
      }
   }

   private static boolean launch(String target, String... windowsCommand) {
      try {
         String os = System.getProperty("os.name", "").toLowerCase();
         if (os.contains("win") && windowsCommand.length > 0) {
            String[] cmd = Arrays.copyOf(windowsCommand, windowsCommand.length + 1);
            cmd[cmd.length - 1] = target;
            new ProcessBuilder(cmd).start();
         } else if (os.contains("mac")) {
            new ProcessBuilder("open", target).start();
         } else {
            new ProcessBuilder("xdg-open", target).start();
         }

         return true;
      } catch (Exception var4) {
         MusicPlayerMod.LOGGER.warn("Could not open {}", target, var4);
         return false;
      }
   }
}
