package dev.musicplayer.util;

import java.util.regex.Pattern;

public final class TrackNames {
   private static final Pattern NOISE = Pattern.compile(
      "\\s*[(\\[]\\s*(official|lyric|lyrics|audio|video|music video|visuali[sz]er|hd|hq|4k|clip|\u043a\u043b\u0438\u043f|\u043f\u0440\u0435\u043c\u044c\u0435\u0440\u0430|\u0442\u0435\u043a\u0441\u0442)[^)\\]]*[)\\]]",
      66
   );

   private TrackNames() {
   }

   public static TrackNames.Parsed split(String rawTitle, String uploader) {
      String title = NOISE.matcher(rawTitle == null ? "" : rawTitle).replaceAll("").trim();
      String artist = cleanUploader(uploader);

      for (String sep : new String[]{" - ", " \u2013 ", " \u2014 "}) {
         int i = title.indexOf(sep);
         if (i > 0 && i <= 60 && i + sep.length() < title.length()) {
            return new TrackNames.Parsed(title.substring(0, i).trim(), title.substring(i + sep.length()).trim());
         }
      }

      return new TrackNames.Parsed(artist, title);
   }

   public static String cleanUploader(String name) {
      if (name == null) {
         return "";
      } else {
         String s = name.trim();
         if (s.endsWith(" - Topic")) {
            s = s.substring(0, s.length() - " - Topic".length());
         }

         if (s.length() > 4 && s.toUpperCase().endsWith("VEVO")) {
            s = s.substring(0, s.length() - 4);
         }

         return s.trim();
      }
   }

   public record Parsed(String artist, String title) {
   }
}
