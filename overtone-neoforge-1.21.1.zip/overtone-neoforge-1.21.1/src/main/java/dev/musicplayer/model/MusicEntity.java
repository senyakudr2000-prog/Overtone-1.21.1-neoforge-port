package dev.musicplayer.model;

public record MusicEntity(MusicEntity.Kind kind, String id, String title, String subtitle, String coverUrl) {
   public static final MusicEntity MINE = new MusicEntity(MusicEntity.Kind.PLAYLIST, "mine", "", "", null);

   public boolean isMine() {
      return this == MINE;
   }

   public static enum Kind {
      ARTIST,
      ALBUM,
      PLAYLIST,
      STATION;

      private Kind() {
      }
   }
}
