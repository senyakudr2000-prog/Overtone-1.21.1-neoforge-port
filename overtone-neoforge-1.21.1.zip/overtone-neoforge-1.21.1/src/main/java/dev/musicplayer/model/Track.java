package dev.musicplayer.model;

public record Track(String id, String title, String artist, String album, long durationMs, String coverUrl, String provider) {
}
