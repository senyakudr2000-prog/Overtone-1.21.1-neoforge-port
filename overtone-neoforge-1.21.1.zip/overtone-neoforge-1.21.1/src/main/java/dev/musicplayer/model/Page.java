package dev.musicplayer.model;

import java.util.List;

public record Page(MusicEntity source, List<Track> tracks, List<MusicEntity> entities) {
}
