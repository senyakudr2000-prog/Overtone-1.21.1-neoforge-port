package dev.musicplayer.model;

import java.util.List;

public record LyricLine(long timeMs, String text, List<LyricLine.Word> words) {
   public static final long UNSYNCED = Long.MAX_VALUE;

   public LyricLine(long timeMs, String text) {
      this(timeMs, text, null);
   }

   public boolean hasWordTimings() {
      return this.words != null && !this.words.isEmpty();
   }

   public record Word(long timeMs, String text) {
   }
}
