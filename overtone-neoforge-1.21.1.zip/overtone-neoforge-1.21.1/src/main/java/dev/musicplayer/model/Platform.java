package dev.musicplayer.model;

import dev.musicplayer.util.T;

public enum Platform {
   YANDEX("yandex", 16763904, true),
   SOUNDCLOUD("soundcloud", 16733440, false),
   LOCAL("local", 3462041, false),
   SPOTIFY("spotify", 1947988, true);

   public final String id;
   public final int rgb;
   public final boolean needsLogin;

   private Platform(String id, int rgb, boolean needsLogin) {
      this.id = id;
      this.rgb = rgb;
      this.needsLogin = needsLogin;
   }

   public String title() {
      return T.get("platform." + this.id);
   }

   public static Platform byId(String id) {
      Platform p = byIdOrNull(id);
      return p != null ? p : YANDEX;
   }

   public static Platform byIdOrNull(String id) {
      for (Platform p : values()) {
         if (p.id.equals(id)) {
            return p;
         }
      }

      return null;
   }
}
